from __future__ import annotations
from gste.version import VERSION
import argparse, json, math
from collections import defaultdict
from pathlib import Path
import xml.etree.ElementTree as ET

STEP_PC = {'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
PC_NAME = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B']

def _load(p):
    with open(p, 'r', encoding='utf-8') as f: return json.load(f)

def _dump(p, obj):
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, 'w', encoding='utf-8') as f: json.dump(obj, f, ensure_ascii=False, indent=2)

def _midi(note):
    pitch=note.find('pitch')
    if pitch is None: return None
    step=pitch.findtext('step'); octv=pitch.findtext('octave')
    if step is None or octv is None: return None
    alt=int(float(pitch.findtext('alter') or 0))
    return 12*(int(octv)+1)+STEP_PC[step]+alt

def _pitch_name(m):
    return f'{PC_NAME[m%12]}{m//12-1}'

def _measure_notes(xml_path, voice=None):
    root=ET.parse(xml_path).getroot(); out=[]
    current_div=1
    for meas in root.iter('measure'):
        try: mn=int(meas.get('number','0'))
        except: continue
        attr=meas.find('attributes')
        if attr is not None and attr.findtext('divisions'):
            current_div=max(1,int(float(attr.findtext('divisions'))))
        cur=0; last_on=0; idx=0
        for el in list(meas):
            tag=el.tag.split('}')[-1]
            if tag=='backup':
                cur -= int(float(el.findtext('duration') or 0)); continue
            if tag=='forward':
                cur += int(float(el.findtext('duration') or 0)); continue
            if tag!='note': continue
            dur=int(float(el.findtext('duration') or 0))
            chord=el.find('chord') is not None; grace=el.find('grace') is not None
            on=last_on if chord else cur
            if voice is not None and el.findtext('voice') != str(voice):
                if not chord and not grace:
                    last_on=on; cur += dur
                continue
            m=_midi(el)
            if m is not None:
                idx += 1
                out.append({'measure':mn,'index':idx,'midi':m,'pitch':_pitch_name(m),
                            'duration_ticks':dur,'duration_quarters':round(dur/current_div,6),
                            'onset_ticks':on,'onset_quarters':round(on/current_div,6),
                            'grace':grace})
            if not chord and not grace:
                last_on=on; cur += dur
    return out

def end_to_end_melody_audit(root: Path):
    src=root/'01_input'/'normalized_input.musicxml'
    final=root/'05_final'/'final_tab.musicxml'
    old=root/'04_register_search'/'existing_core'/'debug'/'19_MELODY_TIMELINE_INTEGRITY.json'
    expected_shift=0
    if old.exists():
        try: expected_shift=int(_load(old).get('expected_pitch_shift',0))
        except: expected_shift=0
    s=[x for x in _measure_notes(src, voice=1) if not x['grace']]
    f=[x for x in _measure_notes(final, voice=1) if not x['grace']]
    sb=defaultdict(list); fb=defaultdict(list)
    for x in s: sb[x['measure']].append(x)
    for x in f: fb[x['measure']].append(x)
    issues=[]; legal=0
    for m in sorted(set(sb)|set(fb)):
        a,b=sb[m],fb[m]
        if len(a)!=len(b):
            issues.append({'severity':'FAIL','type':'EVENT_COUNT_MISMATCH','measure':m,
                           'source_count':len(a),'final_count':len(b)})
        for i,(x,y) in enumerate(zip(a,b),1):
            delta=y['midi']-x['midi']
            pitch_ok=(delta==expected_shift)
            rhythm_ok=(abs(float(x.get('onset_quarters',0))-float(y.get('onset_quarters',0))) <= 1e-6
                       and abs(float(x.get('duration_quarters',0))-float(y.get('duration_quarters',0))) <= 1e-6)
            if pitch_ok and rhythm_ok:
                legal += 1; continue
            if not pitch_ok:
                issues.append({'severity':'FAIL','type':'UNEXPECTED_PITCH_SHIFT','measure':m,'event_index':i,
                               'source_pitch':x['pitch'],'final_pitch':y['pitch'],'actual_shift':delta,
                               'expected_shift':expected_shift,'deviation_from_expected':delta-expected_shift})
            if not rhythm_ok:
                issues.append({'severity':'FAIL','type':'UNEXPECTED_MELODY_RHYTHM_CHANGE','measure':m,'event_index':i,
                               'source_onset_quarters':x.get('onset_quarters'),'final_onset_quarters':y.get('onset_quarters'),
                               'source_duration_quarters':x.get('duration_quarters'),'final_duration_quarters':y.get('duration_quarters')})
    # contiguous measure regions for concise review
    bad_measures=sorted({x['measure'] for x in issues})
    regions=[]
    for m in bad_measures:
        if not regions or m>regions[-1][-1]+1: regions.append([m])
        else: regions[-1].append(m)
    return {'version':VERSION,'status':'PASS' if not issues else 'FAIL','expected_pitch_shift':expected_shift,
            'comparison':'NORMALIZED_INPUT_VOICE1 -> FINAL_SERIALIZED_VOICE1',
            'source_event_count':len(s),'final_event_count':len(f),'legal_expected_shift_count':legal,
            'issue_count':len(issues),'issues':issues,
            'bad_measure_regions':[{'start_measure':r[0],'end_measure':r[-1]} for r in regions],
            'rule':'Melody pitch identity and measure-local onset/duration are evaluated against the normalized input. Declared global/register shift is the only allowed pitch change.'}

def _final_voice_onsets(xml_path: Path, voice='2'):
    root=ET.parse(xml_path).getroot(); result=defaultdict(list)
    current_div=1
    for meas in root.iter('measure'):
        try: mn=int(meas.get('number','0'))
        except: continue
        attr=meas.find('attributes')
        if attr is not None and attr.findtext('divisions'): current_div=int(attr.findtext('divisions'))
        cur=0; last_on=0
        for el in list(meas):
            tag=el.tag.split('}')[-1]
            if tag=='note':
                dur=int(el.findtext('duration') or 0); chord=el.find('chord') is not None
                on=last_on if chord else cur
                if el.findtext('voice')==str(voice) and _midi(el) is not None:
                    result[mn].append({'phase':on/current_div,'midi':_midi(el)})
                if not chord: last_on=on; cur += dur
            elif tag=='backup': cur -= int(el.findtext('duration') or 0)
            elif tag=='forward': cur += int(el.findtext('duration') or 0)
    return result

def rhythm_musical_phase_audit(root: Path):
    arr=_load(root/'02_auto_arrangement'/'accompaniment_events.json')
    final_onsets=_final_voice_onsets(root/'05_final'/'final_tab.musicxml', voice='2')
    issues=[]; advisories=[]
    windows=[]
    for w in arr:
        wid=w.get('window_id','')
        try: wi=int(wid.lstrip('W'))
        except: continue
        measure=(wi+1)//2; measure_start=(measure-1)*4.0
        windows.append((measure,w,measure_start))
        finals=[x['phase'] for x in final_onsets.get(measure,[])]
        for e in w.get('events',[]):
            phase=float(e.get('onset',0))-measure_start
            nearest_half=round(phase*2)/2
            off=abs(phase-nearest_half)
            if e.get('role') not in {'guide_tone','bass','chord_tone'} or not (0.08 <= off <= 0.22):
                continue
            survives=any(abs(fp-phase) <= 0.03 for fp in finals)
            row={'measure':measure,'window_id':wid,'role':e.get('role'),'absolute_onset':e.get('onset'),
                 'measure_phase':round(phase,3),'offset_from_half_beat':round(off,3),
                 'event_id':e.get('event_id'),'survives_to_final':survives}
            # 12.6.1 convergence: a template micro-offset is not a review item merely
            # because it exists pre-Joint. Promote only an exposed >=0.14q offset
            # that survives into the serialized score. Smaller/non-surviving shifts
            # remain available as low-priority evidence without flooding GPT review.
            if survives and off >= 0.14:
                issues.append({**row,'severity':'REVIEW','type':'EXPOSED_NON_MUSICAL_MICRO_PHASE',
                               'reason':'A structural >=0.14-quarter micro-offset survives into final voice 2 and is likely audible as late/early timing.'})
            else:
                advisories.append({**row,'severity':'ADVISORY','type':'TEMPLATE_MICRO_PHASE',
                                   'reason':'Pre-Joint micro-offset is retained for evidence but is not promoted unless materially exposed in the final score.'})
    # High-precision half-window coverage checks.
    by_measure=defaultdict(list)
    for measure,w,ms in windows: by_measure[measure].append((w,ms))
    for measure,pairs in sorted(by_measure.items()):
        finals=[x['phase'] for x in final_onsets.get(measure,[])]
        for w,ms in pairs:
            try: wi=int(w.get('window_id','W0')[1:]); half=0 if wi%2==1 else 1
            except: continue
            if not w.get('events'): continue
            lo,hi=(0.0,2.0) if half==0 else (2.0,4.001)
            if any(lo-1e-6 <= p < hi for p in finals): continue
            collapsed_second_half = (half == 0 and len(finals) >= 2 and min(finals) >= 1.5
                                     and max(finals) - min(finals) <= 1e-6)
            if collapsed_second_half:
                issues.append({'severity':'REVIEW','type':'FINAL_WINDOW_PHASE_COLLAPSE','measure':measure,
                               'window_id':w.get('window_id'),'expected_phase_range':[lo,hi],
                               'generated_event_count':len(w.get('events',[])),
                               'final_voice2_phases':[round(p,3) for p in finals],
                               'reason':'First-half accompaniment vanished while multiple surviving attacks collapsed onto one second-half metric point.'})
            # A generated two-event structural window that disappears while another
            # half survives is a stronger loss signal than ordinary texture thinning.
            elif len(w.get('events',[])) >= 2 and finals:
                issues.append({'severity':'REVIEW','type':'STRUCTURAL_WINDOW_COVERAGE_LOSS','measure':measure,
                               'window_id':w.get('window_id'),'expected_phase_range':[lo,hi],
                               'generated_event_count':len(w.get('events',[])),
                               'final_voice2_phases':[round(p,3) for p in finals],
                               'reason':'A multi-event accompaniment half-window disappeared from final serialization while other accompaniment remained in the measure.'})
    seen=set(); clean=[]
    for x in issues:
        k=(x['type'],x['measure'],x.get('window_id'),x.get('event_id'))
        if k not in seen: seen.add(k); clean.append(x)
    flagged=sorted({x['measure'] for x in clean})
    return {'version':VERSION,'status':'PASS' if not clean else 'REVIEW',
            'semantics':'HIGH-PRECISION MUSICAL PHASE + FINAL WINDOW COVERAGE; advisory only, no automatic arrangement edits.',
            'issue_count':len(clean),'flagged_measures':flagged,'issues':clean,
            'advisory_count':len(advisories),'advisories':advisories,
            'rules':{'micro_phase':'Promote only >=0.14-quarter structural offsets that survive within 0.03q in final voice 2; retain others as advisory evidence.',
                     'window_loss':'Promote phase collapse or disappearance of a multi-event half-window when accompaniment remains elsewhere in the measure.'}}

def chord_transition_audit(root: Path):
    prog=_load(root/'02_auto_arrangement'/'selected_progression.json')
    dis_path=root/'04_register_search'/'existing_core'/'debug'/'21_DISSONANCE_DIAGNOSTICS.json'
    dis=_load(dis_path) if dis_path.exists() else {'issues':[]}
    issues=[]; wrs=prog.get('window_results',[])
    for i,wr in enumerate(wrs):
        w=wr.get('window',{}); sel=wr.get('selected',{}); cands=wr.get('candidates',[])
        if not sel or not cands: continue
        m=w.get('measure_start'); beat=float(w.get('beat_start',0)); conf=float(wr.get('confidence',1.0))
        local=sorted(cands,key=lambda c: float(c.get('total_cost',9999)))
        best=local[0]; sel_cost=float(sel.get('total_cost',0)); best_cost=float(best.get('total_cost',0)); gap=sel_cost-best_cost
        margin=(float(local[1].get('total_cost',0))-best_cost) if len(local)>1 else 99.0
        prev_sel=wrs[i-1].get('selected',{}).get('chord_symbol') if i else None

        # A materially worse local choice is a precise progression-context warning.
        if gap >= 3.0:
            issues.append({'severity':'REVIEW','type':'GLOBAL_PATH_OVERRIDES_LOCAL_FIT','measure':m,'beat':beat,
                           'window_id':w.get('window_id'),'selected':sel.get('chord_symbol'),'local_best':best.get('chord_symbol'),
                           'cost_sacrifice':round(gap,3),'confidence':conf,
                           'reason':'Global progression selected a materially worse local chord; verify that voice-leading/cadential benefit is audible.'})

        # Very-low-confidence near tie: high precision; ordinary 0.70-ish ambiguity is not enough by itself.
        if conf < 0.68 and margin <= 1.5:
            issues.append({'severity':'REVIEW','type':'TRANSITION_AMBIGUITY','measure':m,'beat':beat,
                           'window_id':w.get('window_id'),'selected':sel.get('chord_symbol'),
                           'top_candidates':[c.get('chord_symbol') for c in local[:3]],'local_margin':round(margin,3),
                           'confidence':conf,'reason':'Harmony evidence is near-tied with very low confidence; neighboring chord context should decide.'})

        # Measure-start churn: selected chord breaks continuity even though keeping the previous chord is tied for local best.
        if beat <= 1.01 and sel.get('chord_symbol') != best.get('chord_symbol') and abs(gap) <= 0.2 \
           and prev_sel == best.get('chord_symbol') and conf <= 0.71:
            issues.append({'severity':'REVIEW','type':'UNNECESSARY_MEASURE_START_CHURN','measure':m,'beat':beat,
                           'window_id':w.get('window_id'),'previous':prev_sel,'selected':sel.get('chord_symbol'),
                           'continuity_candidate':best.get('chord_symbol'),'confidence':conf,
                           'reason':'At the measure opening, a tied local-best candidate would preserve the previous harmony but the path changes chord instead.'})

    # Reuse only HIGH/VERY_HIGH exposed collisions. Any beat may matter, but measure-start gets stronger wording.
    for d in dis.get('issues',[]):
        if d.get('severity') not in {'HIGH','VERY_HIGH'}: continue
        m=d.get('measure'); beat=float(d.get('beat_quarters',99))
        issues.append({'severity':d.get('severity'),'type':'EXPOSED_FINAL_VOICING_COLLISION','measure':m,'beat':beat,
                       'issue_id':d.get('issue_id'),'interval':d.get('interval'),'cause':d.get('cause'),
                       'reason':'High-severity final voicing collision can make a legal chord/transition sound wrong.'})
    seen=set(); clean=[]
    for x in issues:
        k=(x['type'],x.get('measure'),x.get('window_id'),x.get('issue_id'))
        if k not in seen: seen.add(k); clean.append(x)
    clean.sort(key=lambda x:(x.get('measure',9999),x.get('beat',0),x['type']))
    return {'version':VERSION,'status':'PASS' if not clean else 'REVIEW','issue_count':len(clean),
            'flagged_measures':sorted({x['measure'] for x in clean if x.get('measure') is not None}),
            'issues':clean,
            'semantics':'High-precision progression-context advisory. Does not automatically replace chords.'}

def build_packet(mel, rhy, cho):
    q=[]
    for x in mel['issues']:
        q.append({'priority':100,'category':'MELODY_END_TO_END','measure':x.get('measure'),'summary':x['type'],'detail':x})
    for x in rhy['issues']:
        q.append({'priority':85,'category':'RHYTHM_MUSICAL_PHASE','measure':x.get('measure'),'summary':x['type'],'detail':x})
    for x in cho['issues']:
        q.append({'priority':70 if x['severity']=='REVIEW' else 80,'category':'CHORD_TRANSITION','measure':x.get('measure'),'summary':x['type'],'detail':x})
    q.sort(key=lambda x:(-x['priority'],x.get('measure') or 9999))
    return {'version':VERSION,'freeze_candidate': mel['status']=='PASS',
            'headline':{'end_to_end_melody_status':mel['status'],'rhythm_phase_status':rhy['status'],'chord_transition_status':cho['status'],
                        'melody_issue_count':mel['issue_count'],'rhythm_issue_count':rhy['issue_count'],'chord_issue_count':cho['issue_count']},
            'review_queue':q,
            'freeze_rule':'Diagnostics may be frozen after the end-to-end melody audit is logically validated and known human rhythm/harmony defects appear in this queue without song-specific rules.'}

def write_markdown(out: Path, mel, rhy, cho, packet):
    def ms(xs): return ', '.join(f'M{x}' for x in xs) if xs else 'None'
    lines=[f'# {VERSION} Diagnostics Freeze Audit','',
           '## 1. End-to-End Melody Audit',f"- Status: **{mel['status']}**",f"- Issues: {mel['issue_count']}",
           f"- Bad regions: {mel['bad_measure_regions']}",'',
           '## 2. Rhythm Musical-Phase Audit',f"- Status: **{rhy['status']}**",f"- Flagged measures: {ms(rhy['flagged_measures'])}",'',
           '## 3. Chord Transition Audit',f"- Status: **{cho['status']}**",f"- Flagged measures: {ms(cho['flagged_measures'])}",'',
           '## Freeze decision',
           '- This patch intentionally reports evidence only; it does not alter arrangement, piano path, fingering, or export behavior.',
           '- Freeze diagnostics only after a fresh conversion confirms the known human-review locations are surfaced and no false PASS is emitted for melody identity.']
    out.write_text('\n'.join(lines),encoding='utf-8')

def run(root: Path):
    dbg=root/'04_register_search'/'existing_core'/'debug'; core=root/'04_register_search'/'existing_core'
    mel=end_to_end_melody_audit(root); rhy=rhythm_musical_phase_audit(root); cho=chord_transition_audit(root); pkt=build_packet(mel,rhy,cho)
    _dump(dbg/'23_END_TO_END_MELODY_AUDIT.json',mel)
    _dump(dbg/'24_RHYTHM_MUSICAL_PHASE.json',rhy)
    _dump(dbg/'25_CHORD_TRANSITION_ANOMALY.json',cho)
    _dump(dbg/'26_DIAGNOSTICS_FREEZE_PACKET.json',pkt)
    write_markdown(core/'13_DIAGNOSTICS_FREEZE_AUDIT.md',mel,rhy,cho,pkt)
    return mel,rhy,cho,pkt

def main():
    ap=argparse.ArgumentParser(description='GSTE integrated diagnostics freeze audit')
    ap.add_argument('output_root',type=Path,help='Converted song output root containing 01_input/..05_final')
    args=ap.parse_args(); mel,rhy,cho,pkt=run(args.output_root)
    print(json.dumps(pkt['headline'],ensure_ascii=False,indent=2))
if __name__=='__main__': main()
