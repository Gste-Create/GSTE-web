from __future__ import annotations

from gste.version import VERSION
from collections import defaultdict
from copy import deepcopy
import json
from pathlib import Path
import xml.dom.minidom as minidom
import xml.etree.ElementTree as ET

STEP_PC = {"C":0,"D":2,"E":4,"F":5,"G":7,"A":9,"B":11}
PC_NAME = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"]
QUALITY_KIND = {
    "major":"major", "minor":"minor", "dominant":"dominant", "dominant-seventh":"dominant",
    "major-seventh":"major-seventh", "minor-seventh":"minor-seventh", "diminished":"diminished",
    "diminished-seventh":"diminished-seventh", "half-diminished":"half-diminished", "augmented":"augmented",
    "sus2":"suspended-second", "sus4":"suspended-fourth",
}


def _load(path: Path, default=None):
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _dump(path: Path, value) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def _strip_ns(root: ET.Element) -> None:
    for el in root.iter():
        if "}" in el.tag:
            el.tag = el.tag.split("}", 1)[1]


def _midi(note: ET.Element):
    p = note.find("pitch")
    if p is None: return None
    step = p.findtext("step"); octv = p.findtext("octave")
    if step is None or octv is None: return None
    return 12 * (int(octv) + 1) + STEP_PC[step] + int(float(p.findtext("alter") or 0))


def _name(midi: int) -> str:
    return f"{PC_NAME[midi % 12]}{midi // 12 - 1}"


def _note_inventory(xml_path: Path) -> dict[int, list[dict]]:
    if not xml_path.exists(): return {}
    root = ET.parse(xml_path).getroot(); _strip_ns(root)
    part = root.find("part")
    if part is None: return {}
    divisions=1; beats=4; beat_type=4; abs_start=0.0
    out=defaultdict(list)
    for idx, meas in enumerate(part.findall("measure"), start=1):
        try: mn=int(meas.get("number", idx))
        except: mn=idx
        attr=meas.find("attributes")
        if attr is not None:
            if attr.findtext("divisions"): divisions=max(1,int(float(attr.findtext("divisions"))))
            time=attr.find("time")
            if time is not None:
                beats=int(time.findtext("beats", beats)); beat_type=int(time.findtext("beat-type", beat_type))
        measure_q=beats*4.0/beat_type
        cur=0; last_on=0
        for el in list(meas):
            tag=el.tag
            if tag=="note":
                chord=el.find("chord") is not None
                dur=int(float(el.findtext("duration") or 0))
                on=last_on if chord else cur
                m=_midi(el)
                if m is not None:
                    role="accompaniment" if el.findtext("voice") == "2" else "melody"
                    out[mn].append({"beat":round(on/divisions,6),"absolute_onset":round(abs_start+on/divisions,6),
                                    "duration_quarters":round(dur/divisions,6),"voice":el.findtext("voice"),
                                    "role":role,"midi":m,"pitch":_name(m)})
                if not chord:
                    last_on=on; cur += dur
            elif tag=="backup": cur -= int(float(el.findtext("duration") or 0))
            elif tag=="forward": cur += int(float(el.findtext("duration") or 0))
        abs_start += measure_q
    return dict(out)


def _chord_symbol(selected: dict) -> str:
    if selected.get("chord_symbol"): return str(selected["chord_symbol"])
    root = selected.get("root_pitch_class")
    if root is None: return "?"
    r = PC_NAME[int(root)%12]
    q = str(selected.get("quality", "major"))
    suffix={"major":"","minor":"m","dominant":"7","minor-seventh":"m7","major-seventh":"maj7",
            "diminished":"dim","half-diminished":"m7b5","augmented":"aug","sus2":"sus2","sus4":"sus4"}.get(q,q)
    return r+suffix


def _progression_windows(root: Path) -> list[dict]:
    prog=_load(root/"02_auto_arrangement"/"selected_progression.json", {}) or {}
    rows=[]
    for wr in prog.get("window_results", []):
        w=wr.get("window",{}); sel=wr.get("selected",{})
        if not sel: continue
        rows.append({"measure":w.get("measure_start"),"beat":float(w.get("beat_start",0) or 0),
                     "window_id":w.get("window_id"),"symbol":_chord_symbol(sel),"selected":sel,
                     "confidence":wr.get("confidence"),"candidates":wr.get("candidates",[])})
    return rows


def _harmony_element(symbol_row: dict, divisions: int) -> ET.Element:
    sel=symbol_row.get("selected",{})
    h=ET.Element("harmony")
    root=ET.SubElement(h,"root")
    pc=int(sel.get("root_pitch_class",0))%12
    spelling=[("C",0),("C",1),("D",0),("E",-1),("E",0),("F",0),("F",1),("G",0),("A",-1),("A",0),("B",-1),("B",0)][pc]
    ET.SubElement(root,"root-step").text=spelling[0]
    if spelling[1]: ET.SubElement(root,"root-alter").text=str(spelling[1])
    kind=ET.SubElement(h,"kind")
    quality=str(sel.get("quality","major"))
    kind.text=QUALITY_KIND.get(quality, quality if quality else "major")
    kind.set("text", symbol_row.get("symbol") or _chord_symbol(sel))
    # selected_progression beat_start is human/score style (Beat 1 == measure start).
    # MusicXML harmony/offset is zero-based from the measure start.
    beat=float(symbol_row.get("beat",1) or 1)
    offset_q=max(0.0, beat - 1.0)
    if offset_q:
        ET.SubElement(h,"offset").text=str(int(round(offset_q*divisions)))
    return h


def _add_harmonies(part: ET.Element, windows: list[dict]) -> None:
    by=defaultdict(list)
    for row in windows:
        try: by[int(row["measure"])].append(row)
        except: pass
    divisions=1
    for idx, meas in enumerate(part.findall("measure"), start=1):
        attr=meas.find("attributes")
        if attr is not None and attr.findtext("divisions"):
            divisions=max(1,int(float(attr.findtext("divisions"))))
        try: mn=int(meas.get("number",idx))
        except: mn=idx
        for old in list(meas.findall("harmony")): meas.remove(old)
        insert_at=0
        if meas.find("attributes") is not None: insert_at=1
        for row in sorted(by.get(mn,[]), key=lambda r:r.get("beat",0)):
            meas.insert(insert_at,_harmony_element(row,divisions)); insert_at += 1


def _key_fifths(part: ET.Element) -> int:
    for measure in part.findall("measure"):
        attr=measure.find("attributes")
        if attr is None:
            continue
        key=attr.find("key")
        if key is not None and key.findtext("fifths") is not None:
            try:
                return int(float(key.findtext("fifths")))
            except Exception:
                return 0
    return 0


def _respell_pitch(pitch: ET.Element, prefer_flats: bool) -> None:
    step=pitch.findtext("step"); octv=pitch.findtext("octave")
    if step is None or octv is None:
        return
    alter=int(float(pitch.findtext("alter") or 0))
    midi=12*(int(octv)+1)+STEP_PC[step]+alter
    # Keep spellings deliberately simple and key-aware.  This removes D#/G#/A#
    # clutter in flat keys such as Ab major while preserving exact MIDI pitch.
    if prefer_flats:
        spell=[("C",0),("D",-1),("D",0),("E",-1),("E",0),("F",0),
               ("G",-1),("G",0),("A",-1),("A",0),("B",-1),("B",0)][midi%12]
    else:
        spell=[("C",0),("C",1),("D",0),("D",1),("E",0),("F",0),
               ("F",1),("G",0),("G",1),("A",0),("A",1),("B",0)][midi%12]
    new_step,new_alter=spell
    pitch.find("step").text=new_step
    a=pitch.find("alter")
    if new_alter:
        if a is None:
            a=ET.Element("alter")
            # alter belongs between step and octave.
            pitch.insert(1,a)
        a.text=str(new_alter)
    elif a is not None:
        pitch.remove(a)
    # For these canonical sharp/flat spellings octave remains MIDI-derived.
    pitch.find("octave").text=str(midi//12-1)


def _standardize_part(part: ET.Element) -> None:
    fifths=_key_fifths(part)
    prefer_flats=fifths < 0
    for measure in part.findall("measure"):
        attr=measure.find("attributes")
        if attr is not None:
            clef=attr.find("clef")
            if clef is None: clef=ET.SubElement(attr,"clef")
            for c in list(clef): clef.remove(c)
            ET.SubElement(clef,"sign").text="G"
            ET.SubElement(clef,"line").text="2"
            # Classical guitar convention: written one octave above sounding pitch.
            # MusicXML represents this with an octave-transposing treble clef; note
            # pitch values themselves remain untouched for identity/playback checks.
            ET.SubElement(clef,"clef-octave-change").text="-1"
            details=attr.find("staff-details")
            if details is not None: attr.remove(details)
        for note in measure.findall("note"):
            pitch=note.find("pitch")
            if pitch is not None:
                _respell_pitch(pitch, prefer_flats)
            notations=note.find("notations")
            if notations is not None:
                tech=notations.find("technical")
                if tech is not None:
                    # Standard staff should not display TAB fingering/string mechanics.
                    notations.remove(tech)
                for other in list(notations.findall("other-notation")):
                    if other.get("type"," ").startswith("gste-"): notations.remove(other)
                if len(notations)==0: note.remove(notations)


def _part_list(score: ET.Element, entries: list[tuple[str,str]]) -> None:
    old=score.find("part-list")
    if old is not None: score.remove(old)
    pl=ET.Element("part-list")
    insert=0
    work=score.find("work")
    if work is not None: insert=list(score).index(work)+1
    score.insert(insert,pl)
    for pid,name in entries:
        sp=ET.SubElement(pl,"score-part",id=pid); ET.SubElement(sp,"part-name").text=name


def write_final_diagnostic_score(root: Path) -> Path | None:
    validation_candidates=[root/"05_final"/"05_FINAL_SOUNDING_HAND_VALIDATION.json",root/"04_register_search"/"existing_core"/"05_FINAL_SOUNDING_HAND_VALIDATION.json",root/"05_FINAL_SOUNDING_HAND_VALIDATION.json"]
    validation=next((p for p in validation_candidates if p.exists()),None)
    if validation is None: return None
    try:
        if json.loads(validation.read_text(encoding="utf-8")).get("status")!="PASS": return None
    except Exception: return None
    src=root/"05_final"/"final_tab.musicxml"
    if not src.exists(): return None
    score=ET.parse(src).getroot(); _strip_ns(score)
    original=score.find("part")
    if original is None: return None
    tab=deepcopy(original); tab.set("id","P2")
    standard=deepcopy(original); standard.set("id","P1"); _standardize_part(standard)
    windows=_progression_windows(root); _add_harmonies(standard,windows); _add_harmonies(tab,windows)
    for p in list(score.findall("part")): score.remove(p)
    score.append(standard); score.append(tab)
    _part_list(score,[("P1","Guitar — Standard Notation + Harmony"),("P2","Guitar TAB")])
    path=root/"05_final"/"final_diagnostic_score.musicxml"
    path.write_text(minidom.parseString(ET.tostring(score,encoding="utf-8")).toprettyxml(indent="  "),encoding="utf-8")
    return path


def write_arrangement_diagnostic_score(root: Path) -> Path | None:
    melody_path=root/"01_input"/"normalized_input.musicxml"; acc_path=root/"03_intermediate_scores"/"accompaniment_only.musicxml"
    if not melody_path.exists() or not acc_path.exists(): return None
    mscore=ET.parse(melody_path).getroot(); _strip_ns(mscore)
    ascore=ET.parse(acc_path).getroot(); _strip_ns(ascore)
    mp=mscore.find("part"); ap=ascore.find("part")
    if mp is None or ap is None: return None
    melody=deepcopy(mp); melody.set("id","P1"); _standardize_part(melody)
    acc=deepcopy(ap); acc.set("id","P2"); _standardize_part(acc)
    windows=_progression_windows(root); _add_harmonies(melody,windows)
    for p in list(mscore.findall("part")): mscore.remove(p)
    mscore.append(melody); mscore.append(acc)
    _part_list(mscore,[("P1","Source Melody + Harmony"),("P2","Generated Accompaniment (pre-Joint)")])
    path=root/"03_intermediate_scores"/"arrangement_diagnostic_score.musicxml"
    path.write_text(minidom.parseString(ET.tostring(mscore,encoding="utf-8")).toprettyxml(indent="  "),encoding="utf-8")
    return path


def _measure_from_window_id(wid: str | None):
    try: return (int(str(wid).lstrip("W"))+1)//2
    except: return None


def _arrangement_by_measure(root: Path) -> dict[int,list[dict]]:
    raw=_load(root/"02_auto_arrangement"/"accompaniment_events.json",[]) or []
    out=defaultdict(list)
    for w in raw:
        m=_measure_from_window_id(w.get("window_id"))
        if m is None: continue
        for e in w.get("events",[]):
            row=dict(e); row["window_id"]=w.get("window_id"); out[m].append(row)
    return dict(out)


def _flags_by_measure(root: Path) -> dict[int,list[dict]]:
    dbg=root/"04_register_search"/"existing_core"/"debug"
    files=["19_MELODY_TIMELINE_INTEGRITY.json","20_RHYTHM_GRID_DIAGNOSTICS.json","21_DISSONANCE_DIAGNOSTICS.json",
           "23_END_TO_END_MELODY_AUDIT.json","24_RHYTHM_MUSICAL_PHASE.json","25_CHORD_TRANSITION_ANOMALY.json"]
    out=defaultdict(list)
    for name in files:
        data=_load(dbg/name,{}) or {}
        candidates=[]
        for key in ("issues","review_queue"):
            if isinstance(data.get(key),list): candidates.extend(data[key])
        for x in candidates:
            # Workflow convergence: low-severity dissonance REVIEW items remain in
            # 21_DISSONANCE_DIAGNOSTICS.json for deep inspection, but do not flood
            # the top-level GPT triage.  HIGH/VERY_HIGH collisions are also echoed
            # by the chord-transition monitor and remain fully visible.
            if name == "21_DISSONANCE_DIAGNOSTICS.json" and x.get("severity") not in {"HIGH","VERY_HIGH"}:
                continue
            m=x.get("measure")
            if m is None and isinstance(x.get("location"),dict): m=x["location"].get("measure")
            try: m=int(m)
            except: continue
            out[m].append({"source":name,"type":x.get("type") or x.get("category") or x.get("cause") or "ISSUE",
                           "severity":x.get("severity"),"detail":x})
    return dict(out)


def build_workflow_packet(root: Path) -> dict:
    source=_note_inventory(root/"01_input"/"normalized_input.musicxml")
    final=_note_inventory(root/"05_final"/"final_tab.musicxml")
    arrangement=_arrangement_by_measure(root)
    chords=_progression_windows(root); chords_by=defaultdict(list)
    for c in chords:
        try: chords_by[int(c["measure"])].append({k:v for k,v in c.items() if k!="candidates"})
        except: pass
    flags=_flags_by_measure(root)
    measures=sorted(set(source)|set(final)|set(arrangement)|set(chords_by)|set(flags))
    rows=[]
    for m in measures:
        s=source.get(m,[]); f=final.get(m,[])
        sm=[x for x in s if x["role"]=="melody"]; fm=[x for x in f if x["role"]=="melody"]
        fa=[x for x in f if x["role"]=="accompaniment"]
        pitch_pc_ok=(len(sm)==len(fm) and all((a["midi"]-b["midi"])%12==0 for a,b in zip(sm,fm))) if sm or fm else True
        onset_ok=(len(sm)==len(fm) and all(abs(a["beat"]-b["beat"])<1e-6 for a,b in zip(sm,fm))) if sm or fm else True
        cats={x["source"] for x in flags.get(m,[])}
        layers=[]
        if any("23_END" in c or "19_MELODY" in c for c in cats) or not pitch_pc_ok or not onset_ok:
            layers.append("MELODY_PATH_OR_SERIALIZATION")
        if any("25_CHORD" in c for c in cats):
            layers.append("HARMONY_SELECTION_OR_VOICING")
        if any("24_RHYTHM" in c or "20_RHYTHM" in c for c in cats):
            layers.append("ARRANGEMENT_TIMING_OR_EXPORT")
        if any("21_DISSONANCE" in c for c in cats):
            layers.append("FINAL_VOICING")
        # Preserve pipeline order and de-duplicate.  A measure can legitimately have
        # both harmony and timing evidence; do not hide the secondary cause.
        ordered=[]
        for layer in layers:
            if layer not in ordered: ordered.append(layer)
        primary=ordered[0] if ordered else "NONE"
        secondary=ordered[1:]
        severities={str(x.get("severity") or "") for x in flags.get(m,[])}
        independent_sources=len(cats)
        confidence=("HIGH" if (not pitch_pc_ok or not onset_ok or severities & {"HIGH","VERY_HIGH","FAIL"})
                    else "MEDIUM" if independent_sources >= 2 or ordered else "LOW")
        rows.append({"measure":m,"source_melody":sm,"harmony_windows":chords_by.get(m,[]),
                     "arrangement_accompaniment_pre_joint":arrangement.get(m,[]),
                     "final_melody":fm,"final_accompaniment":fa,
                     "automatic_identity_checks":{"pitch_class_sequence_match":pitch_pc_ok,"onset_sequence_match":onset_ok,
                                                  "source_melody_count":len(sm),"final_melody_count":len(fm)},
                     "diagnostic_flags":flags.get(m,[]),
                     "primary_suspected_layer":primary,
                     "secondary_suspected_layers":secondary,
                     "evidence_confidence":confidence,
                     "earliest_suspected_layer":primary})
    freeze=_load(root/"04_register_search"/"existing_core"/"debug"/"26_DIAGNOSTICS_FREEZE_PACKET.json",{}) or {}
    old_review=_load(root/"04_register_search"/"existing_core"/"debug"/"22_GPT_HUMAN_REVIEW_PACKET.json",{}) or {}
    flagged=[r["measure"] for r in rows if r["diagnostic_flags"] or not all(r["automatic_identity_checks"].get(k,True) for k in ("pitch_class_sequence_match","onset_sequence_match"))]
    legacy_queue=old_review.get("review_queue",[]) if isinstance(old_review,dict) else []
    identity_item=next((q for q in legacy_queue if q.get("classification") in {
        "A_PARSER_MISMATCH_SURVIVES_FINAL","A_PIPELINE_MISMATCH_SURVIVES_FINAL",
        "B_PARSER_MISMATCH_RECOVERED_FINAL_PASS","B_IN_MEMORY_GAP_FINAL_PASS"}),None)
    identity_class=(identity_item or {}).get("classification","PASS")
    identity_priority=(identity_item or {}).get("priority",0)
    return {"version":VERSION,
            "purpose":"Progressive, measure-addressable evidence packet for GPT/human localization. Read index first, then only flagged measures and referenced raw files.",
            "read_order":[
                "1) 27_GPT_WORKFLOW_INDEX.json headline/read_order",
                "2) review only flagged measure rows in measures[]",
                "3) compare arrangement_accompaniment_pre_joint with final_accompaniment",
                "4) compare source_melody with final_melody",
                "5) inspect harmony_windows plus chord-transition/dissonance flags",
                "6) only then open referenced raw diagnostics for the first suspected layer"],
            "headline":{"flagged_measures":flagged,"flagged_measure_count":len(flagged),
                        "melody_identity_classification":identity_class,"melody_identity_priority":identity_priority,
                        "freeze_headline":freeze.get("headline",{}),"legacy_review_headline":old_review.get("headline",{})},
            "file_map":{"source":"01_input/normalized_input.musicxml",
                        "pre_joint_visual":"03_intermediate_scores/arrangement_diagnostic_score.musicxml",
                        "final_visual":"05_final/final_diagnostic_score.musicxml",
                        "legacy_gpt_packet":"04_register_search/existing_core/debug/22_GPT_HUMAN_REVIEW_PACKET.json",
                        "freeze_packet":"04_register_search/existing_core/debug/26_DIAGNOSTICS_FREEZE_PACKET.json",
                        "workflow_packet":"04_register_search/existing_core/debug/27_GPT_WORKFLOW_INDEX.json"},
            "decision_rules":[
                "If source_melody already differs from expected input, fix parser/normalization before arrangement.",
                "If pre-Joint accompaniment onset/chord is wrong, fix harmony/arrangement; do not blame fingering/export.",
                "If pre-Joint is correct but final accompaniment is missing/moved, inspect Joint/Fingering/Export Recovery.",
                "If chord symbol is plausible but final collision is HIGH/VERY_HIGH, prefer voicing/register repair before changing chord progression.",
                "A-class parser mismatch that survives to Final has priority 100; B-class parser mismatch with Final identity PASS is warning priority 50–60.",
                "Human listening remains authoritative for musicality; flags are evidence, not automatic edits."],
            "measures":rows}


def write_workflow_markdown(packet: dict, path: Path) -> Path:
    path.parent.mkdir(parents=True,exist_ok=True)
    lines=[f"# {VERSION} Progressive GPT Workflow Review","",
           "Use this file as the entry point. The JSON packet contains full per-measure events; this Markdown is the compact navigation view.","",
           "## Read order"]
    lines += [f"- {x}" for x in packet["read_order"]]
    lines += ["","## Flagged measures","", ", ".join(f"M{x}" for x in packet["headline"]["flagged_measures"]) or "None","",
              "## Measure triage","","| Measure | Primary layer | Secondary layers | Confidence | Melody PC | Melody onset | Flags |","|---:|---|---|---|---|---|---:|"]
    for r in packet["measures"]:
        if not r["diagnostic_flags"] and r["automatic_identity_checks"]["pitch_class_sequence_match"] and r["automatic_identity_checks"]["onset_sequence_match"]: continue
        a=r["automatic_identity_checks"]
        lines.append(f"| M{r['measure']} | {r['primary_suspected_layer']} | {', '.join(r['secondary_suspected_layers']) or '-'} | {r['evidence_confidence']} | {'PASS' if a['pitch_class_sequence_match'] else 'FAIL'} | {'PASS' if a['onset_sequence_match'] else 'FAIL'} | {len(r['diagnostic_flags'])} |")
    lines += ["","## GPT instruction","",
              "For each true audible problem, identify the earliest layer where the evidence becomes wrong. State SOURCE / HARMONY / ARRANGEMENT / JOINT-FINGERING / FINAL-EXPORT. Do not recommend downstream fixes for an upstream error. Compare the two diagnostic MusicXML scores when visual confirmation helps."]
    path.write_text("\n".join(lines),encoding="utf-8")
    return path


def run(root: str | Path):
    root=Path(root)
    pre=write_arrangement_diagnostic_score(root)
    final=write_final_diagnostic_score(root)
    packet=build_workflow_packet(root)
    dbg=root/"04_register_search"/"existing_core"/"debug"
    jp=_dump(dbg/"27_GPT_WORKFLOW_INDEX.json",packet)
    mp=write_workflow_markdown(packet,root/"04_register_search"/"existing_core"/"14_GPT_WORKFLOW_REVIEW.md")
    return {"pre_joint_score":str(pre) if pre else None,"final_score":str(final) if final else None,"workflow_json":str(jp),"workflow_md":str(mp)}
