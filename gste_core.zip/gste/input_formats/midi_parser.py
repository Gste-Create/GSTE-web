from __future__ import annotations
from pathlib import Path
from collections import defaultdict
from gste.core.models import NoteEvent, Pitch
from gste.input.project_models import TrackData, TimeSignatureChange


def _midi_name(n:int)->str:
    names=('C','C#','D','D#','E','F','F#','G','G#','A','A#','B')
    return f"{names[n%12]}{n//12-1}"

def parse_midi_track(path: str | Path, *, track_id: str, role: str, midi_track: int | None=None) -> TrackData:
    """Parse Standard MIDI into GSTE quarter-note TrackData.

    This is intentionally format-only: no Melody/Harmony/Bass inference occurs here.
    Note velocity/channel are not yet part of NoteEvent and remain future metadata work.
    """
    try:
        import mido
    except ImportError as exc:
        raise RuntimeError("MIDI input requires the optional 'mido' package") from exc
    p=Path(path)
    mf=mido.MidiFile(p)
    tpq=float(mf.ticks_per_beat or 480)
    indexes=range(len(mf.tracks)) if midi_track is None else (midi_track,)
    abs_events=[]; time_sigs=[]
    for ti in indexes:
        if ti < 0 or ti >= len(mf.tracks): raise IndexError(f"MIDI track {ti} out of range")
        tick=0
        for order,msg in enumerate(mf.tracks[ti]):
            tick += int(msg.time)
            if msg.type=='time_signature':
                time_sigs.append((tick/tpq,int(msg.numerator),int(msg.denominator)))
            if msg.type in {'note_on','note_off'}:
                abs_events.append((tick,ti,order,msg))
    abs_events.sort(key=lambda x:(x[0],x[1],x[2]))
    active=defaultdict(list); raw=[]
    for tick,ti,order,msg in abs_events:
        key=(ti,int(getattr(msg,'channel',0)),int(msg.note))
        is_on=msg.type=='note_on' and int(msg.velocity)>0
        if is_on: active[key].append(tick); continue
        if active[key]:
            start_tick=active[key].pop(0)
            if tick>start_tick: raw.append((start_tick,tick,int(msg.note),ti))
    warnings=[]
    for (ti,ch,note),starts in active.items():
        if starts: warnings.append(f"Unclosed MIDI note ignored: track={ti} channel={ch} note={note} count={len(starts)}")
    ts=sorted(set(time_sigs))
    if not ts:
        ts=[(0.0,4,4)]; warnings.append('MIDI contains no time signature; 4/4 assumed for measure mapping.')
    elif ts[0][0] > 0:
        ts.insert(0,(0.0,4,4)); warnings.append('MIDI time signature starts after beat 0; 4/4 assumed before first change.')
    duration=max([e[1]/tpq for e in raw]+[0.0])
    # Build physical measure timeline in quarter units, splitting at TS changes.
    measure_starts={}; measure_lengths={}; sig_changes=[]; measure=1; cursor=0.0
    tsi=0
    while cursor < duration + 1e-9 or measure==1:
        while tsi+1<len(ts) and ts[tsi+1][0] <= cursor+1e-9: tsi+=1
        _,beats,beat_type=ts[tsi]; qlen=beats*(4.0/beat_type)
        next_change=ts[tsi+1][0] if tsi+1<len(ts) else None
        length=qlen if next_change is None else min(qlen,max(1e-9,next_change-cursor))
        measure_starts[measure]=cursor; measure_lengths[measure]=length
        if abs(cursor-ts[tsi][0])<1e-8: sig_changes.append(TimeSignatureChange(cursor,beats,beat_type,measure))
        cursor += length; measure += 1
        if duration==0 and measure>1: break
    def measure_for(q):
        found=1
        for m,s in measure_starts.items():
            if s <= q+1e-9: found=m
            else: break
        return found
    notes=[]
    for i,(a,b,n,ti) in enumerate(sorted(raw,key=lambda x:(x[0],x[2],x[3])),1):
        start=a/tpq; dur=(b-a)/tpq
        notes.append(NoteEvent(Pitch(n,_midi_name(n)),start,dur,measure_for(start),source_event_id=f"{track_id}:N{i:06d}",source_type='MIDI'))
    return TrackData(track_id,role,p,notes,measure_starts,measure_lengths,sig_changes,duration,warnings,[],{})
