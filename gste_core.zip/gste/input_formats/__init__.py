"""Format-only input layer. No musical-role analysis belongs here."""
from .router import parse_source_track
from .midi_parser import parse_midi_track
__all__ = ["parse_source_track", "parse_midi_track"]
