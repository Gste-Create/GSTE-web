from pathlib import Path
from gste.parser.track_parser import parse_musicxml_track
from .midi_parser import parse_midi_track

_XML_SUFFIXES={'.xml','.musicxml','.mxl'}
_MIDI_SUFFIXES={'.mid','.midi'}

def parse_source_track(path, *, track_id: str, role: str, midi_track: int | None=None):
    """Single format boundary returning canonical TrackData.

    Downstream role processors must consume TrackData and must not reopen source files.
    """
    suffix=Path(path).suffix.lower()
    if suffix in _XML_SUFFIXES:
        return parse_musicxml_track(path, track_id=track_id, role=role)
    if suffix in _MIDI_SUFFIXES:
        return parse_midi_track(path, track_id=track_id, role=role, midi_track=midi_track)
    raise ValueError(f"Unsupported score format: {suffix or '<none>'}")
