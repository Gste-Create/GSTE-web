from __future__ import annotations
from pathlib import Path
import json


def build_priority_identity_lifecycle(priority_pool, result) -> dict:
    expected = {str(n.source_event_id): n for n in priority_pool if getattr(n, 'source_event_id', None)}
    selected = {
        str(c.note.source_event_id): c.note
        for state in result.selected
        for c in state.accompaniment.notes
        if getattr(c.note, 'source_event_id', None) and str(c.note.source_event_id) in expected
    }
    rows=[]
    for eid, note in sorted(expected.items(), key=lambda kv:(kv[1].start, kv[1].pitch.midi, kv[0])):
        if eid in selected:
            status='RETAINED'
            reason='JOINT_SELECTED_WITH_IMMUTABLE_SOURCE_ID'
        else:
            status='DROPPED_BY_JOINT'
            reason='NO_SELECTED_JOINT_STATE_CARRIED_THIS_REQUIRED_PRIORITY_ID'
        rows.append({
            'source_event_id':eid, 'measure':getattr(note,'measure',None), 'start':note.start,
            'midi':note.pitch.midi, 'importance':getattr(note,'importance',None),
            'status':status, 'reason':reason,
        })
    unexplained=[r for r in rows if not r.get('status') or not r.get('reason')]
    return {
        'contract':'UNIFIED_MELODY_PRIORITY_RETENTION_AUDIT; EVERY_EVENT_HAS_AN_EXPLICIT_TERMINAL_STATUS',
        'semantic_role':'UNIFIED_MELODY_PRIORITY_NOT_PRIMARY_MELODY',
        'expected_count':len(rows), 'retained_count':sum(r['status']=='RETAINED' for r in rows),
        'dropped_by_joint_count':sum(r['status']=='DROPPED_BY_JOINT' for r in rows),
        'unexplained_loss_count':len(unexplained),
        'source_priority_contract_preserved': not any(r['status']=='DROPPED_BY_JOINT' for r in rows),
        # Backward-compatible key. This file audits unified Melody Source PRIORITY notes,
        # not the locked primary melody backbone. Do not use it as the primary
        # melody identity verdict.
        'melody_contract_preserved': not any(r['status']=='DROPPED_BY_JOINT' for r in rows),
        'assessment_status': 'NO_EVENTS' if not rows else 'ASSESSED',
        'assessment_note': '本項沒有可核對事件' if not rows else '此項只核對優先事件，不代表主旋律骨架完整性',
        'status':'NOT_AVAILABLE' if not rows else 'PASS' if not any(r['status']=='DROPPED_BY_JOINT' for r in rows) and not unexplained else 'FAIL',
        'events':rows,
    }


def write_priority_identity_lifecycle(data:dict, path:str|Path):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    return p
