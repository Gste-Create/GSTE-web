from __future__ import annotations
from gste.version import VERSION

import json
from pathlib import Path

from gste.harmony.library import chord_family_name
from gste.harmony.piano_analysis import WindowHarmonyAnalysis
from gste.joint_arrangement.models import JointArrangementResult, JointWindowCandidate


_PC_NAMES = ("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")


def _pitch_name(midi: int) -> str:
    return f"{_PC_NAMES[midi % 12]}{midi // 12 - 1}"


def _event_key(note) -> tuple[int, float, float]:
    return (note.pitch.midi, round(note.start, 6), round(note.duration, 6))


def _source_event_metadata(note, source_events, melody_roles=None) -> dict:
    role = (melody_roles or {}).get((note.pitch.midi, round(note.start, 6)))
    if not source_events:
        return {"EventID": None, "staff": None, "voice": None, "is_highest": True, "is_melody": True, "role": role, "confidence": None}
    matches = [event for event in source_events if event.pitch_midi == note.pitch.midi and abs(event.start - note.start) <= 1e-6]
    event = matches[0] if matches else None
    return {"EventID": event.event_id if event else None, "staff": event.staff if event else None, "voice": event.voice if event else None,
            "is_highest": True, "is_melody": True, "role": role, "confidence": None}


def _melody_review(analysis: WindowHarmonyAnalysis, state: JointWindowCandidate, source_events=(), melody_roles=None) -> dict:
    source = sorted((_event_key(note) for note in analysis.window.melody_notes), key=lambda item: (item[1], item[0], item[2]))
    output = sorted((_event_key(note.note) for note in state.melody.notes), key=lambda item: (item[1], item[0], item[2]))
    missing = [item for item in source if item not in output]
    extra = [item for item in output if item not in source]
    return {
        "exact": source == output,
        "source_note_count": len(source),
        "output_note_count": len(output),
        "source_notes": [_pitch_name(item[0]) for item in source],
        "output_notes": [_pitch_name(item[0]) for item in output],
        "missing": [_pitch_name(item[0]) for item in missing],
        "extra": [_pitch_name(item[0]) for item in extra],
        "event_metadata": [_source_event_metadata(note, source_events, melody_roles) for note in analysis.window.melody_notes],
    }


def _harmony_relation(source, selected) -> tuple[str, str]:
    if source.family == selected.family:
        return "SAME", "✅ 相同"
    source_pcs = source.family.pitch_classes
    selected_pcs = selected.family.pitch_classes
    if source.family.root_pc == selected.family.root_pc:
        return "SIMILAR_SAME_ROOT", "🟡 同根音、類型不同"
    overlap = len(source_pcs & selected_pcs)
    union = len(source_pcs | selected_pcs)
    if union and overlap / union >= 0.6:
        return "SIMILAR_SHARED_TONES", "🟠 多數和弦音相同"
    return "DIFFERENT", "❌ 明顯不同"


def _source_bass(analysis: WindowHarmonyAnalysis):
    notes = analysis.window.accompaniment_notes
    return min(notes, key=lambda note: note.pitch.midi) if notes else None


def _output_bass(state: JointWindowCandidate):
    notes = state.accompaniment.notes
    return min(notes, key=lambda note: note.note.pitch.midi) if notes else None


def _bass_review(analysis: WindowHarmonyAnalysis, state: JointWindowCandidate) -> dict:
    source = _source_bass(analysis)
    output = _output_bass(state)
    role = state.bass_role
    if source is None or output is None:
        return {
            "source": "(none)" if source is None else _pitch_name(source.pitch.midi),
            "output": "(none)" if output is None else _pitch_name(output.note.pitch.midi),
            "relation": "MISSING",
            "label": "⚠ 缺少低音",
            "role": role, "identity_rank": state.bass_identity_rank,
            "substitution_reason": state.bass_substitution_reason,
            "exact_candidate_available": False, "octave_candidate_available": False,
            "bass_line_transition_cost": state.transition_breakdown.get("bass_line_transition_cost", 0.0),
        }
    source_midi = source.pitch.midi
    output_midi = output.note.pitch.midi
    if output_midi == source_midi:
        relation, label = "SAME_PITCH", "✅ 原低音保留"
    elif output_midi % 12 == source_midi % 12:
        octaves = (output_midi - source_midi) // 12
        direction = "高" if octaves > 0 else "低"
        relation, label = "OCTAVE_EQUIVALENT", f"✅ 同音名（{direction}{abs(octaves)}八度）"
    elif output_midi % 12 == state.harmony.family.root_pc:
        relation, label = "CHORD_ROOT", "✅ 改用輸出和弦根音"
    elif output_midi % 12 in state.harmony.family.pitch_classes:
        relation, label = "CHORD_TONE", "🟡 使用輸出和弦音"
    else:
        relation, label = "NON_CHORD_TONE", "❌ 非輸出和弦音"
    return {
        "source": _pitch_name(source_midi),
        "output": _pitch_name(output_midi),
        "output_tab": f"S{output.string}F{output.fret}",
        "relation": relation,
        "label": label,
        "role": role,
        "identity_rank": state.bass_identity_rank,
        "substitution_reason": state.bass_substitution_reason,
        "exact_candidate_available": False,
        "octave_candidate_available": False,
        "bass_line_transition_cost": state.transition_breakdown.get("bass_line_transition_cost", 0.0),
    }


def build_review_data(result: JointArrangementResult, analyses: list[WindowHarmonyAnalysis], *, right_source_events=(), boundaries=(), integrity=None, melody_roles=None) -> dict:
    rows = []
    for index, (analysis, state) in enumerate(zip(analyses, result.selected)):
        # v0.13.3 Source Piano stability: source-mapped windows may legitimately
        # reach finalization without a scored harmony candidate (for example a
        # source-rest window or a window whose source evidence was filtered).
        # Human-review reporting must never index an empty candidate list.  In
        # that case use the already-selected joint harmony only as a reporting
        # fallback and explicitly mark the source basis as unavailable.
        source_harmony = analysis.candidates[0] if analysis.candidates else state.harmony
        source_harmony_available = bool(analysis.candidates)
        relation, relation_label = _harmony_relation(source_harmony, state.harmony)
        local_layer = result.candidate_layers[index] if index < len(result.candidate_layers) else ()
        local_best = min(local_layer, key=lambda item: item.local_cost) if local_layer else state
        bass = _bass_review(analysis, state)
        bass["exact_candidate_available"] = any(item.bass_identity_rank == 0 for item in local_layer)
        bass["octave_candidate_available"] = any(item.bass_identity_rank == 1 for item in local_layer)
        boundary = next((item for item in boundaries if abs(item.time - state.start) <= 1e-6), None)
        source_pitch_set = sorted({_pitch_name(note.pitch.midi) for note in [*analysis.window.melody_notes, *analysis.window.accompaniment_notes]})
        rows.append({
            "window_id": state.window_id,
            "measure": state.measure,
            "melody": _melody_review(analysis, state, right_source_events, melody_roles),
            "source_harmony_basis": ("inferred_from_source_accompaniment" if source_harmony_available else "selected_harmony_fallback_no_source_candidate"),
            "source_inferred_chord": chord_family_name(source_harmony.family),
            "selected_chord": chord_family_name(state.harmony.family),
            "harmony_relation": relation,
            "harmony_relation_label": relation_label,
            "bass": bass,
            "source_pitch_set": source_pitch_set,
            "bass_candidate": _pitch_name(_source_bass(analysis).pitch.midi) if _source_bass(analysis) else None,
            "root_candidate": _PC_NAMES[source_harmony.family.root_pc],
            "chord_candidates": [chord_family_name(candidate.family) for candidate in analysis.candidates],
            "local_best": chord_family_name(local_best.harmony.family),
            "global_selected": chord_family_name(state.harmony.family),
            "global_selection_reason": f"local cost {state.local_cost:.3f} + transition cost {state.transition_cost:.3f}; selected by existing joint DP.",
            "EventBoundaryID": boundary.boundary_id if boundary else None,
            "EventID": list(boundary.neighbouring_event_ids) if boundary else [],
            "Confidence": boundary.confidence if boundary else None,
            "LocalScore": state.local_cost,
            "GlobalScore": result.total_cost,
            "SimplificationLevel": state.simplification_level,
            "RemovedNotes": list(state.removed_notes),
        })
    exact = sum(1 for row in rows if row["melody"]["exact"])
    bass_counts = {"present": 0, "exact": 0, "octave": 0, "pitch_class": 0, "root": 0, "other": 0, "omitted": 0}
    for row in rows:
        relation = row["bass"]["relation"]
        if relation != "MISSING": bass_counts["present"] += 1
        if relation == "SAME_PITCH": bass_counts["exact"] += 1
        if relation == "OCTAVE_EQUIVALENT": bass_counts["octave"] += 1
        if relation in {"SAME_PITCH", "OCTAVE_EQUIVALENT"}: bass_counts["pitch_class"] += 1
        if relation == "CHORD_ROOT": bass_counts["root"] += 1
        if relation in {"CHORD_TONE", "NON_CHORD_TONE"}: bass_counts["other"] += 1
        if relation == "MISSING": bass_counts["omitted"] += 1
    return {
        "version": VERSION,
        "notice": "Source chords are inferred from accompaniment notes unless the input contains an explicit chord label.",
        "summary": {
            "windows": len(rows),
            "melody_exact_windows": exact,
            "melody_exact": exact == len(rows),
            "melody_identity_semantics": "WINDOW_REPRESENTATION_ADVISORY_ONLY__FINAL_IDENTITY_VALIDATOR_IS_AUTHORITATIVE",
            "event_boundary_status": "ADVISORY" if boundaries else "NOT_AVAILABLE",
            "event_integrity_status": integrity["status"] if integrity else "NOT_AVAILABLE",
            "problem_measures": sorted({row["measure"] for row in rows if not row["melody"]["exact"] or row["bass"]["relation"] in {"MISSING", "NON_CHORD_TONE"}}),
            "arrangement_status": (
                "PASS_WITH_MELODY_ONLY_FALLBACK" if any(
                    state.accompaniment.candidate_type in {"K_MELODY_ONLY_HARD_CONFLICT","M_LOCAL_MELODY_RESCUE"}
                    for state in result.selected
                ) else ("PASS_WITH_REVOICING" if any(row["SimplificationLevel"] for row in rows) else "PASS")
            ),
            "simplified_windows": sum(1 for row in rows if row["SimplificationLevel"]),
            "bass_preservation": bass_counts,
        },
        "windows": rows,
    }


def write_review_json(result: JointArrangementResult, analyses: list[WindowHarmonyAnalysis], path: str | Path, **context) -> Path:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(build_review_data(result, analyses, **context), indent=2, ensure_ascii=False), encoding="utf-8")
    return output


def _note_list(review: dict) -> str:
    return " ".join(review["source_notes"]) or "(休止)"


def write_review_summary(result: JointArrangementResult, analyses: list[WindowHarmonyAnalysis], path: str | Path, **context) -> Path:
    output = Path(path)
    data = build_review_data(result, analyses, **context)
    summary = data["summary"]
    lines = [
        f"# GSTE {VERSION} 人工審查總表", "",
        f"- 編曲狀態：**{summary['arrangement_status']}**；降階窗格：{summary['simplified_windows']}。",
        "- 失敗診斷：`debug/15_arrangement_diagnostics.json`（含候選過濾計數、首次失敗階段與延音角色）。",
        f"- Window-level 旋律表示一致：**{'✅ 全部相同' if summary['melody_exact'] else '🟡 有局部表示差異'}**（{summary['melody_exact_windows']}/{summary['windows']} 個區段；tie/sustain/window boundary 差異僅供審查）",
        "- **最終主旋律是否保留，請以 `04_FINAL_FINGERING_REVIEW.json` 的 `melody_identity_preserved` 為唯一 hard PASS/FAIL。**",
        "- 和弦欄位：來源 XML 若沒有正式和弦標記，顯示的是依來源伴奏音符推定的和弦。",
        "- 可彈性：請開啟 `04_TAB.musicxml` 實際檢查。", "",
        f"- Event Boundary：**{summary['event_boundary_status']}**（只供審查，固定兩拍流程仍保留）。",
        f"- Event Integrity：**{summary['event_integrity_status']}**。",
        f"- 問題小節：{', '.join(map(str, summary['problem_measures'])) or '無'}。",
        "- 提醒：**Local Best ≠ Global Selected**；全域 DP 可能因跨窗格轉換成本選擇不同候選。", "",
        "| 區段 | 原始旋律 | 輸出旋律 | 旋律一致 | 來源伴奏推定和弦 | GSTE 和弦 | 和弦關係 | 原始低音 | 輸出低音／TAB | 低音判定 | 人工結論 |",
        "|---|---|---|---|---|---|---|---|---|---|---|",
    ]
    for analysis, row in zip(analyses, data["windows"]):
        melody = row["melody"]
        bass = row["bass"]
        output_bass = bass["output"] + (f" / {bass['output_tab']}" if bass.get("output_tab") else "")
        lines.append(
            f"| {row['window_id']} | {_note_list(melody)} | {' '.join(melody['output_notes']) or '(休止)'} | "
            f"{'✅ 完全相同' if melody['exact'] else '❌ 不同'} | {row['source_inferred_chord']} | {row['selected_chord']} | "
            f"{row['harmony_relation_label']} | {bass['source']} | {output_bass} | {bass['label']} | ☐ |"
        )
    lines.extend(["", "## 建議審查順序", "", "1. 先確認最終 `melody_identity_preserved`；window-level 差異僅用來定位 tie/sustain/boundary 表示問題。", "2. 再看和弦是否相同或可接受地相似。", "3. 檢查低音是否保留、移高八度或改成合理和弦音。", "4. 最後開啟 TAB 實際試彈並在人工結論欄記錄。", ""])
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(lines), encoding="utf-8")
    return output


def write_melody_verification(result: JointArrangementResult, analyses: list[WindowHarmonyAnalysis], path: str | Path, **context) -> Path:
    output = Path(path)
    data = build_review_data(result, analyses, **context)
    lines = [f"# GSTE {VERSION} 旋律完整性驗證", ""]
    for analysis, row in zip(analyses, data["windows"]):
        review = row["melody"]
        lines.extend([
            f"## {row['window_id']} — {'✅ PASS' if review['exact'] else '❌ FAIL'}", "",
            f"- 原始／輸出音符數：{review['source_note_count']} / {review['output_note_count']}",
            f"- 原始：{' '.join(review['source_notes']) or '(休止)'}",
            f"- 輸出：{' '.join(review['output_notes']) or '(休止)'}",
            f"- 遺失：{' '.join(review['missing']) or '無'}",
            f"- 多出：{' '.join(review['extra']) or '無'}", "",
            "| 音符 | onset | duration | staff | voice | 最高音 | 旋律 | 信心（預留） |",
            "|---|---:|---:|---|---|---|---|---|",
        ])
        for note, metadata in zip(analysis.window.melody_notes, review["event_metadata"]):
            lines.append(f"| {_pitch_name(note.pitch.midi)} | {note.start:g} | {note.duration:g} | {metadata['staff'] or '—'} | {metadata['voice'] or '—'} | {'是' if metadata['is_highest'] else '否'} | {'是' if metadata['is_melody'] else '否'} | 預留 |")
        lines.append("")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(lines), encoding="utf-8")
    return output


def write_harmony_bass_review(result: JointArrangementResult, analyses: list[WindowHarmonyAnalysis], path: str | Path, **context) -> Path:
    output = Path(path)
    data = build_review_data(result, analyses, **context)
    stats = data["summary"]["bass_preservation"]
    lines = [f"# GSTE {VERSION} 和弦與低音人工審查", "", "> 注意：未含正式和弦標記的 MusicXML，只能由來源伴奏音符推定和弦，不能視為原曲官方和弦。", "", "## 全曲低音身份統計", "", f"- Bass present：{stats['present']}/{data['summary']['windows']}；Exact：{stats['exact']}；Octave-equivalent：{stats['octave']}；Pitch-class retained：{stats['pitch_class']}；Root substitute：{stats['root']}；Other tone：{stats['other']}；Omitted：{stats['omitted']}。", ""]
    for row in data["windows"]:
        bass = row["bass"]
        lines.extend([
            f"## {row['window_id']}", "",
            f"- 來源伴奏推定和弦：**{row['source_inferred_chord']}**",
            f"- GSTE 選擇和弦：**{row['selected_chord']}**",
            f"- 關係：{row['harmony_relation_label']}",
            f"- Source Pitch Set：{', '.join(row['source_pitch_set']) or 'none'}",
            f"- Bass Candidate：{row['bass_candidate'] or 'none'}；Root Candidate：{row['root_candidate']}；Chord Candidate：{', '.join(row['chord_candidates'])}",
            f"- Local Best：**{row['local_best']}**；Global Selected：**{row['global_selected']}**",
            f"- Global Selection Reason：{row['global_selection_reason']}",
            f"- 原始最低音：**{bass['source']}**",
            f"- 輸出最低音：**{bass['output']}**" + (f"（{bass['output_tab']}）" if bass.get("output_tab") else ""),
            f"- 低音判定：{bass['label']}",
            f"- 來源低音角色：**{bass['role']}**；Bass identity level：**B{bass['identity_rank']}**",
            f"- Exact／Octave 候選可用：{'是' if bass['exact_candidate_available'] else '否'}／{'是' if bass['octave_candidate_available'] else '否'}；替代理由：{bass['substitution_reason']}",
            f"- Bass-line transition cost：{float(bass['bass_line_transition_cost']):.3f}",
            "- 人工判定：☐ 接受　☐ 修改　備註：", "",
        ])
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(lines), encoding="utf-8")
    return output
