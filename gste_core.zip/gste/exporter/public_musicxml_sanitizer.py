from __future__ import annotations

from pathlib import Path
import xml.etree.ElementTree as ET
import json

_GSTE_META_NS = "https://gste.local/musicxml/metadata"


def sanitize_public_musicxml(path: str | Path) -> dict[str, int]:
    """Remove GSTE-private trace metadata from a completed user-facing MusicXML.

    This is an export-boundary operation only. It runs after GSTE conversion,
    validation, review, monitoring, and report generation have finished, so
    internal event identity remains available throughout the pipeline.

    Musical MusicXML content is intentionally untouched: pitch, duration,
    voice, staff, rests/forwards/backups, ties/slurs, string/fret, harmony,
    directions, and layout are not rewritten here.
    """
    output = Path(path)
    tree = ET.parse(output)
    root = tree.getroot()

    # Capture identity/semantic ownership before presentation-only cleanup.
    from gste.exporter.joint_tab_xml_exporter import _note_role
    mappings={}
    for part in root.findall('part'):
        for mi,measure in enumerate(part.findall('measure'),1):
            for ei,note in enumerate(measure):
                if note.tag!='note':continue
                nid=f"{part.get('id')}:M{mi}:E{ei}"
                mappings[nid]={'note_id':nid,'event_id':note.findtext("notations/other-notation[@type='gste-event-id']") or note.findtext("notations/other-notation[@type='gste-editor-event-id']"),
                    'role':'rest' if note.find('rest') is not None else (note.findtext("notations/other-notation[@type='gste-editor-role']") or _note_role(note))}
    (output.with_suffix('.notation.json')).write_text(json.dumps(mappings,ensure_ascii=False,indent=2),encoding='utf-8')
    removed_attributes = 0
    removed_markers = 0
    ns_prefix = f"{{{_GSTE_META_NS}}}"

    for element in root.iter():
        for attr_name in list(element.attrib):
            if attr_name.startswith(ns_prefix):
                del element.attrib[attr_name]
                removed_attributes += 1

    # Defensive cleanup for older/intermediate exporter representations. These
    # markers are GSTE trace data, not musical notation intended for MuseScore.
    for note in root.findall(".//note"):
        notations = note.find("notations")
        if notations is None:
            continue
        for marker in list(notations.findall("other-notation")):
            if (marker.get("type") or "").strip().startswith("gste-"):
                notations.remove(marker)
                removed_markers += 1
        technical = notations.find("technical")
        if technical is not None:
            for marker in list(technical.findall("other-technical")):
                if (marker.text or "").strip().startswith("GSTE_"):
                    technical.remove(marker)
                    removed_markers += 1
            if len(technical) == 0:
                notations.remove(technical)
        if len(notations) == 0:
            note.remove(notations)

    tree.write(output, encoding="utf-8", xml_declaration=True)
    return {
        "removed_private_attributes": removed_attributes,
        "removed_private_markers": removed_markers,
    }
