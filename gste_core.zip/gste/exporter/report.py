from __future__ import annotations

from gste.core.models import FingeringPath


def fingering_path_to_text(path: FingeringPath, include_candidates: bool = True) -> str:
    lines: list[str] = []
    lines.append(f"Total cost: {path.total_cost}")

    if path.warnings:
        lines.append("Warnings:")
        for warning in path.warnings:
            lines.append(f"- {warning}")

    lines.append("Selected TAB path:")
    for index, candidate in enumerate(path.candidates):
        lines.append(
            f"{index:03d}: midi={candidate.note.pitch.midi} "
            f"string={candidate.string} "
            f"fret={candidate.fret} "
            f"position={candidate.position_block} "
            f"shape={candidate.caged_shape or '-'} "
            f"local_cost={candidate.cost}"
        )

    if include_candidates and path.candidate_layers is not None:
        lines.append("")
        lines.append("Candidate fingering report:")
        for index, layer in enumerate(path.candidate_layers):
            if not layer:
                lines.append(f"{index:03d}: no playable candidates")
                continue
            note = layer[0].note
            options = "; ".join(
                f"S{candidate.string}-F{candidate.fret} "
                f"pos={candidate.position_block} shape={candidate.caged_shape or '-'} cost={candidate.cost}"
                for candidate in layer
            )
            selected = path.candidates[index] if index < len(path.candidates) else None
            selected_text = (
                f"selected=S{selected.string}-F{selected.fret}" if selected else "selected=none"
            )
            lines.append(
                f"{index:03d}: midi={note.pitch.midi} measure={note.measure or '-'} "
                f"{selected_text} candidates=[{options}]"
            )

    return "\n".join(lines)
