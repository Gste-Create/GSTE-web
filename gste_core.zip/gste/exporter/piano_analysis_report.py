from __future__ import annotations
from gste.version import VERSION

from dataclasses import asdict
import json
from pathlib import Path

from gste.alignment.models import AlignmentResult
from gste.harmony.library import chord_family_name
from gste.harmony.piano_analysis import WindowHarmonyAnalysis


def _note_dict(note):
    return {
        "midi": note.pitch.midi,
        "name": note.pitch.name,
        "start": note.start,
        "duration": note.duration,
        "measure": note.measure,
    }


def _event_dict(event):
    return {
        "event_id": event.event_id,
        "kind": event.kind,
        "start": event.start,
        "duration": event.duration,
        "measure": event.measure,
        "order": event.order,
        "voice": event.voice,
        "staff": event.staff,
        "pitch_midi": event.pitch_midi,
        "is_rest": event.is_rest,
        "is_chord_tone": event.is_chord_tone,
        "source_xml": event.source_xml,
    }


def write_full_musical_events_json(right_hand_source, left_hand_source, path: str | Path) -> Path:
    """Write both unreduced source tracks before any melody/harmony decision."""
    target = Path(path)
    payload = {
        "version": VERSION,
        "policy": {
            "stage": "pre_analysis",
            "all_direct_measure_events_preserved": True,
            "used_by_current_arrangement_algorithm": False,
            "future_use": "event-boundary, melody, and harmony analysis",
        },
        "tracks": [
            {
                "track_id": track.track_id,
                "role": track.role,
                "source_file": str(track.source_file),
                "event_count": len(track.events),
                "events": [_event_dict(event) for event in track.events],
            }
            for track in (right_hand_source, left_hand_source)
        ],
    }
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return target


def write_alignment_report(result: AlignmentResult, path: str | Path) -> Path:
    target = Path(path)
    lines = [
        f"# GSTE {VERSION} Piano Split Input Validation",
        "",
        f"Aligned: {result.is_aligned}",
        f"Melody: `{result.project.melody.source_file}`",
        f"Left hand: `{result.project.left_hand.source_file}`",
        f"Melody duration: {result.project.melody.duration_quarters:g} quarters",
        f"Left-hand duration: {result.project.left_hand.duration_quarters:g} quarters",
        f"Measures: {result.project.melody.measure_count}",
        "",
        "## Issues",
    ]
    if result.issues:
        for issue in result.issues:
            level = "ERROR" if issue.fatal else "WARNING"
            lines.append(f"- **{level} `{issue.code}`**: {issue.message}")
    else:
        lines.append("- None")
    target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return target


def write_aligned_tracks_json(result: AlignmentResult, path: str | Path) -> Path:
    target = Path(path)
    project = result.project
    payload = {
        "version": VERSION,
        "aligned": result.is_aligned,
        "issues": [{"code": i.code, "message": i.message, "fatal": i.fatal} for i in result.issues],
        "tracks": [
            {
                "track_id": track.track_id,
                "role": track.role,
                "source_file": str(track.source_file),
                "duration_quarters": track.duration_quarters,
                "measure_starts": track.measure_starts,
                "measure_lengths": track.measure_lengths,
                "notes": [_note_dict(note) for note in track.notes],
            }
            for track in (project.melody, project.left_hand)
        ],
    }
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return target


def write_harmony_report_json(analyses: list[WindowHarmonyAnalysis], path: str | Path) -> Path:
    target = Path(path)
    payload = {
        "version": VERSION,
        "windows": [
            {
                "window_id": item.window.window_id,
                "measure": item.window.measure,
                "start": item.window.start,
                "duration": item.window.duration,
                "melody_notes": [_note_dict(note) for note in item.window.melody_notes],
                "left_hand_notes": [_note_dict(note) for note in item.window.accompaniment_notes],
                "evidence": {
                    "melody_pitch_weights": item.evidence.melody_pitch_weights,
                    "accompaniment_pitch_weights": item.evidence.accompaniment_pitch_weights,
                    "bass_pitch_class": item.evidence.bass_pitch_class,
                    "note_evidence": [asdict(row) for row in item.evidence.note_evidence],
                },
                "candidates": [
                    {
                        "name": chord_family_name(candidate.family),
                        "root_pc": candidate.family.root_pc,
                        "quality": candidate.family.quality,
                        "total_score": candidate.total_score,
                        "components": {
                            "harmonic": candidate.harmonic_score,
                            "melody": candidate.melody_score,
                            "accompaniment": candidate.accompaniment_score,
                            "bass": candidate.bass_score,
                            "complexity_penalty": candidate.complexity_penalty,
                        },
                    }
                    for candidate in item.candidates
                ],
            }
            for item in analyses
        ]
    }
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return target


def write_harmony_summary(analyses: list[WindowHarmonyAnalysis], path: str | Path) -> Path:
    target = Path(path)
    lines = [f"# GSTE {VERSION} Piano Split Harmony Analysis", ""]
    for item in analyses:
        lines.extend(
            [
                f"## {item.window.window_id} — measure {item.window.measure}, quarter {item.window.start:g}–{item.window.end:g}",
                "",
                f"- Melody pitches: {', '.join(note.pitch.name or str(note.pitch.midi) for note in item.window.melody_notes) or 'none'}",
                f"- Left-hand pitches: {', '.join(note.pitch.name or str(note.pitch.midi) for note in item.window.accompaniment_notes) or 'none'}",
                f"- Bass pitch class: {item.evidence.bass_pitch_class if item.evidence.bass_pitch_class is not None else 'none'}",
                "- Candidates:",
            ]
        )
        if item.candidates:
            for rank, candidate in enumerate(item.candidates, start=1):
                lines.append(f"  {rank}. **{chord_family_name(candidate.family)}** — {candidate.total_score:.3f}")
        else:
            lines.append("  - none above threshold")
        lines.append("")
    target.write_text("\n".join(lines), encoding="utf-8")
    return target


def write_structure_report_json(analysis, path: str | Path) -> Path:
    target = Path(path)
    payload = {
        "version": VERSION,
        "policy": {
            "advisory_only": analysis.advisory_only,
            "melody_complete_required": analysis.melody_complete_required,
            "playability_required": analysis.playability_required,
            "may_modify_fingering_cost": False,
        },
        "boundaries": [
            {
                "time": item.time,
                "measure": item.measure,
                "score": item.score,
                "hard": item.hard,
                "reasons": list(item.reasons),
            }
            for item in analysis.boundaries
        ],
        "arrangement_signals": [
            {
                "start": item.start,
                "duration": item.duration,
                "end": item.end,
                "phrase_role": item.phrase_role.value,
                "boundary_before": item.boundary_before,
                "boundary_after": item.boundary_after,
                "chord_change_suitability": item.chord_change_suitability,
                "position_change_suitability": item.position_change_suitability,
                "accompaniment_density": item.accompaniment_density,
                "preserve_melody": item.preserve_melody,
                "notes": list(item.notes),
            }
            for item in analysis.signals
        ],
    }
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return target


def write_structure_summary(analysis, path: str | Path) -> Path:
    target = Path(path)
    lines = [
        f"# GSTE {VERSION} Arrangement Structure Signals",
        "",
        "> Advisory only. These signals do not change the existing fingering cost calculation.",
        "> Melody completeness and playability remain hard constraints.",
        "",
        "## Detected boundaries",
        "",
    ]
    for item in analysis.boundaries:
        lines.append(
            f"- Quarter {item.time:g}: score {item.score:.3f}; "
            f"reasons: {', '.join(item.reasons)}"
        )
    lines.extend(["", "## Window signals", ""])
    for item in analysis.signals:
        lines.extend(
            [
                f"### Quarter {item.start:g}–{item.end:g}",
                f"- Phrase role: `{item.phrase_role.value}`",
                f"- Chord-change suitability: {item.chord_change_suitability:.3f}",
                f"- Position-change suitability: {item.position_change_suitability:.3f}",
                f"- Suggested accompaniment density: {item.accompaniment_density:.3f}",
                f"- Preserve melody: {item.preserve_melody}",
                "",
            ]
        )
    target.write_text("\n".join(lines), encoding="utf-8")
    return target



def write_melody_extraction_report_json(result, path: str | Path) -> Path:
    target = Path(path)
    payload = {
        "version": VERSION,
        "policy": {
            "mode": result.policy,
            "melody_definition": "highest pitched note at each onset",
            "must_keep_extracted_melody": True,
            "source_notes_preserved_for_audit": True,
            "inner_voice_detection_supported": False,
        },
        "summary": {
            "source_note_count": result.source_note_count,
            "kept_note_count": result.kept_note_count,
            "omitted_note_count": result.omitted_note_count,
            "kept_ratio": result.kept_ratio,
        },
        "decisions": [
            {
                "onset": item.onset,
                "kept": _note_dict(item.kept_note),
                "omitted": [_note_dict(note) for note in item.omitted_notes],
                "rule": item.rule,
            }
            for item in result.decisions
        ],
    }
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return target


def write_melody_extraction_summary(result, path: str | Path) -> Path:
    target = Path(path)
    lines = [
        f"# GSTE {VERSION} Highest-Voice Melody Reduction",
        "",
        "> MVP rule: retain the highest pitched right-hand note at each onset.",
        "> This does not detect inner-voice melody and all omitted source notes remain listed for review.",
        "",
        f"- Source notes: {result.source_note_count}",
        f"- Melody notes retained: {result.kept_note_count}",
        f"- Right-hand notes omitted: {result.omitted_note_count}",
        "",
        "## Decisions",
        "",
    ]
    for item in result.decisions:
        kept = item.kept_note.pitch.name or str(item.kept_note.pitch.midi)
        omitted = ", ".join(note.pitch.name or str(note.pitch.midi) for note in item.omitted_notes) or "none"
        lines.append(f"- Quarter {item.onset:g}: keep **{kept}**; omit {omitted}")
    target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return target

def write_planning_report_json(feasibility, zones, plans, path: str | Path) -> Path:
    target = Path(path)
    payload = {
        "version": VERSION,
        "policy": {
            "melody_complete_required": True,
            "playability_required": True,
            "planning_advisory_only": True,
            "may_modify_detailed_fingering_cost": False,
        },
        "melody_feasibility": {
            "melody_complete": feasibility.melody_complete,
            "playable": feasibility.playable,
            "pitch_min": feasibility.pitch_min,
            "pitch_max": feasibility.pitch_max,
            "max_fret": feasibility.max_fret,
            "hard_constraints": list(feasibility.hard_constraints),
            "notes": [
                {
                    "note_index": item.note_index,
                    "midi": item.midi,
                    "start": item.start,
                    "duration": item.duration,
                    "playable": item.playable,
                    "playable_positions": [
                        {"string": string, "fret": fret}
                        for string, fret in item.playable_positions
                    ],
                }
                for item in feasibility.notes
            ],
        },
        "position_zones": [
            {
                "segment_id": item.segment_id,
                "start": item.start,
                "duration": item.duration,
                "position_block": item.position_block,
                "fret_range": [item.fret_low, item.fret_high],
                "coverage": item.coverage,
                "melody_complete": item.melody_complete,
                "estimated_difficulty": item.estimated_difficulty,
                "preferred": item.preferred,
                "reasons": list(item.reasons),
            }
            for item in zones
        ],
        "position_plans": [
            {
                "plan_id": plan.plan_id,
                "total_cost": plan.total_cost,
                "melody_complete": plan.melody_complete,
                "playable": plan.playable,
                "advisory_only": plan.advisory_only,
                "steps": [
                    {
                        "segment_id": step.segment_id,
                        "start": step.start,
                        "duration": step.duration,
                        "position_block": step.position_block,
                        "shift_mode": step.shift_mode.value,
                        "local_cost": step.local_cost,
                        "boundary_suitability": step.boundary_suitability,
                        "melody_complete": step.melody_complete,
                    }
                    for step in plan.steps
                ],
            }
            for plan in plans
        ],
    }
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return target


def write_planning_summary(feasibility, zones, plans, path: str | Path) -> Path:
    target = Path(path)
    lines = [
        f"# GSTE {VERSION} Hierarchical Melody and Position Planning",
        "",
        "> Melody completeness and physical playability are hard constraints.",
        "> Position plans are advisory and do not modify the existing detailed fingering cost.",
        "",
        "## Melody feasibility",
        "",
        f"- Notes: {len(feasibility.notes)}",
        f"- Melody complete: {feasibility.melody_complete}",
        f"- Playable: {feasibility.playable}",
        f"- Pitch range: {feasibility.pitch_min}–{feasibility.pitch_max}",
        "",
        "## Candidate position zones",
        "",
    ]
    for item in zones:
        lines.append(
            f"- `{item.segment_id}`: block {item.position_block} "
            f"(frets {item.fret_low}–{item.fret_high}), coverage {item.coverage:.3f}, "
            f"difficulty {item.estimated_difficulty:.3f}"
        )
    lines.extend(["", "## Candidate position plans", ""])
    for plan in plans:
        path_text = " → ".join(
            f"B{step.position_block}[{step.shift_mode.value}]" for step in plan.steps
        )
        lines.append(f"- **{plan.plan_id}** cost {plan.total_cost:.3f}: {path_text}")
    target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return target
