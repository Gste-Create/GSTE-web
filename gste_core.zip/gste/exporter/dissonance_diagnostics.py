"""v0.13.5.12.4 harmonic/dissonance diagnostics.

Diagnostic only: this module never changes arrangement, Joint selection,
fingering, or export.  It explains suspicious final accompaniment notes using
melody overlap, chord context, register placement, metrical strength, duration,
and simple resolution evidence.
"""
from __future__ import annotations
from gste.version import VERSION

from collections import defaultdict
from pathlib import Path
import json
import math

from gste.input.project_models import TrackData
from gste.exporter.timeline_rhythm_diagnostics import _pitch_name, _r


def _result_profiles(joint_result) -> dict:
    """Build diagnostic melody/accompaniment rows from the validated in-memory result.

    v0.13.5.13.3 deliberately avoids reparsing final MusicXML for musical
    diagnostics.  The final Joint/Fingering state and Locked Melody Backbone
    share the authoritative clock; serializer representation is not a second
    timing authority.
    """
    melody=[]; accompaniment=[]; seen_m=set(); seen_a=set()
    for state in getattr(joint_result, 'selected', ()) or ():
        for cand in getattr(getattr(state, 'melody', None), 'notes', ()) or ():
            n=cand.note
            key=(str(getattr(n,'source_event_id', '') or ''), round(float(n.start),9), int(n.pitch.midi))
            if key in seen_m: continue
            seen_m.add(key)
            melody.append({'pitch_midi':int(n.pitch.midi),'pitch':_pitch_name(int(n.pitch.midi)),
                           'onset':_r(n.start),'duration':_r(n.duration),'measure':n.measure,'role':'melody'})
        for cand in getattr(getattr(state, 'accompaniment', None), 'notes', ()) or ():
            n=cand.note
            key=(str(getattr(n,'source_event_id','') or ''), round(float(n.start),9), int(n.pitch.midi), cand.string, cand.fret)
            if key in seen_a: continue
            seen_a.add(key)
            accompaniment.append({'pitch_midi':int(n.pitch.midi),'pitch':_pitch_name(int(n.pitch.midi)),
                                  'onset':_r(n.start),'duration':_r(n.duration),'measure':n.measure,'role':'accompaniment'})
    return {'melody':melody,'accompaniment':accompaniment,
            'role_counts':{'melody':len(melody),'accompaniment':len(accompaniment)},
            'marker_counts':{}}

_PC_NAMES = ("C","C#","D","D#","E","F","F#","G","G#","A","A#","B")


def _overlap(a: dict, b: dict, eps: float = 1e-6) -> float:
    start=max(float(a['onset']),float(b['onset']))
    stop=min(float(a['onset'])+float(a['duration']),float(b['onset'])+float(b['duration']))
    return max(0.0, stop-start) if stop > start+eps else 0.0


def _metrical_strength(onset: float, measure_start: float) -> tuple[str,float]:
    local=max(0.0,float(onset)-float(measure_start))
    nearest_beat=round(local)
    if abs(local-nearest_beat) <= 1/96:
        return ("STRONG_BEAT" if nearest_beat == 0 else "BEAT", local)
    nearest_eighth=round(local*2)/2
    if abs(local-nearest_eighth) <= 1/96:
        return ("EIGHTH_SUBDIVISION", local)
    return ("WEAK_OR_OTHER", local)


def _interval_label(semitones: int) -> str:
    simple=semitones%12
    base={0:'P1',1:'m2',2:'M2',3:'m3',4:'M3',5:'P4',6:'TT',7:'P5',8:'m6',9:'M6',10:'m7',11:'M7'}[simple]
    if semitones >= 12 and simple in (1,2):
        return 'm9' if simple == 1 else 'M9'
    return base


def _base_interval_risk(semitones: int) -> float:
    if semitones == 1: return 4.5
    if semitones == 13: return 4.25
    if semitones % 12 == 11: return 3.25
    if semitones == 2: return 2.5
    if semitones == 14: return 2.25
    if semitones % 12 == 6: return 2.25
    if semitones % 12 == 10: return 0.75
    return 0.0


def _harmony_at(joint_result, onset: float):
    candidates=[]
    for state in joint_result.selected:
        if float(state.start)-1e-6 <= onset < float(state.start)+float(state.duration)-1e-6:
            candidates.append(state)
    if not candidates:
        # Boundary note: use nearest window start, but mark lower confidence.
        states=list(joint_result.selected)
        return (min(states,key=lambda s:abs(float(s.start)-onset)), False) if states else (None,False)
    return (min(candidates,key=lambda s:abs(float(s.start)-onset)), True)


def _harmony_dict(state) -> dict | None:
    if state is None: return None
    fam=state.harmony.family
    root=int(fam.root_pc)%12
    return {
        'window_id':state.window_id,
        'measure':state.measure,
        'start':_r(state.start),
        'duration':_r(state.duration),
        'root_pc':root,
        'root':_PC_NAMES[root],
        'quality':fam.quality,
        'required_pitch_classes':sorted(int(x) for x in fam.required_pitch_classes),
        'pitch_classes':sorted(int(x) for x in fam.pitch_classes),
        'function':fam.function,
        'candidate_type':state.accompaniment.candidate_type,
        'tone_roles':list(state.accompaniment.tone_roles),
    }


def _next_accompaniment(rows: list[dict], current: dict) -> dict | None:
    cur_on=float(current['onset']); cur_pitch=int(current['pitch_midi'])
    later=[r for r in rows if float(r['onset']) > cur_on+1e-6 and float(r['onset']) <= cur_on+max(1.5,float(current['duration'])+0.5)]
    if not later: return None
    later.sort(key=lambda r:(float(r['onset']),abs(int(r['pitch_midi'])-cur_pitch)))
    return later[0]


def _source_has_similar_collision(source_melody: TrackData, source_accompaniment: TrackData, row: dict, melody_row: dict, shift: int = 0) -> bool:
    # Conservative provenance hint only: same accompaniment pitch class and same
    # melody pitch class overlapping near the same absolute onset in source.
    for a in source_accompaniment.notes:
        if (a.pitch.midi + shift)%12 != int(row['pitch_midi'])%12: continue
        ar={'onset':a.start,'duration':a.duration}
        for m in source_melody.notes:
            if (m.pitch.midi + shift)%12 != int(melody_row['pitch_midi'])%12: continue
            mr={'onset':m.start,'duration':m.duration}
            if _overlap(ar,mr)>1e-6 and abs(float(a.start)-float(row['onset'])) <= 0.25:
                return True
    return False


def _backbone_melody_rows(melody_backbone) -> list[dict]:
    rows=[]
    if melody_backbone is None:
        return rows
    for e in melody_backbone.events:
        rows.append({
            "event_id": e.structural_event_id,
            "measure": e.measure,
            "onset": _r(e.attack),
            "duration": _r(e.release-e.attack),
            "pitch_midi": int(e.midi_pitch),
            "pitch": _pitch_name(int(e.midi_pitch)),
        })
    return rows


def _in_memory_accompaniment_rows(joint_result) -> list[dict]:
    rows=[]; seen=set()
    for state in getattr(joint_result,"selected",()) or ():
        for cand in getattr(getattr(state,"accompaniment",None),"notes",()) or ():
            n=cand.note
            key=(getattr(n,"source_event_id",None),round(float(n.start),9),round(float(n.duration),9),int(n.pitch.midi),cand.string,cand.fret)
            if key in seen:
                continue
            seen.add(key)
            rows.append({
                "event_id": getattr(n,"source_event_id",None),
                "measure": n.measure,
                "onset": _r(n.start),
                "duration": _r(n.duration),
                "pitch_midi": int(n.pitch.midi),
                "pitch": _pitch_name(int(n.pitch.midi)),
                "string": cand.string,
                "fret": cand.fret,
            })
    return rows


def build_dissonance_diagnostics(*, source_melody: TrackData, source_accompaniment: TrackData,
                                  joint_result, exported_musicxml: str | Path | None = None,
                                  input_route: str, total_semitone_shift: int = 0,
                                  export_recovery_events: list[dict] | None = None,
                                  melody_backbone=None) -> dict:
    # v0.13.5.13.3: observer-only analysis uses the same immutable melody
    # clock and in-memory Final events as Fingering/Final validation.
    # The exported XML is not reparsed into a second timing authority.
    melody=_backbone_melody_rows(melody_backbone)
    if not melody:
        melody=[{
            "event_id":n.source_event_id, "measure":n.measure,
            "onset":_r(n.start), "duration":_r(n.duration),
            "pitch_midi":int(n.pitch.midi+total_semitone_shift),
            "pitch":_pitch_name(int(n.pitch.midi+total_semitone_shift)),
        } for n in source_melody.notes]
    accomp=_in_memory_accompaniment_rows(joint_result)
    expected_accompaniment_count=len(accomp)
    dropped_ids=set()
    extraction_issues=[]
    if not melody:
        extraction_issues.append("LOCKED_MELODY_BACKBONE_EMPTY")
    issues=[]; severity_counts=defaultdict(int); cause_counts=defaultdict(int)
    measure_starts=source_melody.measure_starts

    for ai,a in enumerate(accomp):
        overlaps=[(m,_overlap(a,m)) for m in melody if _overlap(a,m)>1e-6]
        if not overlaps:
            continue
        for m,overlap_dur in overlaps:
            semitones=abs(int(a['pitch_midi'])-int(m['pitch_midi']))
            base=_base_interval_risk(semitones)
            state,inside=_harmony_at(joint_result,float(a['onset']))
            harm=_harmony_dict(state)
            pc=int(a['pitch_midi'])%12
            chord_tone=(pc in harm['pitch_classes']) if harm else None
            required=(pc in harm['required_pitch_classes']) if harm else None
            metric,local=_metrical_strength(float(a['onset']),measure_starts.get(a.get('measure'),0.0))
            score=base
            reasons=[]
            if base:
                reasons.append(f"{_interval_label(semitones)}_MELODY_COLLISION")
            if chord_tone is False:
                score+=2.0; reasons.append('ACCOMPANIMENT_NON_CHORD_TONE')
            if metric in ('STRONG_BEAT','BEAT'):
                score+=1.0; reasons.append('METRICALLY_EXPOSED')
            if overlap_dur >= 0.5:
                score+=1.0; reasons.append('SUSTAINED_OVERLAP')
            # Close-register conflicts are more audible than remote compounds.
            if 0 < semitones <= 2:
                score+=1.0; reasons.append('SAME_REGISTER_CLOSE_INTERVAL')
            nxt=_next_accompaniment(accomp,a)
            resolves=False
            resolution=None
            if nxt is not None and chord_tone is False:
                move=abs(int(nxt['pitch_midi'])-int(a['pitch_midi']))
                nstate,_=_harmony_at(joint_result,float(nxt['onset']))
                nh=_harmony_dict(nstate)
                npc=int(nxt['pitch_midi'])%12
                if move in (1,2) and nh and npc in nh['pitch_classes']:
                    resolves=True; score=max(0.0,score-2.0); reasons.append('STEPWISE_RESOLUTION')
                    resolution=f"{a['pitch']} -> {nxt['pitch']}"
            if base <= 0 and chord_tone is not False:
                continue
            if score < 2.5:
                severity='LOW'
            elif score < 5.0:
                severity='REVIEW'
            elif score < 8.0:
                severity='HIGH'
            else:
                severity='VERY_HIGH'
            # Avoid flooding the review queue with weak theoretical non-chord tones.
            if severity == 'LOW':
                continue
            if chord_tone is True and base>0:
                cause='VOICING_COLLISION'
            elif chord_tone is False and not resolves:
                cause='UNRESOLVED_NON_CHORD_TONE'
            elif chord_tone is False and resolves:
                cause='LIKELY_PASSING_OR_NEIGHBOR_TONE'
            else:
                cause='INTERVAL_COLLISION_REVIEW'
            source_like=_source_has_similar_collision(source_melody,source_accompaniment,a,m,total_semitone_shift)
            suggestions=[]
            if cause=='VOICING_COLLISION':
                suggestions=[f"Try octave-displacing {a['pitch']} away from melody while preserving pitch class.",
                             f"If optional/doubled, remove {a['pitch']} before changing harmony."]
            elif cause=='UNRESOLVED_NON_CHORD_TONE':
                suggestions=[f"Check whether {a['pitch']} is intended passing/suspension tone; no clear stepwise resolution was found.",
                             "Prefer a nearby chord tone or remove the optional accompaniment tone before changing the chord family."]
            else:
                suggestions=["Listen with the flagged melody/accompaniment pair soloed; preserve it if the tension resolves intentionally."]
            issue={
                'issue_id':f"DIS-{len(issues)+1:04d}",
                'severity':severity,
                'score':round(score,2),
                'measure':a.get('measure'),
                'beat_quarters':_r(local),
                'absolute_onset':a['onset'],
                'overlap_duration':_r(overlap_dur),
                'melody_pitch':m['pitch'],
                'melody_midi':m['pitch_midi'],
                'accompaniment_pitch':a['pitch'],
                'accompaniment_midi':a['pitch_midi'],
                'interval_semitones':semitones,
                'interval':_interval_label(semitones),
                'cause':cause,
                'reasons':reasons,
                'chord_tone':chord_tone,
                'required_chord_tone':required,
                'metrical_class':metric,
                'resolution_detected':resolves,
                'resolution':resolution,
                'harmony':harm,
                'window_alignment_exact':inside,
                'source_has_similar_pitch_class_collision':source_like,
                'provenance_hint':('SOURCE_ORIGINAL_MAY_ALREADY_CONTAIN_TENSION' if source_like else 'FINAL_REALIZATION_SPECIFIC_OR_NOT_FOUND_IN_SOURCE'),
                'suggested_repairs':suggestions,
                'human_review':'UNREVIEWED',
                'human_note':'',
            }
            issues.append(issue); severity_counts[severity]+=1; cause_counts[cause]+=1

    # v0.13.5.12.4: tied/split melody notation can cause the same sounding
    # collision to be observed more than once.  Review one musical collision
    # once, while preserving how many notation segments produced it.
    dedup={}
    for row in issues:
        h=row.get('harmony') or {}
        key=(row.get('measure'),_r(row.get('absolute_onset',0.0)),row.get('melody_midi'),row.get('accompaniment_midi'),h.get('window_id'),row.get('cause'))
        prev=dedup.get(key)
        if prev is None or float(row.get('score',0)) > float(prev.get('score',0)):
            base=dict(row); base['duplicate_observation_count']=1 if prev is None else int(prev.get('duplicate_observation_count',1))+1
            dedup[key]=base
        else:
            prev['duplicate_observation_count']=int(prev.get('duplicate_observation_count',1))+1
            prev['overlap_duration']=max(float(prev.get('overlap_duration',0)),float(row.get('overlap_duration',0)))
    raw_issue_count=len(issues)
    issues=list(dedup.values())
    severity_counts=defaultdict(int); cause_counts=defaultdict(int)
    for row in issues:
        severity_counts[row['severity']]+=1; cause_counts[row['cause']]+=1
    issues.sort(key=lambda x:(-x['score'],x['absolute_onset'],x['accompaniment_midi']))
    for i,row in enumerate(issues,1): row['review_rank']=i; row['issue_id']=f"DIS-{i:04d}"
    return {
        'version':VERSION,
        'status':('INCOMPLETE' if extraction_issues else ('REVIEW' if issues else 'PASS')),
        'diagnostic_self_validation':{
            'status':'INCOMPLETE' if extraction_issues else 'PASS',
            'issues':extraction_issues,
            'timing_authority':'LOCKED_MELODY_BACKBONE',
            'event_source':'IN_MEMORY_FINAL_RESULT',
            'expected_in_memory_accompaniment_count':expected_accompaniment_count,
            'recovery_dropped_unique_event_count':0,
            'extracted_accompaniment_count':len(accomp),
            'extracted_melody_count':len(melody),
        },
        'input_route':input_route,
        'expected_pitch_shift':total_semitone_shift,
        'semantics':'ADVISORY_HARMONIC_COLLISION_DIAGNOSTIC_ONLY; uses validated in-memory Final events on the Locked Melody Backbone clock; exported XML is not reparsed as a second timing authority.',
        'issue_count':len(issues),
        'raw_observation_count':raw_issue_count,
        'severity_counts':dict(severity_counts),
        'cause_counts':dict(cause_counts),
        'issues':issues[:500],
        'interpretation':[
            'Chord-valid notes can still be flagged when their register collides with the melody.',
            'Non-chord tones are downgraded when a simple stepwise resolution is detected.',
            'SOURCE_ORIGINAL_MAY_ALREADY_CONTAIN_TENSION is a provenance hint, not proof that the final voicing is correct.',
            'Repair priority: preserve harmony -> octave/revoice -> remove optional doubling -> reduce texture -> change harmony last.',
        ],
    }


def write_dissonance_diagnostics(data: dict, *, debug_dir: str | Path, output_dir: str | Path) -> tuple[Path,Path]:
    debug=Path(debug_dir); out=Path(output_dir); debug.mkdir(parents=True,exist_ok=True); out.mkdir(parents=True,exist_ok=True)
    jp=debug/'21_DISSONANCE_DIAGNOSTICS.json'; mp=out/'11_DISSONANCE_DIAGNOSTICS.md'
    jp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=[f'# GSTE {VERSION} Dissonance Diagnostics','',
           '> Diagnostic only. A flagged dissonance is a listening/review target, not an automatic musical error.','',
           f"- Route: **{data['input_route']}**",f"- Review issues: **{data['issue_count']}**",f"- Severity: `{data['severity_counts']}`",'',
           '| Rank | ID | Measure | Beat | Melody | Accomp | Interval | Harmony | Cause | Severity |','|---:|---|---:|---:|---|---|---|---|---|---|']
    for x in data['issues'][:100]:
        h=x.get('harmony') or {}; htxt=(h.get('root','?')+str(h.get('quality',''))) if h else '?'
        lines.append(f"| {x['review_rank']} | {x['issue_id']} | {x['measure']} | {x['beat_quarters']} | {x['melody_pitch']} | {x['accompaniment_pitch']} | {x['interval']} | {htxt} | {x['cause']} | {x['severity']} |")
    if data.get('status')=='INCOMPLETE': lines.append('| — | — | — | — | — | — | — | — | DIAGNOSTIC_EXTRACTION | INCOMPLETE |')
    elif not data['issues']: lines.append('| — | — | — | — | — | — | — | — | — | PASS |')
    lines += ['','## Review guidance','','Prioritize `VERY_HIGH` and `HIGH`, then compare the flagged pair with the original source. For chord-valid collisions, try register/voicing changes before altering harmony.','','## Top issue details','']
    for x in data['issues'][:20]:
        lines += [f"### {x['issue_id']} — M{x['measure']} beat {x['beat_quarters']}",f"- Pair: **{x['melody_pitch']} / {x['accompaniment_pitch']} ({x['interval']})**",f"- Cause: **{x['cause']}**, score={x['score']}",f"- Source provenance hint: `{x['provenance_hint']}`",f"- Reasons: {', '.join(x['reasons']) or '—'}",f"- Suggested: {' '.join(x['suggested_repairs'])}",'']
    mp.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return jp,mp
