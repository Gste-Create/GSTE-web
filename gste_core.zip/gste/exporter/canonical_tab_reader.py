from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path


def _local_name(tag: str) -> str:
    return tag.split('}', 1)[-1]


def parse_musicxml_root(source: str | Path | ET.Element) -> ET.Element:
    """Return a namespace-normalized MusicXML root for read-only diagnostics."""
    if isinstance(source, ET.Element):
        root = source
    else:
        root = ET.parse(source).getroot()
    for element in root.iter():
        element.tag = _local_name(element.tag)
    return root


def canonical_tab_part(root: ET.Element) -> ET.Element:
    """Return the one authoritative TAB part.

    V7.1+ public/internal export: P2 is the canonical TAB authority and P1 is a
    silent Standard display copy.  Legacy exports used one part with TAB on
    staff 2; in that format the part itself is returned and callers may filter
    canonical notes with ``is_canonical_tab_note``.
    """
    parts = root.findall('part')
    if not parts:
        raise ValueError('CANONICAL_TAB_READER_NO_PART')

    by_id = {p.get('id', ''): p for p in parts}
    if 'P2' in by_id:
        # Verify P2 is actually declared as TAB when a part-list is available.
        score_part = root.find("part-list/score-part[@id='P2']")
        name = (score_part.findtext('part-name') if score_part is not None else '') or ''
        if not name or 'TAB' in name.upper():
            return by_id['P2']

    # Compatibility fallback for older files: identify an explicit TAB-named part.
    for score_part in root.findall('part-list/score-part'):
        name = (score_part.findtext('part-name') or '').upper()
        if 'TAB' in name and score_part.get('id') in by_id:
            return by_id[score_part.get('id')]

    # Legacy one-part/two-staff representation.
    return parts[0]


def is_canonical_tab_note(note: ET.Element, part: ET.Element, root: ET.Element) -> bool:
    """True for notes belonging to the canonical TAB lane across old/new formats."""
    if note.find('rest') is not None:
        return False
    if part.get('id') == 'P2':
        return True
    # Legacy one-part/two-staff: staff 2 is TAB; one-staff historical exports
    # without <staff> remain authoritative for compatibility.
    staff = (note.findtext('staff') or '').strip()
    if staff == '1' and (note.get('dynamics') or '').strip() == '0':
        return False
    return staff in ('', '2')
