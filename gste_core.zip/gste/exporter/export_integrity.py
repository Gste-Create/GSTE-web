from __future__ import annotations

from collections import Counter
from pathlib import Path
import json
import xml.etree.ElementTree as ET

from gste.version import VERSION
from gste.parser.physical_timeline import physical_measure_extent
from gste.exporter.canonical_tab_reader import parse_musicxml_root, canonical_tab_part

_EPS = 1e-7
_ACC_MARKER = "GSTE_ACCOMPANIMENT"
_GSTE_META_NS = "https://gste.local/musicxml/metadata"


def _gste_attr(name: str) -> str:
    return f"{{{_GSTE_META_NS}}}{name}"


def _midi(note: ET.Element) -> int | None:
    pitch = note.find("pitch")
    if pitch is None:
        return None
    step = pitch.findtext("step")
    octave = pitch.findtext("octave")
    if not step or octave is None:
        return None
    base = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}[step]
    alter = int(float(pitch.findtext("alter", "0")))
    return (int(octave) + 1) * 12 + base + alter


def _event_id(note: ET.Element) -> str:
    return (
        note.get(_gste_attr("event-id"))
        or note.findtext("notations/other-notation[@type='gste-event-id']")
        or ""
    ).strip()


def _is_generated_accompaniment(note: ET.Element) -> bool:
    if (note.get(_gste_attr("generated-accompaniment")) or "").lower() == "true":
        return True
    return any((x.text or "").strip() == _ACC_MARKER for x in note.findall("notations/technical/other-technical"))


def _technical(note: ET.Element) -> tuple[int | None, int | None]:
    s = note.findtext("notations/technical/string")
    f = note.findtext("notations/technical/fret")
    return (int(s) if s is not None else None, int(f) if f is not None else None)


def _reparse_tab_melody(path: str | Path, expected_ids: set[str] | None = None) -> list[dict]:
    """Independently reparse written TAB and collapse explicit XML tie segments.

    One Final Canonical Event may require multiple MusicXML <note> segments at
    notation boundaries.  Explicit tie start/stop markers are representation
    syntax, so the verifier reconstructs the single sounding interval before
    comparing it with the frozen serializer manifest.  No tie is inferred.
    """
    root = parse_musicxml_root(path)
    try:
        tab = canonical_tab_part(root)
    except ValueError as exc:
        raise ValueError("EXPORT_INTEGRITY_NO_TAB_PART") from exc

    rows: list[dict] = []
    active_ties: dict[tuple[str, int], dict] = {}
    divisions = 1
    beats, beat_type = 4, 4
    absolute_measure_start = 0.0
    for physical_measure, measure in enumerate(tab.findall("measure"), start=1):
        attrs = measure.find("attributes")
        if attrs is not None:
            if attrs.findtext("divisions"):
                divisions = max(1, int(float(attrs.findtext("divisions"))))
            time = attrs.find("time")
            if time is not None:
                beats = int(time.findtext("beats", str(beats)))
                beat_type = int(time.findtext("beat-type", str(beat_type)))
        measure_quarters = physical_measure_extent(
            measure, divisions=divisions, expected_quarters=beats * (4.0 / beat_type)
        )
        cursor = 0.0
        last_note_onset = 0.0
        for element in list(measure):
            if element.tag == "backup":
                cursor = max(0.0, cursor - float(element.findtext("duration", "0")) / divisions)
                continue
            if element.tag == "forward":
                cursor += float(element.findtext("duration", "0")) / divisions
                continue
            if element.tag != "note":
                continue
            chord = element.find("chord") is not None
            grace = element.find("grace") is not None
            onset = last_note_onset if chord else cursor
            if not chord:
                last_note_onset = onset
            duration = float(element.findtext("duration", "0")) / divisions
            midi = _midi(element)
            event_id = _event_id(element)
            voice = element.findtext("voice", "1")
            tie_start = element.find("tie[@type='start']") is not None or element.find("notations/tied[@type='start']") is not None
            tie_stop = element.find("tie[@type='stop']") is not None or element.find("notations/tied[@type='stop']") is not None
            if midi is not None and event_id and not _is_generated_accompaniment(element) and not grace:
                string, fret = _technical(element)
                attack = absolute_measure_start + onset
                release = attack + duration
                key = (str(voice), int(midi))
                head = active_ties.get(key) if tie_stop else None
                if head is not None and (expected_ids is None or event_id not in expected_ids):
                    # Explicit tie continuation: extend the already observed
                    # Canonical sounding event; the continuation's source ID is
                    # representation identity only and is not emitted as a ghost.
                    head["release"] = release
                    head["notation_segment_count"] = int(head.get("notation_segment_count", 1)) + 1
                    head["tie_continuation_count"] = int(head.get("tie_continuation_count", 0)) + 1
                    if tie_start:
                        active_ties[key] = head
                    else:
                        active_ties.pop(key, None)
                else:
                    row = {
                        "structural_event_id": event_id,
                        "midi_pitch": midi,
                        "attack": attack,
                        "release": release,
                        "string": string,
                        "fret": fret,
                        "physical_measure": physical_measure,
                        "notation_segment_count": 1,
                        "tie_continuation_count": 0,
                    }
                    rows.append(row)
                    if tie_start:
                        active_ties[key] = row
            if not chord and not grace:
                cursor += duration
        absolute_measure_start += measure_quarters
    return rows


def verify_exported_musicxml_against_manifest(
    exported_musicxml: str | Path,
    serializer_manifest: list[dict],
    *,
    report_path: str | Path | None = None,
) -> dict:
    """Hard, read-only round-trip measurement of Final melody -> written XML.

    The serializer manifest is captured from the frozen Final Arrangement while
    writing. The written TAB part is independently reparsed from disk. Nothing
    is repaired: any missing/ghost/mutated event is a hard export failure.
    """
    expected = {str(r["structural_event_id"]): r for r in serializer_manifest}
    actual_rows = _reparse_tab_melody(exported_musicxml, set(expected))
    counts = Counter(str(r["structural_event_id"]) for r in actual_rows)
    actual = {str(r["structural_event_id"]): r for r in actual_rows if counts[str(r["structural_event_id"])] == 1}

    duplicate_ids = sorted(k for k, n in counts.items() if n != 1)
    missing_ids = sorted(set(expected) - set(counts))
    ghost_ids = sorted(set(counts) - set(expected))
    mutations: list[dict] = []
    for event_id in sorted(set(expected) & set(actual)):
        e, a = expected[event_id], actual[event_id]
        fields = {}
        if int(e["midi_pitch"]) != int(a["midi_pitch"]):
            fields["midi_pitch"] = {"expected": int(e["midi_pitch"]), "actual": int(a["midi_pitch"])}
        for key in ("attack", "release"):
            if abs(float(e[key]) - float(a[key])) > _EPS:
                fields[key] = {"expected": float(e[key]), "actual": float(a[key])}
        for key in ("string", "fret"):
            ev = int(e[key]) if e.get(key) is not None else None
            av = int(a[key]) if a.get(key) is not None else None
            if ev != av:
                fields[key] = {"expected": ev, "actual": av}
        if fields:
            mutations.append({"event_id": event_id, "fields": fields})

    status = "PASS" if not (duplicate_ids or missing_ids or ghost_ids or mutations) else "FAIL"
    report = {
        "version": VERSION,
        "status": status,
        "semantics": "READ_ONLY_ROUND_TRIP: frozen Final serializer manifest vs independently reparsed written TAB MusicXML; no repair or fallback.",
        "expected_event_count": len(expected),
        "reparsed_event_count": len(actual_rows),
        "missing_event_count": len(missing_ids),
        "ghost_event_count": len(ghost_ids),
        "duplicate_event_id_count": len(duplicate_ids),
        "mutation_count": len(mutations),
        "missing_event_ids": missing_ids[:50],
        "ghost_event_ids": ghost_ids[:50],
        "duplicate_event_ids": duplicate_ids[:50],
        "mutations": mutations[:50],
        "checked_fields": ["structural_event_id", "midi_pitch", "attack", "release", "string", "fret"],
        "privacy_safe_event_round_trip": [
            {
                "source_event_id": eid,
                "requested_onset": float(expected[eid]["attack"]),
                "requested_release": float(expected[eid]["release"]),
                "actual_onset": float(actual[eid]["attack"]) if eid in actual else None,
                "actual_release": float(actual[eid]["release"]) if eid in actual else None,
                "notation_segment_count": int(actual[eid].get("notation_segment_count", 0)) if eid in actual else 0,
                "tie_continuation_count": int(actual[eid].get("tie_continuation_count", 0)) if eid in actual else 0,
                "contract": ("PASS" if eid in actual and abs(float(expected[eid]["attack"])-float(actual[eid]["attack"])) <= _EPS and abs(float(expected[eid]["release"])-float(actual[eid]["release"])) <= _EPS else ("MISSING" if eid not in actual else "TIMING_MUTATION")),
            } for eid in sorted(expected)
        ],
    }
    if report_path is not None:
        p = Path(report_path); p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    if status != "PASS":
        first = (mutations[0] if mutations else (missing_ids or ghost_ids or duplicate_ids or ["UNKNOWN"])[0])
        raise ValueError(f"EXPORT_INTEGRITY_FAILED: {first}; see {report_path or 'report'}")
    return report
