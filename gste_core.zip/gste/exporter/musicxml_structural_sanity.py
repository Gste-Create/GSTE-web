from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import json
import xml.etree.ElementTree as ET


_ALLOWED_DYNAMICS = {
    "p","pp","ppp","pppp","ppppp","pppppp",
    "f","ff","fff","ffff","fffff","ffffff",
    "mp","mf","sf","sfp","sfpp","fp","rf","rfz","sfz","sffz","fz","pf","sfzp",
    "other-dynamics",
}
_ALLOWED_MEASURE_CHILDREN = {
    "attributes","note","backup","forward","direction","harmony","figured-bass","print","sound","barline","grouping","link","bookmark",
}
_ALLOWED_DIRECTION_TYPE_CHILDREN = {
    "rehearsal","segno","words","coda","wedge","dynamics","dashes","bracket","pedal","metronome","octave-shift","harp-pedals","damp","damp-all","eyeglasses","string-mute","scordatura","image","principal-voice","percussion","accordion-registration","staff-divide","other-direction","symbol","metronome-arrows",
}


@dataclass(frozen=True)
class StructuralIssue:
    severity: str
    code: str
    path: str
    detail: str


def _strip_ns(tag: str) -> str:
    return tag.split('}', 1)[-1] if '}' in tag else tag


def normalize_playback_hazards(root: ET.Element) -> list[dict]:
    """Normalize known notation constructs that are XML-valid but playback-fragile.

    Some source scores contain ``<dynamics><n/></dynamics>``.  It is retained by
    GSTE's source-skeleton serializer and has caused MuseScore playback to stop
    at the following measures in regression material.  Preserve the visible
    intent as generic dynamic text rather than silently deleting it.
    """
    changes: list[dict] = []
    for dynamics in root.findall('.//dynamics'):
        for child in list(dynamics):
            tag = _strip_ns(child.tag)
            if tag == 'n':
                idx = list(dynamics).index(child)
                dynamics.remove(child)
                repl = ET.Element('other-dynamics')
                repl.text = 'n'
                dynamics.insert(idx, repl)
                changes.append({"code":"NORMALIZED_DYNAMIC_N", "detail":"<dynamics><n/></dynamics> -> <other-dynamics>n</other-dynamics>"})
    return changes



def _notation_ticks(note: ET.Element, divisions: int) -> float | None:
    """Return the MusicXML notated duration in division ticks when spellable.

    This is intentionally independent from <duration>: MuseScore uses type/dot/
    time-modification semantics too, so both representations must agree.
    """
    kind = note.findtext("type")
    if not kind:
        return None
    quarter_units = {
        "whole": 4.0, "half": 2.0, "quarter": 1.0, "eighth": 0.5,
        "16th": 0.25, "32nd": 0.125, "64th": 0.0625, "128th": 0.03125,
        "256th": 0.015625,
    }.get(kind)
    if quarter_units is None:
        return None
    value = quarter_units * divisions
    add = value / 2.0
    for _ in note.findall("dot"):
        value += add; add /= 2.0
    tm = note.find("time-modification")
    if tm is not None:
        try:
            actual = int(tm.findtext("actual-notes", "0")); normal = int(tm.findtext("normal-notes", "0"))
            if actual > 0 and normal > 0:
                value *= normal / actual
        except ValueError:
            return None
    return value

def inspect_musicxml_structure(root: ET.Element) -> list[StructuralIssue]:
    issues: list[StructuralIssue] = []
    root_tag = _strip_ns(root.tag)
    if root_tag not in {"score-partwise", "score-timewise"}:
        issues.append(StructuralIssue("ERROR","BAD_ROOT","/",f"unexpected root <{root_tag}>"))
    if root.find('part-list') is None:
        issues.append(StructuralIssue("ERROR","MISSING_PART_LIST","/","MusicXML requires part-list"))
    if not root.findall('part'):
        issues.append(StructuralIssue("ERROR","MISSING_PART","/","score contains no part"))

    # MusicXML is order-sensitive.  ElementTree can parse a document that is
    # well-formed XML while the document is still invalid MusicXML.  In a
    # score-partwise document, <work> must precede movement/identification/
    # defaults/credits/part-list, and <part-list> must precede every <part>.
    if root_tag == "score-partwise":
        order = {
            "work": 0, "movement-number": 1, "movement-title": 2,
            "identification": 3, "defaults": 4, "credit": 5,
            "part-list": 6, "part": 7,
        }
        last_rank = -1
        last_tag = None
        for child in list(root):
            tag = _strip_ns(child.tag)
            rank = order.get(tag)
            if rank is None:
                continue
            if rank < last_rank:
                issues.append(StructuralIssue(
                    "ERROR", "ROOT_ELEMENT_ORDER_INVALID", "/",
                    f"<{tag}> appears after <{last_tag}>; score-partwise top-level element order is invalid",
                ))
                break
            last_rank = rank
            last_tag = tag

    for pi, part in enumerate(root.findall('part'), start=1):
        for mi, measure in enumerate(part.findall('measure'), start=1):
            mlabel = measure.get('number') or str(mi)
            base = f"/part[{pi}]/measure[{mlabel}]"
            for child in list(measure):
                tag = _strip_ns(child.tag)
                if tag not in _ALLOWED_MEASURE_CHILDREN:
                    issues.append(StructuralIssue("ERROR","UNEXPECTED_MEASURE_ELEMENT",base,f"unexpected <{tag}>"))
            divisions = int(measure.findtext('attributes/divisions') or 0)
            if divisions <= 0:
                # divisions normally persists from prior measures; recover it from the part.
                prior = None
                for candidate_measure in part.findall('measure'):
                    if candidate_measure is measure: break
                    raw_div = candidate_measure.findtext('attributes/divisions')
                    if raw_div: prior = int(raw_div)
                divisions = prior or 1
            for ni, note in enumerate(measure.findall('note'), start=1):
                nbase = f"{base}/note[{ni}]"
                has_rest = note.find('rest') is not None
                has_pitch = note.find('pitch') is not None
                has_unpitched = note.find('unpitched') is not None
                if sum((has_rest, has_pitch, has_unpitched)) != 1:
                    issues.append(StructuralIssue("ERROR","NOTE_BODY_INVALID",nbase,"note must contain exactly one of pitch/rest/unpitched"))
                if note.find('grace') is None:
                    duration = note.findtext('duration')
                    if duration is None:
                        issues.append(StructuralIssue("ERROR","MISSING_DURATION",nbase,"non-grace note has no duration"))
                    else:
                        try:
                            if float(duration) <= 0:
                                issues.append(StructuralIssue("ERROR","NONPOSITIVE_DURATION",nbase,f"duration={duration}"))
                        except ValueError:
                            issues.append(StructuralIssue("ERROR","BAD_DURATION",nbase,f"duration={duration!r}"))
                        else:
                            if note.find('chord') is None:
                                # MusicXML whole-measure rests are duration-driven.  A
                                # <rest measure="yes"> may legitimately omit <type>; it
                                # must not be judged by ordinary note spelling rules.
                                # This exemption is intentionally narrow so generated
                                # fragment rests/tuplets (e.g. the Moonlight M66 case)
                                # still require exact type/dot/time-modification spelling.
                                rest = note.find('rest')
                                is_measure_rest = rest is not None and rest.get('measure') == 'yes'
                                if not is_measure_rest:
                                    notated = _notation_ticks(note, divisions)
                                    if notated is None:
                                        issues.append(StructuralIssue("ERROR","UNSPELLABLE_NOTATED_DURATION",nbase,f"duration={duration} has no exact type/dot/tuplet spelling"))
                                    elif abs(float(duration) - notated) > 1e-6:
                                        issues.append(StructuralIssue("ERROR","NOTATED_DURATION_MISMATCH",nbase,f"duration={duration}, notation_ticks={notated:g}"))
            for tagname in ('backup','forward'):
                for xi, elem in enumerate(measure.findall(tagname), start=1):
                    raw = elem.findtext('duration')
                    try:
                        ok = raw is not None and float(raw) > 0
                    except ValueError:
                        ok = False
                    if not ok:
                        issues.append(StructuralIssue("ERROR",f"BAD_{tagname.upper()}_DURATION",f"{base}/{tagname}[{xi}]",f"duration={raw!r}"))
            for di, dtyp in enumerate(measure.findall('direction/direction-type'), start=1):
                for child in list(dtyp):
                    tag = _strip_ns(child.tag)
                    if tag not in _ALLOWED_DIRECTION_TYPE_CHILDREN:
                        issues.append(StructuralIssue("ERROR","UNEXPECTED_DIRECTION_TYPE_ELEMENT",f"{base}/direction-type[{di}]",f"unexpected <{tag}>"))
                for dyn in dtyp.findall('dynamics'):
                    for child in list(dyn):
                        tag = _strip_ns(child.tag)
                        if tag not in _ALLOWED_DYNAMICS:
                            issues.append(StructuralIssue("ERROR","UNSUPPORTED_DYNAMIC_ELEMENT",f"{base}/direction-type[{di}]/dynamics",f"unsupported <{tag}/>"))
    return issues


def validate_musicxml_tree(root: ET.Element, *, stage: str, report_path: str | Path | None = None, normalized: list[dict] | None = None) -> dict:
    issues = inspect_musicxml_structure(root)
    errors = [asdict(x) for x in issues if x.severity == 'ERROR']
    warnings = [asdict(x) for x in issues if x.severity != 'ERROR']
    report = {
        "stage": stage,
        "status": "PASS" if not errors else "FAIL",
        "normalizations": list(normalized or ()),
        "error_count": len(errors),
        "warning_count": len(warnings),
        "errors": errors,
        "warnings": warnings,
    }
    if report_path is not None:
        path = Path(report_path); path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    if errors:
        first = errors[0]
        raise ValueError(f"MUSICXML_STRUCTURAL_SANITY_FAILED[{stage}]: {first['code']} {first['path']} {first['detail']}")
    return report


def validate_musicxml_file(path: str | Path, *, report_path: str | Path | None = None) -> dict:
    p = Path(path)
    try:
        root = ET.parse(p).getroot()
    except ET.ParseError as exc:
        report = {"stage":"POST_WRITE","status":"FAIL","error_count":1,"warning_count":0,"errors":[{"severity":"ERROR","code":"XML_NOT_WELL_FORMED","path":str(p),"detail":str(exc)}],"warnings":[],"normalizations":[]}
        if report_path is not None:
            rp=Path(report_path); rp.parent.mkdir(parents=True,exist_ok=True); rp.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        raise ValueError(f"MUSICXML_STRUCTURAL_SANITY_FAILED[POST_WRITE]: XML_NOT_WELL_FORMED {exc}") from exc
    return validate_musicxml_tree(root, stage='POST_WRITE', report_path=report_path)
