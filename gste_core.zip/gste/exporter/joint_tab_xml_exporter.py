from __future__ import annotations

from collections import defaultdict
from gste.fingering.canonical_validator import CanonicalHandNote, validate_canonical_timeline, validate_near_identical_attack_groups
from copy import deepcopy
from pathlib import Path
import json
import xml.dom.minidom as minidom
import xml.etree.ElementTree as ET

from gste.parser.physical_timeline import physical_measure_extent
from gste.version import VERSION

from gste.core.tuning import STANDARD_TUNING, Tuning
from gste.core.fretboard import midi_to_string_fret
from gste.joint_arrangement.models import JointArrangementResult
from gste.arrangement.importance import parse_auto_importance
from gste.harmony.library import chord_family_name
from gste.exporter.musicxml_structural_sanity import normalize_playback_hazards, validate_musicxml_tree, validate_musicxml_file
from gste.config.expression import BASS_TONE_ROLES, DEFAULT_VELOCITY_PROFILE, VelocityProfile
from gste.exporter.export_integrity import verify_exported_musicxml_against_manifest

_STEPS = {0:("C",0),1:("C",1),2:("D",0),3:("D",1),4:("E",0),5:("F",0),6:("F",1),7:("G",0),8:("G",1),9:("A",0),10:("A",1),11:("B",0)}
_GSTE_ACCOMPANIMENT_MARKER = "GSTE_ACCOMPANIMENT"
_GSTE_META_NS = "https://gste.local/musicxml/metadata"
ET.register_namespace("gste", _GSTE_META_NS)


def _gste_attr(name: str) -> str:
    return f"{{{_GSTE_META_NS}}}{name}"


def _move_gste_debug_metadata_out_of_notations(root: ET.Element) -> None:
    """Keep GSTE trace markers in standard MusicXML extension elements.

    Older Beta builds moved these markers onto ``<note>`` as namespaced XML
    attributes.  MuseScore 3 validates note attributes strictly and reports
    those attributes as unknown.  ``other-notation`` / ``other-technical`` are
    the MusicXML-defined extension points already used by GSTE and are ignored
    safely by notation applications, while remaining readable by the integrity
    verifier.  Therefore this compatibility hook intentionally performs no
    mutation.
    """
    return None


def _text(parent, tag, value):
    child = ET.SubElement(parent, tag); child.text = str(value); return child


def _strip_namespace(root: ET.Element) -> None:
    for element in root.iter():
        if "}" in element.tag:
            element.tag = element.tag.split("}", 1)[1]


def _set_pitch(note: ET.Element, midi: int) -> None:
    pitch = note.find("pitch")
    if pitch is None:
        pitch = ET.SubElement(note, "pitch")
    for child in list(pitch):
        pitch.remove(child)
    step, alter = _STEPS[midi % 12]
    _text(pitch, "step", step)
    if alter:
        _text(pitch, "alter", alter)
    _text(pitch, "octave", midi // 12 - 1)


def _set_technical(note: ET.Element, string: int, fret: int) -> None:
    notations = note.find("notations")
    if notations is None:
        notations = ET.SubElement(note, "notations")
    technical = notations.find("technical")
    if technical is None:
        technical = ET.SubElement(notations, "technical")
    for tag in ("string", "fret"):
        old = technical.find(tag)
        if old is not None:
            technical.remove(old)
    _text(technical, "string", string)
    _text(technical, "fret", fret)



def _set_event_id_marker(note: ET.Element, event_id: str) -> None:
    notations = note.find("notations")
    if notations is None:
        notations = ET.SubElement(note, "notations")
    marker = notations.find("other-notation[@type='gste-event-id']")
    if marker is None:
        marker = ET.SubElement(notations, "other-notation", type="gste-event-id")
    marker.text = str(event_id)


def _normalize_score_divisions(score: ET.Element, target_divisions: int = 16800) -> None:
    """Use one high-resolution integer timebase for source + generated voices.

    Internal arrangement timing can contain sub-quarter attacks that a low-
    division source score (e.g. divisions=1) cannot serialize faithfully.  The
    old exporter rounded those rests/durations, so reparsing produced a
    different performance timeline and false physical violations.  Scale every
    timed MusicXML duration/backup/forward into one canonical division count
    before accompaniment is written.
    """
    for part in score.findall("part"):
        inherited_divisions = 1
        for measure in part.findall("measure"):
            attrs = measure.find("attributes")
            local_divisions = inherited_divisions
            if attrs is not None and attrs.findtext("divisions"):
                local_divisions = max(1, int(float(attrs.findtext("divisions"))))
            scale = float(target_divisions) / float(local_divisions)
            if abs(scale - 1.0) > 1e-12:
                for element in measure.iter():
                    if element.tag not in {"duration"} or not (element.text or "").strip():
                        continue
                    try:
                        old = float(element.text)
                    except ValueError:
                        continue
                    element.text = str(max(0, int(round(old * scale))))
            if attrs is None:
                attrs = ET.Element("attributes")
                measure.insert(0, attrs)
            div = attrs.find("divisions")
            if div is None:
                div = ET.SubElement(attrs, "divisions")
            div.text = str(target_divisions)
            inherited_divisions = local_divisions

def _midi_from_note(note: ET.Element) -> int | None:
    pitch = note.find("pitch")
    if pitch is None:
        return None
    step = pitch.findtext("step")
    octave = pitch.findtext("octave")
    if not step or octave is None:
        return None
    base = {"C":0,"D":2,"E":4,"F":5,"G":7,"A":9,"B":11}[step]
    alter = int(float(pitch.findtext("alter", "0")))
    return (int(octave) + 1) * 12 + base + alter


def _duration_notation(duration: int, divisions: int) -> tuple[str | None, int, tuple[int, int, str] | None]:
    """Return an *exact* MusicXML notation for ``duration`` when possible.

    Never label an arbitrary tick duration as the nearest conventional value:
    strict readers compare ``duration`` with ``type``/dots/time-modification.
    Common 3:2 tuplets are represented explicitly.  If no exact spelling is
    available, ``type`` is omitted rather than writing contradictory notation.
    """
    values = [
        (4 * divisions, "whole", 0),
        (3 * divisions, "half", 1),
        (2 * divisions, "half", 0),
        (int(1.5 * divisions), "quarter", 1),
        (divisions, "quarter", 0),
        (int(0.75 * divisions), "eighth", 1),
        (divisions // 2, "eighth", 0),
        (int(0.375 * divisions), "16th", 1),
        (divisions // 4, "16th", 0),
        (divisions // 8, "32nd", 0),
        (divisions // 16, "64th", 0),
        (divisions // 32, "128th", 0),
    ]
    for ticks, kind, dots in values:
        if ticks == duration:
            return kind, dots, None
    # Common triplet values: compare as rational quarter-note fractions so
    # very small types (e.g. 256th) do not lose precision through integer
    # truncation of the normal duration.
    triplet_denominators = [(1, "quarter"), (2, "eighth"), (4, "16th"), (8, "32nd"), (16, "64th"), (32, "128th"), (64, "256th")]
    for denom, kind in triplet_denominators:
        if duration * 3 * denom == divisions * 2:
            return kind, 0, (3, 2, kind)
    # Exact rational tuplets also cover offset rests created by mixed grids.
    # This changes notation only; duration ticks remain immutable.
    from math import gcd
    divisor=gcd(int(duration),int(divisions))
    actual=int(divisions)//divisor; normal=int(duration)//divisor
    if 0 < duration < divisions and actual % 3 == 0 and 0 < actual <= 192 and 0 < normal <= 192:
        return "quarter", 0, (actual,normal,"quarter")
    return None, 0, None


def _decompose_notated_duration(duration: int, divisions: int) -> tuple[int, ...]:
    """Split a compound tick duration into exact conventional note values.

    Representation only: the pieces sum to the immutable sounding duration and
    are reconnected with ties.  No attack/release is moved.
    """
    duration=int(duration)
    if duration <= 0:
        return ()
    if _duration_notation(duration,divisions)[0] is not None:
        return (duration,)
    atoms=set()
    # Enumerate every tick value that the canonical notation helper can spell.
    for ticks in range(1, max(1,4*divisions)+1):
        if _duration_notation(ticks,divisions)[0] is not None:
            atoms.add(ticks)
    atoms=sorted((x for x in atoms if x<=duration),reverse=True)
    # Dynamic programming for an exact sum, preferring fewer/larger pieces.
    best=[None]*(duration+1); best[0]=()
    for total in range(1,duration+1):
        choice=None
        for atom in atoms:
            if atom>total or best[total-atom] is None:
                continue
            cand=best[total-atom]+(atom,)
            if choice is None or len(cand)<len(choice):
                choice=cand
        best[total]=choice
    return best[duration] or ()

def _append_forward(parent: ET.Element, duration: int, voice: int) -> None:
    """Advance a generated notation lane without creating a notated rest.

    MusicXML importers are allowed to reconstruct rhythm from note type/dots/
    tuplets.  For purely invisible lane padding, <forward> avoids artificial
    micro-rest tuplets and keeps the lane cursor exact.
    """
    if duration <= 0:
        return
    forward = ET.SubElement(parent, "forward")
    _text(forward, "duration", int(duration))
    _text(forward, "voice", int(voice))


def _append_rest(parent: ET.Element, duration: int, voice: int, divisions: int) -> None:
    """Append hidden timeline rests without emitting contradictory notation.

    Generated accompaniment can leave a gap such as 2.75 quarter notes.  A
    single MusicXML note cannot describe every such gap with one ``type``/dot
    combination.  The old nearest-value fallback wrote (for example) a 2.75q
    duration as a dotted half (3q), which strict readers reject.  Split gaps
    into exact conventional rest values instead; the summed cursor duration is
    unchanged.
    """
    if duration <= 0:
        return
    values = [
        (4 * divisions, "whole", 0),
        (3 * divisions, "half", 1),
        (2 * divisions, "half", 0),
        (int(1.5 * divisions), "quarter", 1),
        (divisions, "quarter", 0),
        (int(0.75 * divisions), "eighth", 1),
        (divisions // 2, "eighth", 0),
        (int(0.375 * divisions), "16th", 1),
        (divisions // 4, "16th", 0),
        (divisions // 8, "32nd", 0),
        (divisions // 16, "64th", 0),
        (divisions // 32, "128th", 0),
    ]
    remaining = int(duration)
    attrs = {"print-object": "no"} if voice >= 2 else {}
    for ticks, kind, dots in values:
        while ticks > 0 and remaining >= ticks:
            note = ET.SubElement(parent, "note", attrs)
            ET.SubElement(note, "rest")
            _text(note, "duration", ticks)
            _text(note, "voice", voice)
            _text(note, "type", kind)
            for _ in range(dots):
                ET.SubElement(note, "dot")
            remaining -= ticks
    if remaining > 0:
        # v0.1.9: never leave a hidden rest with duration-only notation when an
        # exact tuplet spelling exists. MuseScore can otherwise reconstruct a
        # different notated voice length even though the raw cursor sums.
        kind, dots, triplet = _duration_notation(remaining, divisions)
        note = ET.SubElement(parent, "note", attrs)
        ET.SubElement(note, "rest")
        _text(note, "duration", remaining)
        _text(note, "voice", voice)
        if kind is not None:
            _text(note, "type", kind)
            for _ in range(dots): ET.SubElement(note, "dot")
            if triplet is not None:
                actual, normal, normal_type = triplet
                tm = ET.SubElement(note, "time-modification")
                _text(tm, "actual-notes", actual); _text(tm, "normal-notes", normal); _text(tm, "normal-type", normal_type)


def _mark_generated_accompaniment(note: ET.Element) -> None:
    """Mark exporter-generated accompaniment with a standard MusicXML technical tag.

    Voice numbers alone are not a reliable semantic role marker because source
    scores may legitimately use voice 2.  ``other-technical`` is standard
    MusicXML, ignored visually by MuseScore, and survives serialization long
    enough for the final export-integrity pass to identify accompaniment
    unambiguously.
    """
    notations = note.find("notations")
    if notations is None:
        notations = ET.SubElement(note, "notations")
    technical = notations.find("technical")
    if technical is None:
        technical = ET.SubElement(notations, "technical")
    marker = ET.SubElement(technical, "other-technical")
    marker.text = _GSTE_ACCOMPANIMENT_MARKER


def _note_role(note: ET.Element) -> str:
    markers = [(element.text or "").strip() for element in note.findall("notations/technical/other-technical") if (element.text or "").strip()]
    if _GSTE_ACCOMPANIMENT_MARKER in markers:
        return "accompaniment"
    return "melody"


def _clamp_velocity(value: int, profile: VelocityProfile = DEFAULT_VELOCITY_PROFILE) -> int:
    return max(profile.minimum, min(profile.maximum, int(round(value))))


def _musicxml_dynamics_for_velocity(velocity: int) -> str:
    """Convert MIDI velocity to MusicXML note-level dynamics percentage.

    MusicXML defines 100 as the default forte velocity 90, so an absolute
    velocity V is serialized as V / 90 * 100.  Keep two decimals at most to
    make Engineer Debug / diffs readable.
    """
    value = float(velocity) * 100.0 / 90.0
    return f"{value:.2f}".rstrip("0").rstrip(".")


def _beat_accent_bonus(
    onset_quarters: float, beats: int, beat_type: int, role: str,
    profile: VelocityProfile = DEFAULT_VELOCITY_PROFILE,
) -> int:
    beat_quarters = 4.0 / max(1, int(beat_type))
    if beat_quarters <= 0:
        return 0
    beat_position = onset_quarters / beat_quarters
    nearest = round(beat_position)
    if abs(beat_position - nearest) > 1e-6:
        return 0
    beat_index = int(nearest) % max(1, int(beats))
    if beat_index == 0:
        if role == "melody":
            return profile.melody_strong_beat_bonus
        if role == "bass":
            return profile.bass_strong_beat_bonus
        return profile.accompaniment_strong_beat_bonus
    # In even meters, the halfway beat gets only a very small secondary accent.
    if beats >= 4 and beats % 2 == 0 and beat_index == beats // 2:
        return profile.secondary_beat_bonus
    return 0


def _velocity_for_role(
    role: str, onset_quarters: float, beats: int, beat_type: int,
    profile: VelocityProfile = DEFAULT_VELOCITY_PROFILE,
) -> int:
    base = {
        "melody": profile.melody,
        "bass": profile.bass,
        "accompaniment": profile.accompaniment,
    }.get(role, profile.accompaniment)
    return _clamp_velocity(base + _beat_accent_bonus(onset_quarters, beats, beat_type, role, profile), profile)


def _set_playback_velocity(note: ET.Element, velocity: int) -> None:
    """Attach note-level playback loudness without changing printed notation."""
    note.set("dynamics", _musicxml_dynamics_for_velocity(velocity))


def _append_tab_note(parent: ET.Element, candidate, duration: int, voice: int, divisions: int, *, chord: bool = False, velocity: int | None = None, tie_stop: bool = False, tie_start: bool = False) -> None:
    # A sounding Final Arrangement event must also be an explicitly printable
    # notation object.  Never rely on an application's implicit visibility
    # defaults for generated secondary voices.
    element = ET.SubElement(parent, "note", {"print-object": "yes", "print-spacing": "yes"})
    if chord:
        ET.SubElement(element, "chord")
    _set_pitch(element, candidate.note.pitch.midi)
    _text(element, "duration", duration)
    # MusicXML note child order is schema-significant: <tie> belongs after
    # <duration> and before <voice>.  Keep sounding-event timing untouched;
    # this is serialization order only.
    if tie_stop:
        ET.SubElement(element, "tie", type="stop")
    if tie_start:
        ET.SubElement(element, "tie", type="start")
    _text(element, "voice", voice)
    kind, dots, tuplet = _duration_notation(duration, divisions)
    if kind is not None:
        _text(element, "type", kind)
        for _ in range(dots):
            ET.SubElement(element, "dot")
        if tuplet is not None:
            actual, normal, normal_type = tuplet
            tm = ET.SubElement(element, "time-modification")
            _text(tm, "actual-notes", actual)
            _text(tm, "normal-notes", normal)
            _text(tm, "normal-type", normal_type)
    # MusicXML note child order requires type/dot/time-modification before stem.
    if voice >= 2:
        _text(element, "stem", "down")
    _set_technical(element, candidate.string, candidate.fret)
    # A barline is notation structure, never a sounding-event boundary.  When a
    # frozen Joint interval crosses a source measure boundary, serialize notation
    # segments connected by ties instead of shortening the canonical duration.
    # The playback <tie> elements were emitted above in schema order; the visual
    # <tied> elements remain inside <notations>.
    if tie_stop or tie_start:
        notations = element.find("notations")
        if notations is None:
            notations = ET.SubElement(element, "notations")
        if tie_stop:
            ET.SubElement(notations, "tied", type="stop")
        if tie_start:
            ET.SubElement(notations, "tied", type="start")
    if velocity is not None:
        _set_playback_velocity(element, velocity)
    if voice >= 2:
        _mark_generated_accompaniment(element)
        event_id = getattr(candidate.note, "source_event_id", None)
        if event_id:
            notations = element.find("notations")
            if notations is None:
                notations = ET.SubElement(element, "notations")
            marker = ET.SubElement(notations, "other-notation", type="gste-event-id")
            marker.text = str(event_id)
            for marker_type, marker_value in (("gste-importance", getattr(candidate.note, "importance", None)), ("gste-arrangement-role", getattr(candidate.note, "arrangement_role", None)), ("gste-source-type", getattr(candidate.note, "source_type", None)), ("gste-source-variant", getattr(candidate.note, "source_variant", None)), ("gste-texture-family", getattr(candidate.note, "texture_family", None))):
                if marker_value is not None:
                    meta = ET.SubElement(notations, "other-notation", type=marker_type)
                    meta.text = str(marker_value)


def _plan_notation_lanes(
    grouped_acc: dict[float, list[tuple[object, str, float, bool, bool]]],
    measure_quarters: float,
    divisions: int,
) -> list[list[tuple[float, float, list[tuple[object, str, float, bool, bool]]]]]:
    """Map frozen accompaniment intervals to deterministic notation lanes.

    This planner is deliberately representation-only.  It never trims a release,
    moves an attack, changes pitch/fingering, or suppresses an event.  Its only
    authority is choosing which MusicXML voice lane carries each attack group.
    """
    lanes: list[list[tuple[float, float, list[tuple[object, str, float, bool, bool]]]]] = []
    lane_ends: list[float] = []
    for onset in sorted(grouped_acc):
        # Simultaneous notes may have different immutable releases. This
        # serializer decomposes one duration per chord group, so put distinct
        # releases into separate voices instead of extending short notes.
        by_duration = {}
        for item in grouped_acc[onset]:
            by_duration.setdefault(round(float(item[2]), 12), []).append(item)
        for duration_q, candidates in sorted(by_duration.items(), reverse=True):
            duration_q = max(duration_q, 1.0 / max(divisions, 1))
            end_q = onset + duration_q
            lane_index = next(
                (i for i, lane_end in enumerate(lane_ends) if lane_end <= onset + 1e-9),
                None,
            )
            if lane_index is None:
                lane_index = len(lanes)
                lanes.append([])
                lane_ends.append(0.0)
            lanes[lane_index].append((onset, duration_q, candidates))
            lane_ends[lane_index] = end_q
    return lanes


def _selected_source_melody_priority_by_event_id(result: JointArrangementResult) -> dict[str, tuple[object, ...]]:
    """Return SOURCE_PIANO priority events that Joint actually selected.

    v0.1.5 ownership contract: role analysis may admit optional RH source events,
    but only Joint selection grants them final ownership.  The immutable
    ``source_event_id`` is the join key back to the original RH MusicXML
    skeleton.  This is route/provenance based, never triplet- or title-specific.
    """
    grouped: dict[str, list[object]] = defaultdict(list)
    for state in result.selected:
        for candidate in state.accompaniment.notes:
            note = candidate.note
            source_type = str(getattr(note, "source_type", "") or "")
            arrangement_role = str(getattr(note, "arrangement_role", "") or "")
            event_id = str(getattr(note, "source_event_id", "") or "")
            # SOURCE_EXACT reaches Joint through the source adapter as
            # source_piano. RH source identity is therefore the authoritative
            # provenance marker; structural melody is carried separately in
            # state.melody and cannot be confused with accompaniment here.
            if not arrangement_role.startswith("melody_priority_"):
                continue
            event_id = str(getattr(note, "source_event_id", "") or "")
            if event_id:
                grouped[event_id].append(candidate)
    return {
        event_id: tuple(sorted(candidates, key=lambda c: (c.note.start, c.note.pitch.midi, c.string, c.fret)))
        for event_id, candidates in grouped.items()
    }


def _canonical_source_priority_release(priority_candidate: object, absolute_onset: float, rep_duration: float) -> float:
    """Resolve the canonical sounding release for a selected RH priority event.

    Grouped priority selections are tuples.  Their candidate notes retain the
    canonical sounding interval even when the source MusicXML head is only the
    first segment of an explicit tie.  Falling back to the head segment duration
    truncates cross-boundary events during export.
    """
    if isinstance(priority_candidate, tuple) and priority_candidate:
        return max(float(candidate.note.start + candidate.note.duration) for candidate in priority_candidate)
    if priority_candidate is not None:
        return float(priority_candidate.note.start + priority_candidate.note.duration)
    return float(absolute_onset + rep_duration)


def _selected_melody_by_event_id(result: JointArrangementResult) -> dict[str, tuple[object, ...]]:
    """Keep every reviewed fingering occurrence for each immutable source id.

    v0.12.6.7 removes the old majority vote.  A fingering accepted by Final
    Review is authoritative and must not be replaced during export merely
    because another repeat occurrence used a different string/fret.
    """
    grouped: dict[str, list[object]] = defaultdict(list)
    for state in result.selected:
        for candidate in state.melody.notes:
            event_id = candidate.note.source_event_id
            if not event_id:
                raise ValueError("final export requires source_event_id on every selected melody note")
            grouped[event_id].append(candidate)
    return {
        event_id: tuple(sorted(candidates, key=lambda c: (c.note.start, c.note.pitch.midi, c.string, c.fret)))
        for event_id, candidates in grouped.items()
    }


def _reviewed_candidate_for_source(
    grouped: dict[str, tuple[object, ...]], event_id: str, absolute_onset: float, expected_midi: int | None,
):
    """Resolve a reviewed melody fingering by immutable structural identity only.

    v0.13.5.13.3 removes onset+MIDI guessing.  ``event_id`` was fixed when
    the melody backbone was created and is the only legal join key between
    parser/extractor, Fingering/Final Review and Serializer.  The onset argument
    is retained for compatibility/diagnostic ordering but never used to infer a
    different event.
    """
    candidates = tuple(
        c for c in grouped.get(event_id, ())
        if expected_midi is None or int(c.note.pitch.midi) == int(expected_midi)
    )
    if not candidates:
        return None
    # Multiple window occurrences may reference the same structural event.
    # They must share the locked pitch/time; Final Review remains authoritative
    # for string/fret.  Prefer the occurrence closest to the locked attack, then
    # deterministic string/fret ordering.
    return min(candidates, key=lambda c: (abs(float(c.note.start) - float(absolute_onset)), c.fret, c.string))


def _fallback_fingering(midi: int, tuning: Tuning):
    """Exact-register melody fallback. Octave rescue is forbidden by v0.13.5.12.6.3."""
    positions = midi_to_string_fret(midi, max_fret=18, tuning=tuning)
    if not positions:
        raise ValueError(f"MELODY_IDENTITY_HARD_LOCK: no exact-register guitar position for melody MIDI {midi}")
    string, fret = min(positions, key=lambda item: (item[1], item[0]))
    return midi, string, fret



def _fallback_fingering_near_reviewed_result(
    midi: int, onset: float, result: JointArrangementResult, tuning: Tuning,
):
    """Place source notes excluded from melody extraction near the reviewed hand.

    Some right-hand source notes are intentionally not part of the extracted
    melody path, so they have no reviewed candidate.  v0.12.6.7 no longer uses
    the globally-lowest-fret fallback; it anchors the fallback to the reviewed
    sounding hand at that onset and lets the downstream export-integrity guard
    reject any remaining conflict.
    """
    # v0.13.5.12.6.3 hard lock: exporter may re-finger, never re-register melody.
    position_options: list[tuple[int, int, int]] = [
        (midi, string, fret) for string, fret in midi_to_string_fret(midi, max_fret=18, tuning=tuning)
    ]
    if not position_options:
        raise ValueError(f"No playable guitar position for source MIDI {midi}")
    active = []
    for state in result.selected:
        for note in (*state.melody.notes, *state.accompaniment.notes):
            if note.note.start <= onset + 1e-6 and note.note.start + note.note.duration > onset + 1e-6:
                active.append(note)
    frets = sorted(note.fret for note in active if note.fret > 0)
    center = 0.0 if not frets else (frets[len(frets)//2] if len(frets) % 2 else (frets[len(frets)//2-1] + frets[len(frets)//2]) / 2.0)
    occupied = {(note.string, note.fret) for note in active}
    occupied_strings = {note.string for note in active}
    output_midi, string, fret = min(
        position_options,
        key=lambda item: (
            1 if item[1] in occupied_strings and (item[1], item[2]) not in occupied else 0,
            abs(item[2] - center) if item[2] > 0 and center > 0 else item[2],
            abs(item[0] - midi), item[2], item[1],
        ),
    )
    return output_midi, string, fret

def _measure_number(measure: ET.Element, fallback: int) -> int:
    text = measure.attrib.get("number")
    try:
        return int(text) if text else fallback
    except ValueError:
        return fallback

def _ensure_tab_attributes(attributes: ET.Element, tuning: Tuning) -> None:
    clef = attributes.find("clef")
    if clef is None:
        clef = ET.SubElement(attributes, "clef")
    for child in list(clef):
        clef.remove(child)
    _text(clef, "sign", "TAB")
    _text(clef, "line", 5)

    details = attributes.find("staff-details")
    if details is not None:
        attributes.remove(details)
    details = ET.SubElement(attributes, "staff-details")
    _text(details, "staff-lines", 6)
    for line, step, octave in tuning.musicxml_staff_tunings():
        st = ET.SubElement(details, "staff-tuning", line=str(line))
        _text(st, "tuning-step", step)
        _text(st, "tuning-octave", octave)


def _restify_note(note: ET.Element) -> None:
    """Turn a timed source note into an equal-duration rest, preserving rhythm notation.

    A previous implementation kept duration/type/dots but discarded
    ``time-modification`` and tuplet notation.  A triplet eighth then became an
    XML contradiction: its duration still meant 1/3 quarter, while ``type``
    alone meant a normal 1/2-quarter eighth.  MuseScore may repair that on
    import, but stricter readers reject the measure.
    """
    duration = note.findtext("duration", "0")
    voice = note.findtext("voice", "1")
    kind = note.findtext("type")
    dots = len(note.findall("dot"))
    staff = note.findtext("staff")
    time_mod = note.find("time-modification")
    time_mod = deepcopy(time_mod) if time_mod is not None else None
    beams = [deepcopy(x) for x in note.findall("beam")]
    source_notations = note.find("notations")
    tuplets = [deepcopy(x) for x in source_notations.findall("tuplet")] if source_notations is not None else []
    event_marker = None
    if source_notations is not None:
        marker = source_notations.find("other-notation[@type='gste-event-id']")
        event_marker = deepcopy(marker) if marker is not None else None

    for child in list(note):
        note.remove(child)
    ET.SubElement(note, "rest")
    _text(note, "duration", duration)
    _text(note, "voice", voice)
    if kind:
        _text(note, "type", kind)
    for _ in range(dots):
        ET.SubElement(note, "dot")
    if time_mod is not None:
        note.append(time_mod)
    for beam in beams:
        note.append(beam)
    if staff:
        _text(note, "staff", staff)
    if tuplets or event_marker is not None:
        notations = ET.SubElement(note, "notations")
        for tuplet in tuplets:
            notations.append(tuplet)
        if event_marker is not None:
            notations.append(event_marker)


def _stamp_stable_structural_event_ids(score: ET.Element, *, track_id: str = "piano_right") -> None:
    """Mirror Source Parser deterministic note serials; never infer identity from music semantics.

    Every original MusicXML <note> receives exactly one serial identity in document
    order. Ties remain notation/music data and never merge or rewrite identities.
    """
    serial = 0
    for measure in score.findall("part/measure"):
        for element in list(measure):
            if element.tag != "note":
                continue
            serial += 1
            _set_event_id_marker(element, f"{track_id}:N{serial:06d}")

def _backbone_map(backbone) -> dict[str, object]:
    if backbone is None:
        return {}
    by_id = getattr(backbone, "by_id", None)
    return by_id() if callable(by_id) else {}



def _standardize_part_for_guitar_notation(part: ET.Element) -> None:
    """Convert a TAB part copy into standard guitar notation.

    Pitch values remain sounding-pitch authoritative; the octave-transposing
    treble clef presents classical-guitar notation one octave above sounding.
    TAB technical string/fret annotations are removed from this copy only.
    """
    for measure in part.findall("measure"):
        attrs = measure.find("attributes")
        if attrs is not None:
            clef = attrs.find("clef")
            if clef is None:
                clef = ET.SubElement(attrs, "clef")
            for child in list(clef):
                clef.remove(child)
            _text(clef, "sign", "G")
            _text(clef, "line", 2)
            _text(clef, "clef-octave-change", -1)
            details = attrs.find("staff-details")
            if details is not None:
                attrs.remove(details)
        for note in measure.findall("note"):
            notations = note.find("notations")
            if notations is None:
                continue
            technical = notations.find("technical")
            if technical is not None:
                notations.remove(technical)
            for marker in list(notations.findall("other-notation")):
                if (marker.get("type") or "").startswith("gste-"):
                    notations.remove(marker)
            if len(notations) == 0:
                note.remove(notations)


def _musicxml_kind(quality: str) -> str:
    return {
        "major": "major",
        "minor": "minor",
        "dominant7": "dominant",
        "maj7": "major-seventh",
        "minor7": "minor-seventh",
        "half_diminished7": "half-diminished",
        "diminished7": "diminished-seventh",
        "sus2": "suspended-second",
        "sus4": "suspended-fourth",
        "diminished": "diminished",
    }.get(quality, "other")


def _append_harmony(measure: ET.Element, family, offset_ticks: int, divisions: int) -> None:
    harmony = ET.Element("harmony")
    root = ET.SubElement(harmony, "root")
    step, alter = _STEPS[int(family.root_pc) % 12]
    _text(root, "root-step", step)
    if alter:
        _text(root, "root-alter", alter)
    kind = ET.SubElement(harmony, "kind")
    kind.text = _musicxml_kind(str(family.quality))
    kind.set("text", chord_family_name(family))
    if offset_ticks:
        _text(harmony, "offset", int(offset_ticks))
    # Harmony objects are independent of the note cursor.  Place them directly
    # after <attributes> so offset is measured from the measure start.
    attrs = measure.find("attributes")
    idx = list(measure).index(attrs) + 1 if attrs is not None else 0
    while idx < len(measure) and measure[idx].tag == "harmony":
        idx += 1
    measure.insert(idx, harmony)


def _add_selected_harmonies_to_part(part: ET.Element, result: JointArrangementResult) -> None:
    """Add chord symbols at the selected harmony attack / measure first beat.

    Joint windows already own canonical absolute starts.  This function never
    re-derives note timing from the serialized XML; it only maps each selected
    harmony attack onto the existing measure grid.
    """
    states = sorted(result.selected, key=lambda s: (float(s.start), int(s.measure), s.window_id))
    measures = part.findall("measure")
    if not measures or not states:
        return
    divisions = 1
    beats = 4
    beat_type = 4
    absolute_start = 0.0
    previous_signature = None
    for measure_index, measure in enumerate(measures, start=1):
        for existing_harmony in list(measure.findall("harmony")):
            measure.remove(existing_harmony)
        attrs = measure.find("attributes")
        if attrs is not None:
            if attrs.findtext("divisions"):
                divisions = int(float(attrs.findtext("divisions")))
            time = attrs.find("time")
            if time is not None:
                beats = int(time.findtext("beats", str(beats)))
                beat_type = int(time.findtext("beat-type", str(beat_type)))
        length_q = beats * (4.0 / beat_type)
        candidates = [s for s in states if absolute_start - 1e-9 <= float(s.start) < absolute_start + length_q - 1e-9]
        for state in candidates:
            family = state.harmony.family
            signature = (int(family.root_pc), str(family.quality))
            # Always mark beat 1 / first harmony of a measure.  Within a measure,
            # only add another symbol when the harmony itself changes.
            rel_q = max(0.0, float(state.start) - absolute_start)
            if rel_q < 1e-8 or signature != previous_signature:
                _append_harmony(measure, family, int(round(rel_q * divisions)), divisions)
                previous_signature = signature
        absolute_start += length_q


def _set_note_staff(note: ET.Element, staff_number: int) -> None:
    staff = note.find("staff")
    if staff is None:
        staff = ET.SubElement(note, "staff")
    staff.text = str(staff_number)


def _make_standard_display_note(tab_note: ET.Element) -> ET.Element:
    """Create the standard-notation display twin of one authoritative TAB note.

    The TAB note remains the sole playback authority.  MusicXML has no portable
    linked-staff primitive, so the display twin is explicitly silent via
    note-level dynamics=0 while retaining printable pitch/rhythm notation.
    This silence is presentation metadata only; canonical role velocities stay
    untouched on the authoritative TAB lane.
    """
    note = deepcopy(tab_note)
    _set_note_staff(note, 1)

    note.set("dynamics", "0")
    notations = note.find("notations")
    if notations is not None:
        technical = notations.find("technical")
        if technical is not None:
            notations.remove(technical)
        for marker in list(notations.findall("other-notation")):
            if (marker.get("type") or "").startswith("gste-") and marker.get("type")!='gste-event-id':
                notations.remove(marker)
        event_marker=notations.find("other-notation[@type='gste-event-id']")
        if event_marker is not None:event_marker.set('type','gste-editor-event-id')
        # Preserve twin ownership until the public sanitizer captures the JSON map.
        ET.SubElement(notations,'other-notation',type='gste-editor-role').text=_note_role(tab_note)
    return note


def _configure_dual_guitar_staves(measure: ET.Element, *, declare_structure: bool) -> None:
    """Normalize attributes for the generated Standard+TAB guitar part.

    The fixed two-staff guitar structure belongs to the part, not to every
    measure.  Declare it once in the first measure.  Later measures keep their
    musical attributes (divisions/key/time/etc.) but must not redundantly
    redeclare staves, clefs, or TAB tuning.  Any surviving <attributes> node is
    moved before the first note so MuseScore never sees a staff redefinition in
    the middle of a measure.
    """
    attrs = measure.find("attributes")
    if attrs is None:
        if not declare_structure:
            return
        attrs = ET.Element("attributes")
        measure.insert(0, attrs)
    else:
        # MusicXML attributes affect following content.  Source files may place
        # them later in a measure; after GSTE changes the score to Standard+TAB,
        # keep the retained attributes before any notes to avoid mid-measure
        # engraving state changes.
        children = list(measure)
        attrs_index = children.index(attrs)
        first_note_index = next((i for i, child in enumerate(children) if child.tag == "note"), len(children))
        if attrs_index > first_note_index:
            measure.remove(attrs)
            first_note = next((child for child in list(measure) if child.tag == "note"), None)
            if first_note is None:
                measure.insert(0, attrs)
            else:
                measure.insert(list(measure).index(first_note), attrs)

    # The generated guitar part has one stable staff structure.  Remove any
    # inherited/repeated source declarations first; only measure 1 recreates it.
    for child in list(attrs):
        if child.tag in {"staves", "clef", "staff-details"}:
            attrs.remove(child)

    if not declare_structure:
        # Keep divisions/key/time/transpose and other genuinely musical
        # attributes.  Remove an empty node rather than emitting XML noise.
        if len(attrs) == 0:
            measure.remove(attrs)
        return

    staves = ET.SubElement(attrs, "staves")
    staves.text = "2"

    standard_clef = ET.SubElement(attrs, "clef", number="1")
    _text(standard_clef, "sign", "G")
    _text(standard_clef, "line", 2)
    _text(standard_clef, "clef-octave-change", -1)
    tab_clef = ET.SubElement(attrs, "clef", number="2")
    _text(tab_clef, "sign", "TAB")
    _text(tab_clef, "line", 5)

    details = ET.SubElement(attrs, "staff-details", number="2")
    _text(details, "staff-lines", 6)
    for line, tuning in enumerate((40, 45, 50, 55, 59, 64), start=1):
        staff_tuning = ET.SubElement(details, "staff-tuning", line=str(line))
        step, alter = _STEPS[tuning % 12]
        _text(staff_tuning, "tuning-step", step)
        if alter:
            _text(staff_tuning, "tuning-alter", alter)
        _text(staff_tuning, "tuning-octave", tuning // 12 - 1)


def _build_standard_plus_tab_score(score: ET.Element, result: JointArrangementResult) -> ET.Element:
    """Build one MusicXML score containing TAB authority + silent Standard display.

    V0.1_V7: the two visual representations are separate MusicXML *parts*, not
    two staves inside one part.  MusicXML voice numbers are part-scoped.  The
    previous one-part/two-staff representation duplicated the same voice
    timelines inside P1; MuseScore can consequently diagnose a voice as longer
    than its measure.  Separate parts preserve one output file and both visual
    notations without making the display copy participate in P1's voice clock.

    V0.1.9.4 ownership contract:
    P2 is the canonical TAB/playback authority and is the only score part that
    owns GSTE's converted note events, stable event IDs and string/fret choices.
    P1 is created *afterwards* as a silent engraving-only projection of P2.
    Never rebuild P2 from P1: standard notation loses guitar position identity.
    """
    parts = score.findall("part")
    if not parts:
        return score
    tab_part = parts[0]
    tab_part.set("id", "P2")
    _add_selected_harmonies_to_part(tab_part, result)

    # Canonical TAB part: one staff only.  Do not duplicate/replay its timeline.
    for measure_index, measure in enumerate(tab_part.findall("measure")):
        attrs = measure.find("attributes")
        if attrs is None and measure_index == 0:
            attrs = ET.Element("attributes")
            measure.insert(0, attrs)
        if attrs is not None:
            for child in list(attrs):
                if child.tag in {"staves", "clef", "staff-details"}:
                    attrs.remove(child)
            if measure_index == 0:
                clef = ET.SubElement(attrs, "clef")
                _text(clef, "sign", "TAB")
                _text(clef, "line", 5)
                details = ET.SubElement(attrs, "staff-details")
                _text(details, "staff-lines", 6)
                for line, tuning_midi in enumerate((40, 45, 50, 55, 59, 64), start=1):
                    st = ET.SubElement(details, "staff-tuning", line=str(line))
                    step, alter = _STEPS[tuning_midi % 12]
                    _text(st, "tuning-step", step)
                    if alter:
                        _text(st, "tuning-alter", alter)
                    _text(st, "tuning-octave", tuning_midi // 12 - 1)
        for note in measure.findall("note"):
            staff = note.find("staff")
            if staff is not None:
                note.remove(staff)
        for harmony in measure.findall("harmony"):
            staff = harmony.find("staff")
            if staff is not None:
                harmony.remove(staff)

    # Display-only Standard projection: derive it strictly from the completed
    # canonical TAB part.  Because it is a different part, its voice numbers
    # cannot extend/merge TAB voices.  Remove TAB-only technical/identity data
    # so integrity accounting continues to have exactly one canonical authority.
    standard_part = deepcopy(tab_part)
    standard_part.set("id", "P1")
    for measure_index, measure in enumerate(standard_part.findall("measure")):
        attrs = measure.find("attributes")
        if attrs is None and measure_index == 0:
            attrs = ET.Element("attributes")
            measure.insert(0, attrs)
        if attrs is not None:
            for child in list(attrs):
                if child.tag in {"staves", "clef", "staff-details"}:
                    attrs.remove(child)
            if measure_index == 0:
                clef = ET.SubElement(attrs, "clef")
                _text(clef, "sign", "G")
                _text(clef, "line", 2)
                _text(clef, "clef-octave-change", -1)
        for note in measure.findall("note"):
            staff = note.find("staff")
            if staff is not None:
                note.remove(staff)
            note.set("dynamics", "0")
            editor_role=note.findtext("notations/other-notation[@type='gste-editor-role']") or _note_role(note)
            editor_event_id=note.findtext("notations/other-notation[@type='gste-event-id']") or note.findtext("notations/other-notation[@type='gste-editor-event-id']")
            # Keep editor-only correspondence until the public JSON capture.
            notations = note.find("notations")
            if notations is not None:
                technical = notations.find("technical")
                if technical is not None:
                    notations.remove(technical)
                for marker in list(notations.findall("other-notation")):
                    if (marker.get("type") or "").startswith("gste-"):
                        notations.remove(marker)
                if editor_event_id:ET.SubElement(notations,'other-notation',type='gste-editor-event-id').text=editor_event_id
                ET.SubElement(notations,'other-notation',type='gste-editor-role').text=editor_role
        # Harmony is shown once, on the Standard display part.
    for measure in tab_part.findall("measure"):
        for harmony in list(measure.findall("harmony")):
            measure.remove(harmony)

    # Remove inherited extra source parts and rebuild a deterministic part list.
    for extra in list(score.findall("part"))[1:]:
        score.remove(extra)
    tab_index = list(score).index(tab_part)
    score.insert(tab_index, standard_part)
    old = score.find("part-list")
    if old is not None:
        insert_at = list(score).index(old)
        score.remove(old)
    else:
        insert_at = list(score).index(tab_part)
    pl = ET.Element("part-list")
    score.insert(insert_at, pl)
    sp1 = ET.SubElement(pl, "score-part", id="P1")
    _text(sp1, "part-name", "Guitar Standard (Display)")
    sp2 = ET.SubElement(pl, "score-part", id="P2")
    _text(sp2, "part-name", "Guitar TAB")
    return score



def _measure_cursor_ticks(measure):
    """Decode the actual serialized cursor; meter and maximum extent are not its position."""
    cursor=0
    for element in measure:
        ticks=int(element.findtext('duration','0'))
        if element.tag=='backup':cursor-=ticks
        elif element.tag=='forward':cursor+=ticks
        elif element.tag=='note' and element.find('chord') is None and element.find('grace') is None:
            cursor+=ticks
    return cursor

def _serialize_accompaniment_lanes(measure, lanes, measure_ticks, divisions, accompaniment_voice_base, beats, beat_type):
    """Shared representation-only lane writer for global and frozen local results."""
    for lane_index, lane in enumerate(lanes):
        # Source voices can end before the bar boundary (pickup/short voice),
        # or after a backup can finish before another voice's maximum extent.
        # Reset from the actual XML cursor, never from the nominal bar length.
        cursor_ticks=_measure_cursor_ticks(measure)
        if cursor_ticks<0:
            raise ValueError('SOURCE_XML_NEGATIVE_CURSOR_BEFORE_ACCOMPANIMENT')
        if cursor_ticks:
            backup = ET.SubElement(measure, "backup")
            _text(backup, "duration", cursor_ticks)
        # Serialize each lane on the integer MusicXML tick grid.  Mixing
        # rounded XML durations with a floating-point cursor can leave a
        # spurious one-tick tail (notably after thirds), making the lane
        # 67201 ticks long in a 67200-tick bar and shifting later events.
        acc_cursor_ticks = 0
        measure_ticks_int = int(measure_ticks)
        voice_number = accompaniment_voice_base + lane_index
        for onset, duration_q, candidates in lane:
            onset_ticks = max(0, int(round(onset * divisions)))
            if onset_ticks > acc_cursor_ticks:
                # Generated accompaniment lanes use invisible cursor gaps, not
                # notated hidden rests.  Tiny mixed binary/triplet rest
                # decompositions can sum correctly in raw <duration> ticks yet
                # be reconstructed by MuseScore as e.g. 385/384 of a beat.
                # <forward> is the MusicXML-native representation for a silent
                # cursor advance and therefore carries no conflicting rhythmic
                # spelling.
                _append_forward(measure, onset_ticks - acc_cursor_ticks, voice_number)
                acc_cursor_ticks = onset_ticks
            duration_ticks = max(1, int(round(duration_q * divisions)))
            duration_ticks = min(duration_ticks, max(1, measure_ticks_int - onset_ticks))
            pieces = _decompose_notated_duration(duration_ticks, divisions)
            if not pieces:
                pieces = (duration_ticks,)
            piece_cursor = onset_ticks
            for piece_index, piece_ticks in enumerate(pieces):
                if piece_cursor > acc_cursor_ticks:
                    _append_forward(measure, piece_cursor - acc_cursor_ticks, voice_number)
                for idx, (candidate, playback_role, segment_duration, tie_stop, tie_start) in enumerate(candidates):
                    velocity = _velocity_for_role(playback_role, onset, beats, beat_type)
                    # Internal splits are notation-only and therefore tied.
                    local_stop = tie_stop or piece_index > 0
                    local_start = tie_start or piece_index < len(pieces)-1
                    _append_tab_note(
                        measure, candidate, piece_ticks, voice_number, divisions,
                        chord=idx > 0, velocity=velocity, tie_stop=local_stop, tie_start=local_start,
                    )
                piece_cursor += piece_ticks
                acc_cursor_ticks = max(acc_cursor_ticks, piece_cursor)
        if acc_cursor_ticks < measure_ticks_int:
            _append_forward(measure, measure_ticks_int - acc_cursor_ticks, voice_number)

def joint_arrangement_to_musicxml(
    result: JointArrangementResult,
    title: str,
    tuning: Tuning = STANDARD_TUNING,
    *,
    source_path: str | Path | None = None,
    canonical_timeline=None,
    total_semitone_shift: int = 0,
    selected_melody_source_event_ids: set[str] | None = None,
    melody_backbone=None,
    serializer_manifest: list[dict] | None = None,
) -> str:
    """Render final TAB while preserving the source melody rhythm exactly.

    v0.12.3: when ``source_path`` is supplied, the source MusicXML is used as
    the immutable rhythmic skeleton. Original measures, time signatures,
    durations, note types, dots, beams, rests, grace notes, slurs and ties are
    retained. The arranger may only replace melody pitch/register and attach
    string/fret notation; accompaniment is appended as voice 2.
    """
    if source_path is None:
        raise ValueError("source_path is required for rhythm-safe joint TAB export in v0.12.3")

    root = ET.parse(source_path).getroot()
    _strip_namespace(root)
    score = deepcopy(root)
    # Common grid can outlive the source melody. Add explicit empty measures;
    # original note elements and their identities are never reconstructed.
    grid={}
    for w in result.selected:
        row=grid.setdefault(w.measure,[w.start,w.start+w.duration])
        row[0]=min(row[0],w.start);row[1]=max(row[1],w.start+w.duration)
    if canonical_timeline is not None:
        grid={m:[start,start+canonical_timeline.measure_lengths[m]] for m,start in canonical_timeline.measure_starts.items()}
    for part in score.findall("part"):
        existing=len(part.findall("measure")); divisions=1
        for node in part.findall("measure/attributes/divisions"):
            divisions=int(node.text or 1)
        if grid and max(grid)>existing:
            for bar in part.findall("measure/barline"):
                if bar.findtext("bar-style")=="light-heavy":
                    bar.find("bar-style").text="regular"
            for m in range(existing+1,max(grid)+1):
                if m not in grid: raise ValueError("SERIALIZER_COMMON_GRID_GAP:"+str(m))
                measure=ET.SubElement(part,"measure",number=str(m))
                note=ET.SubElement(measure,"note");ET.SubElement(note,"rest",measure="yes")
                ET.SubElement(note,"duration").text=str(round((grid[m][1]-grid[m][0])*divisions))
            bar=ET.SubElement(measure,"barline",location="right");ET.SubElement(bar,"bar-style").text="light-heavy"
    # v0.13.5.13.3: identity is stamped on the untouched source skeleton.
    # Every later mutation must preserve this marker; list indices are never
    # allowed to redefine structural melody identity.
    _stamp_stable_structural_event_ids(score, track_id="piano_right")
    backbone_by_id = _backbone_map(melody_backbone)
    emitted_structural_ids: set[str] = set()
    selected_priority_by_event_id = _selected_source_melody_priority_by_event_id(result)
    selected_priority_source_event_ids = set(selected_priority_by_event_id)
    # v0.13.4: SOURCE_PIANO melody extraction must affect the exported
    # rhythmic skeleton. Omitted right-hand notes are secondary material, not
    # mandatory melody. Preserve timing by converting an omitted base note to
    # a rest; omitted chord members are removed. If the base is omitted but a
    # following chord member is selected, promote the first selected member to
    # the timed base note by removing its <chord/> marker.
    if selected_melody_source_event_ids is not None:
        # v0.13.5.15.6.4: a Canonical melody event may be represented by
        # several source MusicXML note segments connected by explicit ties.
        # Preserve those representation-only continuation segments when (and
        # only when) their tie head is a selected Final Event.  This is not a
        # musical guess: the source tie relation was explicit, while the Final
        # Canonical attack/release remains the authority verified after write.
        # v0.1.5: the source RH skeleton is owned by Joint selection, not by
        # binary melody-role admission.  Structural melody remains protected,
        # while optional SOURCE_PIANO priority events survive only when Joint
        # selected their immutable source_event_id.
        representation_event_ids = set(selected_melody_source_event_ids) | selected_priority_source_event_ids
        active_representation_ties: dict[tuple[str, int], tuple[str, float]] = {}
        rep_divisions = 1
        rep_beats, rep_beat_type = 4, 4
        rep_measure_start = 0.0
        for source_measure in score.findall("part/measure"):
            attrs = source_measure.find("attributes")
            if attrs is not None:
                if attrs.findtext("divisions"):
                    rep_divisions = max(1, int(float(attrs.findtext("divisions"))))
                time = attrs.find("time")
                if time is not None:
                    rep_beats = int(time.findtext("beats", str(rep_beats)))
                    rep_beat_type = int(time.findtext("beat-type", str(rep_beat_type)))
            rep_cursor = 0.0
            rep_last_onset = 0.0
            for source_element in list(source_measure):
                if source_element.tag == "backup":
                    rep_cursor = max(0.0, rep_cursor - float(source_element.findtext("duration", "0")) / rep_divisions)
                    continue
                if source_element.tag == "forward":
                    rep_cursor += float(source_element.findtext("duration", "0")) / rep_divisions
                    continue
                if source_element.tag != "note":
                    continue
                is_chord = source_element.find("chord") is not None
                is_grace = source_element.find("grace") is not None
                rep_onset = rep_last_onset if is_chord else rep_cursor
                if not is_chord:
                    rep_last_onset = rep_onset
                rep_duration = float(source_element.findtext("duration", "0")) / rep_divisions
                source_midi = _midi_from_note(source_element)
                if source_midi is not None and source_element.find("rest") is None and not is_grace:
                    source_id = (source_element.findtext("notations/other-notation[@type='gste-event-id']") or "").strip()
                    voice = source_element.findtext("voice", "1")
                    key = (str(voice), int(source_midi))
                    tie_start = source_element.find("tie[@type='start']") is not None or source_element.find("notations/tied[@type='start']") is not None
                    tie_stop = source_element.find("tie[@type='stop']") is not None or source_element.find("notations/tied[@type='stop']") is not None
                    active = active_representation_ties.get(key) if tie_stop else None
                    absolute_onset = rep_measure_start + rep_onset
                    if active is not None:
                        head_id, canonical_release = active
                        # Canonical release is the hard authority.  A source tie
                        # continuation is retained only when it starts strictly
                        # inside that frozen sounding interval.  A decorative or
                        # stale source tie at/after release cannot extend Final.
                        # Continuation ownership follows Final Joint ownership,
                        # not only the hard melody-backbone set.  Optional RH
                        # source-priority events selected by Joint are equally
                        # entitled to their explicit source tie continuations.
                        if head_id in representation_event_ids and absolute_onset < canonical_release - 1e-7:
                            representation_event_ids.add(source_id)
                        if tie_start and absolute_onset < canonical_release - 1e-7:
                            active_representation_ties[key] = active
                        elif not tie_start:
                            active_representation_ties.pop(key, None)
                    elif tie_start and source_id in representation_event_ids:
                        backbone_event = backbone_by_id.get(source_id)
                        if backbone_event is not None:
                            canonical_release = float(getattr(backbone_event, "release"))
                        else:
                            priority_candidate = selected_priority_by_event_id.get(source_id)
                            canonical_release = _canonical_source_priority_release(
                                priority_candidate, absolute_onset, rep_duration
                            )
                        active_representation_ties[key] = (source_id, canonical_release)
                if not is_chord and not is_grace:
                    rep_cursor += rep_duration
            rep_measure_start += rep_beats * (4.0 / rep_beat_type)


        # v0.13.5.15.6.2 Canonical -> XML encoding boundary.
        # Final Event IDs decide content. Canonical/source cursor onset + XML voice
        # decide only how simultaneous survivors are encoded as base/<chord/>.
        # Source <chord/> tags are never an authority after arrangement.
        encoding_divisions = 1
        for measure in score.findall("part/measure"):
            children = list(measure)
            attributes = measure.find("attributes")
            if attributes is not None and attributes.findtext("divisions"):
                encoding_divisions = max(1, int(float(attributes.findtext("divisions"))))
            divisions = encoding_divisions

            # Observe the untouched source cursor once. This is representation
            # decoding only; locked CanonicalTime remains authoritative later.
            cursor = 0.0
            last_note_onset = 0.0
            rows = []
            for element in children:
                if element.tag == "backup":
                    cursor = max(0.0, cursor - float(element.findtext("duration", "0")) / divisions)
                    continue
                if element.tag == "forward":
                    cursor += float(element.findtext("duration", "0")) / divisions
                    continue
                if element.tag != "note":
                    continue
                is_chord = element.find("chord") is not None
                is_grace = element.find("grace") is not None
                onset = last_note_onset if is_chord else cursor
                if not is_chord:
                    last_note_onset = onset
                duration = float(element.findtext("duration", "0")) / divisions
                event_id = (element.findtext("notations/other-notation[@type='gste-event-id']") or "").strip()
                pitched = element.find("rest") is None and _midi_from_note(element) is not None
                if pitched and not event_id:
                    raise ValueError("SERIALIZER_MISSING_STABLE_STRUCTURAL_EVENT_ID_DURING_SELECTION")
                rows.append((element, event_id, onset, duration, element.findtext("voice", "1"), is_grace, is_chord, pitched))
                if not is_chord and not is_grace:
                    cursor += duration

            # Group pitched, timed source events by decoded onset+voice. This
            # replaces the fragile assumption that <chord/> must be adjacent to
            # a preceding normal note. Grace events are independent.
            groups = defaultdict(list)
            for row in rows:
                element, event_id, onset, duration, voice, is_grace, is_chord, pitched = row
                if pitched and not is_grace:
                    groups[(round(onset, 9), str(voice))].append(row)

            handled = set()
            for group_rows in groups.values():
                selected = [r for r in group_rows if r[1] in representation_event_ids]
                advancing = [r for r in group_rows if not r[6]]
                if not selected:
                    # Preserve exactly the source cursor advance while removing
                    # musical content. Chord members never advance the cursor.
                    if advancing:
                        base = advancing[0][0]
                        _restify_note(base)
                        handled.add(id(base))
                    for r in group_rows:
                        element = r[0]
                        if id(element) in handled:
                            continue
                        if element in list(measure):
                            measure.remove(element)
                        handled.add(id(element))
                    continue

                # Final survivors define the XML simultaneity representation.
                # First survivor is the time-advancing base; later survivors are
                # <chord/> members. Pitch/time/Event ID are not changed.
                for index, r in enumerate(selected):
                    element = r[0]
                    chord_tag = element.find("chord")
                    if index == 0:
                        if chord_tag is not None:
                            element.remove(chord_tag)
                    elif chord_tag is None:
                        element.insert(0, ET.Element("chord"))
                    handled.add(id(element))
                for r in group_rows:
                    element = r[0]
                    if r not in selected and element in list(measure):
                        measure.remove(element)
                        handled.add(id(element))

            # Grace notes are membership-filtered independently and never alter
            # the cursor. They may not survive merely because Source XML had them.
            for row in rows:
                element, event_id, onset, duration, voice, is_grace, is_chord, pitched = row
                if pitched and is_grace and event_id not in representation_event_ids:
                    if element in list(measure):
                        measure.remove(element)
    # Preserve source metadata structure. <work> is optional; do not synthesize it.
    work = score.find("work")
    if work is not None:
        work_title = work.find("work-title")
        if work_title is None:
            work_title = ET.SubElement(work, "work-title")
        work_title.text = title

    parts = score.findall("part")
    if not parts:
        raise ValueError("Source MusicXML has no part")
    part = parts[0]
    # Keep one score part and rename it for the generated TAB.
    part_list = score.find("part-list")
    if part_list is not None:
        score_parts = part_list.findall("score-part")
        for extra in score_parts[1:]:
            part_list.remove(extra)
        if score_parts:
            name = score_parts[0].find("part-name")
            if name is None:
                name = ET.SubElement(score_parts[0], "part-name")
            name.text = "Guitar TAB"
    for extra in parts[1:]:
        score.remove(extra)

    # Structural IDs were stamped once on the untouched source skeleton above.
    # Never recompute them from a mutated child index.

    # v0.13.5.12.7.1.2: internal and serialized validators must observe the
    # same integer timebase.  This prevents low source divisions from rounding
    # generated attacks/durations into different sounding intervals.
    # Duration-only source rests may represent a whole measure. Make that
    # semantic explicit before structural validation, without changing timing.
    for source_part in score.findall("part"):
        rest_divisions, rest_beats, rest_beat_type = 1, 4, 4
        for source_measure in source_part.findall("measure"):
            rest_attrs = source_measure.find("attributes")
            if rest_attrs is not None:
                rest_divisions = int(rest_attrs.findtext("divisions", str(rest_divisions)))
                rest_time = rest_attrs.find("time")
                if rest_time is not None:
                    rest_beats = int(rest_time.findtext("beats", str(rest_beats)))
                    rest_beat_type = int(rest_time.findtext("beat-type", str(rest_beat_type)))
            timed_notes = [n for n in source_measure.findall("note") if n.find("grace") is None]
            if (len(timed_notes) == 1 and source_measure.find("backup") is None
                    and source_measure.find("forward") is None):
                only_note = timed_notes[0]
                rest_node = only_note.find("rest")
                if (rest_node is not None and only_note.find("chord") is None
                        and only_note.find("type") is None
                        and int(only_note.findtext("duration", "0")) * rest_beat_type
                        == rest_divisions * rest_beats * 4):
                    rest_node.set("measure", "yes")
    _normalize_score_divisions(score, target_divisions=16800)

    melody_by_event_id = _selected_melody_by_event_id(result)
    source_owned_by_event_id = dict(melody_by_event_id)
    source_owned_by_event_id.update(selected_priority_by_event_id)
    accompaniment_by_start: dict[float, list] = defaultdict(list)
    for state in result.selected:
        accompaniment_by_start[round(state.start, 9)].extend(state.accompaniment.notes)

    divisions = 1
    beats = 4
    beat_type = 4
    absolute_measure_start = 0.0
    active_ties: dict[tuple[str, int], object] = {}

    for measure_index, measure in enumerate(part.findall("measure"), start=1):
        attributes = measure.find("attributes")
        if attributes is not None:
            divisions = int(float(attributes.findtext("divisions", str(divisions))))
            time = attributes.find("time")
            if time is not None:
                beats = int(time.findtext("beats", str(beats)))
                beat_type = int(time.findtext("beat-type", str(beat_type)))
            _ensure_tab_attributes(attributes, tuning)
        elif measure_index == 1:
            attributes = ET.Element("attributes")
            _text(attributes, "divisions", divisions)
            time = ET.SubElement(attributes, "time")
            _text(time, "beats", beats); _text(time, "beat-type", beat_type)
            _ensure_tab_attributes(attributes, tuning)
            measure.insert(0, attributes)

        # v0.13.5.15.6.8: serialize on the physical source cursor grid.
        # Meter is context only; irregular/overfull measures keep their actual
        # MusicXML extent instead of being forced onto beats/beat-type.
        measure_quarters = physical_measure_extent(
            measure, divisions=divisions, expected_quarters=beats * (4.0 / beat_type)
        )
        cursor = 0.0
        last_note_onset = 0.0

        # Preserve every original melody notation element. Only pitch/register
        # and TAB technical information may change.
        for element in list(measure):
            if element.tag == "backup":
                cursor = max(0.0, cursor - float(element.findtext("duration", "0")) / divisions)
                continue
            if element.tag == "forward":
                cursor += float(element.findtext("duration", "0")) / divisions
                continue
            if element.tag != "note":
                continue
            is_chord = element.find("chord") is not None
            onset = last_note_onset if is_chord else cursor
            if not is_chord:
                last_note_onset = onset
            duration = float(element.findtext("duration", "0")) / divisions
            is_grace = element.find("grace") is not None
            source_midi = _midi_from_note(element)
            voice = element.findtext("voice", "1")
            # Once a measure contains generated Voice 2/3 lanes, every sounding
            # melody event needs an explicit voice identity as well.  Preserve
            # source voices when present; only make the implicit default explicit.
            if element.find("voice") is None:
                voice_node = ET.Element("voice")
                voice_node.text = "1"
                # MusicXML note child order is schema-significant. Source notes
                # may already contain one or more playback <tie> elements after
                # <duration>.  A previous default-voice insertion placed <voice>
                # immediately after <duration>, which moved it *before* those
                # existing ties and produced duration -> voice -> tie (invalid).
                # Insert the implicit voice after the last existing <tie>; if no
                # tie exists, immediately after duration remains correct.
                children = list(element)
                tie_positions = [i for i, child in enumerate(children) if child.tag == "tie"]
                if tie_positions:
                    insert_at = max(tie_positions) + 1
                else:
                    duration_node = element.find("duration")
                    insert_at = children.index(duration_node) + 1 if duration_node is not None else len(children)
                element.insert(insert_at, voice_node)
                voice = "1"
            tie_start = element.find("tie[@type='start']") is not None or element.find("notations/tied[@type='start']") is not None
            tie_stop = element.find("tie[@type='stop']") is not None or element.find("notations/tied[@type='stop']") is not None

            if source_midi is not None and element.find("rest") is None:
                measure_number = _measure_number(measure, measure_index)
                source_event_id = (element.findtext("notations/other-notation[@type='gste-event-id']") or "").strip()
                if not source_event_id:
                    raise ValueError(
                        f"SERIALIZER_MISSING_STABLE_STRUCTURAL_EVENT_ID: measure={measure_number} onset={absolute_measure_start + onset:.9f}"
                    )
                backbone_event = backbone_by_id.get(source_event_id)
                expected_midi = (
                    int(getattr(backbone_event, "midi_pitch"))
                    if backbone_event is not None
                    else source_midi + total_semitone_shift
                )
                if is_grace:
                    midi, string, fret = _fallback_fingering(expected_midi, tuning)
                    _set_pitch(element, midi)
                    _set_technical(element, string, fret)
                else:
                    tie_key = (voice, source_midi)
                    candidate = active_ties.get(tie_key) if tie_stop else None
                    if candidate is None:
                        locked_attack = (
                            float(getattr(backbone_event, "attack"))
                            if backbone_event is not None
                            else absolute_measure_start + onset
                        )
                        candidate = _reviewed_candidate_for_source(
                            source_owned_by_event_id, source_event_id, locked_attack,
                            None if source_event_id in selected_priority_source_event_ids else expected_midi
                        )
                    if isinstance(candidate, tuple):
                        output_midi, string, fret = candidate
                    elif candidate is not None:
                        output_midi = candidate.note.pitch.midi
                        # Candidate absolute pitch is the authoritative post-register
                        # plan. main.py has already hard-locked it against that plan.
                        string, fret = candidate.string, candidate.fret
                    else:
                        raise ValueError(
                            f"SERIALIZER_CANONICAL_MELODY_MAPPING_FAILED: {source_event_id} "
                            f"onset={absolute_measure_start + onset:.9f} midi={expected_midi}"
                        )
                    _set_pitch(element, output_midi)
                    _set_technical(element, string, fret)
                    if backbone_event is not None and source_event_id not in emitted_structural_ids:
                        emitted_structural_ids.add(source_event_id)
                        if serializer_manifest is not None:
                            serializer_manifest.append({
                                "structural_event_id": source_event_id,
                                "midi_pitch": int(output_midi),
                                "attack": float(getattr(backbone_event, "attack")),
                                "release": float(getattr(backbone_event, "release")),
                                "string": int(string),
                                "fret": int(fret),
                                "measure": getattr(backbone_event, "measure", None),
                            })
                    elif source_event_id in selected_priority_source_event_ids and source_event_id not in emitted_structural_ids:
                        emitted_structural_ids.add(source_event_id)
                        if serializer_manifest is not None and candidate is not None:
                            serializer_manifest.append({
                                "structural_event_id": source_event_id,
                                "midi_pitch": int(output_midi),
                                "attack": float(candidate.note.start),
                                "release": float(candidate.note.start + candidate.note.duration),
                                "string": int(string),
                                "fret": int(fret),
                                "measure": candidate.note.measure,
                            })
                    if tie_start:
                        active_ties[tie_key] = candidate if candidate is not None else (output_midi, string, fret)
                    if tie_stop and not tie_start:
                        active_ties.pop(tie_key, None)
                # Performance-only layer: melody remains louder than every
                # accompaniment role. Grace/chord notes share the same onset.
                _set_playback_velocity(
                    element,
                    _velocity_for_role("melody", onset, beats, beat_type),
                )
            if not is_chord and not is_grace:
                cursor += duration

        # Add accompaniment on the original measure grid while preserving the
        # internal sounding interval exactly.  v0.13.5.12.7.1.1 serialized all
        # accompaniment into one monophonic voice and clipped each duration at
        # the next accompaniment attack.  That changed the physical timeline:
        # arpeggio tones that should still ring were shortened, so internal and
        # reparsed validators judged different hand states.  Allocate overlapping
        # attacks to separate voice lanes instead; every lane is monophonic, but
        # the union reproduces the canonical internal [start,end) intervals.
        measure_ticks = int(round(measure_quarters * divisions))
        acc_events: list[tuple[float, object, str]] = []
        for state in result.selected:
            roles = tuple(state.accompaniment.tone_roles)
            for note_index, candidate in enumerate(state.accompaniment.notes):
                # v0.1.5: a selected RH priority source event is serialized in
                # its original source-skeleton location.  Appending it again as
                # generated accompaniment would duplicate both sound and time.
                if (
                    str(candidate.note.arrangement_role or "").startswith("melody_priority_")
                    and str(getattr(candidate.note, "source_event_id", "") or "") in selected_priority_source_event_ids
                ):
                    continue
                absolute_onset = float(candidate.note.start)
                absolute_release = absolute_onset + float(candidate.note.duration)
                tone_role = roles[note_index] if note_index < len(roles) else "accompaniment"
                playback_role = "bass" if tone_role in BASS_TONE_ROLES else "accompaniment"
                measure_end = absolute_measure_start + measure_quarters
                # Preserve cross-measure sounding events.  Each source measure gets
                # only its notation segment; tie metadata reconnects the segments.
                segment_start = max(absolute_onset, absolute_measure_start)
                segment_end = min(absolute_release, measure_end)
                if segment_end > segment_start + 1e-9:
                    tie_stop = absolute_onset < absolute_measure_start - 1e-9
                    tie_start = absolute_release > measure_end + 1e-9
                    acc_events.append((
                        segment_start - absolute_measure_start, candidate, playback_role,
                        segment_end - segment_start, tie_stop, tie_start,
                    ))
        acc_events.sort(key=lambda item: (item[0], item[1].note.pitch.midi, item[1].string, item[1].fret))
        grouped_acc: dict[float, list[tuple[object, str, float, bool, bool]]] = defaultdict(list)
        for onset, candidate, playback_role, segment_duration, tie_stop, tie_start in acc_events:
            grouped_acc[round(onset, 9)].append((candidate, playback_role, segment_duration, tie_stop, tie_start))

        # v0.13.5.15.7.5 Notation Lane Planning.  Keep canonical sounding
        # intervals untouched; this stage decides only how those frozen events
        # are engraved.  Attack groups sharing an onset remain a chord.  A new
        # lane is created only when every existing accompaniment lane is still
        # sounding at that attack.  The resulting lane number is stable for the
        # whole measure and is explicitly engraved as a down-stem layer below
        # the melody.
        lanes = _plan_notation_lanes(grouped_acc, measure_quarters, divisions)

        # V0.1_V7.1: source piano notation may already use voice 2 (or higher).
        # Never assign a generated accompaniment lane to an existing source
        # voice ID; otherwise two independent timelines share one voice after
        # separate <backup> resets and importers can report an overlong voice.
        source_voice_numbers = []
        for existing_note in measure.findall("note"):
            try:
                source_voice_numbers.append(int(existing_note.findtext("voice", "1")))
            except (TypeError, ValueError):
                pass
        accompaniment_voice_base = max([1, *source_voice_numbers]) + 1

        _serialize_accompaniment_lanes(measure, lanes, measure_ticks, divisions, accompaniment_voice_base, beats, beat_type)

        absolute_measure_start += measure_quarters

    if backbone_by_id:
        missing = sorted(set(backbone_by_id) - emitted_structural_ids)
        if missing:
            first = missing[0]
            event = backbone_by_id[first]
            raise ValueError(
                f"SERIALIZER_LOCKED_BACKBONE_EVENT_NOT_EMITTED: {first} "
                f"attack={getattr(event, 'attack', None)} midi={getattr(event, 'midi_pitch', None)}"
            )

    # v0.13.5.13.3 final presentation: one score with standard guitar notation
    # above TAB, both carrying the selected harmony symbols.
    score = _build_standard_plus_tab_score(score, result)
    rough = ET.tostring(score, encoding="utf-8")
    return minidom.parseString(rough).toprettyxml(indent="  ")


def write_joint_tab_musicxml(
    result: JointArrangementResult,
    path: str | Path,
    title: str,
    tuning: Tuning = STANDARD_TUNING,
    *,
    source_path: str | Path | None = None,
    canonical_timeline=None,
    total_semitone_shift: int = 0,
    validate_integrity: bool = False,
    auto_recovery: bool = False,
    selected_melody_source_event_ids: set[str] | None = None,
    recovery_log: list[dict] | None = None,
    melody_backbone=None,
    serializer_manifest_path: str | Path | None = None,
    structural_sanity_report_path: str | Path | None = None,
    export_integrity_report_path: str | Path | None = None,
) -> Path:
    """Serialize an already reviewed Joint/Fingering result.

    v0.13.5.12.10.1 restores the pre-monitoring responsibility boundary: the
    exporter never re-judges playability and never repairs/revoices/deletes
    musical content.  ``validate_integrity`` and ``auto_recovery`` remain only
    as compatibility arguments for older callers and are intentionally ignored.
    """
    output = Path(path); output.parent.mkdir(parents=True, exist_ok=True)
    serializer_manifest: list[dict] = []
    xml_text = joint_arrangement_to_musicxml(
        result, title, tuning, source_path=source_path, canonical_timeline=canonical_timeline, total_semitone_shift=total_semitone_shift,
        selected_melody_source_event_ids=selected_melody_source_event_ids,
        melody_backbone=melody_backbone, serializer_manifest=serializer_manifest,
    )
    # PRE_WRITE: inspect the exact XML tree that is about to become final output.
    pre_root = ET.fromstring(xml_text)
    _move_gste_debug_metadata_out_of_notations(pre_root)
    normalizations = normalize_playback_hazards(pre_root)
    # Re-serialize the normalized tree; this preserves musical events while
    # replacing playback-fragile source notation such as <dynamics><n/>.
    xml_text = minidom.parseString(ET.tostring(pre_root, encoding="utf-8")).toprettyxml(indent="  ")
    pre_report = None
    post_report = None
    if structural_sanity_report_path is not None:
        base = Path(structural_sanity_report_path)
        pre_report = base.with_name(base.stem + "_PRE_WRITE" + base.suffix)
        post_report = base.with_name(base.stem + "_POST_WRITE" + base.suffix)
    validate_musicxml_tree(pre_root, stage="PRE_WRITE", report_path=pre_report, normalized=normalizations)
    output.write_text(xml_text, encoding="utf-8")
    # POST_WRITE: parse the bytes users will actually open.  This catches both
    # malformed serialization and structural contamination introduced at write.
    post_result = validate_musicxml_file(output, report_path=post_report)
    # v0.13.5.15.6.3: final exporter measurement. Reparse the bytes users
    # receive and compare them against the frozen Final serializer manifest.
    # This observer may only PASS or hard-FAIL; it never repairs output.
    verify_exported_musicxml_against_manifest(
        output, serializer_manifest, report_path=export_integrity_report_path,
    )
    if structural_sanity_report_path is not None:
        base = Path(structural_sanity_report_path)
        base.write_text(json.dumps({
            "version": VERSION,
            "status": "PASS",
            "pre_write": {"status": "PASS", "normalizations": normalizations},
            "post_write": {"status": post_result.get("status", "PASS")},
            "semantics": "Structural-only validation; pitch/timing/fingering/harmony are not re-derived from MusicXML.",
        }, ensure_ascii=False, indent=2), encoding="utf-8")
    if serializer_manifest_path is not None:
        manifest_path = Path(serializer_manifest_path)
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        manifest_path.write_text(json.dumps({
            "version": VERSION,
            "status": "PASS",
            "semantics": "Serializer emits the immutable Locked Melody Backbone; no XML re-derived melody timeline is authoritative.",
            "event_count": len(serializer_manifest),
            "events": serializer_manifest,
        }, ensure_ascii=False, indent=2), encoding="utf-8")
    return output


def frozen_local_to_musicxml(source_path, notes, harmonies=()):
    """Encode frozen local decisions with the same lane/note writer as Joint.

    Original melody XML is retained, including rests, ties and expression.
    This adapter does not choose pitches, durations or fingerings.
    """
    from gste.exporter.canonical_tab_reader import canonical_tab_part
    from gste.editor.score import read_score, load_identities
    from gste.harmony.models import ChordFamily
    from gste.harmony.library import QUALITY_INTERVALS
    root=ET.parse(source_path).getroot();_strip_namespace(root)
    part=canonical_tab_part(root)
    if len(root.findall('part')) != 2 or part.get('id')!='P2':
        raise ValueError('Local export requires the current Standard + TAB format. Reconvert the source first.')
    identities=load_identities(source_path)
    grid=read_score(source_path);divisions=1;beats=4;beat_type=4
    for measure,row in zip(part.findall('measure'),grid):
        attrs=measure.find('attributes')
        if attrs is not None:
            divisions=int(attrs.findtext('divisions',str(divisions)))
            beats=int(attrs.findtext('time/beats',str(beats)));beat_type=int(attrs.findtext('time/beat-type',str(beat_type)))
        # Melody is the first lane in GSTE's current exported contract.
        cursor=0;last=0;melody=[]
        for ei,e in enumerate(list(measure)):
            duration=int(e.findtext('duration','0'))
            if e.tag=='backup':cursor-=duration
            elif e.tag=='forward':cursor+=duration
            elif e.tag=='note':
                onset=last if e.find('chord') is not None else cursor
                if e.find('chord') is None:
                    last=onset
                    if e.find('grace') is None:cursor+=duration
                identity=identities.get(f"{part.get('id')}:M{row['measure']}:E{ei}",{})
                if identity.get('role')=='melody' or (e.find('rest') is not None and e.findtext('voice','1')=='1'):
                    if identity.get('event_id'):_set_event_id_marker(e,identity['event_id'])
                    melody.append((onset,e))
            if e.tag in ('note','backup','forward'):measure.remove(e)
        cursor=0
        barlines=measure.findall('barline')
        for barline in barlines:measure.remove(barline)
        for onset,e in melody:
            if onset>cursor:_append_forward(measure,onset-cursor,1);cursor=onset
            measure.append(e)
            if e.find('chord') is None and e.find('grace') is None:cursor=onset+int(e.findtext('duration','0'))
        ticks=int(round(row['duration']*divisions))
        if cursor<ticks:_append_forward(measure,ticks-cursor,1)
        grouped=defaultdict(list)
        for f,role in notes:
            if role=='melody':continue
            start=max(f.note.start,row['start']);end=min(f.note.start+f.note.duration,row['start']+row['duration'])
            if end>start+1e-9:
                grouped[round(start-row['start'],9)].append((f,'accompaniment',end-start,
                    f.note.start<row['start']-1e-9,f.note.start+f.note.duration>row['start']+row['duration']+1e-9))
        lanes=_plan_notation_lanes(grouped,row['duration'],divisions)
        _serialize_accompaniment_lanes(measure,lanes,ticks,divisions,2,beats,beat_type)
        local_h=[h for h in harmonies if row['start']<=h[0]<row['start']+row['duration']-1e-7]
        if local_h:
            for h in measure.findall('harmony'):measure.remove(h)
            for onset,pc,quality in local_h:
                required,optional=QUALITY_INTERVALS[quality]
                _append_harmony(measure,ChordFamily(pc,quality,required,optional),int(round((onset-row['start'])*divisions)),divisions)
        for barline in barlines:measure.append(barline)
    display=root.find("part[@id='P1']")
    for old,new in zip(list(display),part.findall('measure')):
        if old.tag!='measure':continue
        twin=deepcopy(new)
        # Retain standard staff attributes/engraving from the original display.
        attrs=twin.find('attributes');original=old.find('attributes')
        if attrs is not None:twin.remove(attrs)
        if original is not None:twin.insert(0,deepcopy(original))
        for note in list(twin.findall('note')):
            i=list(twin).index(note);twin.remove(note);twin.insert(i,_make_standard_display_note(note))
        display.remove(old);display.append(twin)
    return minidom.parseString(ET.tostring(root,encoding='utf-8')).toprettyxml(indent='  ')
