from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import xml.dom.minidom as minidom
import xml.etree.ElementTree as ET

from gste.core.models import FingeringPath
from gste.core.tuning import STANDARD_TUNING, Tuning

_SEMITONE_TO_STEP_ALTER = {
    0: ("C", 0), 1: ("C", 1), 2: ("D", 0), 3: ("D", 1),
    4: ("E", 0), 5: ("F", 0), 6: ("F", 1), 7: ("G", 0),
    8: ("G", 1), 9: ("A", 0), 10: ("A", 1), 11: ("B", 0),
}
_STEP_TO_SEMITONE = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}


def _strip_namespace(root: ET.Element) -> None:
    for elem in root.iter():
        if "}" in elem.tag:
            elem.tag = elem.tag.split("}", 1)[1]


def _midi_to_step_alter_octave(midi: int) -> tuple[str, int, int]:
    octave = midi // 12 - 1
    step, alter = _SEMITONE_TO_STEP_ALTER[midi % 12]
    return step, alter, octave


def _pitch_element_to_midi(pitch: ET.Element) -> int:
    step = pitch.findtext("step")
    octave = pitch.findtext("octave")
    if step is None or octave is None:
        raise ValueError("Pitch element must contain step and octave")
    alter = int(float(pitch.findtext("alter") or 0))
    return (int(octave) + 1) * 12 + _STEP_TO_SEMITONE[step] + alter


def _set_pitch_element(pitch: ET.Element, midi: int) -> None:
    step, alter, octave = _midi_to_step_alter_octave(midi)
    step_el = pitch.find("step")
    if step_el is None:
        step_el = ET.SubElement(pitch, "step")
    step_el.text = step
    alter_el = pitch.find("alter")
    if alter:
        if alter_el is None:
            alter_el = ET.SubElement(pitch, "alter")
        alter_el.text = str(alter)
    elif alter_el is not None:
        pitch.remove(alter_el)
    octave_el = pitch.find("octave")
    if octave_el is None:
        octave_el = ET.SubElement(pitch, "octave")
    octave_el.text = str(octave)


def _add_text(parent: ET.Element, tag: str, text: str | int | float) -> ET.Element:
    child = ET.SubElement(parent, tag)
    child.text = str(text)
    return child


def _ensure_technical(note: ET.Element, string: int, fret: int) -> None:
    notations = note.find("notations")
    if notations is None:
        notations = ET.SubElement(note, "notations")
    technical = notations.find("technical")
    if technical is None:
        technical = ET.SubElement(notations, "technical")
    for tag in ("string", "fret"):
        old = technical.find(tag)
        if old is not None:
            technical.remove(old)
    _add_text(technical, "string", string)
    _add_text(technical, "fret", fret)


def _fallback_fingering(midi: int, tuning: Tuning) -> tuple[int, int]:
    choices: list[tuple[int, int]] = []
    for string, open_midi in tuning.strings.items():
        fret = midi - open_midi
        if 0 <= fret <= 24:
            choices.append((fret, string))
    if not choices:
        return 1, max(0, midi - tuning.strings[1])
    fret, string = min(choices, key=lambda item: (item[0], item[1]))
    return string, fret


def _set_tab_attributes(first_measure: ET.Element, tuning: Tuning) -> None:
    attributes = first_measure.find("attributes")
    if attributes is None:
        attributes = ET.Element("attributes")
        first_measure.insert(0, attributes)
    clef = attributes.find("clef")
    if clef is None:
        clef = ET.SubElement(attributes, "clef")
    for child in list(clef):
        clef.remove(child)
    _add_text(clef, "sign", "TAB")
    _add_text(clef, "line", 5)

    staff_details = attributes.find("staff-details")
    if staff_details is None:
        staff_details = ET.SubElement(attributes, "staff-details")
    for child in list(staff_details):
        staff_details.remove(child)
    _add_text(staff_details, "staff-lines", 6)
    for line, step, octave in tuning.musicxml_staff_tunings():
        staff_tuning = ET.SubElement(staff_details, "staff-tuning", line=str(line))
        _add_text(staff_tuning, "tuning-step", step)
        _add_text(staff_tuning, "tuning-octave", octave)


def fingering_path_to_tab_musicxml(
    path: FingeringPath,
    title: str = "GSTE TAB Export",
    tuning: Tuning = STANDARD_TUNING,
    *,
    source_path: str | Path | None = None,
    semitone_shift: int = 0,
) -> str:
    """Serialize a fingering path as TAB MusicXML.

    When ``source_path`` is supplied, GSTE preserves the source MusicXML timing
    structure verbatim (rests, grace notes, ties, note types, dots, repeats and
    measure boundaries), transposes pitches, and only adds TAB technical data.
    This prevents the former melody-only exporter from rebuilding a compressed
    timeline that lost rests and tie sustain durations.
    """
    if source_path is not None:
        root = ET.parse(Path(source_path)).getroot()
        _strip_namespace(root)
        parts = root.findall("part")
        if not parts:
            raise ValueError("No <part> elements found in source MusicXML")
        measures = parts[0].findall("measure")
        if measures:
            _set_tab_attributes(measures[0], tuning)

        candidates = iter(path.candidates)
        current_candidate = None
        last_fingering_by_midi: dict[int, tuple[int, int]] = {}

        for measure in measures:
            for note in measure.findall("note"):
                pitch = note.find("pitch")
                if pitch is None:
                    continue
                original_midi = _pitch_element_to_midi(pitch)
                output_midi = original_midi + semitone_shift
                _set_pitch_element(pitch, output_midi)

                is_grace = note.find("grace") is not None
                stop_only = note.find("tie[@type='stop']") is not None and note.find("tie[@type='start']") is None
                is_chord = note.find("chord") is not None

                if stop_only and output_midi in last_fingering_by_midi:
                    string, fret = last_fingering_by_midi[output_midi]
                elif is_grace:
                    string, fret = _fallback_fingering(output_midi, tuning)
                else:
                    try:
                        current_candidate = next(candidates)
                    except StopIteration:
                        current_candidate = None
                    if current_candidate is not None:
                        string, fret = current_candidate.string, current_candidate.fret
                    else:
                        string, fret = _fallback_fingering(output_midi, tuning)
                    last_fingering_by_midi[output_midi] = (string, fret)

                _ensure_technical(note, string, fret)

        # Update title without disturbing the remainder of the source score.
        work = root.find("work")
        if work is None:
            work = ET.Element("work")
            root.insert(0, work)
        work_title = work.find("work-title")
        if work_title is None:
            work_title = ET.SubElement(work, "work-title")
        work_title.text = title

        rough = ET.tostring(root, encoding="utf-8")
        return minidom.parseString(rough).toprettyxml(indent="  ")

    # Legacy fallback for callers that have no source score available.
    score = ET.Element("score-partwise", version="3.1")
    work = ET.SubElement(score, "work")
    _add_text(work, "work-title", title)
    part_list = ET.SubElement(score, "part-list")
    score_part = ET.SubElement(part_list, "score-part", id="P1")
    _add_text(score_part, "part-name", "Guitar TAB")
    part = ET.SubElement(score, "part", id="P1")
    divisions = 480

    grouped: dict[int, list] = {}
    for candidate in path.candidates:
        grouped.setdefault(candidate.note.measure or 1, []).append(candidate)
    if not grouped:
        grouped[1] = []

    for measure_number in sorted(grouped):
        measure_el = ET.SubElement(part, "measure", number=str(measure_number))
        if measure_number == min(grouped):
            attributes = ET.SubElement(measure_el, "attributes")
            _add_text(attributes, "divisions", divisions)
            time = ET.SubElement(attributes, "time")
            _add_text(time, "beats", 4); _add_text(time, "beat-type", 4)
            _set_tab_attributes(measure_el, tuning)
        cursor = float(measure_number - min(grouped)) * 4.0
        for candidate in sorted(grouped[measure_number], key=lambda c: c.note.start):
            gap = candidate.note.start - cursor
            if gap > 1e-6:
                rest = ET.SubElement(measure_el, "note")
                ET.SubElement(rest, "rest")
                _add_text(rest, "duration", int(round(gap * divisions)))
                _add_text(rest, "voice", 1)
                cursor += gap
            note_el = ET.SubElement(measure_el, "note")
            pitch_el = ET.SubElement(note_el, "pitch")
            step, alter, octave = _midi_to_step_alter_octave(candidate.note.pitch.midi)
            _add_text(pitch_el, "step", step)
            if alter: _add_text(pitch_el, "alter", alter)
            _add_text(pitch_el, "octave", octave)
            duration = max(1, int(round(candidate.note.duration * divisions)))
            _add_text(note_el, "duration", duration)
            _add_text(note_el, "voice", 1)
            _ensure_technical(note_el, candidate.string, candidate.fret)
            cursor = candidate.note.start + candidate.note.duration

    rough = ET.tostring(score, encoding="utf-8")
    return minidom.parseString(rough).toprettyxml(indent="  ")


def write_tab_musicxml(
    path: FingeringPath,
    output_path: str | Path,
    title: str = "GSTE TAB Export",
    tuning: Tuning = STANDARD_TUNING,
    *,
    source_path: str | Path | None = None,
    semitone_shift: int = 0,
) -> Path:
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        fingering_path_to_tab_musicxml(
            path, title=title, tuning=tuning,
            source_path=source_path, semitone_shift=semitone_shift,
        ),
        encoding="utf-8",
    )
    return output
