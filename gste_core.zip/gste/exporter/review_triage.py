"""v0.13.5.12.4 consolidated human + GPT review packet."""
from __future__ import annotations
from gste.version import VERSION
from pathlib import Path
import json


def build_review_triage(*, timeline: dict, rhythm: dict, dissonance: dict, input_route: str) -> dict:
    queue=[]
    dis_status=dissonance.get('status')
    first_stage=timeline.get('first_mismatch_stage')
    serializer_ok=timeline.get('serializer_melody_status')=='PASS'
    if first_stage:
        queue.append({
            'priority':100,'category':'MELODY_BACKBONE_MUTATION',
            'location':timeline.get('first_mismatch'),
            'classification':'LOCKED_BACKBONE_MUTATION',
            'summary':f'Locked melody first differs at {first_stage}',
            'action':'Inspect the first stage that changed structural_event_id / MIDI / attack / release. Do not repair in Serializer.'
        })
    if not serializer_ok:
        audit=timeline.get('serializer_manifest_audit',{})
        queue.append({
            'priority':95,'category':'SERIALIZER_BACKBONE_EMISSION',
            'location':audit.get('mismatches',[None])[0] if audit.get('mismatches') else None,
            'summary':f"Serializer emission status = {timeline.get('serializer_melody_status')}",
            'action':'Fix structural-event mapping in Serializer; the Locked Melody Backbone remains authoritative.'
        })
    diag=rhythm.get('primary_diagnosis')
    if diag and diag!='TIMELINE_INTEGRITY_PASS':
        pr=90 if diag in ('GSTE_TIMELINE_MUTATION','SERIALIZER_BACKBONE_EMISSION_MISMATCH') else 55
        queue.append({'priority':pr,'category':'RHYTHM','location':None,'summary':diag,'action':'Check the locked backbone and the first mutation stage; do not reconstruct another melody timeline.'})
    for x in dissonance.get('issues',[]):
        sev=x.get('severity'); pr={'VERY_HIGH':85,'HIGH':75,'REVIEW':50}.get(sev,30)
        queue.append({'priority':pr,'category':'DISSONANCE','issue_id':x.get('issue_id'),'location':{'measure':x.get('measure'),'beat':x.get('beat_quarters')},'summary':f"{x.get('melody_pitch')} vs {x.get('accompaniment_pitch')} {x.get('interval')} — {x.get('cause')}",'action':x.get('suggested_repairs',[None])[0],'source_hint':x.get('provenance_hint')})
    queue.sort(key=lambda x:-x['priority'])
    return {
        'version':VERSION,'input_route':input_route,
        'purpose':'Review-only triage using one Locked Melody Backbone. No serialized melody timeline is reconstructed.',
        'headline':{
            'melody_first_mismatch_stage':first_stage,
            'serializer_melody_status':timeline.get('serializer_melody_status'),
            'rhythm_primary_diagnosis':rhythm.get('primary_diagnosis'),
            'dissonance_status':dissonance.get('status','UNKNOWN'),
            'diagnostic_self_validation_status':('INCOMPLETE' if dis_status=='INCOMPLETE' else 'PASS'),
            'dissonance_issue_count':dissonance.get('issue_count',0),
            'dissonance_severity_counts':dissonance.get('severity_counts',{})
        },
        'review_queue':queue[:300],
        'review_protocol':[
            '1. structural_event_id + MIDI + attack/release are locked when melody identity is established.',
            '2. Any later mutation is a hard correctness error; do not repair it in export.',
            '3. Serializer is checked only against the same backbone emission manifest.',
            '4. Review harmony/voicing only after backbone + hand hard rules pass.'
        ],
        'gpt_review_prompt':'Treat the Locked Melody Backbone as the only melody timing authority. Never infer a second melody clock from MusicXML output.'
    }


def write_review_triage(data: dict, *, debug_dir: str | Path, output_dir: str | Path) -> tuple[Path,Path]:
    debug=Path(debug_dir); out=Path(output_dir); debug.mkdir(parents=True,exist_ok=True); out.mkdir(parents=True,exist_ok=True)
    jp=debug/'22_GPT_HUMAN_REVIEW_PACKET.json'; mp=out/'12_GPT_HUMAN_REVIEW_PACKET.md'
    jp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    h=data['headline']
    lines=[f'# GSTE {VERSION} GPT + Human Review Packet','',
           'This is a **review queue**, not an automatic correction list. Use it to avoid missing isolated anomalies.','',
           '## One-page status','',
           f"- Melody first mismatch: **{h['melody_first_mismatch_stage'] or 'NONE'}**",
           f"- Serializer melody emission: **{h['serializer_melody_status']}**",
           f"- Rhythm diagnosis: **{h['rhythm_primary_diagnosis']}**",
           f"- Dissonance issues: **{h['dissonance_issue_count']}** `{h['dissonance_severity_counts']}`",'',
           '## Prioritized review queue','',
           '| Priority | Category | Location | Summary | Suggested first action | Human result |','|---:|---|---|---|---|---|']
    for q in data['review_queue'][:120]:
        loc=q.get('location'); loc_txt='—'
        if isinstance(loc,dict) and 'measure' in loc: loc_txt=f"M{loc.get('measure')} beat {loc.get('beat')}"
        elif loc: loc_txt=str(loc)[:80]
        action=(q.get('action') or '—').replace('|','/')
        lines.append(f"| {q['priority']} | {q['category']} | {loc_txt} | {q['summary']} | {action} | ☐ |")
    if not data['review_queue']: lines.append('| — | — | — | No flagged review items | — | ☐ |')
    lines += ['','## Human review labels','','Use one of: `TRUE_PROBLEM`, `INTENTIONAL`, `SOURCE_ORIGINAL`, `FALSE_POSITIVE`. Add the measure/beat and a short listening note.','','## GPT review instruction','',data['gpt_review_prompt'],'']
    mp.write_text('\n'.join(lines),encoding='utf-8')
    return jp,mp
