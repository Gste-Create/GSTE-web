from __future__ import annotations

import json
from pathlib import Path


def _pitch_name(midi: int) -> str:
    names = ("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    return f"{names[midi % 12]}{midi // 12 - 1}"


def build_melody_range_debug(backbone, tuning, *, maximum_fret: int = 18, evaluations=None) -> dict:
    """Read-only range diagnostic. Never changes melody, transform, or fingering state."""
    events = tuple(getattr(backbone, "events", ()) or ())
    notes = tuple(getattr(backbone, "notes", ()) or ())
    source_kind = "LOCKED_MELODY_BACKBONE"
    # TrackData also has an audit-only ``events`` collection of MusicalEvent
    # objects whose pitch field is named ``pitch_midi``.  Those records include
    # rests/tie continuations and are not the authoritative arranged melody.
    # Prefer locked backbone events only when they expose ``midi_pitch``; for a
    # TrackData debug view, use its canonical NoteEvent ``notes`` instead.
    if events and all(hasattr(e, "midi_pitch") for e in events):
        midis = [int(e.midi_pitch) for e in events]
    elif notes:
        midis = [int(n.pitch.midi) for n in notes]
        source_kind = "MELODY_TRACK_DEBUG_VIEW"
    else:
        midis = [int(e.pitch_midi) for e in events if getattr(e, "pitch_midi", None) is not None]
        source_kind = "MUSICAL_EVENT_AUDIT_DEBUG_VIEW" if midis else "EMPTY"
    opens = tuple(int(v) for v in tuning.strings.values())
    guitar_min = min(opens)
    guitar_max = max(opens) + int(maximum_fret)
    guitar_span = guitar_max - guitar_min

    melody_min = min(midis) if midis else None
    melody_max = max(midis) if midis else None
    melody_span = melody_max - melody_min if midis else None
    mathematical_fit = bool(midis) and melody_span <= guitar_span

    # Inclusive interval of whole-song semitone shifts that fit pitch range only.
    shift_min = guitar_min - melody_min if midis else None
    shift_max = guitar_max - melody_max if midis else None

    data = {
        "semantics": "READ_ONLY_DEBUG; compares the current authoritative melody view with configured guitar physical pitch span. No arrangement state is changed.",
        "source_kind": source_kind,
        "melody": {
            "event_count": len(midis),
            "min_midi": melody_min,
            "min_pitch": _pitch_name(melody_min) if melody_min is not None else None,
            "max_midi": melody_max,
            "max_pitch": _pitch_name(melody_max) if melody_max is not None else None,
            "span_semitones": melody_span,
        },
        "guitar": {
            "tuning": getattr(tuning, "name", "unknown"),
            "min_midi": guitar_min,
            "min_pitch": _pitch_name(guitar_min),
            "max_midi": guitar_max,
            "max_pitch": _pitch_name(guitar_max),
            "maximum_fret": int(maximum_fret),
            "span_semitones": guitar_span,
        },
        "whole_song_shift_feasibility": {
            "pitch_span_can_fit": mathematical_fit,
            "reason": (
                "MELODY_SPAN_WITHIN_GUITAR_SPAN" if mathematical_fit
                else "MELODY_SPAN_EXCEEDS_GUITAR_SPAN"
            ) if midis else "NO_MELODY_EVENTS",
            "valid_total_shift_min_semitones": shift_min,
            "valid_total_shift_max_semitones": shift_max,
            "has_any_pitch_range_only_shift": bool(midis) and shift_min <= shift_max,
            "note": "This proves pitch-range feasibility only; Joint/hand-shape/voice-separation constraints can still reject a transform.",
        },
    }

    if evaluations is not None:
        rows = []
        for item in evaluations:
            shift = int(item.candidate.total_shift)
            rows.append({
                "label": item.candidate.label,
                "total_shift": shift,
                "shifted_min_midi": melody_min + shift if melody_min is not None else None,
                "shifted_max_midi": melody_max + shift if melody_max is not None else None,
                "pitch_range_fit": bool(midis) and guitar_min <= melody_min + shift and melody_max + shift <= guitar_max,
                "melody_playable_ok": bool(item.melody_playable_ok),
                "eligible": bool(item.eligible),
                "rejection_reasons": list(item.rejection_reasons),
            })
        data["evaluated_global_transforms"] = rows
    return data


def write_melody_range_debug(backbone, tuning, path: str | Path, *, maximum_fret: int = 18, evaluations=None) -> tuple[Path, Path]:
    js = Path(path)
    if js.suffix.lower() != ".json":
        js = js.with_suffix(".json")
    md = js.with_suffix(".md")
    js.parent.mkdir(parents=True, exist_ok=True)
    data = build_melody_range_debug(backbone, tuning, maximum_fret=maximum_fret, evaluations=evaluations)
    js.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    m, g, f = data["melody"], data["guitar"], data["whole_song_shift_feasibility"]
    lines = [
        "# Melody / Guitar Range DEBUG", "",
        "**READ ONLY — this report never changes pitch, timing, transform, Joint, or fingering.**", "",
        f"- Melody min: **{m['min_pitch']} / MIDI {m['min_midi']}**",
        f"- Melody max: **{m['max_pitch']} / MIDI {m['max_midi']}**",
        f"- Melody span: **{m['span_semitones']} semitones**",
        f"- Guitar range: **{g['min_pitch']} / MIDI {g['min_midi']} → {g['max_pitch']} / MIDI {g['max_midi']}**",
        f"- Guitar span: **{g['span_semitones']} semitones** (max fret {g['maximum_fret']})",
        f"- Whole-song shift can fit pitch range: **{'YES' if f['pitch_span_can_fit'] else 'NO'}**",
        f"- Pitch-range-only valid total shift interval: **{f['valid_total_shift_min_semitones']} .. {f['valid_total_shift_max_semitones']} semitones**",
        "", f"Result: **{f['reason']}**", "",
        "> This checks pitch range only. A mathematically fitting shift may still fail Joint / hand-shape / voice-separation constraints.",
    ]
    rows = data.get("evaluated_global_transforms")
    if rows is not None:
        lines += ["", "## Evaluated Global Transforms", "", "| Candidate | Shift | Shifted range | Range fit | Playable | Eligible | Rejection |", "|---|---:|---|---|---|---|---|"]
        for r in rows:
            shifted = f"{_pitch_name(r['shifted_min_midi'])}..{_pitch_name(r['shifted_max_midi'])}" if r['shifted_min_midi'] is not None else "-"
            lines.append(f"| {r['label']} | {r['total_shift']:+d} | {shifted} | {'PASS' if r['pitch_range_fit'] else 'FAIL'} | {'PASS' if r['melody_playable_ok'] else 'FAIL'} | {'YES' if r['eligible'] else 'NO'} | {', '.join(r['rejection_reasons']) or '-'} |")
    md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return md, js
