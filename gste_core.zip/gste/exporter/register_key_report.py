from __future__ import annotations
from gste.version import VERSION

import json
from pathlib import Path

from gste.register_key_config import (
    HIGH_FRET_THRESHOLD, ORIGINAL_REGISTER_MIN_BASS_RETENTION,
    ORIGINAL_REGISTER_MIN_COMFORT_RATE, ORIGINAL_REGISTER_MIN_FULL_WINDOW_RATE,
    REGISTER_PRESERVATION_ENABLED,
)
from gste.register_key_optimization import RegisterKeyEvaluation

_PRIORITY_FIELDS = (
    "hard eligibility / melody preservation", "melody fingering + transform soft cost",
    "severe transitions", "high-fret ratio", "comfortable fret coverage",
    "key transposition penalty", "melody octave penalty", "bass retention tie-break",
    "full-window tie-break", "melody-only fallback tie-break", "consecutive bass loss",
    "Joint DP total cost", "deterministic tie-break",
)


def _row(item: RegisterKeyEvaluation) -> dict:
    total = len(item.result.selected)
    return {
        "candidate_id": f"key_{item.candidate.key_semitones:+d}_oct_{item.candidate.octave_shift:+d}",
        "label": item.candidate.label,
        "key_semitones": item.candidate.key_semitones,
        "octave_shift": item.candidate.octave_shift,
        "melody_floor_ok": item.melody_floor_ok,
        "melody_preferred_register_ok": item.melody_floor_ok,
        "melody_physical_range_ok": item.melody_playable_ok,
        "voice_separation_ok": item.voice_separation_ok,
        "bass_retention_rate": item.bass_retention_rate,
        "comfort_rate_0_7": item.comfort_rate,
        "full_candidate_windows": item.full_candidate_windows,
        "octave_repair_count": item.octave_repair_count,
        "full_window_rate": item.full_candidate_windows / total if total else 0.0,
        "total_windows": total,
        "melody_only_fallback_count": item.melody_only_fallback_count,
        "severe_transition_count": item.severe_transition_count,
        "long_high_fret_run_count": item.long_high_fret_run_count,
        "consecutive_bass_loss_max": item.consecutive_bass_loss_max,
        "register_preservation_rank": item.register_preservation_rank,
        "melody_average_fret": item.melody_average_fret,
        "melody_median_fret": item.melody_median_fret,
        "melody_high_fret_ratio": item.melody_high_fret_ratio,
        "melody_fingering_cost": item.melody_fingering_cost,
        "transpose_distance_penalty": item.transpose_distance_penalty,
        "octave_shift_penalty": item.octave_shift_penalty,
        "joint_dp_total_cost": item.result.total_cost,
        "melody_playable_ok": item.melody_playable_ok,
        "melody_transform_integrity_ok": item.melody_transform_integrity_ok,
        "eligible": item.eligible,
        "rejection_reasons": list(item.rejection_reasons),
        "physical_failure_details": list(item.physical_failure_details),
        "final_rank_tuple": list(item.score),
    }


def _first_difference(a: RegisterKeyEvaluation, b: RegisterKeyEvaluation) -> str:
    for index, (left, right) in enumerate(zip(a.score, b.score)):
        if left != right:
            return _PRIORITY_FIELDS[index]
    return "none"


def write_register_key_report(selected: RegisterKeyEvaluation, all_evaluations: tuple[RegisterKeyEvaluation, ...], path: str | Path) -> tuple[Path, Path]:
    md = Path(path); js = md.with_suffix(".json"); md.parent.mkdir(parents=True, exist_ok=True)
    ordered = sorted(all_evaluations, key=lambda item: item.score)
    competitor = next((item for item in ordered if item is not selected), None)
    first_difference = _first_difference(selected, competitor) if competitor else "none"
    octave_required = selected.candidate.octave_shift != 0
    reason = (
        f"Selected by v0.13.4 physical-validity-first Global Transform scoring; first difference from nearest competitor: {first_difference}. "
        "Original key and octave are soft preferences and may be overridden only by a better melody fingering result."
    )
    data = {
        "version": VERSION,
        "engine_version": "0.13.4",
        "search_pruning": {"strategy": "route-aware-safe-hierarchical", "stage1_total": 22, "auto_melody_stage1_target": 8, "source_piano_stage1_target": 4, "safe_expansion_enabled": True},
        "transform_semantics": {"key_transpose_applies_to": "melody+source_harmony", "melody_octave_applies_to": "melody_only", "local_key_changes_allowed": False, "local_octave_changes_allowed": False},
        "parameters": {
            "register_preservation_enabled": REGISTER_PRESERVATION_ENABLED,
            "original_register_min_comfort_rate": ORIGINAL_REGISTER_MIN_COMFORT_RATE,
            "original_register_min_bass_retention": ORIGINAL_REGISTER_MIN_BASS_RETENTION,
            "original_register_min_full_window_rate": ORIGINAL_REGISTER_MIN_FULL_WINDOW_RATE,
            "high_fret_threshold": HIGH_FRET_THRESHOLD,
        },
        "selection": {
            "selected_candidate_id": _row(selected)["candidate_id"],
            "nearest_competitor_id": _row(competitor)["candidate_id"] if competitor else None,
            "first_differing_priority_field": first_difference,
            "original_register_preserved": not octave_required,
            "octave_down_required": octave_required,
            "reason": reason,
        },
        "selected": {**_row(selected), "selected": True},
        "candidates": [{**_row(item), "selected": item is selected} for item in all_evaluations],
    }
    js.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = [
        f"# GSTE {VERSION} Global Transform Search",
        "", f"- Selected: **{selected.candidate.label}**",
        f"- Original register preserved: **{'YES' if not octave_required else 'NO'}**",
        f"- Octave-down required: **{'YES' if octave_required else 'NO'}**",
        f"- Nearest competitor: **{competitor.candidate.label if competitor else 'None'}**",
        f"- First differing priority: **{first_difference}**",
        f"- Selection reason: {reason}",
        f"- Melody fingering cost: **{selected.melody_fingering_cost:.2f}**",
        f"- Transform soft penalty: **{selected.transpose_distance_penalty + selected.octave_shift_penalty:.2f}**",
        f"- Average / median fret: **{selected.melody_average_fret:.2f} / {selected.melody_median_fret:.2f}**",
        f"- High-fret ratio: **{selected.melody_high_fret_ratio:.0%}**",
        f"- Bass retention: **{selected.bass_retention_rate:.0%}**",
        f"- Melody in 0–7 fret comfort zone: **{selected.comfort_rate:.0%}**",
        f"- Preferred melody register floor (D3): **{'PASS' if selected.melody_floor_ok else 'FAIL'}**",
        f"- Melody fully playable on fretboard: **{'PASS' if selected.melody_playable_ok else 'FAIL'}**",
        f"- Global-transform melody integrity: **{'PASS' if selected.melody_transform_integrity_ok else 'FAIL'}**",
        f"- Voice separation: **{'PASS' if selected.voice_separation_ok else 'FAIL'}**",
        f"- Melody-only fallback windows: **{selected.melody_only_fallback_count}**",
        f"- Severe transitions: **{selected.severe_transition_count}**",
        f"- Longest high-fret run: **{selected.long_high_fret_run_count} window(s)**",
        f"- Maximum consecutive bass loss: **{selected.consecutive_bass_loss_max} window(s)**",
        "", "| Candidate | Eligible | Register | Bass | 0–7 fret | Full | Melody only | Severe moves | High run | Bass-loss run |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for item in all_evaluations:
        row = _row(item)
        lines.append(
            f"| {row['label']} | {'Yes' if row['eligible'] else 'No'} | {row['register_preservation_rank']} | "
            f"{row['bass_retention_rate']:.0%} | {row['comfort_rate_0_7']:.0%} | "
            f"{row['full_candidate_windows']}/{row['total_windows']} | {row['melody_only_fallback_count']} | "
            f"{row['severe_transition_count']} | {row['long_high_fret_run_count']} | {row['consecutive_bass_loss_max']} |"
        )
    md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return md, js


def write_no_valid_register_key_report(all_evaluations: tuple[RegisterKeyEvaluation, ...], path: str | Path) -> tuple[Path, Path]:
    """Write diagnostics when no physically/integrity-valid Global Transform survives full evaluation."""
    md = Path(path); js = md.with_suffix(".json"); md.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "engine_version": "0.13.4",
        "status": "NO_VALID_GLOBAL_TRANSFORM",
        "selected": None,
        "candidates": [{**_row(item), "selected": False} for item in all_evaluations],
    }
    js.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = [
        f"# GSTE {VERSION} Global Transform Search", "",
        "**Status: NO_VALID_GLOBAL_TRANSFORM**", "",
        "Every fully evaluated transform violated a true melody hard gate. Preferred register or ergonomic weakness alone does not make a transform invalid.", "",
        "| Candidate | Eligible | Rejection reasons | Preferred register | Physical range | Integrity |",
        "|---|---|---|---|---|---|",
    ]
    for item in all_evaluations:
        row = _row(item)
        reasons = ", ".join(row["rejection_reasons"]) or "-"
        lines.append(
            f"| {row['label']} | {'Yes' if row['eligible'] else 'No'} | {reasons} | "
            f"{'PASS' if row['melody_floor_ok'] else 'FAIL'} | "
            f"{'PASS' if row['melody_playable_ok'] else 'FAIL'} | "
            f"{'PASS' if row['melody_transform_integrity_ok'] else 'FAIL'} |"
        )
    detailed = [item for item in all_evaluations if item.physical_failure_details]
    if detailed:
        lines.extend(["", "## Physical range failure details", ""] )
        for item in detailed:
            lines.append(f"### {item.candidate.label}")
            lines.append("")
            lines.append("| Measure | Start | MIDI | Pitch | Reason | Guitar range |")
            lines.append("|---:|---:|---:|---|---|---|")
            for detail in item.physical_failure_details[:24]:
                lines.append(
                    f"| {detail.get('measure')} | {detail.get('start')} | {detail.get('pitch_midi')} | "
                    f"{detail.get('pitch_name') or '-'} | {detail.get('reason')} | "
                    f"{detail.get('lowest_guitar_pitch_midi')}..{detail.get('highest_guitar_pitch_midi')} |"
                )
            if len(item.physical_failure_details) > 24:
                lines.append(f"| ... | ... | ... | ... | +{len(item.physical_failure_details)-24} more | ... |")
            lines.append("")
    md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return md, js
