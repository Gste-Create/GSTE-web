from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from gste.control.loader import active_profile_path, get_value
from gste.version import VERSION


@dataclass(frozen=True)
class EngineerDebugSummaryPaths:
    markdown: Path
    json: Path


PARAMETER_HINTS: dict[str, tuple[str, str]] = {
    "harmony_low_score": (
        "Harmony candidate/scoring",
        "harmony.melody_fit_weight, harmony.strong_beat_fit_weight, harmony.long_note_fit_weight, harmony.conflict_penalty, harmony.*complexity*, harmony.transition_*",
    ),
    "texture_static": (
        "Texture policy",
        "texture.strong_transition_threshold, texture.phrase_contrast_transition_threshold",
    ),
    "melody_too_sparse": (
        "Melody-only rhythm conditioning",
        "melody_only.max_motion_attacks, melody_only.busy_max_motion_attacks, melody_only.busy_attack_occupancy, melody_only.*grammars",
    ),
    "piano_too_dense": (
        "Piano compression / rhythm",
        "piano.dense_source_threshold, piano.high_budget_max_attacks, piano.medium_budget_max_attacks, piano.compressed_max_attacks",
    ),
    "joint_position": (
        "Joint hand movement",
        "joint.position_move_cost_per_fret, joint.large_position_move_threshold, joint.large_position_move_penalty, joint.retained_note_reward, joint.same_shape_family_reward",
    ),
    "joint_span": (
        "Joint ergonomic soft cost",
        "joint.joint_span_penalty_per_fret, joint.ergonomic_span3_soft_cost, joint.ergonomic_span4_soft_cost, joint.optional_wide_span3_cost, joint.optional_wide_span4_cost",
    ),
    "joint_bass": (
        "Bass preservation",
        "joint.bass_identity_rank_cost, joint.bass_line_pitch_class_break_cost, joint.bass_line_unnecessary_jump_cost",
    ),
    "joint_repetition": (
        "Arpeggio repetition / musicality",
        "joint.two_note_arpeggio_repetition_cost",
    ),
    "joint_collision": (
        "Melody/accompaniment register collision",
        "joint.melody_collision_m2_m9_cost, joint.melody_register_proximity_cost, joint.melody_accompaniment_distance_*",
    ),
    "search_loss": (
        "Search width / prefilter",
        "search.melody_paths_per_window, search.accompaniment_per_chord, search.joint_candidates_per_window, search.max_candidates_per_note",
    ),
    "information_loss": (
        "Piano information retention",
        "piano.information_loss.*, joint.pruning_order",
    ),
}


def _load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else None
    except Exception:
        return None


def _find_core_root(root: Path) -> Path:
    if (root / "debug" / "10_joint_candidates.json").exists():
        return root
    nested = root / "04_register_search" / "existing_core"
    if (nested / "debug" / "10_joint_candidates.json").exists():
        return nested
    for p in root.rglob("10_joint_candidates.json"):
        if p.parent.name == "debug":
            return p.parent.parent
    return root


def _safe_num(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _selected_candidate(window: dict[str, Any]) -> dict[str, Any] | None:
    for c in window.get("candidates", []):
        if c.get("selected"):
            return c
    return None


def _top_positive_costs(candidate: dict[str, Any], limit: int = 5) -> list[tuple[str, float]]:
    items: list[tuple[str, float]] = []
    for source_key in ("cost_breakdown", "diagnostic_transition_breakdown"):
        mapping = candidate.get(source_key) or {}
        if not isinstance(mapping, dict):
            continue
        for key, value in mapping.items():
            if isinstance(value, (int, float)) and value > 0.0 and key.endswith(("cost", "penalty")):
                items.append((key, float(value)))
    items.sort(key=lambda kv: kv[1], reverse=True)
    return items[:limit]


def _hint_keys_for_candidate(candidate: dict[str, Any]) -> list[str]:
    cb = candidate.get("cost_breakdown") or {}
    tb = candidate.get("diagnostic_transition_breakdown") or {}
    hints: list[str] = []
    if _safe_num(tb.get("hand_center_transition_cost")) >= 10 or _safe_num(tb.get("position_move_cost")) >= 10:
        hints.append("joint_position")
    if _safe_num(cb.get("ergonomic_wide_shape_soft_cost")) > 0 or _safe_num(cb.get("optional_accompaniment_wide_shape_cost")) > 0 or _safe_num(cb.get("joint_span_penalty")) > 0:
        hints.append("joint_span")
    if _safe_num(cb.get("bass_identity_cost")) > 0 or _safe_num(tb.get("bass_line_transition_cost")) > 0:
        hints.append("joint_bass")
    if _safe_num(cb.get("arpeggio_motion_cost")) > 0:
        hints.append("joint_repetition")
    if _safe_num(cb.get("melody_register_collision_cost")) > 0 or _safe_num(cb.get("melody_accompaniment_distance_cost")) > 0:
        hints.append("joint_collision")
    if _safe_num(cb.get("musical_information_loss_cost")) > 0 or _safe_num(cb.get("pruning_cost")) > 0:
        hints.append("information_loss")
    return hints


def _load_auto_context(root: Path) -> dict[str, dict[str, Any]]:
    auto_dir = root / "02_auto_arrangement"
    result: dict[str, dict[str, Any]] = {}
    if not auto_dir.exists():
        return result
    intents = _load_json(auto_dir / "arrangement_intents.json") or []
    canon = _load_json(auto_dir / "canonical_music_intents.json") or []
    prefilter = _load_json(auto_dir / "candidate_prefilter_diagnostics.json") or {}
    selected = _load_json(auto_dir / "selected_arrangement_candidates.json") or []
    for item in intents if isinstance(intents, list) else []:
        wid = item.get("window_id") if isinstance(item, dict) else None
        if wid:
            result.setdefault(wid, {})["intent"] = item
    for item in canon if isinstance(canon, list) else []:
        wid = item.get("window_id") if isinstance(item, dict) else None
        if not wid and isinstance(item, dict):
            wid = (item.get("harmony") or {}).get("window_id")
        if wid:
            result.setdefault(wid, {})["canonical"] = item
    for item in prefilter.get("windows", []) if isinstance(prefilter, dict) else []:
        wid = item.get("window_id") if isinstance(item, dict) else None
        if wid:
            result.setdefault(wid, {})["prefilter"] = item
    for item in selected if isinstance(selected, list) else []:
        if not isinstance(item, dict):
            continue
        wid = item.get("window_id") or (item.get("metadata") or {}).get("window_id")
        if wid:
            result.setdefault(wid, {})["selected_arrangement"] = item
    return result


def _load_piano_context(core_root: Path) -> dict[str, dict[str, Any]]:
    source = _load_json(core_root / "02_SOURCE_ARRANGEMENT_INTENTS.json") or {}
    result: dict[str, dict[str, Any]] = {}
    for row in source.get("windows", []) if isinstance(source, dict) else []:
        if not isinstance(row, dict):
            continue
        intent = row.get("intent") or {}
        wid = intent.get("window_id")
        if wid:
            result[wid] = row
    return result


def _global_status(core_root: Path) -> tuple[str, list[str]]:
    reasons: list[str] = []
    blocking = _load_json(core_root / "BLOCKING_INVARIANT.json")
    if isinstance(blocking, dict) and blocking.get("status") == "BLOCKED":
        reasons.append(f"BLOCKED: {blocking.get('invariant')} — {blocking.get('message')}")
        return "CORRECTNESS_BLOCKED", reasons
    timeline = _load_json(core_root / "debug" / "19_MELODY_TIMELINE_INTEGRITY.json") or {}
    mismatch = timeline.get("first_mismatch_stage") if isinstance(timeline, dict) else None
    if mismatch:
        reasons.append(f"Melody/timing first mismatch at {mismatch}")
        return "CORRECTNESS_REVIEW", reasons
    rhythm = _load_json(core_root / "debug" / "20_RHYTHM_GRID_DIAGNOSTICS.json") or {}
    diagnosis = rhythm.get("primary_diagnosis") if isinstance(rhythm, dict) else None
    if diagnosis and diagnosis not in {"TIMELINE_INTEGRITY_PASS", "MONITORING_UNAVAILABLE"}:
        reasons.append(f"Rhythm diagnosis: {diagnosis}")
    return "MUSICALITY_TUNING_ALLOWED", reasons


def _profile_snapshot() -> dict[str, Any]:
    keys = [
        "harmony.conflict_penalty", "harmony.diminished_complexity_cost", "harmony.transition_functional_reward", "harmony.transition_reverse_penalty",
        "texture.strong_transition_threshold", "texture.phrase_contrast_transition_threshold",
        "melody_only.busy_attack_occupancy", "melody_only.max_motion_attacks", "melody_only.busy_max_motion_attacks",
        "piano.dense_source_threshold", "piano.high_budget_max_attacks", "piano.medium_budget_max_attacks", "piano.compressed_max_attacks",
        "joint.position_move_cost_per_fret", "joint.large_position_move_penalty", "joint.bass_identity_rank_cost", "joint.two_note_arpeggio_repetition_cost",
        "joint.ergonomic_span3_soft_cost", "joint.ergonomic_span4_soft_cost", "joint.melody_collision_m2_m9_cost", "joint.melody_register_proximity_cost",
        "search.melody_paths_per_window", "search.accompaniment_per_chord", "search.joint_candidates_per_window", "search.max_candidates_per_note",
    ]
    return {key: get_value(key, None) for key in keys}


def _engineering_health(core_root: Path) -> dict[str, Any]:
    """Summarize path health without changing any production decision."""
    lifecycle = _load_json(core_root / "debug" / "18_retention_lifecycle.json") or {}
    final_review = _load_json(core_root / "04_FINAL_FINGERING_REVIEW.json") or _load_json(core_root / "final_fingering_review.json") or {}
    identity = _load_json(core_root / "debug" / "25_MELODY_IDENTITY_LIFECYCLE.json") or {}
    timeline = _load_json(core_root / "debug" / "19_MELODY_TIMELINE_INTEGRITY.json") or {}
    arrangement = _load_json(core_root / "debug" / "15_arrangement_diagnostics.json") or {}

    transitions = lifecycle.get("transitions", []) if isinstance(lifecycle, dict) else []
    losses = [r for r in transitions if int(r.get("delta_notes", 0) or 0) < 0]
    largest_loss = min((int(r.get("delta_notes", 0) or 0) for r in transitions), default=0)
    stages = lifecycle.get("stages", []) if isinstance(lifecycle, dict) else []
    legacy_safe = 0
    for stage in stages:
        legacy_safe = max(legacy_safe, int((stage.get("by_texture") or {}).get("LEGACY_SAFE", 0) or 0))
    issues = final_review.get("issues", []) if isinstance(final_review, dict) else []
    fingering_deletions = sum(1 for row in issues if row.get("status") == "ACCOMPANIMENT_SIMPLIFIED")
    local_reopts = sum(1 for row in issues if row.get("status") == "LOCAL_REOPTIMIZED")
    physical_remaining = int(((final_review.get("counts") or {}).get("physical_remaining", 0)) or 0) if isinstance(final_review, dict) else 0
    final_melody_ok = bool(final_review.get("melody_identity_preserved", True)) if isinstance(final_review, dict) else True
    joint_dropped = int(identity.get("dropped_by_joint_count", 0) or 0) if isinstance(identity, dict) else 0
    joint_priority_ok = bool(identity.get("source_priority_contract_preserved", identity.get("melody_contract_preserved", joint_dropped == 0))) if isinstance(identity, dict) else True
    timeline_ok = not bool(timeline.get("first_mismatch_stage")) if isinstance(timeline, dict) else True
    # Primary melody identity is the locked 303-event backbone audited by the
    # timeline + final-fingering monitors. Source-piano-priority notes are an
    # accompaniment/texture retention contract and must not be mislabeled as
    # missing primary melody.
    melody_ok = final_melody_ok and timeline_ok
    arrangement_ok = (arrangement.get("arrangement_status") in {None, "PASS"}) if isinstance(arrangement, dict) else True

    if not melody_ok or not timeline_ok or physical_remaining or not arrangement_ok:
        status = "UNHEALTHY"
    elif (not joint_priority_ok) or fingering_deletions or losses:
        status = "HEALTHY_OUTPUT_WITH_RECOVERY"
    elif legacy_safe or local_reopts:
        status = "HEALTHY_WITH_SAFETY_NET"
    else:
        status = "HEALTHY_DIRECT_PATH"
    return {
        "scope": "LOCAL_ENGINEERING_HEALTH",
        "global_verdict_authority": False,
        "status": status,
        "direct_path": status == "HEALTHY_DIRECT_PATH",
        "timeline_clean": timeline_ok,
        "melody_identity_preserved": melody_ok,
        "final_fingering_melody_identity_preserved": final_melody_ok,
        "joint_priority_contract_preserved": joint_priority_ok,
        "primary_melody_contract_source": "19_MELODY_TIMELINE_INTEGRITY + 04_FINAL_FINGERING_REVIEW",
        "joint_priority_dropped_count": joint_dropped,
        "physical_remaining": physical_remaining,
        "accompaniment_loss_transitions": len(losses),
        "largest_accompaniment_delta": largest_loss,
        "fingering_accompaniment_deletions": fingering_deletions,
        "fingering_local_reoptimizations": local_reopts,
        "legacy_safe_notes": legacy_safe,
        "interpretation": {
            "HEALTHY_DIRECT_PATH": "正常候選一路通過，未觀察到伴奏刪除或保險路徑介入。",
            "HEALTHY_WITH_SAFETY_NET": "輸出正確，但曾使用保險/局部重選機制；先保留功能並持續批次觀察。",
            "HEALTHY_OUTPUT_WITH_RECOVERY": "最後輸出可用，但路徑中發生伴奏遺失或 Fingering 刪伴奏；不可只看 PASS，應追根因。",
            "UNHEALTHY": "Correctness/physical invariant 未通過；禁止用調參數或補釘掩蓋。",
        }.get(status, ""),
    }

def build_engineer_debug_summary(output_root: str | Path) -> dict[str, Any]:
    root = Path(output_root)
    core = _find_core_root(root)
    joint = _load_json(core / "debug" / "10_joint_candidates.json") or {"windows": []}
    arrangement_diag = _load_json(core / "debug" / "15_arrangement_diagnostics.json") or {}
    timeline = _load_json(core / "debug" / "19_MELODY_TIMELINE_INTEGRITY.json") or {}
    rhythm = _load_json(core / "debug" / "20_RHYTHM_GRID_DIAGNOSTICS.json") or {}
    dissonance = _load_json(core / "debug" / "21_DISSONANCE_DIAGNOSTICS.json") or {}
    identity = _load_json(core / "debug" / "25_MELODY_IDENTITY_LIFECYCLE.json") or {}
    dropped_priority = [e for e in (identity.get("events") or []) if e.get("status") == "DROPPED_BY_JOINT"] if isinstance(identity, dict) else []
    first_priority_drop = dropped_priority[0] if dropped_priority else None
    auto_context = _load_auto_context(root)
    piano_context = _load_piano_context(core)
    status, global_reasons = _global_status(core)

    windows: list[dict[str, Any]] = []
    for window in joint.get("windows", []) if isinstance(joint, dict) else []:
        selected = _selected_candidate(window)
        if not selected:
            continue
        wid = str(window.get("window_id"))
        auto = auto_context.get(wid, {})
        piano = piano_context.get(wid, {})
        intent = auto.get("intent") or piano.get("intent") or {}
        canonical = auto.get("canonical") or {}
        prefilter = auto.get("prefilter") or {}

        texture = intent.get("texture")
        density = intent.get("density")
        source_pattern = None
        if piano:
            source_pattern = (piano.get("source_pattern_analysis") or {}).get("pattern_type") or intent.get("pattern_type")
        if auto:
            source_pattern = intent.get("pattern_type") or source_pattern
        rhythm_intent = canonical.get("rhythm") if isinstance(canonical, dict) else None
        attacks = (rhythm_intent or {}).get("attacks") if isinstance(rhythm_intent, dict) else None
        if attacks is None:
            attacks = (intent.get("metadata") or {}).get("attacks")

        flags = list(window.get("check_flags") or [])
        top_costs = _top_positive_costs(selected)
        hints = _hint_keys_for_candidate(selected)
        if selected.get("chord_score") is not None and _safe_num(selected.get("chord_score")) < 5.0:
            hints.append("harmony_low_score")
        if texture in {"ROOT", "ROOT_GUIDE"} and density in {"MD0", "MD1", "HIGH"}:
            hints.append("texture_static")
        if texture in {"ARPEGGIO", "SPARSE_ARPEGGIO"} and isinstance(attacks, list | tuple) and len(attacks) <= 2:
            hints.append("melody_too_sparse")
        realized = prefilter.get("realized_candidate_count") if isinstance(prefilter, dict) else None
        if isinstance(realized, int) and realized <= 1:
            hints.append("search_loss")
        hints = list(dict.fromkeys(hints))

        windows.append({
            "window_id": wid,
            "check_required": bool(window.get("check_required") or flags or hints),
            "flags": flags,
            "chord": selected.get("chord"),
            "chord_score": selected.get("chord_score"),
            "density_or_budget": density,
            "texture": texture,
            "source_pattern": source_pattern,
            "rhythm_attacks": attacks,
            "grammar_or_candidate_type": selected.get("candidate_type") or selected.get("accompaniment_name"),
            "candidate_count": len(window.get("candidates") or []),
            "selected_vs_alternative_gap": window.get("selected_vs_best_alternative_gap"),
            "local_cost": selected.get("local_cost"),
            "transition_cost": selected.get("diagnostic_transition_cost"),
            "top_positive_costs": [{"name": k, "value": v} for k, v in top_costs],
            "parameter_hints": [
                {"area": PARAMETER_HINTS[h][0], "parameters": PARAMETER_HINTS[h][1]} for h in hints if h in PARAMETER_HINTS
            ],
        })

    def priority(w: dict[str, Any]) -> tuple[int, float]:
        score = 0
        if w.get("flags"): score += 5
        score += len(w.get("parameter_hints") or []) * 2
        top = w.get("top_positive_costs") or []
        maxcost = max((x.get("value", 0) for x in top), default=0)
        if maxcost >= 20: score += 4
        elif maxcost >= 8: score += 2
        gap = w.get("selected_vs_alternative_gap")
        if isinstance(gap, (int, float)) and abs(gap) < 3: score += 1
        return score, maxcost

    ranked = sorted(windows, key=priority, reverse=True)
    summary = {
        "version": VERSION,
        "purpose": "ENGINEER_DEBUG_SUMMARY",
        "output_root": str(root),
        "core_root": str(core),
        "active_profile": str(active_profile_path()),
        "status": status,
        "engineering_health": _engineering_health(core),
        "global_reasons": global_reasons,
        "first_meaningful_deviation": ({
            "stage": "SOURCE_PRIORITY_RETENTION_AT_JOINT",
            "measure": first_priority_drop.get("measure"),
            "source_event_id": first_priority_drop.get("source_event_id"),
            "reason": first_priority_drop.get("reason"),
            "dropped_by_joint_count": len(dropped_priority),
            "semantic_role": "SOURCE_PIANO_PRIORITY_NOT_PRIMARY_MELODY",
            "evidence": ["debug/25_MELODY_IDENTITY_LIFECYCLE.json", "debug/10_joint_candidates.json"],
        } if first_priority_drop else None),
        "correctness": {
            "melody_first_mismatch_stage": timeline.get("first_mismatch_stage") if isinstance(timeline, dict) else None,
            "rhythm_primary_diagnosis": rhythm.get("primary_diagnosis") if isinstance(rhythm, dict) else None,
            "dissonance_issue_count": dissonance.get("issue_count", 0) if isinstance(dissonance, dict) else 0,
            "arrangement_status": arrangement_diag.get("arrangement_status") if isinstance(arrangement_diag, dict) else None,
            "first_failed_window": arrangement_diag.get("first_failed_window") if isinstance(arrangement_diag, dict) else None,
        },
        "active_parameters": _profile_snapshot(),
        "review_priority": ranked[:20],
        "windows": windows,
        "reading_rule": "If correctness is not clean, do not tune musicality parameters. Otherwise inspect the first suspicious stage: Harmony -> Density/Budget -> Texture -> Rhythm -> Grammar/Candidate -> Joint/Fingering.",
    }
    return summary


def write_engineer_debug_summary(output_root: str | Path) -> EngineerDebugSummaryPaths:
    root = Path(output_root)
    data = build_engineer_debug_summary(root)
    target_dir = root / "00_summary" if (root / "00_summary").exists() else root
    target_dir.mkdir(parents=True, exist_ok=True)
    machine_dir = root / "debug"
    machine_dir.mkdir(parents=True, exist_ok=True)
    jp = machine_dir / "ENGINEER_DEBUG_SUMMARY.json"
    mp = target_dir / "ENGINEER_DEBUG_SUMMARY.md"
    jp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    status = data["status"]
    lines = [
        f"# {VERSION} Engineer Debug Summary", "",
        "> 目的：像看工程量測表一樣，先定位哪一層開始不合理，再決定要調參數還是改演算法。", "",
        f"- Status: **{status}**",
        f"- Active profile: `{data['active_profile']}`",
        f"- Melody first mismatch: **{data['correctness'].get('melody_first_mismatch_stage') or 'NONE'}**",
        f"- Rhythm diagnosis: **{data['correctness'].get('rhythm_primary_diagnosis') or 'N/A'}**",
        f"- Arrangement status: **{data['correctness'].get('arrangement_status') or 'N/A'}**",
        f"- Dissonance review issues: **{data['correctness'].get('dissonance_issue_count', 0)}**", "",
        "## 工程健康審查（先看這裡）", "",
        f"- 路徑健康度：**{data['engineering_health']['status']}**",
        f"- 旋律身份：**{'OK' if data['engineering_health']['melody_identity_preserved'] else 'FAIL'}**",
        f"- 時間主幹：**{'OK' if data['engineering_health']['timeline_clean'] else 'FAIL'}**",
        f"- Physical violation remaining：**{data['engineering_health']['physical_remaining']}**",
        f"- 伴奏在 stage 間遺失：**{data['engineering_health']['accompaniment_loss_transitions']} 個 transition**",
        f"- Fingering 刪伴奏：**{data['engineering_health']['fingering_accompaniment_deletions']} 次**",
        f"- Fingering 局部重選：**{data['engineering_health']['fingering_local_reoptimizations']} 次**",
        f"- LEGACY_SAFE 使用量：**{data['engineering_health']['legacy_safe_notes']}**", "",
        f"> {data['engineering_health']['interpretation']}", "",
        "**判讀原則：PASS 只代表最後結果可接受；HEALTHY_DIRECT_PATH 才代表目前沒有靠 recovery/保險機制掩蓋問題。保險功能先保留，不因單次 0 次使用就移除。**", "",
    ]
    if data["global_reasons"]:
        lines += ["## 先處理的 Correctness 問題", ""]
        lines += [f"- {x}" for x in data["global_reasons"]]
        lines += ["", "**此時先不要調 Harmony/Texture/Joint 音樂性參數。**", ""]
    else:
        lines += ["## 快速判斷", "", "Correctness 基本通過，可進入音樂性調參。依序看：**Harmony → Density/Budget → Texture → Rhythm → Grammar/Candidate → Joint/Fingering**。", ""]

    lines += [
        "## 優先檢查 Window", "",
        "| Window | Chord | Density/Budget | Texture | Attacks | Candidate | Local | Transition | 主要成本/警告 | 建議檢查 |",
        "|---|---|---|---|---|---|---:|---:|---|---|",
    ]
    for w in data["review_priority"]:
        costs = ", ".join(f"{x['name']}={x['value']:.1f}" for x in w.get("top_positive_costs", [])[:3]) or "—"
        flags = ", ".join(w.get("flags") or [])
        issue = "; ".join(x for x in (flags, costs) if x) or "—"
        hints = "; ".join(h["area"] for h in w.get("parameter_hints", [])) or "—"
        attacks = w.get("rhythm_attacks")
        lines.append(
            f"| {w['window_id']} | {w.get('chord') or '—'} | {w.get('density_or_budget') or '—'} | {w.get('texture') or '—'} | "
            f"{attacks if attacks is not None else '—'} | {w.get('grammar_or_candidate_type') or '—'} | "
            f"{_safe_num(w.get('local_cost')):.2f} | {_safe_num(w.get('transition_cost')):.2f} | {issue} | {hints} |"
        )
    if not data["review_priority"]:
        lines.append("| — | — | — | — | — | — | — | — | No flagged window | — |")

    lines += ["", "## 建議參數", ""]
    seen: set[tuple[str, str]] = set()
    for w in data["review_priority"]:
        for hint in w.get("parameter_hints", []):
            key = (hint["area"], hint["parameters"])
            if key in seen:
                continue
            seen.add(key)
            lines += [f"### {hint['area']}", f"- 先看：`{hint['parameters']}`", ""]
    if not seen:
        lines.append("目前沒有自動指向特定 Soft/Search parameter；若人耳仍覺得不自然，先確認該 Window 的 Texture / Attacks / Candidate 是否符合預期。")

    lines += [
        "", "## 讀法", "",
        "1. **旋律或節拍錯**：看 Melody first mismatch / Rhythm diagnosis；這是 correctness，不要用音樂性參數補。",
        "2. **和弦本身怪**：先看 chord / chord score，再調 `harmony.*`；若候選根本沒有想要的和弦，要改 candidate set，不是調權重。",
        "3. **伴奏太少/太機械**：先看 Density/Budget，再看 Texture；Texture 已是 ARPEGGIO 但 Attacks 很少，就查 Rhythm Conditioning。",
        "4. **有好候選但沒選**：看 Local/Transition cost 與 top_positive_costs，通常是 Joint/Fingering 權重。",
        "5. **候選數很少**：先看 Search / Prefilter，不要直接放寬 Hard Rule。", "",
        "## 目前 Profile 快照", "",
    ]
    for key, value in data["active_parameters"].items():
        lines.append(f"- `{key}` = `{value}`")
    mp.write_text("\n".join(lines) + "\n", encoding="utf-8")
    # Privacy-safe output is derived from the same diagnostic snapshot; no new observer layer.
    from gste.exporter.privacy_safe_debug_report import write_privacy_safe_debug_report
    write_privacy_safe_debug_report(root, data)
    return EngineerDebugSummaryPaths(markdown=mp, json=jp)
