from __future__ import annotations
from gste.version import VERSION

import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable

from gste.arrangement.importance import parse_auto_importance
from gste.joint_arrangement.models import JointArrangementResult


def _auto_texture(source_event_id: str | None) -> str:
    text = str(source_event_id or "")
    for name in ("ARPEGGIO", "SPARSE_ARPEGGIO", "ROOT_GUIDE", "ROOT", "LEGACY_SAFE"):
        if f"AUTO_{name}" in text or f"AUTODEG_{name}" in text:
            return name
    return "UNKNOWN"


def snapshot_result(result: JointArrangementResult, stage: str) -> dict:
    notes = []
    by_measure: Counter[int] = Counter()
    by_texture: Counter[str] = Counter()
    by_importance: Counter[str] = Counter()
    by_candidate_type: Counter[str] = Counter()
    by_window: dict[str, int] = {}
    event_ids: set[str] = set()
    for state in result.selected:
        count = len(state.accompaniment.notes)
        by_window[state.window_id] = count
        by_candidate_type[state.accompaniment.candidate_type] += 1
        for fc in state.accompaniment.notes:
            sid = str(fc.note.source_event_id or "")
            imp = fc.note.importance
            texture = str(getattr(fc.note, "texture_family", None) or getattr(fc.note, "source_variant", None) or _auto_texture(sid))
            by_measure[int(state.measure)] += 1
            by_texture[texture] += 1
            by_importance[str(imp if imp is not None else "UNMARKED")] += 1
            if sid:
                event_ids.add(sid)
            notes.append({
                "window_id": state.window_id,
                "measure": int(state.measure),
                "pitch": int(fc.note.pitch.midi),
                "start": float(fc.note.start),
                "duration": float(fc.note.duration),
                "string": int(fc.string),
                "fret": int(fc.fret),
                "source_event_id": sid or None,
                "importance": imp,
                "texture": texture,
                "candidate_type": state.accompaniment.candidate_type,
                "simplification_level": int(state.simplification_level),
            })
    return {
        "stage": stage,
        "windows": len(result.selected),
        "accompaniment_notes": len(notes),
        "unique_event_ids": len(event_ids),
        "by_measure": dict(sorted(by_measure.items())),
        "by_texture": dict(sorted(by_texture.items())),
        "by_importance": dict(sorted(by_importance.items())),
        "candidate_types": dict(sorted(by_candidate_type.items())),
        "by_window": dict(sorted(by_window.items())),
        "event_ids": sorted(event_ids),
        "notes": notes,
    }


def compare_snapshots(before: dict, after: dict, label: str) -> dict:
    before_ids = set(before.get("event_ids", []))
    after_ids = set(after.get("event_ids", []))
    before_measure = {int(k): int(v) for k, v in before.get("by_measure", {}).items()}
    after_measure = {int(k): int(v) for k, v in after.get("by_measure", {}).items()}
    measures = sorted(set(before_measure) | set(after_measure))
    per_measure = []
    for m in measures:
        b, a = before_measure.get(m, 0), after_measure.get(m, 0)
        if b != a:
            per_measure.append({"measure": m, "before": b, "after": a, "delta": a - b})
    bnotes, anotes = int(before.get("accompaniment_notes", 0)), int(after.get("accompaniment_notes", 0))
    return {
        "transition": label,
        "before_notes": bnotes,
        "after_notes": anotes,
        "delta_notes": anotes - bnotes,
        "retention_pct": round(anotes * 100.0 / bnotes, 1) if bnotes else None,
        "lost_event_ids": sorted(before_ids - after_ids),
        "added_event_ids": sorted(after_ids - before_ids),
        "lost_unique_event_ids": len(before_ids - after_ids),
        "per_measure_changes": per_measure,
    }


def build_lifecycle_report(snapshots: Iterable[dict], *, recovery_events: list[dict] | None = None) -> dict:
    snaps = list(snapshots)
    transitions = [
        compare_snapshots(snaps[i], snaps[i + 1], f"{snaps[i]['stage']} -> {snaps[i + 1]['stage']}")
        for i in range(len(snaps) - 1)
    ]
    biggest = sorted(
        transitions,
        key=lambda row: row.get("delta_notes", 0),
    )[:3]
    events=list(recovery_events or [])
    reason_counts=Counter(str(e.get("reason") or e.get("action") or "UNKNOWN") for e in events)
    variant_counts=Counter(str(e.get("source_variant") or "UNKNOWN") for e in events if e.get("source_variant"))
    importance_counts=Counter(str(e.get("importance") if e.get("importance") is not None else "UNMARKED") for e in events)
    return {
        "version": VERSION,
        "diagnostic_only": True,
        "purpose": "Trace accompaniment retention from Joint selection through Final Review and serialized export recovery without changing musical decisions.",
        "stages": snaps,
        "transitions": transitions,
        "largest_loss_transitions": biggest,
        "export_recovery_events": events,
        "export_recovery_attribution": {
            "reason_counts": dict(sorted(reason_counts.items())),
            "source_variant_counts": dict(sorted(variant_counts.items())),
            "importance_counts": dict(sorted(importance_counts.items())),
            "same_pitch_relocations": reason_counts.get("SAME_PITCH_STRING_FRET_RELOCATION", 0),
            "single_note_drops": reason_counts.get("AUTO_MELODY_IMPORTANCE_ORDERED_SINGLE_NOTE_DROP", 0),
            "measure_melody_only": reason_counts.get("MEASURE_LOCAL_MELODY_ONLY_LAST_RESORT", 0),
        },
    }


def write_lifecycle_report(data: dict, json_path: str | Path, md_path: str | Path) -> tuple[Path, Path]:
    jp, mp = Path(json_path), Path(md_path)
    jp.parent.mkdir(parents=True, exist_ok=True)
    mp.parent.mkdir(parents=True, exist_ok=True)
    jp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = [
        f"# GSTE {VERSION} Retention Lifecycle Diagnostics", "",
        "> Diagnostic-only. No arrangement, Joint scoring, fingering hard rule, or Piano behavior is changed by this report.", "",
        "## Stage summary", "", "| Stage | Accompaniment notes | Unique event IDs |", "|---|---:|---:|",
    ]
    for s in data.get("stages", []):
        lines.append(f"| {s['stage']} | {s['accompaniment_notes']} | {s['unique_event_ids']} |")
    lines += ["", "## Transition losses", "", "| Transition | Before | After | Delta | Retention |", "|---|---:|---:|---:|---:|"]
    for row in data.get("transitions", []):
        pct = "n/a" if row.get("retention_pct") is None else f"{row['retention_pct']:.1f}%"
        lines.append(f"| {row['transition']} | {row['before_notes']} | {row['after_notes']} | {row['delta_notes']} | {pct} |")
    lines += ["", "## Export recovery events", ""]
    events = data.get("export_recovery_events", [])
    if not events:
        lines.append("- None")
    else:
        for e in events:
            action=e.get("reason") or e.get("action")
            measure=e.get("measure") or e.get("measures")
            lines.append(f"- {action}: measure={measure} midi={e.get('midi')} variant={e.get('source_variant')} importance={e.get('importance')} string/fret={e.get('from_string')}/{e.get('from_fret')} -> {e.get('to_string')}/{e.get('to_fret')}")
        a=data.get("export_recovery_attribution", {})
        lines += ["", "### Recovery attribution", "", f"- Same-pitch relocations: {a.get('same_pitch_relocations',0)}", f"- Single-note drops: {a.get('single_note_drops',0)}", f"- Measure melody-only fallbacks: {a.get('measure_melody_only',0)}", f"- Source variants: {a.get('source_variant_counts',{})}"]
    mp.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return jp, mp
