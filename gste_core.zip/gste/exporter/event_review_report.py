"""v0.11.2 audit exports; these reports never feed arrangement decisions."""
from __future__ import annotations
from gste.version import VERSION

import json
from collections import Counter
from pathlib import Path


def event_to_dict(event) -> dict:
    return {
        "EventID": event.event_id,
        "kind": event.kind,
        "pitch": event.pitch_midi,
        "onset": event.start,
        "duration": event.duration,
        "measure": event.measure,
        "order": event.order,
        "staff": event.staff,
        "voice": event.voice,
        "tie": list(event.tie_types),
        "chord_id": event.chord_id,
        "grace": event.is_grace,
        "rest": event.is_rest,
        "chord_tone": event.is_chord_tone,
        "source_xml": event.source_xml,
    }


def build_event_integrity(right_hand, left_hand) -> dict:
    tracks = (right_hand, left_hand)
    all_events = [event for track in tracks for event in track.events]
    notes = [event for event in all_events if event.kind == "note"]
    ids = [event.event_id for event in all_events]
    duplicate_ids = sorted({event_id for event_id, count in Counter(ids).items() if count > 1})
    return {
        "status": "PASS" if not duplicate_ids else "FAIL",
        "source_event_count": len(all_events),
        "right_hand_event_count": len(right_hand.events),
        "left_hand_event_count": len(left_hand.events),
        "source_note_count": len(notes),
        "right_hand_note_count": sum(event.kind == "note" for event in right_hand.events),
        "left_hand_note_count": sum(event.kind == "note" for event in left_hand.events),
        "tie_count": sum(bool(event.tie_types) for event in notes),
        "voice_count": sum(event.voice is not None for event in notes),
        "staff_count": sum(event.staff is not None for event in notes),
        "grace_note_count": sum(event.is_grace for event in notes),
        "chord_group_count": len({event.chord_id for event in notes if event.chord_id}),
        "rest_count": sum(event.is_rest for event in notes),
        "missing_event_ids": [],
        "duplicate_event_ids": duplicate_ids,
    }


def write_event_dump_json(right_hand, left_hand, path: str | Path) -> Path:
    target = Path(path); target.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "version": VERSION,
        "policy": {"pre_analysis": True, "used_by_current_arrangement_algorithm": False},
        "tracks": [
            {"track_id": track.track_id, "role": track.role, "events": [event_to_dict(event) for event in track.events]}
            for track in (right_hand, left_hand)
        ],
    }
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return target


def write_event_integrity_report(integrity: dict, path: str | Path) -> Path:
    target = Path(path); target.parent.mkdir(parents=True, exist_ok=True)
    lines = [f"# GSTE {VERSION} Event Integrity Report", "", f"- Status: **{integrity['status']}**", "",
             "| 項目 | 數量 |", "|---|---:|"]
    labels = (("原始事件", "source_event_count"), ("原始音符", "source_note_count"), ("右手音符", "right_hand_note_count"),
              ("左手音符", "left_hand_note_count"), ("Tie", "tie_count"), ("Voice 標記", "voice_count"),
              ("Staff 標記", "staff_count"), ("Grace Note", "grace_note_count"), ("Chord Group", "chord_group_count"), ("Rest", "rest_count"))
    lines.extend(f"| {label} | {integrity[key]} |" for label, key in labels)
    lines.extend(["", "## Missing Event IDs", "", ", ".join(integrity["missing_event_ids"]) or "- None", "", "## Duplicate Event IDs", "", ", ".join(integrity["duplicate_event_ids"]) or "- None", ""])
    target.write_text("\n".join(lines), encoding="utf-8")
    return target


def _boundary_dict(boundary) -> dict:
    return {"EventBoundaryID": boundary.boundary_id, "time": boundary.time, "end_time": boundary.next_time,
            "measure": boundary.measure, "confidence": boundary.confidence, "reasons": list(boundary.reasons),
            "forced": boundary.forced, "fixed_two_beat_retained": boundary.fixed_two_beat_retained,
            "neighbouring_events": list(boundary.neighbouring_event_ids)}


def write_boundary_candidates_json(boundaries, path: str | Path) -> Path:
    target = Path(path); target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps({"version": VERSION, "advisory_only": True, "candidates": [_boundary_dict(item) for item in boundaries]}, ensure_ascii=False, indent=2), encoding="utf-8")
    return target


def write_event_boundary_review(boundaries, path: str | Path) -> Path:
    target = Path(path); target.parent.mkdir(parents=True, exist_ok=True)
    lines = [f"# GSTE {VERSION} Event Boundary Review", "", "> 僅供審查；目前正式和聲窗格仍固定為兩拍。", "",
             "| Boundary | 起始拍 | 結束拍 | 信心 | 判定原因 | 強制 | 保留固定兩拍 |", "|---|---:|---:|---:|---|---|---|"]
    for item in boundaries:
        end = "—" if item.next_time is None else f"{item.next_time:g}"
        lines.append(f"| {item.boundary_id} | {item.time:g} | {end} | {item.confidence:.3f} | {', '.join(item.reasons)} | {'是' if item.forced else '否'} | {'是' if item.fixed_two_beat_retained else '否'} |")
    target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return target


def build_source_registry_integrity(tracks):
    from dataclasses import replace
    accompaniment=replace(tracks[0],events=[e for t in tracks[1:] for e in t.events])
    result=build_event_integrity(tracks[0],accompaniment)
    result["tracks"]=[{"track_id":t.track_id,"event_count":len(t.events),"duration":t.duration_quarters} for t in tracks]
    return result
