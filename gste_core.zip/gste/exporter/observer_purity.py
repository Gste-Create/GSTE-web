from __future__ import annotations

import hashlib
from pathlib import Path


def arrangement_signature(result) -> tuple:
    """Stable musical/fingering signature used only to prove observers are pure."""
    rows=[]
    for state in getattr(result, "selected", ()) or ():
        for role, group in (("M", state.melody), ("A", state.accompaniment)):
            for fc in getattr(group, "notes", ()) or ():
                n=fc.note
                rows.append((role, str(getattr(n,"source_event_id",None)), int(n.pitch.midi),
                             round(float(n.start),9), round(float(n.duration),9),
                             int(fc.string), int(fc.fret)))
    return tuple(sorted(rows))


def file_sha256(path: str | Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def assert_observer_purity(*, result, result_signature_before: tuple, exported_path: str | Path,
                           exported_hash_before: str) -> None:
    if arrangement_signature(result) != result_signature_before:
        raise RuntimeError("MONITORING_PURITY_VIOLATION: diagnostics changed the validated arrangement")
    if file_sha256(exported_path) != exported_hash_before:
        raise RuntimeError("MONITORING_PURITY_VIOLATION: diagnostics changed the exported MusicXML")
