"""V0.13.5.12.4 timeline/rhythm diagnostics.

Diagnostic only.  This module deliberately does not change arrangement,
fingering, Joint scoring, source interpretation, or export semantics.
"""
from __future__ import annotations
from gste.version import VERSION

from collections import defaultdict
from dataclasses import asdict
from pathlib import Path
import json

from gste.input.project_models import TrackData

_EPS = 1e-6
_GSTE_ACCOMPANIMENT_MARKERS = {"GSTE_ACCOMPANIMENT", "GSTE_GENERATED_ACCOMPANIMENT"}
_COMMON_GRIDS = (
    (1.0, "QUARTER"),
    (0.5, "EIGHTH"),
    (1.0/3.0, "EIGHTH_TRIPLET"),
    (0.25, "SIXTEENTH"),
    (1.0/6.0, "SIXTEENTH_TRIPLET"),
    (0.125, "THIRTY_SECOND"),
)


def _r(v: float) -> float:
    return round(float(v), 9)


def _pitch_name(midi: int) -> str:
    names = ("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    return f"{names[midi % 12]}{midi // 12 - 1}"


def _timesig_for_measure(track: TrackData, measure: int) -> tuple[int, int]:
    beats, beat_type = 4, 4
    for change in sorted(track.time_signatures, key=lambda x: x.measure):
        if change.measure <= measure:
            beats, beat_type = change.beats, change.beat_type
        else:
            break
    return beats, beat_type


def _expected_measure_quarters(track: TrackData, measure: int) -> float:
    beats, beat_type = _timesig_for_measure(track, measure)
    return beats * (4.0 / beat_type)


def _content_extent(track: TrackData, measure: int) -> float:
    """Return sounding/notated note extent, never cursor-control extent.

    MusicalEvent also records MusicXML <backup>/<forward> elements for audit.
    Their ``duration`` is a cursor movement amount, not sounding duration.
    Treating ``backup.start + backup.duration`` as content made a normal 4/4
    two-voice measure look exactly 8 quarters long.  Measure length itself is
    already computed by the canonical physical-timeline parser.
    """
    start = track.measure_starts.get(measure, 0.0)
    ends = []
    for event in track.events:
        if event.measure != measure or event.kind != "note":
            continue
        if event.duration is not None:
            ends.append(event.start + max(0.0, event.duration) - start)
    return max(ends, default=0.0)


def _classify_measure(track: TrackData, measure: int) -> dict:
    expected = _expected_measure_quarters(track, measure)
    parser_length = track.measure_lengths.get(measure, expected)
    content = _content_extent(track, measure)
    delta = content - expected
    if abs(delta) <= _EPS:
        status = "EXACT"
    elif content < expected - _EPS:
        status = "UNDERFULL_FIRST_MEASURE_POSSIBLE_PICKUP" if measure == min(track.measure_starts or {measure: 0}) else "UNDERFULL_OR_IMPLICIT_REST"
    else:
        status = "OVERFULL_OR_MULTIVOICE_CURSOR_ANOMALY"
    return {
        "measure": measure,
        "time_signature": "%d/%d" % _timesig_for_measure(track, measure),
        "expected_quarters": _r(expected),
        "content_extent_quarters": _r(content),
        "parser_measure_length_quarters": _r(parser_length),
        "content_delta_quarters": _r(delta),
        "status": status,
    }


def _nearest_grid(position: float) -> tuple[str, float]:
    best = ("OTHER", float("inf"))
    for step, label in _COMMON_GRIDS:
        nearest = round(position / step) * step
        err = abs(position - nearest)
        if err < best[1]:
            best = (label, err)
    return best


def _track_rhythm_profile(track: TrackData) -> dict:
    measures = [_classify_measure(track, m) for m in sorted(track.measure_starts)]
    onset_rows = []
    counts = defaultdict(int)
    for note in track.notes:
        mstart = track.measure_starts.get(note.measure or 0, 0.0)
        local = note.start - mstart
        label, err = _nearest_grid(local)
        # <= 1/192 quarter is strict enough to distinguish genuine off-grid
        # placement while not treating float noise as musical irregularity.
        if err > 1.0 / 192.0:
            label = "OTHER_SUBDIVISION"
        counts[label] += 1
        onset_rows.append({
            "measure": note.measure,
            "pitch": _pitch_name(note.pitch.midi),
            "absolute_onset": _r(note.start),
            "local_onset": _r(local),
            "duration": _r(note.duration),
            "grid_class": label,
            "grid_error_quarters": _r(err),
            "source_event_id": note.source_event_id,
        })
    irregular = [m for m in measures if m["status"] != "EXACT"]
    unusual = [r for r in onset_rows if r["grid_class"] == "OTHER_SUBDIVISION"]
    return {
        "track_id": track.track_id,
        "duration_quarters": _r(track.duration_quarters),
        "parser_warnings": list(track.warnings),
        "measure_integrity": measures,
        "irregular_measure_count": len(irregular),
        "irregular_measures": irregular,
        "onset_grid_counts": dict(counts),
        "unusual_onset_count": len(unusual),
        "unusual_onsets": unusual[:200],
        "interpretation": "OTHER_SUBDIVISION is advisory only; tuplets, expressive notation, pickup bars, and syncopation can be musically valid.",
    }


def _stage_melody_events(result) -> list[dict]:
    grouped = defaultdict(list)
    for state in result.selected:
        for candidate in state.melody.notes:
            n = candidate.note
            key = n.source_event_id or f"SIG:{n.pitch.midi}:{_r(n.start)}:{_r(n.duration)}"
            grouped[key].append(n)
    rows = []
    for key, notes in grouped.items():
        # One source melody event can be present in adjacent windows because of
        # sustain ownership.  Keep the earliest/longest representative here;
        # duplicated window ownership is reported separately, not called a
        # melody mutation.
        n = min(notes, key=lambda x: (x.start, -x.duration, x.pitch.midi))
        rows.append({
            "event_id": key,
            "pitch_midi": n.pitch.midi,
            "pitch": _pitch_name(n.pitch.midi),
            "onset": _r(n.start),
            "duration": _r(n.duration),
            "measure": n.measure,
            "window_occurrences": len(notes),
        })
    return sorted(rows, key=lambda x: (x["onset"], x["pitch_midi"], x["event_id"]))


def _track_events(track: TrackData, shift: int = 0) -> list[dict]:
    return [{
        "event_id": n.source_event_id or f"SIG:{n.pitch.midi}:{_r(n.start)}:{_r(n.duration)}",
        "pitch_midi": n.pitch.midi + shift,
        "pitch": _pitch_name(n.pitch.midi + shift),
        "onset": _r(n.start),
        "duration": _r(n.duration),
        "measure": n.measure,
        "window_occurrences": 1,
    } for n in track.notes]


def _signature(row: dict, *, include_duration: bool = True) -> tuple:
    base=(int(row["pitch_midi"]), _r(row["onset"]))
    return base+((_r(row["duration"]),) if include_duration else ())


def _compare(reference: list[dict], actual: list[dict], stage: str) -> dict:
    """Compare two melody stages without inventing identity mismatches.

    Immutable source IDs are preferred only when the two collections actually
    share the same ID namespace.  XML-native source audits often have no embedded
    GSTE ID, so a musical signature comparison is the authoritative fallback.
    """
    from collections import Counter
    ref_ids={str(r.get("event_id")) for r in reference if r.get("event_id") and not str(r.get("event_id")).startswith("SIG:")}
    act_ids={str(r.get("event_id")) for r in actual if r.get("event_id") and not str(r.get("event_id")).startswith("SIG:")}
    overlap=len(ref_ids & act_ids)
    usable_id_overlap=bool(ref_ids and act_ids and overlap >= max(1, int(0.8*min(len(ref_ids),len(act_ids)))))
    mismatches=[]
    match_mode="SOURCE_EVENT_ID" if usable_id_overlap else "MUSICAL_SIGNATURE"
    if usable_id_overlap:
        ref_by_id={r["event_id"]:r for r in reference}
        act_by_id={r["event_id"]:r for r in actual}
        for eid,ref in ref_by_id.items():
            cur=act_by_id.get(eid)
            if cur is None:
                mismatches.append({"type":"MISSING_EVENT","event_id":eid,"expected":ref}); continue
            fields=[]
            if cur["pitch_midi"]!=ref["pitch_midi"]: fields.append("pitch")
            if abs(cur["onset"]-ref["onset"])>_EPS: fields.append("onset")
            if abs(cur["duration"]-ref["duration"])>_EPS: fields.append("duration")
            if fields:
                mismatches.append({"type":"EVENT_CHANGED","event_id":eid,"fields":fields,"expected":ref,"actual":cur})
        for eid,cur in act_by_id.items():
            if eid not in ref_by_id:
                mismatches.append({"type":"EXTRA_EVENT","event_id":eid,"actual":cur})
    else:
        rc=Counter(_signature(r) for r in reference); ac=Counter(_signature(r) for r in actual)
        missing=rc-ac; extra=ac-rc
        for sig,count in missing.items():
            for _ in range(count): mismatches.append({"type":"MISSING_SIGNATURE","signature":sig})
        for sig,count in extra.items():
            for _ in range(count): mismatches.append({"type":"EXTRA_SIGNATURE","signature":sig})
    return {
        "stage":stage,"status":"PASS" if not mismatches else "MISMATCH",
        "match_mode":match_mode,"shared_event_id_count":overlap,
        "reference_count":len(reference),"actual_count":len(actual),
        "mismatch_count":len(mismatches),"mismatches":mismatches[:200],
    }

def _accompaniment_grid_profile(rows: list[dict], measure_starts: dict[int, float]) -> dict:
    counts=defaultdict(int); unusual=[]
    for row in rows:
        m=row.get("measure")
        mstart=measure_starts.get(m, 0.0)
        local=float(row["onset"])-mstart
        label,err=_nearest_grid(local)
        if err>1.0/192.0: label="OTHER_SUBDIVISION"
        counts[label]+=1
        if label=="OTHER_SUBDIVISION":
            unusual.append({**row,"local_onset":_r(local),"grid_error_quarters":_r(err)})
    return {"onset_grid_counts":dict(counts),"unusual_onset_count":len(unusual),"unusual_onsets":unusual[:200]}




def _missing_event_provenance(reference: list[dict], stages: list[dict], joint_result) -> list[dict]:
    selected_ids={}
    for state in getattr(joint_result,"selected",()) or ():
        for cand in getattr(getattr(state,"melody",None),"notes",()) or ():
            sid=getattr(getattr(cand,"note",None),"source_event_id",None)
            if sid:
                selected_ids.setdefault(str(sid),[]).append({"window_id":getattr(state,"window_id",None),"measure":getattr(state,"measure",None),"window_start":_r(getattr(state,"start",0.0)),"pitch":_pitch_name(cand.note.pitch.midi),"onset":_r(cand.note.start)})
    first=next((s for s in stages if s["status"]!="PASS"),None)
    rows=[]
    if first:
        for mm in first.get("mismatches",[]):
            if mm.get("type")!="MISSING_EVENT": continue
            exp=mm.get("expected",{}); eid=str(mm.get("event_id"))
            rows.append({"event_id":eid,"measure":exp.get("measure"),"pitch":exp.get("pitch"),"onset":exp.get("onset"),"duration":exp.get("duration"),"first_missing_stage":first.get("stage"),"joint_occurrences":selected_ids.get(eid,[]),"classification":"TRUE_PIPELINE_MISSING_CANDIDATE" if not selected_ids.get(eid) else "WINDOW_OR_IDENTITY_ATTRIBUTION_REVIEW"})
    return rows[:200]

def _backbone_events(backbone) -> list[dict]:
    rows=[]
    for event in getattr(backbone, "events", ()) or ():
        rows.append({
            "event_id": str(event.structural_event_id),
            "pitch_midi": int(event.midi_pitch),
            "pitch": _pitch_name(int(event.midi_pitch)),
            "onset": _r(float(event.attack)),
            "duration": _r(float(event.release) - float(event.attack)),
            "measure": event.measure,
            "window_occurrences": 1,
        })
    return sorted(rows,key=lambda x:(x["onset"],x["pitch_midi"],x["event_id"]))


def _serializer_manifest_audit(backbone, manifest_path: str | Path | None) -> dict:
    reference=_backbone_events(backbone)
    if manifest_path is None or not Path(manifest_path).exists():
        return {
            "status":"INCOMPLETE", "reason":"SERIALIZER_MANIFEST_NOT_FOUND",
            "reference_count":len(reference), "actual_count":0, "mismatch_count":0, "mismatches":[],
        }
    try:
        payload=json.loads(Path(manifest_path).read_text(encoding="utf-8"))
    except Exception as exc:
        return {
            "status":"INCOMPLETE", "reason":f"SERIALIZER_MANIFEST_READ_FAILED:{exc}",
            "reference_count":len(reference), "actual_count":0, "mismatch_count":0, "mismatches":[],
        }
    actual=[]
    for row in payload.get("events",[]):
        actual.append({
            "event_id":str(row.get("structural_event_id","")),
            "pitch_midi":int(row.get("midi_pitch",-999)),
            "pitch":_pitch_name(int(row.get("midi_pitch",0))),
            "onset":_r(float(row.get("attack",0.0))),
            "duration":_r(float(row.get("release",0.0))-float(row.get("attack",0.0))),
            "measure":row.get("measure"),
            "window_occurrences":1,
        })
    report=_compare(reference,actual,"SERIALIZER_EMISSION")
    report["manifest_path"]=str(manifest_path)
    report["semantics"]="Serializer manifest is checked against the same Locked Melody Backbone; exported XML is not reparsed into a second melody timeline."
    return report


def _result_accompaniment_rows(result) -> tuple[list[dict], dict[int,float]]:
    rows=[]; measure_starts={}
    seen=set()
    for state in getattr(result,"selected",()) or ():
        measure=int(getattr(state,"measure",0) or 0)
        if measure and measure not in measure_starts:
            measure_starts[measure]=float(getattr(state,"start",0.0))
        for cand in getattr(getattr(state,"accompaniment",None),"notes",()) or ():
            n=cand.note
            key=(getattr(n,"source_event_id",None),round(float(n.start),9),int(n.pitch.midi),cand.string,cand.fret)
            if key in seen: continue
            seen.add(key)
            rows.append({"measure":n.measure,"onset":_r(n.start),"pitch_midi":n.pitch.midi,"source_event_id":n.source_event_id})
    return rows,measure_starts


def build_timeline_rhythm_diagnostics(*, source_melody: TrackData, source_accompaniment: TrackData,
                                      transformed_melody: TrackData, joint_result, final_result,
                                      export_result, exported_musicxml: str | Path | None,
                                      total_semitone_shift: int, input_route: str, accompaniment_mode: str | None = None,
                                      melody_backbone=None, serializer_manifest_path: str | Path | None = None) -> tuple[dict, dict]:
    """Observer-only timeline diagnostics using one authoritative melody clock.

    v0.13.5.13.3 intentionally does *not* reparse exported MusicXML to invent a
    second melody timeline.  The Locked Melody Backbone created after parser /
    Piano melody extraction is the sole reference for pitch + [attack,release).
    """
    reference=_backbone_events(melody_backbone) if melody_backbone is not None else _track_events(source_melody,shift=total_semitone_shift)
    transformed=_track_events(transformed_melody)
    joint=_stage_melody_events(joint_result)
    final=_stage_melody_events(final_result)
    export_stage=_stage_melody_events(export_result)
    stages=[
        {"stage":"LOCKED_MELODY_BACKBONE","status":"PASS","match_mode":"STRUCTURAL_EVENT_ID",
         "reference_count":len(reference),"actual_count":len(reference),"mismatch_count":0,"mismatches":[]},
        _compare(reference,transformed,"GLOBAL_TRANSFORM"),
        _compare(reference,joint,"JOINT_SELECTED"),
        _compare(reference,final,"FINAL_REVIEW"),
        _compare(reference,export_stage,"EXPORT_INPUT_STATE"),
    ]
    first=next((x for x in stages if x["status"]!="PASS"),None)
    serializer_audit=_serializer_manifest_audit(melody_backbone,serializer_manifest_path) if melody_backbone is not None else {"status":"INCOMPLETE","reason":"NO_BACKBONE"}
    timeline={
        "version":VERSION,"input_route":input_route,
        "semantics":"ONE_LOCKED_MELODY_BACKBONE; pitch + structural_event_id + [attack,release) are established once and reused by Fingering, Final validation, Serializer and diagnostics.",
        "expected_pitch_shift":total_semitone_shift,
        "locked_event_count":len(reference),
        "stages":stages,"first_mismatch_stage":first["stage"] if first else None,
        "first_mismatch":first["mismatches"][0] if first and first.get("mismatches") else None,
        "serializer_melody_status":serializer_audit.get("status","INCOMPLETE"),
        "serializer_manifest_audit":serializer_audit,
        "missing_event_provenance":_missing_event_provenance(reference,stages,joint_result),
        "interpretation":[
            "Melody-only locks timing immediately after source parsing; SOURCE_PIANO locks it immediately after melody extraction.",
            "No downstream stage may recompute melody attack/release from arrangement windows or from serialized MusicXML.",
            "Serializer correctness is checked by its emitted structural-event manifest against the same Locked Melody Backbone; output XML is not a second authority."
        ],
    }
    source_melody_profile=_track_rhythm_profile(source_melody)
    secondary_profile=_track_rhythm_profile(source_accompaniment)
    acc_rows, acc_measure_starts=_result_accompaniment_rows(export_result)
    final_grid=_accompaniment_grid_profile(acc_rows,acc_measure_starts)
    rhythm={
        "version":VERSION,"input_route":input_route,
        "source_melody":source_melody_profile,
        "secondary_or_generated_accompaniment":secondary_profile,
        "source_accompaniment":secondary_profile,
        "secondary_track_origin":"NONE" if accompaniment_mode=="NONE" else ("GENERATED_SYNTHETIC" if input_route=="AUTO_MELODY" else "SOURCE_SCORE"),
        "accompaniment_mode": accompaniment_mode,
        "final_accompaniment_grid":final_grid,
        "diagnostic_self_validation":{"status":"PASS"},
        "classification_rules":{
            "SOURCE_MELODY_IRREGULAR":"locked source melody measure metadata differs materially from meter.",
            "SYNTHETIC_ACCOMPANIMENT_TIMELINE_ANOMALY":"generated accompaniment track has a material measure-length error.",
            "GSTE_TIMELINE_MUTATION":"a downstream stage changes the Locked Melody Backbone timing.",
            "RHYTHM_NATURALNESS_ADVISORY":"timeline is valid but accompaniment attacks use uncommon subdivisions; listening review only.",
        },
    }
    if source_melody_profile["irregular_measure_count"]:
        rhythm["primary_diagnosis"]="SOURCE_MELODY_IRREGULAR_OR_PICKUP"
    elif accompaniment_mode != "NONE" and input_route=="AUTO_MELODY" and secondary_profile["irregular_measure_count"]:
        rhythm["primary_diagnosis"]="SYNTHETIC_ACCOMPANIMENT_TIMELINE_ANOMALY"
    elif first:
        rhythm["primary_diagnosis"]="GSTE_TIMELINE_MUTATION"
    elif serializer_audit.get("status") not in {"PASS",None}:
        rhythm["primary_diagnosis"]="SERIALIZER_BACKBONE_EMISSION_MISMATCH"
    elif final_grid["unusual_onset_count"]:
        rhythm["primary_diagnosis"]="RHYTHM_NATURALNESS_ADVISORY"
    else:
        rhythm["primary_diagnosis"]="TIMELINE_INTEGRITY_PASS"
    return timeline,rhythm


def write_timeline_rhythm_diagnostics(timeline: dict, rhythm: dict, *, debug_dir: str | Path, output_dir: str | Path) -> tuple[Path,Path,Path,Path]:
    debug=Path(debug_dir); out=Path(output_dir); debug.mkdir(parents=True,exist_ok=True); out.mkdir(parents=True,exist_ok=True)
    tj=debug/"19_MELODY_TIMELINE_INTEGRITY.json"; rj=debug/"20_RHYTHM_GRID_DIAGNOSTICS.json"
    tj.write_text(json.dumps(timeline,ensure_ascii=False,indent=2),encoding="utf-8")
    rj.write_text(json.dumps(rhythm,ensure_ascii=False,indent=2),encoding="utf-8")
    tm=out/"09_MELODY_TIMELINE_INTEGRITY.md"; rm=out/"10_RHYTHM_GRID_DIAGNOSTICS.md"
    sa=timeline.get("serializer_manifest_audit",{})
    lines=[
        f"# GSTE {VERSION} Melody Timeline Integrity","",
        f"- Route: **{timeline['input_route']}**",
        f"- Authoritative clock: **LOCKED_MELODY_BACKBONE**",
        f"- First mutation stage: **{timeline['first_mismatch_stage'] or 'NONE'}**",
        f"- Serializer emission: **{timeline.get('serializer_melody_status','INCOMPLETE')}**",
        f"- Locked structural melody events: **{timeline.get('locked_event_count',0)}**","",
        "| Stage | Status | Match | Ref | Actual | Mismatches |","|---|---|---|---:|---:|---:|"
    ]
    for st in timeline["stages"]:
        lines.append(f"| {st['stage']} | {st['status']} | {st.get('match_mode','?')} | {st['reference_count']} | {st['actual_count']} | {st['mismatch_count']} |")
    lines += ["", "## Serializer manifest audit", "",
              f"- Status: **{sa.get('status','INCOMPLETE')}**",
              f"- Mismatches: **{sa.get('mismatch_count',0)}**",
              "- Exported MusicXML is not reparsed into a second melody timeline; the serializer manifest is compared to the same locked backbone."]
    if timeline.get("first_mismatch"):
        lines += ["","## First mutation","","```json",json.dumps(timeline["first_mismatch"],ensure_ascii=False,indent=2),"```"]
    if sa.get("mismatches"):
        lines += ["","## First serializer mismatch","","```json",json.dumps(sa["mismatches"][0],ensure_ascii=False,indent=2),"```"]
    tm.write_text("\n".join(lines)+"\n",encoding="utf-8")
    sm=rhythm["source_melody"]; sec=rhythm["secondary_or_generated_accompaniment"]; fg=rhythm["final_accompaniment_grid"]
    lines=[
        f"# GSTE {VERSION} Rhythm Grid Diagnostics","",
        f"- Primary diagnosis: **{rhythm['primary_diagnosis']}**",
        f"- Locked melody irregular measures: **{sm['irregular_measure_count']}**",
        f"- Secondary/generated track origin: **{rhythm['secondary_track_origin']}**",
        f"- Secondary/generated irregular measures: **{sec['irregular_measure_count']}**",
        f"- Final accompaniment uncommon-grid attacks: **{fg['unusual_onset_count']}**","",
        "All melody timing comes from the locked parser/extraction backbone. No serialized melody clock is reconstructed.",""
    ]
    for title,prof in (("Locked melody source",sm),("Secondary / generated accompaniment",sec)):
        lines += [f"## {title}","","| Measure | Meter | Expected | Content extent | Status |","|---:|---|---:|---:|---|"]
        for m in prof["irregular_measures"][:100]:
            lines.append(f"| {m['measure']} | {m['time_signature']} | {m['expected_quarters']} | {m['content_extent_quarters']} | {m['status']} |")
        if not prof["irregular_measures"]: lines.append("| — | — | — | — | PASS |")
        lines.append("")
    rm.write_text("\n".join(lines),encoding="utf-8")
    return tj,rj,tm,rm
