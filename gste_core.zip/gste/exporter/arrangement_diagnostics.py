from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path

from gste.joint_arrangement.models import JointArrangementResult
from gste.version import VERSION


def build_arrangement_diagnostics(result: JointArrangementResult, *, tie_roles: dict[str, int]) -> dict:
    rows = [asdict(item) for item in result.diagnostics]
    first = next((item for item in rows if item["first_zero_stage"]), None)

    # V0.13.5.12.4 primary rejection funnel: unique topology cohorts from the
    # same branch population.  Unlike the legacy assignment-expanded counters,
    # these are monotonic and may be compared across stages.
    unique_raw = sum(int(r.get("unique_raw_topologies", 0) or 0) for r in rows)
    unique_span = sum(int(r.get("unique_after_fret_span", 0) or 0) for r in rows)
    unique_play = sum(int(r.get("unique_after_playability", 0) or 0) for r in rows)
    unique_local = sum(int(r.get("unique_after_local_cost", 0) or 0) for r in rows)
    unique_funnel = {
        "raw_unique_topologies": unique_raw,
        "after_fret_span": unique_span,
        "after_joint_playability": unique_play,
        "after_local_cost": unique_local,
        "losses": {
            "simultaneous_fret_span": max(0, unique_raw - unique_span),
            "joint_playability_or_hand_distance": max(0, unique_span - unique_play),
            "local_cost_or_finger_assignment": max(0, unique_play - unique_local),
        },
        "survival_pct": {
            "after_fret_span": round(unique_span * 100.0 / unique_raw, 1) if unique_raw else None,
            "after_joint_playability": round(unique_play * 100.0 / unique_raw, 1) if unique_raw else None,
            "after_local_cost": round(unique_local * 100.0 / unique_raw, 1) if unique_raw else None,
        },
        "duplicate_merge_events": sum(int(r.get("duplicate_merge_events", 0) or 0) for r in rows),
        "semantics": "Unique topology cohort. Same-signature candidate counted once regardless of alternate finger assignments or repeated generation branches.",
    }

    # Preserve v0.13.5.13.3.1 raw counters for historical comparison only.
    legacy_hard_rejected = sum(max(0, int(r["raw_candidates"]) - int(r["after_stretch"])) for r in rows)
    legacy_span_rejected = sum(max(0, int(r["after_string_conflict"]) - int(r["after_fret_span"])) for r in rows)
    legacy_other_physical = sum(max(0, int(r["after_fret_span"]) - int(r["after_stretch"])) for r in rows)
    legacy_competition = sum(max(0, int(r["after_dp_transition"]) - 1) for r in rows if int(r["after_dp_transition"]) > 0)
    return {
        "version": VERSION,
        "metric_semantics_version": "2.0",
        "arrangement_status": "PASS" if result.selected and not any(r["simplification_level"] for r in rows) else "DEGRADED" if result.selected else "FAIL",
        "first_failed_window": first["window_id"] if first else None,
        "failure_reason": first["failure_reason"] if first else None,
        "tie_roles": tie_roles,
        "pipeline_debug_counters": dict(result.debug_counters),
        "pipeline_debug_semantics": "Read-only counters only; they do not change candidates, costs, pruning, DP, or selection.",
        "joint_rejection_audit": {
            # Backward-compatible legacy summary keys. Prefer primary_unique_topology_funnel.
            "raw_candidates": sum(int(r["raw_candidates"]) for r in rows),
            "hard_or_high_risk_rejected": legacy_hard_rejected,
            "simultaneous_span_rejected": legacy_span_rejected,
            "other_physical_or_stretch_rejected": legacy_other_physical,
            "legal_candidates_not_selected_estimate": legacy_competition,
            "primary_unique_topology_funnel": unique_funnel,
            "legacy_assignment_expanded_counters": {
                "metric_status": "LEGACY_DIAGNOSTIC_ONLY_NOT_A_MONOTONIC_FUNNEL",
                "raw_candidates": sum(int(r["raw_candidates"]) for r in rows),
                "stage_counts": {
                    "after_string_conflict": sum(int(r["after_string_conflict"]) for r in rows),
                    "after_fret_span": sum(int(r["after_fret_span"]) for r in rows),
                    "after_stretch": sum(int(r["after_stretch"]) for r in rows),
                    "after_sustain_conflict": sum(int(r["after_sustain_conflict"]) for r in rows),
                    "after_dp_transition": sum(int(r["after_dp_transition"]) for r in rows),
                },
                "hard_or_high_risk_rejected": legacy_hard_rejected,
                "simultaneous_span_rejected": legacy_span_rejected,
                "other_physical_or_stretch_rejected": legacy_other_physical,
                "legal_candidates_not_selected_estimate": legacy_competition,
            },
            "windows_with_zero_stage": dict(__import__('collections').Counter(r["first_zero_stage"] for r in rows if r["first_zero_stage"])),
            "interpretation": "Use primary_unique_topology_funnel for v2 analysis. Legacy counters are retained only to compare old reports and may increase between stages because they count expanded assignments/branches.",
        },
        "windows": rows,
        "warnings": list(result.warnings),
    }


def write_arrangement_diagnostics(result: JointArrangementResult, path: str | Path, *, tie_roles: dict[str, int]) -> Path:
    output = Path(path); output.parent.mkdir(parents=True, exist_ok=True)
    data = build_arrangement_diagnostics(result, tie_roles=tie_roles)
    output.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return output
