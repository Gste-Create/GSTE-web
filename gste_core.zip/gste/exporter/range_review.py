from __future__ import annotations
from copy import deepcopy
from pathlib import Path
import xml.etree.ElementTree as ET


def write_range_review_musicxml(source_path, track, output_path, *, tuning, maximum_fret: int = 18, context_measures: int = 2):
    """Write a source-faithful excerpt around notes outside GSTE's supported range.

    Read-only diagnostic: never transposes or edits source pitches.
    Returns None when all structural notes are in range.
    """
    low = min(tuning.strings.values())
    high = max(tuning.strings.values()) + maximum_fret
    bad = [n for n in track.notes if n.pitch.midi < low or n.pitch.midi > high]
    if not bad:
        return None
    bad_measures = {int(n.measure) for n in bad if n.measure is not None}
    keep = {m+d for m in bad_measures for d in range(-context_measures, context_measures+1) if m+d >= 1}
    root = ET.parse(source_path).getroot()
    # Preserve namespaces/tags as parsed; measure selection uses local-name.
    for part in [e for e in root.iter() if e.tag.split('}')[-1] == 'part']:
        for measure in list(part):
            if measure.tag.split('}')[-1] != 'measure':
                continue
            try: number = int(measure.attrib.get('number',''))
            except ValueError: continue
            if number not in keep:
                part.remove(measure)
            elif number in bad_measures:
                direction = ET.Element('direction', {'placement':'above'})
                dtype = ET.SubElement(direction, 'direction-type')
                words = ET.SubElement(dtype, 'words')
                words.text = f'GSTE RANGE REVIEW: note outside supported MIDI {low}-{high}; review phrase/octave manually.'
                measure.insert(0, direction)
    out=Path(output_path); out.parent.mkdir(parents=True, exist_ok=True)
    ET.ElementTree(root).write(out, encoding='utf-8', xml_declaration=True)
    return out
