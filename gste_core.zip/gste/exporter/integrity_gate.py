from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from gste.version import VERSION


def _load(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else None
    except Exception:
        return None


def _status(value: str | None) -> str:
    return value if value in {"PASS", "REVIEW", "FAIL", "NOT_AVAILABLE"} else "NOT_AVAILABLE"


def build_integrity_gate(output_root: str | Path, *, source_integrity: dict | None = None) -> dict:
    """Read-only G1-G4 triage. Never changes arrangement or MusicXML."""
    root = Path(output_root)
    debug = root / "debug"
    source_integrity = source_integrity or {}
    identity = _load(debug / "25_MELODY_IDENTITY_LIFECYCLE.json")
    export = _load(debug / "23_EXPORT_INTEGRITY.json") or {}
    structure = _load(debug / "22_MUSICXML_STRUCTURAL_SANITY.json") or {}

    # G1: parser/source structural integrity. This deliberately does not claim
    # semantic melody recognition; it catches duplicate/broken source identity.
    g1_fail = source_integrity.get("status") == "FAIL" or bool(source_integrity.get("duplicate_event_ids"))
    g1 = {
        "name": "SOURCE_INTEGRITY",
        "status": "FAIL" if g1_fail else ("PASS" if source_integrity else "NOT_AVAILABLE"),
        "source_event_count": source_integrity.get("source_event_count"),
        "source_note_count": source_integrity.get("source_note_count"),
        "duplicate_event_ids": source_integrity.get("duplicate_event_ids", []),
        "scope": "Parsed source identity/structure. Does not prove melody-role classification is musically correct.",
    }

    # G2: unified melody priority retention. group_V0.0 requires every role-analysis
    # melody source to emit the same lifecycle audit, independent of input route.
    if identity:
        dropped = int(identity.get("dropped_by_joint_count", 0) or 0)
        unexplained = int(identity.get("unexplained_loss_count", 0) or 0)
        g2_status = "NOT_AVAILABLE" if identity.get("expected_count") == 0 else ("FAIL" if unexplained else ("REVIEW" if dropped else "PASS"))
        dropped_events = [e for e in identity.get("events", []) if e.get("status") == "DROPPED_BY_JOINT"]
        g2 = {
            "name": "PRIORITY_RETENTION",
            "status": g2_status,
            "expected_priority_count": identity.get("expected_count"),
            "retained_priority_count": identity.get("retained_count"),
            "dropped_by_joint_count": dropped,
            "unexplained_loss_count": unexplained,
            "first_review_events": dropped_events[:20],
            "scope": "Unified melody priority material admitted before Melody Shape/Joint. REVIEW means Joint intentionally dropped possible melody material and those locations need spot-checking.",
        }
    else:
        g2 = {
            "name": "PRIORITY_RETENTION",
            "status": "NOT_AVAILABLE",
            "reason": "Unified melody lifecycle was not emitted. For a role-analysis melody source this is an architecture/monitoring defect, not evidence of completeness.",
            "scope": "All non-prefingered melody sources must use the shared non-destructive priority-retention contract.",
        }

    # G3: serialization completeness only (event existence/identity).
    if export:
        structural_fail = structure.get("status") == "FAIL"
        missing = int(export.get("missing_event_count", 0) or 0)
        ghost = int(export.get("ghost_event_count", 0) or 0)
        duplicate = int(export.get("duplicate_event_id_count", 0) or 0)
        g3_fail = structural_fail or missing or ghost or duplicate
        g3 = {
            "name": "EXPORT_COMPLETENESS",
            "status": "FAIL" if g3_fail else "PASS",
            "expected_event_count": export.get("expected_event_count"),
            "reparsed_event_count": export.get("reparsed_event_count"),
            "missing_event_count": missing,
            "ghost_event_count": ghost,
            "duplicate_event_id_count": duplicate,
            "structural_status": structure.get("status", "UNKNOWN"),
            "first_missing_event_ids": export.get("missing_event_ids", [])[:20],
            "first_ghost_event_ids": export.get("ghost_event_ids", [])[:20],
        }
    else:
        g3 = {"name": "EXPORT_COMPLETENESS", "status": "NOT_AVAILABLE", "reason": "23_EXPORT_INTEGRITY.json not found."}

    # G4: semantic round-trip: pitch/onset/release/string/fret must survive XML.
    if export:
        mutations = export.get("mutations", []) or []
        g4 = {
            "name": "ROUND_TRIP_PLAYBACK",
            "status": "FAIL" if mutations else "PASS",
            "mutation_count": int(export.get("mutation_count", len(mutations)) or 0),
            "checked_fields": export.get("checked_fields", []),
            "first_mutations": mutations[:20],
            "scope": "Reparsed TAB pitch/onset/release/string/fret equality. This is a data/playback integrity check, not a GUI engraving screenshot test.",
        }
    else:
        g4 = {"name": "ROUND_TRIP_PLAYBACK", "status": "NOT_AVAILABLE", "reason": "23_EXPORT_INTEGRITY.json not found."}

    gates = [g1, g2, g3, g4]
    statuses = [_status(g.get("status")) for g in gates]
    overall = "FAIL" if "FAIL" in statuses else ("REVIEW" if any(s in {"REVIEW", "NOT_AVAILABLE"} for s in statuses) else "PASS")
    first_problem = next((g for g in gates if g.get("status") in {"FAIL", "REVIEW", "NOT_AVAILABLE"}), None)
    return {
        "version": VERSION,
        "purpose": "G1_G4_FAST_INTEGRITY_GATE",
        "scope": "LOCAL_OBSERVATION",
        "global_verdict_authority": False,
        "local_verdict": overall,
        "overall": overall,  # deprecated compatibility alias; not a global verdict
        "first_problem_gate": first_problem.get("name") if first_problem else None,
        "repair_rule": "Modify only the first failing/review layer; do not tune downstream layers until the earlier gate is understood.",
        "gates": {"G1": g1, "G2": g2, "G3": g3, "G4": g4},
    }


def write_integrity_gate(output_root: str | Path, *, source_integrity: dict | None = None) -> dict:
    root = Path(output_root)
    data = build_integrity_gate(root, source_integrity=source_integrity)
    (root / "debug").mkdir(parents=True, exist_ok=True)
    (root / "debug" / "00_GSTE_INTEGRITY_GATE.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    g = data["gates"]
    lines = [
        f"# {VERSION} GSTE Integrity Gate", "",
        f"## LOCAL INTEGRITY OBSERVATION: **{data['local_verdict']}**", "",
        "| Gate | Result | Meaning |", "|---|---|---|",
        f"| G1 Source | **{g['G1']['status']}** | Input parse / source identity |",
        f"| G2 Musical | **{g['G2']['status']}** | Priority / possible-melody retention |",
        f"| G3 Export | **{g['G3']['status']}** | Final events written once, no missing/ghost |",
        f"| G4 Playback | **{g['G4']['status']}** | Re-read pitch/time/fingering equals serializer |", "",
        f"- First problem layer: **{data['first_problem_gate'] or 'NONE'}**",
        f"- Rule: {data['repair_rule']}", "",
    ]
    if g['G2'].get('dropped_by_joint_count'):
        lines += [f"## G2 spot-check", "", f"Joint dropped **{g['G2']['dropped_by_joint_count']}** admitted priority events. Check these locations first:", ""]
        for e in g['G2'].get('first_review_events', [])[:10]:
            lines.append(f"- measure={e.get('measure')} start={e.get('start')} midi={e.get('midi')} id={e.get('source_event_id')}")
        lines.append("")
    if g['G2']['status'] == 'NOT_AVAILABLE':
        lines += ["> G2 is not available for this route yet. G1/G3/G4 passing does **not** prove the true melody was preserved before Joint.", ""]
    lines += ["## Repair map", "", "- **G1** → parser / source identity", "- **G2** → Unified Melody: role analysis / priority retention / Melody Shape / Joint", "- **G3** → MusicXML exporter / structure", "- **G4** → duration, voice cursor, tuplet/tie, serializer round-trip", ""]
    (root / "00_GSTE_INTEGRITY_GATE.md").write_text("\n".join(lines), encoding="utf-8")
    return data
