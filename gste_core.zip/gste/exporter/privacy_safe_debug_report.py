from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from gste.version import VERSION


@dataclass(frozen=True)
class PrivacySafeDebugReportPaths:
    markdown: Path
    json: Path


def _safe_count(value: Any) -> int:
    """Return a non-sensitive count for legacy fields stored as either count or collection."""
    if value is None:
        return 0
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, float)):
        return int(value)
    try:
        return len(value)
    except TypeError:
        return 0


def _anon_window(index: int) -> str:
    return f"W{index + 1:04d}"


def build_privacy_safe_debug_report(engineer_summary: dict[str, Any]) -> dict[str, Any]:
    """Create a shareable diagnostic view using an explicit allow-list.

    Deliberately excluded: file paths/names, score title/metadata, pitches,
    chords, note/rhythm sequences, part/track names, candidate musical
    content, parameter values, and raw event/window identifiers.
    """
    correctness = engineer_summary.get("correctness") or {}
    health = engineer_summary.get("engineering_health") or {}
    windows = engineer_summary.get("windows") or []

    safe_windows: list[dict[str, Any]] = []
    for idx, window in enumerate(windows):
        if not isinstance(window, dict):
            continue
        flags = [str(x) for x in (window.get("flags") or [])]
        hints = [str(x.get("area")) for x in (window.get("parameter_hints") or []) if isinstance(x, dict) and x.get("area")]
        safe_windows.append({
            "anonymous_window_id": _anon_window(idx),
            "review_required": bool(window.get("check_required")),
            "diagnostic_flags": flags,
            "candidate_count": int(window.get("candidate_count") or 0),
            "diagnostic_areas": hints,
        })

    return {
        "schema": "GSTE_PRIVACY_SAFE_DEBUG_V1",
        "version": VERSION,
        "purpose": "PRIVACY_SAFE_DEBUG_REPORT",
        "privacy_notice": (
            "Allow-list diagnostic export. It intentionally omits score content and direct source identifiers. "
            "Users should still review the file before sharing when subject to contractual or organizational rules."
        ),
        "status": engineer_summary.get("status"),
        "correctness": {
            "melody_first_mismatch_stage": correctness.get("melody_first_mismatch_stage"),
            "rhythm_primary_diagnosis": correctness.get("rhythm_primary_diagnosis"),
            "arrangement_status": correctness.get("arrangement_status"),
            "dissonance_issue_count": int(correctness.get("dissonance_issue_count") or 0),
        },
        "engineering_health": {
            "status": health.get("status"),
            "melody_identity_preserved": health.get("melody_identity_preserved"),
            "timeline_clean": health.get("timeline_clean"),
            "physical_remaining": int(health.get("physical_remaining") or 0),
            "accompaniment_loss_transition_count": _safe_count(health.get("accompaniment_loss_transitions")),
            "fingering_accompaniment_deletions": int(health.get("fingering_accompaniment_deletions") or 0),
            "fingering_local_reoptimizations": int(health.get("fingering_local_reoptimizations") or 0),
            "legacy_safe_notes": int(health.get("legacy_safe_notes") or 0),
        },
        "review_window_count": len(safe_windows),
        "review_windows": safe_windows,
    }


def write_privacy_safe_debug_report(output_root: str | Path, engineer_summary: dict[str, Any]) -> PrivacySafeDebugReportPaths:
    root = Path(output_root)
    target_dir = root / "00_summary" if (root / "00_summary").exists() else root
    target_dir.mkdir(parents=True, exist_ok=True)
    debug_dir = root / "debug"
    debug_dir.mkdir(parents=True, exist_ok=True)

    data = build_privacy_safe_debug_report(engineer_summary)
    jp = debug_dir / "PRIVACY_SAFE_DEBUG_REPORT.json"
    mp = target_dir / "PRIVACY_SAFE_DEBUG_REPORT.md"
    jp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    c = data["correctness"]
    h = data["engineering_health"]
    lines = [
        f"# GSTE {VERSION} Privacy-Safe Debug Report", "",
        "> This report is designed for issue reporting without including score content. It uses an explicit allow-list of diagnostic fields.",
        "> 本報告使用白名單欄位，設計目的為在不包含樂譜內容的情況下回報工程錯誤。", "",
        f"- GSTE engine version: `{data['version']}`",
        f"- Status: **{data.get('status') or 'UNKNOWN'}**",
        f"- Melody first mismatch stage: **{c.get('melody_first_mismatch_stage') or 'NONE'}**",
        f"- Rhythm diagnosis: **{c.get('rhythm_primary_diagnosis') or 'N/A'}**",
        f"- Arrangement status: **{c.get('arrangement_status') or 'N/A'}**",
        f"- Dissonance issue count: **{c.get('dissonance_issue_count', 0)}**", "",
        "## Engineering health / 工程健康", "",
        f"- Health status: **{h.get('status') or 'UNKNOWN'}**",
        f"- Melody identity preserved: **{h.get('melody_identity_preserved')}**",
        f"- Timeline clean: **{h.get('timeline_clean')}**",
        f"- Physical violations remaining: **{h.get('physical_remaining', 0)}**",
        f"- Accompaniment-loss transitions: **{h.get('accompaniment_loss_transition_count', 0)}**",
        f"- Fingering accompaniment deletions: **{h.get('fingering_accompaniment_deletions', 0)}**",
        f"- Fingering local reoptimizations: **{h.get('fingering_local_reoptimizations', 0)}**", "",
        "## Review windows / 診斷區段", "",
        "| Anonymous ID | Review | Candidate count | Flags | Diagnostic areas |",
        "|---|---:|---:|---|---|",
    ]
    for row in data["review_windows"]:
        flags = ", ".join(row["diagnostic_flags"]) or "—"
        areas = ", ".join(row["diagnostic_areas"]) or "—"
        lines.append(f"| {row['anonymous_window_id']} | {'YES' if row['review_required'] else 'NO'} | {row['candidate_count']} | {flags} | {areas} |")
    if not data["review_windows"]:
        lines.append("| — | — | 0 | — | — |")
    lines += [
        "", "## Intentionally excluded / 刻意排除", "",
        "Score title, source filename/path, pitches, chords, note/rhythm sequences, lyrics, part/track names, raw event/window IDs, musical candidate content, and parameter values are not exported here.", "",
        "Even with this reduced report, follow any NDA, employer, client, or organizational data-handling rules that apply to your project.",
    ]
    mp.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return PrivacySafeDebugReportPaths(markdown=mp, json=jp)


def write_privacy_safe_failure_report(output_root: str | Path, *, error_type: str, input_mode: str | None = None) -> PrivacySafeDebugReportPaths:
    """Write a minimal failure report without traceback, paths, filenames or exception text."""
    root = Path(output_root)
    root.mkdir(parents=True, exist_ok=True)
    debug_dir = root / "debug"
    debug_dir.mkdir(parents=True, exist_ok=True)
    data = {
        "schema": "GSTE_PRIVACY_SAFE_DEBUG_V1",
        "version": VERSION,
        "purpose": "PRIVACY_SAFE_DEBUG_REPORT",
        "status": "FAILED",
        "input_mode": input_mode,
        "error_type": error_type,
        "privacy_notice": "No traceback, path, filename, score content, pitch, chord, note sequence, or exception message is included.",
    }
    jp = debug_dir / "PRIVACY_SAFE_DEBUG_REPORT.json"
    mp = root / "PRIVACY_SAFE_DEBUG_REPORT.md"
    jp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    mp.write_text(
        f"# GSTE {VERSION} Privacy-Safe Debug Report\n\n"
        "- Status: **FAILED**\n"
        f"- GSTE engine version: `{VERSION}`\n"
        f"- Input mode: **{input_mode or 'UNKNOWN'}**\n"
        f"- Error type: **{error_type}**\n\n"
        "This reduced report intentionally excludes traceback text, paths, filenames and musical score content.\n"
        "此精簡報告刻意排除 traceback、路徑、檔名與樂譜內容。\n",
        encoding="utf-8",
    )
    return PrivacySafeDebugReportPaths(markdown=mp, json=jp)
