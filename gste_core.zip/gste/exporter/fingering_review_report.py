from __future__ import annotations
from gste.version import VERSION

import json
from pathlib import Path

from gste.fingering_review.review_models import ReviewResult


def write_fingering_review_report(review: ReviewResult, path: str | Path) -> tuple[Path, Path]:
    md_path = Path(path)
    md_path.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    categories = (
        ("physical_repair", review.issues),
        ("physical_remaining", review.remaining_issues),
        ("physical_advisory", review.advisory_issues),
        ("smoothness_repair", review.smoothing_issues),
        ("smoothness_remaining", review.smoothing_remaining),
    )
    for category, issues in categories:
        for issue in issues:
            if category == "physical_advisory" or category == "smoothness_remaining":
                status = "ADVISORY"
            else:
                status = issue.status.value
            rows.append({
                "category": category,
                "measure": issue.measure, "beat": issue.beat, "onset": issue.onset,
                "issue": issue.issue_type, "original_value": issue.original_value,
                "final_value": issue.final_value, "barre_fret": issue.barre_fret,
                "barre_strings": list(issue.barre_strings), "conflict_string": issue.conflict_string,
                "required_fret": issue.required_fret, "repair": issue.repair,
                "status": status,
            })
    lines = [
        f"# GSTE {VERSION} Full Joint Fingering Review", "",
        f"Result: **{review.outcome}**", "",
        "Review architecture: **Pass 1 full sounding-hand physical validation -> Pass 2 isolated-position smoothing -> final hard validation**", "",
        f"Melody identity preserved: **{'YES' if review.melody_signature_before == review.melody_signature_after else 'NO'}**", "",
        f"Physical repairs attempted/recorded: **{len(review.issues)}**", "",
        f"Physical issues remaining: **{len(review.remaining_issues)}**", "",
        f"Directionally legal four-fret advisories: **{len(review.advisory_issues)}**", "",
        f"Isolated-position repairs: **{len(review.smoothing_issues)}**", "",
        f"Isolated-position advisories remaining: **{len(review.smoothing_remaining)}**", "",
    ]
    if not rows:
        lines.append("No physical or isolated-position fingering issues were detected.")
    for row in rows:
        lines.extend([
            f"## Measure {row['measure']}, beat {row['beat']:.3f}", "",
            f"- Category: `{row['category']}`",
            f"- Issue: `{row['issue']}`", f"- Status: `{row['status']}`",
            f"- Original / final value: `{row['original_value']}` / `{row['final_value']}`",
            f"- Repair/details: {row['repair'] or 'Manual review required'}", "",
        ])
    md_path.write_text("\n".join(lines), encoding="utf-8")
    json_path = md_path.with_suffix(".json")
    json_path.write_text(json.dumps({
        "version": VERSION, "passed": review.passed,
        "degraded": review.degraded, "outcome": review.outcome,
        "review_passes": ["full_sounding_hand_physical", "isolated_position_smoothing", "final_hard_validation"],
        "melody_identity_preserved": review.melody_signature_before == review.melody_signature_after,
        "counts": {
            "physical_recorded": len(review.issues),
            "physical_remaining": len(review.remaining_issues),
            "four_fret_advisories": len(review.advisory_issues),
            "smoothing_repaired": len(review.smoothing_issues),
            "smoothing_remaining": len(review.smoothing_remaining),
        },
        "issues": rows,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    return md_path, json_path
