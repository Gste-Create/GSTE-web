from __future__ import annotations
from gste.version import VERSION

import json
from pathlib import Path

from gste.harmony.library import chord_family_name
from gste.harmony.piano_analysis import WindowHarmonyAnalysis
from gste.joint_arrangement.models import JointArrangementResult, JointWindowCandidate
from gste.joint_arrangement.optimizer import evaluate_transition


CHECK_OUTER_STRETCH = 6.0
CHECK_MELODY_REACH = 4.0
CHECK_STATIC_HAND = 8.0
CHECK_TRANSITION = 12.0
CHECK_CANDIDATE_GAP = 3.0


def _fingering(note):
    return {
        "midi": note.note.pitch.midi,
        "start": note.note.start,
        "duration": note.note.duration,
        "string": note.string,
        "fret": note.fret,
        "source_event_id": note.note.source_event_id,
        "importance": note.note.importance,
        "arrangement_role": note.note.arrangement_role,
        "intent_id": note.note.intent_id,
        "candidate_id": note.note.candidate_id,
        "pattern_type": note.note.pattern_type,
        "provenance": [__import__("dataclasses").asdict(e) for e in note.note.provenance],
    }


def _signature(state: JointWindowCandidate) -> tuple:
    return (
        state.window_id,
        chord_family_name(state.harmony.family),
        tuple((n.string, n.fret) for n in state.melody.notes),
        tuple((n.string, n.fret) for n in state.accompaniment.notes),
    )


def _num(mapping, key: str) -> float:
    value = mapping.get(key, 0.0)
    return float(value) if isinstance(value, (int, float)) else 0.0


def _notes_text(notes) -> str:
    return ", ".join(f"S{n.string}F{n.fret}" for n in notes) or "(rest)"


def _candidate_score(state: JointWindowCandidate, previous: JointWindowCandidate | None) -> tuple[float, float, dict[str, float | str]]:
    if previous is None:
        return state.local_cost, 0.0, {}
    transition, breakdown = evaluate_transition(previous, state)
    return state.local_cost + transition, transition, breakdown


def _ranked_layer(layer: tuple[JointWindowCandidate, ...], previous: JointWindowCandidate | None) -> list[tuple[JointWindowCandidate, float, float, dict[str, float | str]]]:
    ranked = []
    for state in layer:
        score, transition, breakdown = _candidate_score(state, previous)
        ranked.append((state, score, transition, breakdown))
    return sorted(ranked, key=lambda item: (item[1], item[0].local_cost))


def _flags(state: JointWindowCandidate, gap: float | None = None) -> list[str]:
    cb = state.cost_breakdown
    flags: list[str] = []
    if str(cb.get("shape_family", "UNKNOWN")) == "UNKNOWN":
        flags.append("UNKNOWN_SHAPE")
    if _num(cb, "outer_string_stretch_cost") >= CHECK_OUTER_STRETCH:
        flags.append("OUTER_STRING_STRETCH")
    if _num(cb, "melody_reach") >= CHECK_MELODY_REACH:
        flags.append("MELODY_EXTREME_REACH")
    if _num(cb, "static_hand_cost") >= CHECK_STATIC_HAND:
        flags.append("HIGH_STATIC_HAND_COST")
    if state.transition_cost >= CHECK_TRANSITION:
        flags.append("HIGH_TRANSITION_COST")
    if gap is not None and abs(gap) < CHECK_CANDIDATE_GAP:
        flags.append("CLOSE_ALTERNATIVE")
    flags.extend(state.accompaniment.modifications)
    if "OMITTED_FIFTH" in state.accompaniment.modifications:
        flags.append("FIFTH_OMITTED")
    if "OMITTED_THIRD" in state.accompaniment.modifications:
        flags.append("THIRD_OMITTED")
    return flags


def write_joint_candidates_json(result: JointArrangementResult, path: str | Path) -> Path:
    output = Path(path)
    selected = {_signature(state): state for state in result.selected}
    payload = {"version": VERSION, "total_cost": result.total_cost, "warnings": list(result.warnings), "windows": []}
    previous: JointWindowCandidate | None = None
    for index, layer in enumerate(result.candidate_layers):
        ranked = _ranked_layer(layer, previous)
        selected_state = result.selected[index] if index < len(result.selected) else None
        selected_score = next((score for state, score, _, _ in ranked if selected_state and _signature(state) == _signature(selected_state)), None)
        second_score = next((score for state, score, _, _ in ranked if not selected_state or _signature(state) != _signature(selected_state)), None)
        gap = None if selected_score is None or second_score is None else second_score - selected_score
        payload["windows"].append({
            "window_id": layer[0].window_id if layer else None,
            "check_required": bool(selected_state and _flags(selected_state, gap)),
            "check_flags": _flags(selected_state, gap) if selected_state else [],
            "selected_vs_best_alternative_gap": gap,
            "candidates": [
                {
                    "diagnostic_rank": rank,
                    "selected": _signature(state) in selected,
                    "chord": chord_family_name(state.harmony.family),
                    "chord_score": state.harmony.total_score,
                    "melody_cost": state.melody.local_cost,
                    "melody": [_fingering(n) for n in state.melody.notes],
                    "accompaniment_name": state.accompaniment.name,
                    "accompaniment_cost": state.accompaniment.local_cost,
                    "accompaniment": [_fingering(n) for n in state.accompaniment.notes],
                    "source_bass_pitch": state.source_bass_pitch,
                    "output_bass_pitch": state.output_bass_pitch,
                    "bass_identity_rank": state.bass_identity_rank,
                    "bass_role": state.bass_role,
                    "bass_substitution_reason": state.bass_substitution_reason,
                    "source_harmony_locked": state.source_harmony_locked,
                    "tone_roles": list(state.accompaniment.tone_roles),
                    "pruned_roles": list(state.accompaniment.pruned_roles),
                    "pruning_reasons": list(state.accompaniment.pruning_reasons),
                    "candidate_type": state.accompaniment.candidate_type,
                    "modifications": list(state.accompaniment.modifications),
                    "omitted_pitch_classes": list(state.accompaniment.omitted_pitch_classes),
                    "raised_octave_pitch_classes": list(state.accompaniment.raised_octave_pitch_classes),
                    "harmony_coverage": list(state.accompaniment.harmony_coverage),
                    "local_cost": state.local_cost,
                    "diagnostic_score_from_previous_selected": score,
                    "diagnostic_transition_cost": transition,
                    "cost_breakdown": state.cost_breakdown,
                    "diagnostic_transition_breakdown": transition_breakdown,
                }
                for rank, (state, score, transition, transition_breakdown) in enumerate(ranked, start=1)
            ],
        })
        if selected_state:
            previous = selected_state
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return output


def write_arrangement_dashboard(result: JointArrangementResult, path: str | Path) -> Path:
    output = Path(path)
    checks: list[tuple[JointWindowCandidate, list[str], float | None]] = []
    previous: JointWindowCandidate | None = None
    for index, state in enumerate(result.selected):
        layer = result.candidate_layers[index]
        ranked = _ranked_layer(layer, previous)
        selected_score = next((score for item, score, _, _ in ranked if _signature(item) == _signature(state)), None)
        alt_score = next((score for item, score, _, _ in ranked if _signature(item) != _signature(state)), None)
        gap = None if selected_score is None or alt_score is None else alt_score - selected_score
        flags = _flags(state, gap)
        if flags:
            checks.append((state, flags, gap))
        previous = state

    melody_only_count = sum(1 for state in result.selected if state.accompaniment.candidate_type in {"K_MELODY_ONLY_HARD_CONFLICT", "M_LOCAL_MELODY_RESCUE"})
    revoiced_count = sum(1 for state in result.selected if state.accompaniment.candidate_type in {
        "B_TIMED_TEXTURE_REVOICING", "C_REVOICING", "D_FUNCTIONAL_REVOICING",
        "E_NEAR_POSITION_VOICING", "F_HIGH_REGISTER_OCTAVE_REVOICE", "G_HIGH_REGISTER_INVERSION",
        "L_GUITAR_NATIVE_BASS_GUIDE", "L_GUITAR_NATIVE_BASS_ONLY",
    })
    runtime_status = (
        "PASS_WITH_MELODY_ONLY_FALLBACK" if melody_only_count else
        ("PASS_WITH_REVOICING" if revoiced_count else "PASS")
    )

    lines = [
        f"# GSTE {VERSION} Arrangement Dashboard", "",
        f"- Runtime status: **{runtime_status}**",
        f"- Guitar-native/revoiced windows: **{revoiced_count}**",
        f"- Melody-only fallback windows: **{melody_only_count}**",
        f"- Total windows: **{len(result.selected)}**",
        f"- PASS: **{len(result.selected) - len(checks)}**",
        f"- CHECK: **{len(checks)}**",
        f"- Total DP cost: **{result.total_cost:.3f}**", "",
        "## Windows requiring review", "",
    ]
    if not checks:
        lines.append("No window triggered the current review thresholds.")
    for state, flags, gap in checks:
        lines.extend([
            f"### ⚠ {state.window_id} — {chord_family_name(state.harmony.family)}", "",
            f"- Flags: **{', '.join(flags)}**",
            f"- Melody: {_notes_text(state.melody.notes)}",
            f"- Accompaniment: {state.accompaniment.name}: {_notes_text(state.accompaniment.notes)}",
            f"- Shape: {state.cost_breakdown.get('shape_family', 'UNKNOWN')}",
            f"- Outer-stretch cost: {_num(state.cost_breakdown, 'outer_string_stretch_cost'):.3f}",
            f"- Melody reach: {_num(state.cost_breakdown, 'melody_reach'):.0f} frets (cost {_num(state.cost_breakdown, 'melody_reach_cost'):.3f})",
            f"- Static hand cost: {_num(state.cost_breakdown, 'static_hand_cost'):.3f}",
            f"- Transition cost: {state.transition_cost:.3f}",
            f"- Selected/alternative gap: {'n/a' if gap is None else f'{gap:.3f}'}", "",
        ])
    lines.extend([
        "## Reading order", "",
        "1. Open `13_best_arrangement_tab.musicxml` and locate a suspicious measure.",
        "2. Find the same window ID in this dashboard.",
        "3. Open `12_diagnostic_alternatives.md` to compare the selected candidate with three alternatives.",
        "4. Open `10_joint_candidates.json` only when the desired alternative is absent or deeper numeric detail is needed.", "",
    ])
    if result.warnings:
        lines.extend(["## Pipeline warnings", "", *[f"- {w}" for w in result.warnings], ""])
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(lines), encoding="utf-8")
    return output


def write_diagnostic_alternatives(result: JointArrangementResult, path: str | Path, top_n: int = 3) -> Path:
    output = Path(path)
    lines = [
        f"# GSTE {VERSION} Diagnostic Alternatives", "",
        "Each window shows the selected voicing and the three lowest one-step diagnostic alternatives when approached from the previous selected hand shape. The globally selected DP path may have a higher one-step score because it creates an easier following transition.", "",
    ]
    previous: JointWindowCandidate | None = None
    for index, selected in enumerate(result.selected):
        layer = result.candidate_layers[index]
        ranked = _ranked_layer(layer, previous)
        selected_row = next(row for row in ranked if _signature(row[0]) == _signature(selected))
        alternatives = [row for row in ranked if _signature(row[0]) != _signature(selected)][:top_n]
        selected_score = selected_row[1]
        alt_gap = alternatives[0][1] - selected_score if alternatives else None
        flags = _flags(selected, alt_gap)
        lines.extend([
            f"## {'⚠ CHECK' if flags else '✓ PASS'} {selected.window_id} — {chord_family_name(selected.harmony.family)}", "",
            f"Flags: {', '.join(flags) if flags else 'none'}", "",
            "### Selected", "",
        ])
        _append_candidate(lines, selected_row, selected_score, selected=True)
        if alternatives:
            lines.extend(["### Top alternatives", ""])
            for rank, row in enumerate(alternatives, start=1):
                _append_candidate(lines, row, selected_score, label=f"Alternative {rank}")
        else:
            lines.extend(["No alternative survived candidate filtering.", ""])
        previous = selected
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(lines), encoding="utf-8")
    return output


def write_mixed_harmony_diagnostics(
    analyses: list[WindowHarmonyAnalysis], result: JointArrangementResult, path: str | Path,
) -> Path:
    """Report possible two-harmony windows without changing their boundaries.

    v0.11.6 deliberately does not implement Dynamic Harmony Window.  This file
    is evidence for deciding whether that next experiment is justified.
    """
    selected_by_id = {state.window_id: state for state in result.selected}
    rows = []
    for analysis in analyses:
        selected = selected_by_id.get(analysis.window.window_id)
        ranked = analysis.candidates
        first = chord_family_name(ranked[0].family) if ranked else None
        second = chord_family_name(ranked[1].family) if len(ranked) > 1 else None
        selected_name = chord_family_name(selected.harmony.family) if selected else None
        # A close runner-up together with a selected/source discrepancy is a
        # diagnostic signal only; it never changes the fixed two-beat window.
        close = len(ranked) > 1 and abs(ranked[0].total_score - ranked[1].total_score) <= 0.75
        suspected = bool(close and selected_name and selected_name != first)
        rows.append({
            "window_id": analysis.window.window_id,
            "mixed_harmony_suspected": suspected,
            "candidate_split_points": [analysis.window.start + analysis.window.duration / 2] if suspected else [],
            "pre_split_chord": first,
            "post_split_chord": second,
            "selected_chord": selected_name,
            "action": "diagnostic_only_fixed_window_retained",
        })
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps({"version": VERSION, "windows": rows}, ensure_ascii=False, indent=2), encoding="utf-8")
    return output


def _append_candidate(lines: list[str], row, selected_score: float, selected: bool = False, label: str | None = None) -> None:
    state, score, transition, tb = row
    cb = state.cost_breakdown
    heading = "Chosen candidate" if selected else (label or "Candidate")
    lines.extend([
        f"#### {heading}", "",
        f"- Diagnostic score: **{score:.3f}** ({score - selected_score:+.3f} vs selected)",
        f"- Chord: {chord_family_name(state.harmony.family)}",
        f"- Melody: {_notes_text(state.melody.notes)}",
        f"- Accompaniment: {state.accompaniment.name}: {_notes_text(state.accompaniment.notes)}",
        f"- Voicing strategy: {state.accompaniment.candidate_type}; changes: {', '.join(state.accompaniment.modifications) or 'none'}",
        f"- Harmony coverage (melody + accompaniment): {', '.join(map(str, state.accompaniment.harmony_coverage)) or 'none'}; omitted: {', '.join(map(str, state.accompaniment.omitted_pitch_classes)) or 'none'}",
        f"- Bass: source {state.source_bass_pitch}, output {state.output_bass_pitch}, B{state.bass_identity_rank} ({state.bass_substitution_reason})",
        f"- Source harmony lock: {'yes' if state.source_harmony_locked else 'no'}; local pruning: {', '.join(state.accompaniment.pruned_roles) or 'none'}",
        f"- Shape: {cb.get('shape_family', 'UNKNOWN')}",
        f"- Joint span: {_num(cb, 'joint_fret_span'):.0f}",
        f"- Combined hand centre: {_num(cb, 'hand_center'):.1f}; assignment cost: {_num(cb, 'finger_assignment_static_cost'):.3f}",
        f"- Melody / accompaniment centre distance: {_num(cb, 'melody_to_accompaniment_center_distance'):.1f} frets ({_num(cb, 'accompaniment_non_open_count'):.0f} fretted accompaniment tones)",
        f"- Outer-string distance: {_num(cb, 'outer_string_distance'):.0f}",
        f"- Outer-stretch cost: {_num(cb, 'outer_string_stretch_cost'):.3f}",
        f"- Melody reach/cost: {_num(cb, 'melody_reach'):.0f} / {_num(cb, 'melody_reach_cost'):.3f}",
        f"- Low-bass / mini-barre risk: {_num(cb, 'low_bass_risk'):.3f} / {_num(cb, 'mini_barre_risk'):.3f}",
        f"- Static hand cost: {_num(cb, 'static_hand_cost'):.3f}",
        f"- Transition cost: {transition:.3f}",
        f"- Hand-centre transition: {_num(tb, 'previous_hand_center'):.1f} → {_num(tb, 'current_hand_center'):.1f}; cost {_num(tb, 'hand_center_transition_cost'):.3f}",
        f"- Geometry-change cost: {_num(tb, 'outer_geometry_change_cost'):.3f}", "",
    ])
