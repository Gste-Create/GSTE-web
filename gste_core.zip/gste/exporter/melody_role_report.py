from __future__ import annotations
from gste.version import VERSION
import json
from pathlib import Path
from gste.melody_extraction.models import MelodyPathResult

def _pitch(midi: int) -> str:
    names = ("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    return f"{names[midi % 12]}{midi // 12 - 1}"

def write_melody_role_report(result: MelodyPathResult, path: str | Path) -> tuple[Path, Path]:
    md = Path(path); js = md.with_suffix(".json"); md.parent.mkdir(parents=True, exist_ok=True)
    selected = {(d.kept_note.measure, round(d.kept_note.start, 6), d.kept_note.pitch.midi) for d in result.extraction.decisions}
    rows = [{"measure": c.note.measure, "onset": c.note.start, "midi": c.note.pitch.midi, "pitch": _pitch(c.note.pitch.midi), "duration": c.note.duration, "source_voice": c.source_voice, "is_highest_at_onset": c.is_highest_at_onset, "selected_for_path": (c.note.measure, round(c.note.start, 6), c.note.pitch.midi) in selected, "role": c.role.value, "confidence": round(c.confidence, 3), "score": round(c.score, 3), "reasons": list(c.reasons)} for c in result.candidates]
    segments = [{"segment": s.index, "measures": f"M{s.start_measure}–M{s.end_measure}", "primary_voices": list(s.primary_voices), "primary_cost": round(s.best_score, 3), "alternative_cost": None if s.second_score is None else round(s.second_score, 3), "confidence": round(s.confidence, 3), "flag": s.flag, "cost_breakdown": s.cost_breakdown or {}, "alternatives": [[{"measure": x[0], "onset": x[1], "midi": x[2], "voice": x[3]} for x in route] for route in s.alternatives]} for s in result.segments]
    data = {"version": VERSION, "mode": "phrase_path_beam_dp", "policy": result.extraction.policy, "path": {"primary_cost": result.best_path_score, "alternative_cost": result.second_path_score, "cost_gap": result.confidence_gap, "ranking": "lower_cost_is_better"}, "summary": {"source_notes": result.extraction.source_note_count, "core_melody_notes": result.extraction.kept_note_count, "low_confidence_segments": sum(s["flag"] is not None for s in segments)}, "segments": segments, "notes": rows}
    js.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = [f"# GSTE {VERSION} 主旋律路徑分析", "", "- 模式：**2 小節樂句級 Beam Search / DP**", "- 排序：**成本越低越好**", f"- Primary／Alternative 總成本：{result.best_path_score:.2f} / {result.second_path_score:.2f}", f"- 低信心區段：**{data['summary']['low_confidence_segments']}**", "", "## 區段候選路徑", "", "| 區段 | Primary Voice | Alternative | Primary cost | Alternative cost | 信心 | Flag |", "|---|---|---|---:|---:|---:|---|"]
    for s in segments:
        alternative = ", ".join(sorted({str(n["voice"]) for n in s["alternatives"][1][0:1]})) if len(s["alternatives"]) > 1 else "—"
        alt_cost = "—" if s['alternative_cost'] is None else f"{s['alternative_cost']:.2f}"
        primary_voices = ", ".join(sorted({str(x) if x is not None else "—" for x in s["primary_voices"]}))
        lines.append(f"| {s['measures']} | {primary_voices} | {alternative} | {s['primary_cost']:.2f} | {alt_cost} | {s['confidence']:.0%} | {s['flag'] or '—'} |")
        lines.append(f"| ↳ cost | — | — | {', '.join(f'{k}={v:.2f}' for k, v in s['cost_breakdown'].items())} | — | — | — |")
    lines += ["", "## 逐音審查", "", "| 小節 | onset | 音符 | Voice | 最高音 | 選取 | 角色 | 原因 |", "|---|---:|---|---|---|---|---|---|"]
    for r in rows:
        lines.append(f"| {r['measure']} | {r['onset']:g} | {r['pitch']} | {r['source_voice'] or '—'} | {'是' if r['is_highest_at_onset'] else '否'} | {'是' if r['selected_for_path'] else '否'} | {r['role']} | {', '.join(r['reasons'])} |")
    lines += ["", "低信心區段會標示 `MELODY_ROLE_AMBIGUOUS`；Alternative Path 僅供人工審查，絕不進入伴奏 DP。", ""]
    md.write_text("\n".join(lines), encoding="utf-8")
    debug = md.parent / "debug"; debug.mkdir(exist_ok=True)
    (debug / "melody_path_candidates.json").write_text(json.dumps({"version":"0.12.0", "segments":segments}, ensure_ascii=False, indent=2), encoding="utf-8")
    (debug / "melody_path_cost_breakdown.md").write_text("# Melody Path Cost Breakdown\n\nSee `01_MELODY_ROLE_ANALYSIS.json` for segment scores and candidate routes.\n", encoding="utf-8")
    return md, js
