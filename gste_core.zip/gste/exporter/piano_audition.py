from __future__ import annotations

from pathlib import Path
import xml.etree.ElementTree as ET


def write_piano_audition_without_ties(source_path: str | Path, output_path: str | Path) -> Path:
    """Write a MuseScore audition copy with tie semantics removed.

    The official TAB is not changed.  This review-only copy intentionally
    re-attacks tied segments so harmonic clashes are easier to hear during
    SOURCE_PIANO manual review.
    """
    source=Path(source_path); output=Path(output_path)
    tree=ET.parse(source)
    root=tree.getroot()
    for note in root.findall(".//note"):
        for tie in list(note.findall("tie")):
            note.remove(tie)
        notations=note.find("notations")
        if notations is not None:
            for tied in list(notations.findall("tied")):
                notations.remove(tied)
    output.parent.mkdir(parents=True, exist_ok=True)
    tree.write(output,encoding="utf-8",xml_declaration=True)
    return output
