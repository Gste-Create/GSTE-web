"""Canonical output projection shared by GUI, CLI and batch.

This module does not diagnose music.  It only projects artifacts already written
by the conversion pipeline into one stable output contract.
"""
from __future__ import annotations
from pathlib import Path
import json, shutil
from gste.version import VERSION

CANONICAL_FILES = (
    "PIPELINE_DIAGNOSTICS.json",
    "UNIFIED_RUNTIME_MONITOR.md",
    "PRIVACY_SAFE_DEBUG_REPORT.md",
    "ENGINEER_DEBUG_SUMMARY.md",
)

def _core_dir(out: Path) -> Path:
    nested = out / "04_register_search" / "existing_core"
    return nested if nested.exists() else out

def project_canonical_outputs(out_dir: str | Path, *, route: str, status: str = "COMPLETE") -> Path:
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    core = _core_dir(out)
    copied = []
    for name in CANONICAL_FILES:
        src = core / name
        dst = out / name
        if src.exists() and src.resolve() != dst.resolve():
            shutil.copy2(src, dst); copied.append(name)
    src_monitor_json = core / "debug" / "UNIFIED_RUNTIME_MONITOR.json"
    dst_monitor_json = out / "debug" / "UNIFIED_RUNTIME_MONITOR.json"
    if src_monitor_json.exists():
        dst_monitor_json.parent.mkdir(parents=True, exist_ok=True)
        if src_monitor_json.resolve() != dst_monitor_json.resolve(): shutil.copy2(src_monitor_json, dst_monitor_json)
        copied.append("debug/UNIFIED_RUNTIME_MONITOR.json")
    # Stable user-facing report name. It only reports routing/status and points to
    # the canonical monitor; it does not recompute musical conclusions.
    report = out / "CONVERSION_REPORT.md"
    report.write_text(
        f"# {VERSION} Conversion Report\n\n"
        f"- Route: {route}\n- Status: {status}\n"
        "- Runtime truth: `PIPELINE_DIAGNOSTICS.json`\n"
        "- Privacy-safe debug: `PRIVACY_SAFE_DEBUG_REPORT.md`\n"
        "- Unified monitor: `UNIFIED_RUNTIME_MONITOR.md`\n",
        encoding="utf-8",
    )
    manifest = {
        "schema": "GSTE_OUTPUT_CONTRACT_V1", "version": VERSION,
        "route": route, "status": status,
        "canonical_files": {
            "conversion_report": "CONVERSION_REPORT.md",
            "pipeline_diagnostics": "PIPELINE_DIAGNOSTICS.json",
            "unified_monitor": "UNIFIED_RUNTIME_MONITOR.md",
            "privacy_safe_debug": "PRIVACY_SAFE_DEBUG_REPORT.md",
            "engineer_debug_summary": "ENGINEER_DEBUG_SUMMARY.md",
            "unified_monitor_json": "debug/UNIFIED_RUNTIME_MONITOR.json",
        },
        "source_specific_artifacts_allowed": True,
        "rule": "GUI, CLI and batch use the same conversion service and canonical output projection. Route-specific analysis may add artifacts but may not redefine canonical monitor truth.",
    }
    path = out / "OUTPUT_MANIFEST.json"
    path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return path
