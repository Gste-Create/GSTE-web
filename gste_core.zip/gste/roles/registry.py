from dataclasses import dataclass
from typing import Any, Callable
from gste.arrangement.source_adapters.bass import BassSourceAdapter
from gste.arrangement.source_adapters.rhythm_guitar import RhythmGuitarSourceAdapter

@dataclass
class RoleProcessorRegistry:
    processors: dict[str, Callable]
    def process(self, role: str, data: Any, **kwargs):
        key=role.upper()
        if key not in self.processors: raise KeyError(f"No role processor registered for {role}")
        return self.processors[key](data, **kwargs)

def build_default_role_registry():
    bass=BassSourceAdapter(); rhythm=RhythmGuitarSourceAdapter()
    return RoleProcessorRegistry({
        'BASS': bass.analyze_track,
        'GUITAR': rhythm.analyze_track,
        'RHYTHM_GUITAR': rhythm.analyze_track,
        'LEAD_GUITAR': rhythm.analyze_track,
        # Melody and piano remain routed through their established services until
        # their richer contracts are wrapped without changing verified behavior.
    })
