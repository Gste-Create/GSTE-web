"""Role preprocessing boundary: TrackData -> role-specific musical information."""
from .registry import RoleProcessorRegistry, build_default_role_registry
__all__=['RoleProcessorRegistry','build_default_role_registry']
