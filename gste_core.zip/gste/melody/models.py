from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum


class ShiftMode(StrEnum):
    STAY = "stay"
    BOUNDARY_SHIFT = "boundary_shift"
    CONTINUOUS_TRANSLATION = "continuous_translation"
    FORCED_SHIFT = "forced_shift"


@dataclass(frozen=True)
class NoteFeasibility:
    note_index: int
    midi: int
    start: float
    duration: float
    playable_positions: tuple[tuple[int, int], ...]

    @property
    def playable(self) -> bool:
        return bool(self.playable_positions)


@dataclass(frozen=True)
class MelodyFeasibility:
    notes: tuple[NoteFeasibility, ...]
    melody_complete: bool
    playable: bool
    pitch_min: int | None
    pitch_max: int | None
    max_fret: int
    hard_constraints: tuple[str, ...] = (
        "preserve_every_melody_note",
        "reject_unplayable_pitch",
    )


@dataclass(frozen=True)
class PositionZoneCandidate:
    segment_id: str
    start: float
    duration: float
    position_block: int
    fret_low: int
    fret_high: int
    covered_note_indices: tuple[int, ...]
    total_note_count: int
    estimated_difficulty: float
    preferred: bool = False
    reasons: tuple[str, ...] = field(default_factory=tuple)

    @property
    def coverage(self) -> float:
        if self.total_note_count == 0:
            return 1.0
        return len(self.covered_note_indices) / self.total_note_count

    @property
    def melody_complete(self) -> bool:
        return self.coverage == 1.0


@dataclass(frozen=True)
class PositionPlanStep:
    segment_id: str
    start: float
    duration: float
    position_block: int
    shift_mode: ShiftMode
    local_cost: float
    boundary_suitability: float
    melody_complete: bool = True


@dataclass(frozen=True)
class PositionPlan:
    plan_id: str
    steps: tuple[PositionPlanStep, ...]
    total_cost: float
    melody_complete: bool
    playable: bool
    advisory_only: bool = True
