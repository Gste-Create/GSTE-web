from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from gste.core.models import NoteEvent
from gste.input.project_models import TrackData


@dataclass(frozen=True)
class LockedMelodyEvent:
    """Immutable structural melody identity created once after melody reading/extraction.

    Timing is authoritative for every later stage.  Arrangement/Fingering may only
    choose a string/fret realization; they may not invent a new attack/release or
    single-note register change.
    """

    structural_event_id: str
    source_xml_id: str
    midi_pitch: int
    attack: float
    release: float
    measure: int | None

    @property
    def duration(self) -> float:
        return self.release - self.attack


@dataclass(frozen=True)
class LockedMelodyBackbone:
    events: tuple[LockedMelodyEvent, ...]
    lock_stage: str

    def by_id(self) -> dict[str, LockedMelodyEvent]:
        return {event.structural_event_id: event for event in self.events}

    @property
    def event_ids(self) -> frozenset[str]:
        return frozenset(event.structural_event_id for event in self.events)

    def shifted(self, semitones: int, *, lock_stage: str | None = None) -> "LockedMelodyBackbone":
        return LockedMelodyBackbone(
            events=tuple(
                LockedMelodyEvent(
                    structural_event_id=event.structural_event_id,
                    source_xml_id=event.source_xml_id,
                    midi_pitch=event.midi_pitch + int(semitones),
                    attack=event.attack,
                    release=event.release,
                    measure=event.measure,
                )
                for event in self.events
            ),
            lock_stage=lock_stage or self.lock_stage,
        )


def lock_melody_backbone(track: TrackData, *, stage: str) -> LockedMelodyBackbone:
    """Freeze structural melody identity/timing from the authoritative melody track.

    ``source_event_id`` is created by the parser from the *original* MusicXML
    element order and is treated as immutable from this point onward.
    """
    rows: list[LockedMelodyEvent] = []
    seen: set[str] = set()
    for note in sorted(track.notes, key=lambda n: (n.start, n.measure or 0, n.pitch.midi, n.duration)):
        if note.duration <= 0:
            continue
        event_id = str(note.source_event_id or "")
        if not event_id:
            raise ValueError("LOCKED_MELODY_BACKBONE_MISSING_EVENT_ID")
        if event_id in seen:
            # The same structural event may be referenced by multiple windows later,
            # but the authoritative melody track itself must contain it exactly once.
            raise ValueError(f"LOCKED_MELODY_BACKBONE_DUPLICATE_EVENT_ID:{event_id}")
        seen.add(event_id)
        attack = float(note.start)
        release = attack + float(note.duration)
        rows.append(
            LockedMelodyEvent(
                structural_event_id=event_id,
                source_xml_id=event_id,
                midi_pitch=int(note.pitch.midi),
                attack=attack,
                release=release,
                measure=note.measure,
            )
        )
    if not rows:
        raise ValueError("LOCKED_MELODY_BACKBONE_EMPTY")
    return LockedMelodyBackbone(tuple(rows), stage)


def validate_result_against_backbone(backbone: LockedMelodyBackbone, result, *, stage: str) -> dict:
    """Validate only immutable melody identity/pitch/timing against one backbone.

    Duplicate window occurrences are allowed, but every occurrence must agree
    with the same locked structural event.  Missing events are also hard errors.
    """
    ref = backbone.by_id()
    seen: set[str] = set()
    violations: list[dict] = []
    for state in getattr(result, "selected", ()) or ():
        for cand in getattr(getattr(state, "melody", None), "notes", ()) or ():
            note = cand.note
            event_id = str(getattr(note, "source_event_id", "") or "")
            if not event_id:
                violations.append({"type": "MISSING_EVENT_ID", "stage": stage})
                continue
            expected = ref.get(event_id)
            if expected is None:
                violations.append({
                    "type": "UNKNOWN_STRUCTURAL_EVENT",
                    "stage": stage,
                    "event_id": event_id,
                    "actual": {
                        "midi": int(note.pitch.midi),
                        "attack": float(note.start),
                        "release": float(note.start + note.duration),
                    },
                })
                continue
            seen.add(event_id)
            actual = (int(note.pitch.midi), round(float(note.start), 9), round(float(note.start + note.duration), 9))
            wanted = (expected.midi_pitch, round(expected.attack, 9), round(expected.release, 9))
            if actual != wanted:
                violations.append({
                    "type": "MELODY_BACKBONE_MUTATION",
                    "stage": stage,
                    "event_id": event_id,
                    "expected": {"midi": wanted[0], "attack": wanted[1], "release": wanted[2]},
                    "actual": {"midi": actual[0], "attack": actual[1], "release": actual[2]},
                })
    missing = sorted(set(ref) - seen)
    for event_id in missing:
        event = ref[event_id]
        violations.append({
            "type": "MISSING_STRUCTURAL_MELODY_EVENT",
            "stage": stage,
            "event_id": event_id,
            "expected": {"midi": event.midi_pitch, "attack": event.attack, "release": event.release},
        })
    report = {
        "stage": stage,
        "status": "PASS" if not violations else "FAIL",
        "locked_event_count": len(ref),
        "seen_event_count": len(seen),
        "violation_count": len(violations),
        "violations": violations,
    }
    if violations:
        first = violations[0]
        raise ValueError(
            f"MELODY_BACKBONE_HARD_LOCK:{stage}: {len(violations)} violation(s); first={first}"
        )
    return report



def validate_track_against_backbone(backbone: LockedMelodyBackbone, track: TrackData, *, stage: str) -> dict:
    ref = backbone.by_id()
    actual = {str(n.source_event_id): n for n in track.notes if n.source_event_id}
    violations: list[dict] = []
    for event_id, expected in ref.items():
        note = actual.get(event_id)
        if note is None:
            violations.append({"type": "MISSING_STRUCTURAL_MELODY_EVENT", "stage": stage, "event_id": event_id})
            continue
        got = (int(note.pitch.midi), round(float(note.start), 9), round(float(note.start + note.duration), 9))
        wanted = (expected.midi_pitch, round(expected.attack, 9), round(expected.release, 9))
        if got != wanted:
            violations.append({
                "type": "MELODY_BACKBONE_MUTATION", "stage": stage, "event_id": event_id,
                "expected": {"midi": wanted[0], "attack": wanted[1], "release": wanted[2]},
                "actual": {"midi": got[0], "attack": got[1], "release": got[2]},
            })
    unknown = sorted(set(actual) - set(ref))
    for event_id in unknown:
        note = actual[event_id]
        violations.append({
            "type": "UNKNOWN_STRUCTURAL_EVENT", "stage": stage, "event_id": event_id,
            "actual": {"midi": int(note.pitch.midi), "attack": float(note.start), "release": float(note.start + note.duration)},
        })
    report = {
        "stage": stage, "status": "PASS" if not violations else "FAIL",
        "locked_event_count": len(ref), "actual_event_count": len(actual),
        "violation_count": len(violations), "violations": violations,
    }
    if violations:
        raise ValueError(f"MELODY_BACKBONE_HARD_LOCK:{stage}: {len(violations)} violation(s); first={violations[0]}")
    return report


def backbone_to_dict(backbone: LockedMelodyBackbone) -> dict:
    return {
        "lock_stage": backbone.lock_stage,
        "event_count": len(backbone.events),
        "semantics": "structural_event_id + absolute MIDI + [attack,release) are immutable; only string/fret may change downstream",
        "events": [
            {
                "structural_event_id": e.structural_event_id,
                "source_xml_id": e.source_xml_id,
                "midi_pitch": e.midi_pitch,
                "attack": e.attack,
                "release": e.release,
                "duration": e.duration,
                "measure": e.measure,
            } for e in backbone.events
        ],
    }

def backbone_track_signature(backbone: LockedMelodyBackbone) -> tuple[tuple[str, int, float, float], ...]:
    return tuple(
        (event.structural_event_id, event.midi_pitch, round(event.attack, 9), round(event.release, 9))
        for event in backbone.events
    )


def build_prelock_event_identity_audit(track: TrackData) -> dict:
    """Read-only v0.13.5.15.4 audit of structural IDs immediately before lock.

    This never repairs or renames IDs. It records enough source context to find
    the first layer that assigned one identity to multiple structural notes.
    """
    from collections import defaultdict
    groups = defaultdict(list)
    raw_by_id = {str(e.event_id): e for e in track.events if getattr(e, "event_id", None)}
    for index, note in enumerate(sorted(track.notes, key=lambda n:(n.start,n.measure or 0,n.pitch.midi,n.duration))):
        sid = str(note.source_event_id or "")
        raw = raw_by_id.get(sid)
        groups[sid].append({
            "track_note_index": index,
            "source_event_id": sid,
            "pitch_midi": int(note.pitch.midi),
            "onset": float(note.start),
            "release": float(note.start + note.duration),
            "duration": float(note.duration),
            "measure": note.measure,
            "source_order": getattr(raw, "order", None),
            "voice": getattr(raw, "voice", None),
            "staff": getattr(raw, "staff", None),
            "chord_id": getattr(raw, "chord_id", None),
            "is_chord_tone": getattr(raw, "is_chord_tone", None),
            "tie_types": list(getattr(raw, "tie_types", ()) or ()),
        })
    duplicates = {sid: rows for sid, rows in groups.items() if sid and len(rows) > 1}
    missing = groups.get("", [])
    return {
        "status": "FAIL_DUPLICATE_ID" if duplicates else ("FAIL_MISSING_ID" if missing else "PASS"),
        "note_count": sum(len(v) for v in groups.values()),
        "unique_nonempty_id_count": len([k for k in groups if k]),
        "duplicate_id_count": len(duplicates),
        "missing_id_count": len(missing),
        "duplicates": duplicates,
        "missing": missing,
        "semantics": "Read-only pre-lock audit. No IDs are renamed or repaired.",
    }
