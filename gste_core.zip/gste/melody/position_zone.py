from __future__ import annotations

from collections.abc import Sequence

from gste.core.fretboard import POSITION_BLOCKS, position_block_for_fret
from gste.input.project_models import TrackData
from gste.melody.models import MelodyFeasibility, PositionZoneCandidate


def _notes_overlapping(track: TrackData, start: float, duration: float) -> list[tuple[int, object]]:
    end = start + duration
    return [
        (index, note)
        for index, note in enumerate(track.notes)
        if note.start < end and note.start + note.duration > start
    ]


def build_position_zone_candidates(
    melody: TrackData,
    feasibility: MelodyFeasibility,
    segments: Sequence[object],
    *,
    max_candidates_per_segment: int = 5,
) -> list[PositionZoneCandidate]:
    """Create coarse position candidates without fixing detailed string/fret choices.

    Only zones that can preserve every melody note in a segment are returned.
    When no single zone covers a segment, note-local zones are retained as partial
    diagnostic candidates; the later planner then marks the transition as forced.
    """
    by_note = {item.note_index: item for item in feasibility.notes}
    output: list[PositionZoneCandidate] = []

    for seg_index, segment in enumerate(segments):
        start = float(segment.start)
        duration = float(segment.duration)
        segment_id = getattr(segment, "window_id", f"segment_{seg_index:03d}")
        overlapping = _notes_overlapping(melody, start, duration)
        total = len(overlapping)
        candidates: list[PositionZoneCandidate] = []

        for block_index, (low, high) in enumerate(POSITION_BLOCKS):
            covered: list[int] = []
            fret_samples: list[int] = []
            for note_index, _note in overlapping:
                options = by_note[note_index].playable_positions
                matching = [fret for _string, fret in options if low <= fret <= high]
                if matching:
                    covered.append(note_index)
                    fret_samples.append(min(matching))

            coverage = 1.0 if total == 0 else len(covered) / total
            if not covered and total:
                continue
            center = (low + high) / 2.0
            average_distance = (
                sum(abs(fret - center) for fret in fret_samples) / len(fret_samples)
                if fret_samples
                else 0.0
            )
            difficulty = round((1.0 - coverage) * 10.0 + average_distance * 0.15 + block_index * 0.03, 6)
            reasons = ["complete_melody_coverage" if coverage == 1.0 else "partial_coverage"]
            if low == 0:
                reasons.append("open_position_available")
            candidates.append(
                PositionZoneCandidate(
                    segment_id=segment_id,
                    start=start,
                    duration=duration,
                    position_block=block_index,
                    fret_low=low,
                    fret_high=high,
                    covered_note_indices=tuple(covered),
                    total_note_count=total,
                    estimated_difficulty=difficulty,
                    reasons=tuple(reasons),
                )
            )

        complete = [item for item in candidates if item.melody_complete]
        pool = complete or candidates
        pool.sort(key=lambda item: (not item.melody_complete, item.estimated_difficulty, item.position_block))
        for rank, item in enumerate(pool[:max_candidates_per_segment]):
            output.append(
                PositionZoneCandidate(
                    **{**item.__dict__, "preferred": rank == 0}
                )
            )

    return output
