from __future__ import annotations

from gste.core.fretboard import midi_to_string_fret
from gste.core.tuning import STANDARD_TUNING, Tuning
from gste.input.project_models import TrackData
from gste.melody.models import MelodyFeasibility, NoteFeasibility


def analyze_melody_feasibility(
    melody: TrackData,
    *,
    max_fret: int = 17,
    tuning: Tuning = STANDARD_TUNING,
) -> MelodyFeasibility:
    notes: list[NoteFeasibility] = []
    for index, note in enumerate(melody.notes):
        positions = tuple(midi_to_string_fret(note.pitch.midi, max_fret=max_fret, tuning=tuning))
        notes.append(
            NoteFeasibility(
                note_index=index,
                midi=note.pitch.midi,
                start=note.start,
                duration=note.duration,
                playable_positions=positions,
            )
        )

    midi_values = [item.midi for item in notes]
    playable = all(item.playable for item in notes)
    return MelodyFeasibility(
        notes=tuple(notes),
        melody_complete=playable,
        playable=playable,
        pitch_min=min(midi_values) if midi_values else None,
        pitch_max=max(midi_values) if midi_values else None,
        max_fret=max_fret,
    )


def validate_locked_melody_identity(reference_track, result, *, stage: str) -> None:
    """Hard rule retained in v0.13.5.12.10.1.

    After the global/phrase register decision, each structural melody event keeps
    its absolute MIDI pitch, attack and duration.  Later fingering stages may
    change only string/fret realization for the same pitch.
    """
    ref = {
        str(n.source_event_id): (
            int(n.pitch.midi), round(float(n.start), 9), round(float(n.duration), 9)
        )
        for n in getattr(reference_track, "notes", ())
        if getattr(n, "source_event_id", None)
    }
    violations = []
    for state in getattr(result, "selected", ()) or ():
        for cand in getattr(getattr(state, "melody", None), "notes", ()) or ():
            note = cand.note
            sid = str(getattr(note, "source_event_id", "") or "")
            if not sid or sid not in ref:
                continue
            actual = (
                int(note.pitch.midi), round(float(note.start), 9), round(float(note.duration), 9)
            )
            if actual != ref[sid]:
                violations.append((sid, ref[sid], actual))
    if violations:
        sid, expected, actual = violations[0]
        raise ValueError(
            f"MELODY_IDENTITY_HARD_LOCK:{stage}: {len(violations)} violation(s); "
            f"first={sid} expected={expected} actual={actual}"
        )
