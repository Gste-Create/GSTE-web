from __future__ import annotations

from dataclasses import dataclass

from gste.harmony.evidence import extract_harmonic_evidence
from gste.harmony.library import basic_chord_families
from gste.harmony.models import ChordFamilyCandidate, HarmonicEvidence
from gste.harmony.scoring import prune_chord_families
from gste.harmony.windows import HarmonyWindow


@dataclass(frozen=True)
class WindowHarmonyAnalysis:
    window: HarmonyWindow
    evidence: HarmonicEvidence
    candidates: list[ChordFamilyCandidate]


def analyze_harmony_windows(
    windows: list[HarmonyWindow],
    *,
    top_k: int = 3,
    minimum_score: float = 0.0,
) -> list[WindowHarmonyAnalysis]:
    families = basic_chord_families()
    return [
        WindowHarmonyAnalysis(
            window=window,
            evidence=(evidence := extract_harmonic_evidence(window)),
            candidates=prune_chord_families(families, evidence, top_k=top_k, minimum_score=minimum_score),
        )
        for window in windows
    ]
