from __future__ import annotations

from gste.harmony.models import ChordFamily

QUALITY_INTERVALS: dict[str, tuple[frozenset[int], frozenset[int]]] = {
    "major": (frozenset({0, 4}), frozenset({7})),
    "minor": (frozenset({0, 3}), frozenset({7})),
    "dominant7": (frozenset({0, 4, 10}), frozenset({7})),
    "maj7": (frozenset({0, 4, 11}), frozenset({7})),
    "minor7": (frozenset({0, 3, 10}), frozenset({7})),
    "half_diminished7": (frozenset({0, 3, 6, 10}), frozenset()),
    "diminished7": (frozenset({0, 3, 6, 9}), frozenset()),
    "sus2": (frozenset({0, 2}), frozenset({7})),
    "sus4": (frozenset({0, 5}), frozenset({7})),
    "diminished": (frozenset({0, 3, 6}), frozenset()),
}

PITCH_CLASS_NAMES = ["C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B"]


def basic_chord_families() -> list[ChordFamily]:
    return [
        ChordFamily(root_pc=root, quality=quality, required_intervals=required, optional_intervals=optional)
        for root in range(12)
        for quality, (required, optional) in QUALITY_INTERVALS.items()
    ]


def chord_family_name(family: ChordFamily) -> str:
    suffix = {
        "major": "",
        "minor": "m",
        "dominant7": "7",
        "maj7": "maj7",
        "minor7": "m7",
        "half_diminished7": "m7b5",
        "diminished7": "dim7",
        "sus2": "sus2",
        "sus4": "sus4",
        "diminished": "dim",
    }.get(family.quality, f"({family.quality})")
    return f"{PITCH_CLASS_NAMES[family.root_pc]}{suffix}"
