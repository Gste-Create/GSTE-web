from __future__ import annotations

from dataclasses import dataclass, field
from gste.structure.metric import MetricContext


@dataclass(frozen=True)
class HarmonyNoteEvidence:
    event_id: str | None
    role: str
    onset: float
    duration: float
    overlap_duration: float
    pitch_class: int
    metric_context: MetricContext
    final_harmony_weight: float



@dataclass(frozen=True)
class HarmonicEvidence:
    """Weighted pitch-class evidence inside one harmonic window."""

    start: float
    duration: float
    melody_pitch_weights: dict[int, float] = field(default_factory=dict)
    accompaniment_pitch_weights: dict[int, float] = field(default_factory=dict)
    bass_pitch_class: int | None = None
    key_pitch_classes: frozenset[int] = frozenset()
    note_evidence: tuple[HarmonyNoteEvidence, ...] = ()


@dataclass(frozen=True)
class ChordFamily:
    """Coarse harmony identity used before exact guitar voicing is chosen."""

    root_pc: int
    quality: str
    required_intervals: frozenset[int]
    optional_intervals: frozenset[int] = frozenset()
    function: str | None = None

    @property
    def pitch_classes(self) -> frozenset[int]:
        return frozenset((self.root_pc + interval) % 12 for interval in self.required_intervals | self.optional_intervals)

    @property
    def required_pitch_classes(self) -> frozenset[int]:
        return frozenset((self.root_pc + interval) % 12 for interval in self.required_intervals)


@dataclass(frozen=True)
class ChordFamilyCandidate:
    family: ChordFamily
    harmonic_score: float
    melody_score: float
    accompaniment_score: float
    bass_score: float
    complexity_penalty: float = 0.0

    @property
    def total_score(self) -> float:
        return (
            self.harmonic_score
            + self.melody_score
            + self.accompaniment_score
            + self.bass_score
            - self.complexity_penalty
        )
