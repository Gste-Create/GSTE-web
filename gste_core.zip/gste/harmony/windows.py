from __future__ import annotations

from dataclasses import dataclass

from gste.core.models import NoteEvent
from gste.input.project_models import PianoSplitProject
from gste.structure.metric import MetricGroup


@dataclass(frozen=True)
class HarmonyWindow:
    window_id: str
    measure: int
    start: float
    duration: float
    melody_notes: list[NoteEvent]
    accompaniment_notes: list[NoteEvent]
    metric_groups: tuple[MetricGroup, ...] = ()

    @property
    def end(self) -> float:
        return self.start + self.duration


def _overlapping(notes: list[NoteEvent], start: float, end: float) -> list[NoteEvent]:
    return [note for note in notes if note.start < end and note.start + note.duration > start]


def build_fixed_harmony_windows(project: PianoSplitProject, quarters_per_window: float = 2.0) -> list[HarmonyWindow]:
    if quarters_per_window <= 0:
        raise ValueError("quarters_per_window must be positive")

    from gste.structure.metric import build_analysis_windows
    windows = []
    for span in build_analysis_windows(project.melody, quarters_per_window):
        windows.append(HarmonyWindow(span.window_id, span.measure, span.start,
            span.end-span.start, _overlapping(project.melody.notes, span.start, span.end),
            _overlapping(project.left_hand.notes, span.start, span.end), project.melody.metric_groups))
    return windows



# Compatibility export: identity has one owner with the common builder.
from gste.structure.metric import canonical_window_id
