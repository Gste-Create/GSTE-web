from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, Sequence

from gste.core.models import NoteEvent


@dataclass(frozen=True)
class ChordEvent:
    symbol: str
    start: float
    duration: float
    confidence: float = 1.0
    source: str = "unknown"


class HarmonyProvider(Protocol):
    """Boundary for rule-based, extracted, or future learned harmony engines."""

    def generate(self, melody: Sequence[NoteEvent]) -> list[ChordEvent]: ...
