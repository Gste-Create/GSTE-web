from __future__ import annotations

from collections.abc import Iterable

from gste.harmony.models import ChordFamily, ChordFamilyCandidate, HarmonicEvidence


def _weighted_coverage(weights: dict[int, float], allowed: frozenset[int]) -> float:
    total = sum(max(weight, 0.0) for weight in weights.values())
    if total <= 0:
        return 0.0
    covered = sum(max(weight, 0.0) for pitch_class, weight in weights.items() if pitch_class % 12 in allowed)
    return covered / total


def score_chord_family(family: ChordFamily, evidence: HarmonicEvidence) -> ChordFamilyCandidate:
    """Score one family while keeping melody and accompaniment roles separate.

    Melody is not made optional here: complete melody reproduction is enforced by
    the later fingering feasibility layer. This score only measures harmonic fit.
    """

    allowed = family.pitch_classes
    melody = _weighted_coverage(evidence.melody_pitch_weights, allowed)
    accompaniment = _weighted_coverage(evidence.accompaniment_pitch_weights, allowed)

    bass = 0.0
    if evidence.bass_pitch_class is not None:
        bass_pc = evidence.bass_pitch_class % 12
        if bass_pc == family.root_pc:
            bass = 1.0
        elif bass_pc in family.required_pitch_classes:
            bass = 0.65
        elif bass_pc in allowed:
            bass = 0.35
        else:
            bass = -0.5

    key_fit = 0.0
    if evidence.key_pitch_classes:
        family_in_key = len(allowed & evidence.key_pitch_classes) / max(len(allowed), 1)
        key_fit = 0.5 * family_in_key

    observed = {
        pitch_class % 12
        for pitch_class, weight in {
            **evidence.melody_pitch_weights,
            **evidence.accompaniment_pitch_weights,
        }.items()
        if weight > 0
    }
    missing_required = len(family.required_pitch_classes - observed)
    # A more specific family (for example dominant seventh) should not outrank
    # a simple triad when its defining tone is absent from both tracks.
    required_tone_penalty = 0.9 * missing_required

    return ChordFamilyCandidate(
        family=family,
        harmonic_score=key_fit,
        melody_score=2.0 * melody,
        accompaniment_score=3.0 * accompaniment,
        bass_score=2.0 * bass,
        complexity_penalty=0.15 * len(family.optional_intervals) + required_tone_penalty,
    )


def prune_chord_families(
    families: Iterable[ChordFamily],
    evidence: HarmonicEvidence,
    top_k: int = 3,
    minimum_score: float = 0.0,
) -> list[ChordFamilyCandidate]:
    """Keep only a small number of coarse chord families before shape expansion."""

    scored = [score_chord_family(family, evidence) for family in families]
    scored = [candidate for candidate in scored if candidate.total_score >= minimum_score]
    scored.sort(
        key=lambda candidate: (
            -candidate.total_score,
            candidate.family.root_pc,
            candidate.family.quality,
        )
    )
    return scored[: max(top_k, 0)]
