from __future__ import annotations

from collections import defaultdict

from gste.core.models import NoteEvent
from gste.harmony.models import HarmonicEvidence, HarmonyNoteEvidence
from gste.structure import metric
from gste.harmony.windows import HarmonyWindow


def _overlap_duration(note: NoteEvent, start: float, end: float) -> float:
    return max(0.0, min(note.start + note.duration, end) - max(note.start, start))


def _weights(notes: list[NoteEvent], window: HarmonyWindow, *, melody: bool, audit: list[HarmonyNoteEvidence]) -> dict[int, float]:
    values: dict[int, float] = defaultdict(float)
    for note in notes:
        overlap = _overlap_duration(note, window.start, window.end)
        if overlap <= 0:
            continue
        context = metric.metric_context_at(note.start, window.metric_groups)
        strength = context.onset_accent
        if melody:
            # Sustained melody notes and structural onsets matter more than short passing notes.
            weight = overlap * (0.6 + strength)
        else:
            weight = overlap * strength
            if note.duration <= 0.25 and strength <= 0.25:
                weight *= 0.35
        values[note.pitch.midi % 12] += weight
        audit.append(HarmonyNoteEvidence(note.source_event_id, "MELODY" if melody else "ACCOMPANIMENT",
            note.start, note.duration, overlap, note.pitch.midi % 12, context, weight))
    return dict(values)


def extract_harmonic_evidence(window: HarmonyWindow) -> HarmonicEvidence:
    audit: list[HarmonyNoteEvidence] = []
    accompaniment_weights = _weights(window.accompaniment_notes, window, melody=False, audit=audit)
    melody_weights = _weights(window.melody_notes, window, melody=True, audit=audit)

    bass_pitch_class: int | None = None
    if window.accompaniment_notes:
        ranked = sorted(
            window.accompaniment_notes,
            key=lambda note: (
                note.pitch.midi,
                -_overlap_duration(note, window.start, window.end),
                note.start,
            ),
        )
        bass_pitch_class = ranked[0].pitch.midi % 12

    return HarmonicEvidence(
        start=window.start,
        duration=window.duration,
        melody_pitch_weights=melody_weights,
        accompaniment_pitch_weights=accompaniment_weights,
        bass_pitch_class=bass_pitch_class,
        note_evidence=tuple(audit),
    )
