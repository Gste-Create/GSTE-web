"""Core single-score conversion implementation.

This module owns melody/TAB conversion logic. CLI and conversion_service are
adapters only; core conversion must never import CLI.
"""
from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import Literal

from gste.version import VERSION
from gste.core.tuning import Tuning, resolve_tuning
from gste.exporter.report import fingering_path_to_text
from gste.exporter.tab_xml_exporter import write_tab_musicxml
from gste.fingering.dp import find_best_fingering
from gste.parser.track_parser import parse_musicxml_track
from gste.parser.tab_parser import has_tab_fingerings, parse_tab_musicxml
from gste.shift.shift_finder import find_best_shift, transpose_notes
from gste.shift.tab_shift_finder import find_best_tab_shift

ConvertMode = Literal["auto", "melody", "tab"]

def _default_output_dir() -> Path:
    return Path("outputs")


def _convert_melody_score(source: Path, auto_shift: bool, tuning: Tuning, max_candidates: int) -> tuple[int, str, object]:
    notes = parse_musicxml_track(source, track_id="melody", role="melody").notes
    shift = 0
    shift_warnings: list[str] = []

    if auto_shift:
        shift_result = find_best_shift(notes, tuning=tuning)
        shift = shift_result.semitone_shift
        shift_warnings = shift_result.warnings
        notes = transpose_notes(notes, shift)

    path = find_best_fingering(notes, tuning=tuning, max_candidates=max_candidates)
    if shift_warnings:
        path = replace(path, warnings=[*path.warnings, *shift_warnings])
    return shift, "melody-to-tab", path


def _convert_tab_score(source: Path, auto_shift: bool, tuning: Tuning, max_candidates: int) -> tuple[int, str, object]:
    notes = parse_tab_musicxml(source)
    if auto_shift:
        result = find_best_tab_shift(notes, tuning=tuning)
        mode = "tab-shift"
        if result.used_fallback:
            mode = "tab-shift-fallback-regenerated"
        return result.semitone_shift, mode, result.path

    # Preserve the existing TAB exactly when automatic shift is disabled.
    result = find_best_tab_shift(notes, candidate_shifts=range(0, 1), allow_fallback=False, tuning=tuning)
    return 0, "tab-preserve", result.path


def convert_score(
    input_path: str | Path,
    output_dir: str | Path | None = None,
    auto_shift: bool = True,
    mode: ConvertMode = "auto",
    tuning_name: str = "standard",
    custom_tuning: str | None = None,
    max_candidates: int = 5,
    keep_candidates: bool = True,
    auto_accompaniment: bool = False,
    accompaniment_pattern: str = "auto",
    accompaniment_mode: str | None = None,
) -> tuple[Path, Path]:
    source = Path(input_path)
    out_dir = Path(output_dir) if output_dir else _default_output_dir()
    out_dir.mkdir(parents=True, exist_ok=True)
    tuning = resolve_tuning(tuning_name, custom_tuning)

    effective_accompaniment_mode = (accompaniment_mode or ("AUTO_GENERATED" if auto_accompaniment else "NONE")).upper()
    if accompaniment_mode is not None or auto_accompaniment:
        if effective_accompaniment_mode == "SOURCE_ANALYZED":
            raise ValueError("SOURCE_ANALYZED requires the two-input accompaniment route, not convert_score melody-only input.")
        if mode == "tab" or (mode == "auto" and has_tab_fingerings(source)):
            raise ValueError("Automatic accompaniment is only available for melody input.")
        from gste.auto_arrangement import run_melody_auto_arrangement
        outputs = run_melody_auto_arrangement(
            source, output_dir=out_dir, pattern=accompaniment_pattern, tuning=tuning, accompaniment_mode=effective_accompaniment_mode,
        )
        return outputs.chord_review, outputs.final_tab

    if mode == "auto":
        selected_mode: ConvertMode = "tab" if has_tab_fingerings(source) else "melody"
    else:
        selected_mode = mode

    if selected_mode == "tab":
        shift, pipeline_mode, path = _convert_tab_score(source, auto_shift=auto_shift, tuning=tuning, max_candidates=max_candidates)
    elif selected_mode == "melody":
        shift, pipeline_mode, path = _convert_melody_score(source, auto_shift=auto_shift, tuning=tuning, max_candidates=max_candidates)
    else:
        raise ValueError(f"Unsupported convert mode: {mode}")

    report = [
        f"# {VERSION} Conversion Report",
        "",
        f"Version: {VERSION}",
        f"Input: {source}",
        f"Requested mode: {mode}",
        f"Pipeline mode: {pipeline_mode}",
        f"Auto shift: {auto_shift}",
        f"Tuning: {tuning.name}",
        f"Open strings low-to-high: {','.join(str(tuning.strings[s]) for s in sorted(tuning.strings, reverse=True))}",
        f"Applied semitone shift: {shift}",
        f"Max candidates per note: {max_candidates}",
        "",
        fingering_path_to_text(path, include_candidates=keep_candidates),
        "",
    ]

    stem = source.stem
    report_path = out_dir / f"{stem}_report.md"
    tab_path = out_dir / f"{stem}_tab.musicxml"
    report_path.write_text("\n".join(report), encoding="utf-8")
    write_tab_musicxml(path, tab_path, title=f"{stem} - {VERSION} TAB", tuning=tuning, source_path=source, semitone_shift=shift)
    return report_path, tab_path


