"""Single public conversion entry used by GUI, CLI and batch runners.

The service owns routing only. Musical algorithms remain in their existing modules.
Batch mode must call this same entry (normally through ``gste.cli``) and may only
add a batch summary outside each song's normal output directory.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from gste.output_contract import project_canonical_outputs
from gste.output_packaging import package_success, package_failure

ConversionKind = Literal["melody", "piano", "ensemble"]

@dataclass(frozen=True)
class ConversionRequest:
    kind: ConversionKind
    melody: Path
    output_dir: Path
    left_hand: Path | None = None
    accompaniment_mode: str = "AUTO_GENERATED"
    accompaniment_pattern: str = "auto"
    tuning_name: str = "standard"
    custom_tuning: str | None = None
    max_candidates: int = 5
    window_quarters: float = 2.0
    chord_top_k: int = 3
    melody_paths: int = 6
    accompaniment_per_chord: int = 4
    joint_candidates: int = 24
    ensemble_tracks: tuple[object, ...] = ()
    editor_context: Path | None = None
    edit_requests: Path | None = None

@dataclass(frozen=True)
class ConversionResult:
    tab_musicxml: Path
    output_dir: Path
    report: Path | None = None


def run_conversion(request: ConversionRequest) -> ConversionResult:
    from gste.editor.session import CURRENT, EditorSession
    session = EditorSession(request)
    token = CURRENT.set(session)
    try:
        result = _run_conversion(request)
        return session.finish(result)
    finally:
        CURRENT.reset(token)


def _run_conversion(request: ConversionRequest) -> ConversionResult:
    """Only public conversion entry for GUI, CLI and batch.

    Route-specific analysis is allowed below this boundary; output packaging and
    monitoring truth are normalized here.
    """
    request.output_dir.mkdir(parents=True, exist_ok=True)
    from gste.user_reports import initialize_locations
    initialize_locations(request.output_dir, request.melody)
    route = f"{request.kind}:{request.accompaniment_mode}"
    try:
        if request.kind == "ensemble":
            if not request.ensemble_tracks:
                raise ValueError("ensemble conversion requires at least one accompaniment track")
            from gste.core.tuning import resolve_tuning
            from gste.pipeline.ensemble_priority import arrange_ensemble_priority
            outputs = arrange_ensemble_priority(
                request.melody, request.ensemble_tracks, output_dir=request.output_dir,
                tuning=resolve_tuning(request.tuning_name, request.custom_tuning),
            )
            project_canonical_outputs(request.output_dir, route=route, status="COMPLETE")
            packaged = package_success(request.output_dir, outputs.tab_musicxml, mode_label="Ensemble")
            return ConversionResult(packaged, request.output_dir, request.output_dir / "CONVERSION_REPORT.md")

        if request.kind == "piano":
            if request.left_hand is None:
                raise ValueError("piano conversion requires left_hand")
            from gste.core.tuning import resolve_tuning
            from gste.main import arrange_source_score
            outputs = arrange_source_score(
                request.melody, request.left_hand, output_dir=request.output_dir,
                quarters_per_window=request.window_quarters,
                chord_top_k=request.chord_top_k,
                melody_paths_per_window=request.melody_paths,
                accompaniment_per_chord=request.accompaniment_per_chord,
                joint_candidates_per_window=request.joint_candidates,
                max_candidates_per_note=request.max_candidates,
                tuning=resolve_tuning(request.tuning_name, request.custom_tuning),
            )
            project_canonical_outputs(request.output_dir, route=route, status="COMPLETE")
            packaged = package_success(request.output_dir, outputs.tab_musicxml, mode_label="Piano / two-hand")
            return ConversionResult(packaged, request.output_dir, request.output_dir / "CONVERSION_REPORT.md")

        from gste.conversion_core import convert_score
        report, tab = convert_score(
            request.melody, output_dir=request.output_dir, mode="melody",
            tuning_name=request.tuning_name, custom_tuning=request.custom_tuning,
            max_candidates=request.max_candidates,
            accompaniment_pattern=request.accompaniment_pattern,
            accompaniment_mode=request.accompaniment_mode,
        )
        project_canonical_outputs(request.output_dir, route=route, status="COMPLETE")
        packaged = package_success(request.output_dir, tab, mode_label="Melody only")
        return ConversionResult(packaged, request.output_dir, request.output_dir / "CONVERSION_REPORT.md")
    except BaseException as exc:
        # Failure packages must expose the same canonical paths as successful runs.
        # Privacy-safe generation consumes recorder state only; it does not inspect
        # or reproduce score content.
        try:
            from gste.exporter.privacy_safe_debug_report import write_privacy_safe_failure_report
            core = request.output_dir / "04_register_search" / "existing_core"
            write_privacy_safe_failure_report(core if core.exists() else request.output_dir, error_type="ConversionError", input_mode=request.kind)
        except Exception:
            pass
        project_canonical_outputs(request.output_dir, route=route, status="FAILED")
        package_failure(request.output_dir, mode_label=("Piano / two-hand" if request.kind == "piano" else "Ensemble" if request.kind == "ensemble" else "Melody only"), detail=str(exc), traceback_text=__import__("traceback").format_exc())
        raise

