from __future__ import annotations

from pathlib import Path
from math import gcd
import xml.dom.minidom as minidom
import xml.etree.ElementTree as ET

from gste.core.models import NoteEvent
from gste.input.project_models import TrackData

from .domain import AccompanimentEvent, ArrangementPackage, ChordProgressionResult

_STEPS = {0: ("C", 0), 1: ("C", 1), 2: ("D", 0), 3: ("E", -1), 4: ("E", 0), 5: ("F", 0), 6: ("F", 1), 7: ("G", 0), 8: ("A", -1), 9: ("A", 0), 10: ("B", -1), 11: ("B", 0)}


def build_arrangement_package(notes: list[NoteEvent], progression: ChordProgressionResult, accompaniment: tuple[AccompanimentEvent, ...]) -> ArrangementPackage:
    return ArrangementPackage(tuple(notes), accompaniment, progression, "original_pitch", 0, {
        "melody_integrity": "hard_constraint",
        "adapter": "auto_arrangement_to_existing_guitar_engine",
    })


def _text(parent: ET.Element, tag: str, value: object) -> ET.Element:
    child = ET.SubElement(parent, tag); child.text = str(value); return child


def _score(title: str) -> tuple[ET.Element, ET.Element]:
    score = ET.Element("score-partwise", version="3.1")
    work = ET.SubElement(score, "work"); _text(work, "work-title", title)
    part_list = ET.SubElement(score, "part-list")
    score_part = ET.SubElement(part_list, "score-part", id="P1"); _text(score_part, "part-name", title)
    return score, ET.SubElement(score, "part", id="P1")


def _add_note(measure: ET.Element, midi: int, ticks: int, chord: bool = False, event_id: str | None = None) -> None:
    note = ET.SubElement(measure, "note")
    if chord: ET.SubElement(note, "chord")
    pitch = ET.SubElement(note, "pitch")
    step, alter = _STEPS[midi % 12]
    _text(pitch, "step", step)
    if alter: _text(pitch, "alter", alter)
    _text(pitch, "octave", midi // 12 - 1)
    _text(note, "duration", ticks); _text(note, "voice", 1); _text(note, "type", "quarter")
    if event_id:
        notations = ET.SubElement(note, "notations")
        marker = ET.SubElement(notations, "other-notation", type="gste-event-id")
        marker.text = event_id


def _source_compatible_divisions(timeline: TrackData | None, base: int = 480) -> int:
    """Choose a MusicXML divisions value that can exactly represent the source grid.

    AUTO_MELODY accompaniment is serialized and parsed again before the Joint
    stage.  Using an unrelated fixed grid can introduce one-tick rounding drift
    on tuplets or uncommon source divisions.  LCM(base, source divisions) keeps
    the historical 480-tick resolution while preserving every source duration
    denominator that is visible in the MusicXML file.
    """
    if timeline is None:
        return base
    values = [base]
    try:
        root = ET.parse(timeline.source_file).getroot()
        for node in root.findall(".//divisions"):
            if node.text:
                value = int(node.text.strip())
                if value > 0:
                    values.append(value)
    except (OSError, ET.ParseError, ValueError):
        return base

    result = base
    for value in values[1:]:
        result = result * value // gcd(result, value)
        # MusicXML accepts arbitrary positive divisions, but an accidentally
        # pathological source should not create enormous synthetic files.
        if result > 1_000_000:
            return base
    return result


def _add_rest(measure: ET.Element, ticks: int) -> None:
    if ticks <= 0:
        return
    rest = ET.SubElement(measure, "note")
    ET.SubElement(rest, "rest")
    _text(rest, "duration", ticks)
    _text(rest, "voice", 1)


def write_accompaniment_musicxml(
    events: tuple[AccompanimentEvent, ...],
    total_duration: float,
    path: str | Path,
    *,
    title: str = "Generated accompaniment",
    timeline: TrackData | None = None,
) -> Path:
    """Write generated notes on exactly the melody source's quantized grid.

    v0.13.5.12.3.1 fixes AUTO_MELODY synthetic-grid drift.  The previous writer
    rounded each rest/note duration independently.  Several individually valid
    rounded fragments could therefore sum to 1921 ticks inside a 1920-tick
    measure, and that error accumulated across the score until strict alignment
    rejected the generated accompaniment.

    This writer quantizes *absolute boundaries* first and obtains every duration
    by subtracting those integer boundaries.  Consequently each measure always
    serializes to exactly its expected tick length; there is no cumulative
    duration rounding drift.  Source MusicXML divisions are folded into the
    output divisions through an LCM so tuplets/unusual grids remain representable.
    """
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    score, part = _score(title)
    divisions = _source_compatible_divisions(timeline)

    if timeline is None:
        measure_grid = [
            (index + 1, index * 4.0, min((index + 1) * 4.0, total_duration), 4, 4)
            for index in range(max(1, int((total_duration + 3.999999) // 4)))
        ]
    else:
        signatures = sorted(timeline.time_signatures, key=lambda item: item.start)
        measure_grid = []
        for number in sorted(timeline.measure_starts):
            start = timeline.measure_starts[number]
            stop = start + timeline.measure_lengths[number]
            eligible = [item for item in signatures if item.start <= start + 1e-6]
            # Some valid MusicXML scores (including imported/normalized scores)
            # contain explicit measure boundaries but no <time> signature.  NONE
            # accompaniment must preserve that unmetered timeline rather than
            # calling max() on an empty signature sequence.
            active = max(eligible, key=lambda item: item.start) if eligible else None
            measure_grid.append((
                number, start, stop,
                active.beats if active is not None else None,
                active.beat_type if active is not None else None,
            ))

    previous_signature: tuple[int, int] | None = None
    for measure_index, (number, start, stop, beats, beat_type) in enumerate(measure_grid):
        measure = ET.SubElement(part, "measure", number=str(number))
        signature = (beats, beat_type) if beats is not None and beat_type is not None else None
        if measure_index == 0 or signature != previous_signature:
            attributes = ET.SubElement(measure, "attributes")
            _text(attributes, "divisions", divisions)
            # Preserve unmetered source timelines: absence of a source time
            # signature is meaningful and must not be replaced by an invented
            # 4/4 signature merely to serialize an empty accompaniment track.
            if signature is not None:
                time = ET.SubElement(attributes, "time")
                _text(time, "beats", beats)
                _text(time, "beat-type", beat_type)
        previous_signature = signature

        # Quantize absolute source boundaries once.  All local durations are
        # boundary differences, never independently rounded floating durations.
        start_tick_abs = int(round(start * divisions))
        stop_tick_abs = int(round(stop * divisions))
        measure_ticks = max(0, stop_tick_abs - start_tick_abs)
        cursor_tick = 0

        # Events that collapse to the same source-grid tick are a chord.  Clamp
        # near-boundary floating point noise onto [0, measure_ticks].  A tick at
        # the exact right boundary belongs to the next measure and is skipped.
        grouped: dict[int, list[AccompanimentEvent]] = {}
        for event in events:
            if event.onset < start - (0.5 / divisions) or event.onset > stop + (0.5 / divisions):
                continue
            onset_tick = int(round(event.onset * divisions)) - start_tick_abs
            if onset_tick < 0:
                onset_tick = 0
            if onset_tick >= measure_ticks:
                continue
            grouped.setdefault(onset_tick, []).append(event)

        ordered_onsets = sorted(grouped)
        for onset_index, onset_tick in enumerate(ordered_onsets):
            if onset_tick > cursor_tick:
                _add_rest(measure, onset_tick - cursor_tick)

            group = grouped[onset_tick]
            next_tick = ordered_onsets[onset_index + 1] if onset_index + 1 < len(ordered_onsets) else measure_ticks

            # Preserve the requested sustain when possible, but quantize its
            # endpoint on the same absolute tick grid.  Clip to the next attack
            # because this synthetic part intentionally uses one sequential voice.
            max_duration = max(event.duration for event in group)
            onset_abs_tick = start_tick_abs + onset_tick
            requested_end_tick = int(round((start + onset_tick / divisions + max_duration) * divisions))
            duration_end_tick = min(stop_tick_abs, start_tick_abs + next_tick, requested_end_tick)
            duration_ticks = duration_end_tick - onset_abs_tick

            # If a positive-duration generated event is narrower than one tick,
            # represent it by one tick only when that tick fits before the next
            # boundary.  Never push the cursor past the pre-quantized boundary.
            if duration_ticks <= 0 and next_tick > onset_tick:
                duration_ticks = 1
            duration_ticks = min(duration_ticks, max(0, next_tick - onset_tick), max(0, measure_ticks - onset_tick))
            if duration_ticks <= 0:
                continue

            for index, event in enumerate(group):
                _add_note(
                    measure,
                    event.pitch,
                    duration_ticks,
                    chord=index > 0,
                    event_id=event.event_id,
                )
            cursor_tick = onset_tick + duration_ticks

        if cursor_tick < measure_ticks:
            _add_rest(measure, measure_ticks - cursor_tick)
            cursor_tick = measure_ticks

        # Serializer invariant: every sequential voice must end exactly at the
        # source measure boundary.  Keeping this assertion local makes future
        # timing regressions fail at generation instead of much later in Joint.
        if cursor_tick != measure_ticks:
            raise AssertionError(
                f"Synthetic accompaniment measure {number} grid mismatch: "
                f"written={cursor_tick} expected={measure_ticks} ticks"
            )

    output.write_text(
        minidom.parseString(ET.tostring(score, encoding="utf-8")).toprettyxml(indent="  "),
        encoding="utf-8",
    )
    return output


def write_progression_musicxml(progression: ChordProgressionResult, path: str | Path) -> Path:
    output = Path(path); output.parent.mkdir(parents=True, exist_ok=True)
    score, part = _score("GSTE_Beta_V0.1.3 chord progression")
    for index, result in enumerate(progression.window_results, start=1):
        measure = ET.SubElement(part, "measure", number=str(index))
        if index == 1:
            attributes = ET.SubElement(measure, "attributes"); _text(attributes, "divisions", 480)
            time = ET.SubElement(attributes, "time"); _text(time, "beats", 2); _text(time, "beat-type", 4)
        harmony = ET.SubElement(measure, "harmony")
        root = ET.SubElement(harmony, "root")
        step, alter = _STEPS[result.selected.root_pitch_class]
        _text(root, "root-step", step)
        if alter: _text(root, "root-alter", alter)
        _text(harmony, "kind", result.selected.quality)
        rest = ET.SubElement(measure, "note"); ET.SubElement(rest, "rest"); _text(rest, "duration", 960)
    output.write_text(minidom.parseString(ET.tostring(score, encoding="utf-8")).toprettyxml(indent="  "), encoding="utf-8")
    return output
