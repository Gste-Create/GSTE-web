from __future__ import annotations
from gste.version import VERSION

from dataclasses import dataclass
import json
from pathlib import Path
import shutil

from gste.core.tuning import STANDARD_TUNING, Tuning
from gste.main import arrange_source_score
from gste.input_formats.router import parse_source_track

from gste.arrangement.auto.service import analyze_and_arrange_melody
from gste.input.project_models import PianoSplitProject
from gste.arrangement.accompaniment_contract import normalize_accompaniment_plan, contract_to_joint_bundle, contract_summary
from .adapters import build_arrangement_package, write_accompaniment_musicxml, write_progression_musicxml
from .config import AutoArrangementConfig, DEFAULT_CONFIG
from .domain import serializable
from .reports import write_accompaniment_review, write_chord_review, write_register_review
from .retention_diagnostics import build_accompaniment_retention_diagnostics, write_accompaniment_retention_diagnostics
from gste_diagnostics.freeze_audit import run as run_diagnostics_freeze
from gste_diagnostics.score_workflow import run as run_score_workflow
from gste.exporter.engineer_debug_summary import write_engineer_debug_summary
from gste.exporter.public_musicxml_sanitizer import sanitize_public_musicxml


@dataclass(frozen=True)
class AutoArrangementOutputs:
    output_dir: Path
    final_tab: Path
    chord_review: Path
    accompaniment_review: Path
    register_review: Path
    progression_musicxml: Path
    accompaniment_musicxml: Path
    retention_diagnostics_json: Path | None = None
    retention_diagnostics_md: Path | None = None


def _json(path: Path, value: object) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(serializable(value), ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def run_melody_auto_arrangement(
    source: str | Path, *, output_dir: str | Path, pattern: str = "auto",
    tuning: Tuning = STANDARD_TUNING, config: AutoArrangementConfig = DEFAULT_CONFIG,
    accompaniment_mode: str = "AUTO_GENERATED",
) -> AutoArrangementOutputs:
    source = Path(source)
    out = Path(output_dir)
    summary = out / "00_summary"; input_dir = out / "01_input"; auto = out / "02_auto_arrangement"
    intermediate = out / "03_intermediate_scores"; register = out / "04_register_search"; final = out / "05_final"
    for directory in (summary, input_dir, auto, intermediate, register, final):
        directory.mkdir(parents=True, exist_ok=True)
    source_timeline = parse_source_track(source, track_id="piano_right", role="melody")
    notes = source_timeline.notes
    shutil.copy2(source, input_dir / "normalized_input.musicxml")
    _json(input_dir / "melody_events.json", notes)
    accompaniment_mode = str(accompaniment_mode).upper()
    if accompaniment_mode not in {"AUTO_GENERATED", "NONE"}:
        raise ValueError("Melody-only pipeline accepts accompaniment_mode AUTO_GENERATED or NONE; SOURCE_ANALYZED requires an accompaniment input.")
    _json(summary / "accompaniment_mode.json", {"version": VERSION, "mode": accompaniment_mode})
    from gste.editor.session import CURRENT as _editor_current
    _has_edits = _editor_current.get() is not None and bool(_editor_current.get().requests)
    if accompaniment_mode == "NONE" and not _has_edits:
        accompaniment_xml = write_accompaniment_musicxml(tuple(), source_timeline.duration_quarters, intermediate / "accompaniment_none.musicxml", title="No accompaniment", timeline=source_timeline)
        joint = arrange_source_score(
            source, accompaniment_xml, output_dir=register / "existing_core", tuning=tuning,
            accompaniment_source="none", melody_extraction_mode="role_analysis",
            external_accompaniment_contract=None, parsed_source_project=PianoSplitProject(source_timeline,source_timeline), sanitize_public_output=False,
        )
        shutil.copy2(joint.tab_musicxml, final / "final_tab.musicxml")
        chord_review = summary / "chord_selection_review.md"
        accompaniment_review = summary / "accompaniment_review.md"
        register_review = summary / "register_review.md"
        chord_review.write_text("# Chord Selection Review\n\nAccompaniment mode: NONE. No chord accompaniment was generated.\n", encoding="utf-8")
        accompaniment_review.write_text("# Accompaniment Review\n\nMode: NONE\n\nGenerated accompaniment events: 0\nJoint accompaniment events: 0 expected.\n", encoding="utf-8")
        register_review.write_text("# Register Review\n\nMelody-only fingering completed through the Unified Melody Core and Joint/Fingering path.\n", encoding="utf-8")
        _json(auto / "unified_accompaniment_contract.json", {"version":VERSION,"source_kind":"none","status":"PASS","intent_count":0,"candidate_count":0,"policy":"EMPTY_IS_VALID_NO_GENERATION"})
        _core_monitor = register / "existing_core" / "UNIFIED_RUNTIME_MONITOR.md"
        _core_monitor_json = register / "existing_core" / "debug" / "UNIFIED_RUNTIME_MONITOR.json"
        if _core_monitor.exists(): shutil.copy2(_core_monitor, summary / "UNIFIED_RUNTIME_MONITOR.md")
        if _core_monitor_json.exists(): shutil.copy2(_core_monitor_json, summary / "UNIFIED_RUNTIME_MONITOR.json")
        chord_xml = write_accompaniment_musicxml(tuple(), source_timeline.duration_quarters, intermediate / "chord_progression.musicxml", title="No chord progression", timeline=source_timeline)
        sanitize_public_musicxml(final / 'final_tab.musicxml')
        return AutoArrangementOutputs(out, final / "final_tab.musicxml", chord_review, accompaniment_review, register_review, chord_xml, accompaniment_xml, None, None)
    arrangement_plan = analyze_and_arrange_melody(notes, source, pattern=pattern, config=config, timeline=source_timeline)
    accompaniment_contract = normalize_accompaniment_plan(arrangement_plan, source_kind="synthetic")
    _json(auto / "unified_accompaniment_contract.json", contract_summary(accompaniment_contract))
    progression = arrangement_plan.progression
    accompaniment_windows = arrangement_plan.selected_windows
    accompaniment_events = tuple(event for window in accompaniment_windows for event in window.events)
    package = build_arrangement_package(notes, progression, accompaniment_events)
    _json(auto / "key_candidates.json", progression.key_candidates)
    from gste.tonality import write_tonality_analysis
    write_tonality_analysis(progression.tonality_analysis,auto / "tonality_analysis.json")
    _json(auto / "chord_windows.json", [w.window for w in progression.window_results])
    _json(auto / "chord_candidates.json", progression.window_results)
    _json(auto / "progression_paths.json", {"selected": progression.selected_chords, "alternatives": progression.alternative_paths})
    _json(auto / "selected_progression.json", progression)
    _json(auto / "arrangement_intents.json", arrangement_plan.intents)
    _json(auto / "canonical_music_intents.json", arrangement_plan.canonical_intents)
    _json(auto / "arrangement_candidates.json", arrangement_plan.candidate_groups)
    prefilter_rows=[]
    for canonical, group in zip(arrangement_plan.canonical_intents, arrangement_plan.candidate_groups):
        meta=(group[0].metadata if group else {})
        prefilter_rows.append({
            "window_id": canonical.window_id,
            "melody_density": canonical.metadata.get("melody_density"),
            "section_role": canonical.metadata.get("section_role"),
            "survivors": meta.get("prefilter_survivors", []),
            "rejected": meta.get("prefilter_rejected", []),
            "scores": meta.get("prefilter_scores", {}),
            "beam_size": meta.get("prefilter_beam_size"),
            "reasons": meta.get("prefilter_reasons", []),
            "realized_candidate_count": len(group),
            "modern_candidate_count": sum(1 for candidate in group if not candidate.metadata.get("guaranteed_safe_candidate")),
            "guaranteed_safe_candidate_count": sum(1 for candidate in group if candidate.metadata.get("guaranteed_safe_candidate")),
            "importance_values": sorted({event.importance for candidate in group for event in candidate.events}, reverse=True),
            "importance_lineage": "ARRANGEMENT_TO_JOINT_TO_FINAL",
            "melody_hand_center": meta.get("melody_hand_center"),
            "melody_hand_low_fret": meta.get("melody_hand_low_fret"),
            "melody_hand_high_fret": meta.get("melody_hand_high_fret"),
            "melody_hand_center_confidence": meta.get("melody_hand_center_confidence"),
            "melody_hand_center_reason": meta.get("melody_hand_center_reason"),
            "melody_realization_pressure": meta.get("melody_realization_pressure"),
            "melody_realization_action": meta.get("melody_realization_action"),
            "melody_realization_attack_count": meta.get("melody_realization_attack_count"),
            "melody_attack_occupancy": meta.get("melody_attack_occupancy"),
            "melody_max_polyphony": meta.get("melody_max_polyphony"),
            "melody_hand_span": meta.get("melody_hand_span"),
            "selection_owner": "JOINT_ARRANGEMENT_DP",
        })
    if prefilter_rows:
        _json(auto / "candidate_prefilter_diagnostics.json", {
            "version":VERSION, "input_route":"AUTO_MELODY",
            "policy":"MELODY_INFORMED_BOUNDED_SUPERSET", "windows":prefilter_rows,
        })
    _json(auto / "selected_arrangement_candidates.json", arrangement_plan.selected_candidates)
    _json(auto / "accompaniment_events.json", accompaniment_windows)
    chord_xml = write_progression_musicxml(progression, intermediate / "chord_progression.musicxml")
    accompaniment_xml = write_accompaniment_musicxml(
        accompaniment_events,
        source_timeline.duration_quarters,
        intermediate / "accompaniment_only.musicxml",
        timeline=source_timeline,
    )
    bass_events = tuple(event for event in accompaniment_events if event.role == "bass")
    write_accompaniment_musicxml(
        bass_events,
        source_timeline.duration_quarters,
        intermediate / "bass_only.musicxml",
        title="Generated bass only",
        timeline=source_timeline,
    )
    chord_review = write_chord_review(progression, summary / "chord_selection_review.md")
    accompaniment_review = write_accompaniment_review(accompaniment_windows, summary / "accompaniment_review.md")
    joint_report = None
    warning = None
    octave_repair_warnings: list[str] = []
    selected_register = {
        "register": package.register_candidate,
        "semitones": package.transposition_semitones,
        "warning": None,
    }
    try:
        joint = arrange_source_score(
            source,
            accompaniment_xml,
            output_dir=register / "existing_core",
            tuning=tuning,
            accompaniment_source="synthetic_from_melody_grid",
            melody_extraction_mode="role_analysis",
            external_accompaniment_contract=accompaniment_contract,
            parsed_source_project=PianoSplitProject(source_timeline,contract_to_joint_bundle(accompaniment_contract,source_timeline)[0]),
            sanitize_public_output=False,
        )
        # Keep the Guitar-core artifact private/internal until all outer Melody
        # monitors have consumed GSTE identity metadata.  The user-facing copy
        # is sanitized only at the final export boundary.
        shutil.copy2(joint.tab_musicxml, final / "final_tab.musicxml")
        _core_monitor = register / "existing_core" / "UNIFIED_RUNTIME_MONITOR.md"
        _core_monitor_json = register / "existing_core" / "debug" / "UNIFIED_RUNTIME_MONITOR.json"
        if _core_monitor.exists():
            shutil.copy2(_core_monitor, summary / "UNIFIED_RUNTIME_MONITOR.md")
        if _core_monitor_json.exists():
            shutil.copy2(_core_monitor_json, summary / "UNIFIED_RUNTIME_MONITOR.json")
        joint_report = joint.register_key_report_md
        _json(final / "fingering_candidates.json", {"existing_core_candidates": str(joint.candidates_json)})
        _json(final / "accompaniment_reductions.json", [{"window_id": w.window_id, "level": w.reduction_level, "reasons": w.reasons} for w in accompaniment_windows])
        shutil.copy2(joint.tab_musicxml, intermediate / "melody_with_accompaniment.musicxml")
        register_data = json.loads(joint.register_key_report_json.read_text(encoding="utf-8"))
        diagnostic_data = json.loads(joint.arrangement_diagnostics_json.read_text(encoding="utf-8"))
        octave_repair_warnings = [
            item for item in diagnostic_data.get("warnings", []) if "octave-normalized" in item
        ]
        selected_core = register_data["selected"]
        selected_register = {
            "register": selected_core["label"],
            "key_semitones": selected_core["key_semitones"],
            "octave_shift": selected_core["octave_shift"],
            "total_semitones": selected_core["key_semitones"] + selected_core["octave_shift"],
            "eligible": selected_core["eligible"],
            "playable_windows": selected_core["total_windows"],
            "warning": None,
        }
        retention_data = build_accompaniment_retention_diagnostics(
            accompaniment_windows,
            joint_candidates_json=joint.candidates_json,
            arrangement_diagnostics_json=joint.arrangement_diagnostics_json,
            final_review_json=joint.fingering_review_json,
            runtime_timing_json=register / "existing_core" / "debug" / "17_runtime_timing.json",
            final_tab=joint.tab_musicxml,
        )
        retention_json, retention_md = write_accompaniment_retention_diagnostics(
            retention_data,
            summary / "accompaniment_retention_diagnostics.json",
            summary / "accompaniment_retention_diagnostics.md",
        )
    except Exception as exc:
        # v0.13.5.13.3: no automatic whole-song downgrade and no export-side
        # musical recovery.  Any failure here belongs to Arrangement/Joint/Fingering
        # or a true hard rule, not to an observer/serializer repair layer.
        raise RuntimeError(
            "AUTO_ARRANGEMENT_FAILED_NO_WHOLE_SONG_FALLBACK: " + str(exc)
        ) from exc
    register_review = write_register_review(summary / "register_review.md", joint_report=joint_report, warning=warning)
    retention_json = locals().get("retention_json")
    retention_md = locals().get("retention_md")
    _json(register / "register_candidates.json", package.diagnostic_metadata)
    _json(register / "transposition_candidates.json", {"order": [0, -12, 12, -1, 1, -2, 2, -3, 3, -5, 5, -7, 7]})
    _json(register / "selected_register.json", selected_register)
    # v0.13.5.12.6.1: retain the merged v0.13.5.12.5 freeze monitors and then
    # generate observer-only diagnostic scores + progressive GPT workflow packet.
    # These readers consume already-written artifacts and never alter arrangement,
    # fingering, Joint selection, or exporter decisions.
    try:
        run_diagnostics_freeze(out)
        workflow_outputs = run_score_workflow(out)
        _json(summary / "diagnostic_score_workflow_outputs.json", workflow_outputs)
    except Exception as diagnostic_exc:
        _json(summary / "diagnostic_monitor_warning.json", {
            "version": VERSION, "status": "WARNING", "message": str(diagnostic_exc),
            "policy": "monitoring is observer-only and may not fail conversion",
        })

    try:
        write_engineer_debug_summary(out)
    except Exception as engineer_summary_exc:
        _json(summary / "engineer_debug_summary_warning.json", {
            "version": VERSION, "status": "WARNING", "message": str(engineer_summary_exc),
            "policy": "engineer summary is observer-only and may not fail conversion",
        })

    # V7.3 final public-export boundary: every Melody monitor above has now run
    # against the unsanitized canonical P2 TAB.  Only the public final copy is
    # stripped of GSTE-private tracing text/attributes.
    public_sanitize = sanitize_public_musicxml(final / "final_tab.musicxml")
    _json(summary / "public_export_sanitizer.json", {
        "version": VERSION, "status": "PASS", **public_sanitize,
        "semantics": "Sanitized only after retention/integrity/observer diagnostics completed.",
    })

    (summary / "conversion_summary.md").write_text(
        f"# GSTE {VERSION} Conversion Summary\n\n"
        f"- Input: {source.name}\n- Mode: melody auto-arrangement / canonical-intent unified Guitar core\n- Key: {progression.selected_key.name}\n"
        f"- Progression: {' | '.join(progression.selected_chords)}\n- Pattern: {pattern}\n"
        f"- Effective patterns: {', '.join(sorted({window.pattern for window in accompaniment_windows}))}\n"
        f"- Melody integrity: absolute pitch and rhythm hard-locked after global/phrase planning\n"
        f"- Single-note octave relocation allowed: no\n"
        f"- Core fallback: {'yes' if warning else 'no'}\n",
        encoding="utf-8",
    )
    return AutoArrangementOutputs(out, final / "final_tab.musicxml", chord_review, accompaniment_review, register_review, chord_xml, accompaniment_xml, retention_json, retention_md)
