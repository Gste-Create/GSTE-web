"""v0.12 compatibility facade using the shared guitar arrangement core."""
from gste.arrangement.guitar.service import build_melody_arrangement_plan

SUPPORTED_PATTERNS = (
    "auto", "root", "root_guide", "bass_chord", "bass_inner",
    "reduced_arpeggio", "arpeggio",
)


def generate_accompaniment(progression, pattern: str = "auto"):
    if pattern not in SUPPORTED_PATTERNS:
        raise ValueError(f"Unsupported accompaniment pattern: {pattern}")
    return build_melody_arrangement_plan(progression, pattern).selected_windows


__all__ = ["SUPPORTED_PATTERNS", "generate_accompaniment"]
