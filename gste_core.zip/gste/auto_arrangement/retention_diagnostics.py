from __future__ import annotations
from gste.version import VERSION

from collections import Counter, defaultdict
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from .domain import AccompanimentWindow
from gste.arrangement.importance import parse_auto_importance, parse_auto_role
from gste.exporter.canonical_tab_reader import parse_musicxml_root, canonical_tab_part, is_canonical_tab_note

_MARKER = "GSTE_ACCOMPANIMENT"
_GSTE_META_NS = "https://gste.local/musicxml/metadata"


def _gste_attr(name: str) -> str:
    return f"{{{_GSTE_META_NS}}}{name}"


def _is_generated_accompaniment(note: ET.Element) -> bool:
    """Accept canonical Final metadata first, with legacy marker fallback."""
    if (note.get(_gste_attr("generated-accompaniment")) or "").strip().lower() == "true":
        return True
    return any(
        (node.text or "").strip() == _MARKER
        for node in note.findall("notations/technical/other-technical")
    )


def _pct(num: int | float, den: int | float) -> float:
    return 0.0 if not den else round(float(num) * 100.0 / float(den), 1)


def _load_json(path: str | Path | None) -> dict:
    if not path:
        return {}
    p = Path(path)
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _selected_joint_rows(candidate_json: dict) -> list[dict]:
    rows: list[dict] = []
    for window in candidate_json.get("windows", []):
        selected = [row for row in window.get("candidates", []) if row.get("selected")]
        if not selected:
            continue
        # A few signatures can be marked selected more than once.  The first
        # diagnostic rank is the canonical representative for retention stats.
        selected.sort(key=lambda row: row.get("diagnostic_rank", 10**9))
        row = dict(selected[0])
        row["window_id"] = window.get("window_id")
        rows.append(row)
    return rows


def _functional_points_from_ids(event_ids) -> tuple[float, dict[str, int]]:
    points = 0.0
    roles: Counter[str] = Counter()
    for event_id in event_ids:
        imp = parse_auto_importance(str(event_id))
        role = parse_auto_role(str(event_id)) or "unmarked"
        roles[role] += 1
        points += float(imp if imp is not None else 50) / 100.0
    return round(points, 3), dict(roles)


def _final_export_stats(path: str | Path) -> dict:
    root = parse_musicxml_root(path)
    tab_part = canonical_tab_part(root)

    total = open_count = fretted_count = 0
    measures_with_accompaniment: set[int] = set()
    per_measure: Counter[int] = Counter()
    event_ids: list[str] = []
    functional_meta: list[tuple[int | None, str | None]] = []
    for measure in tab_part.findall("measure"):
        try:
            measure_no = int(measure.get("number", "0").split(".", 1)[0])
        except ValueError:
            measure_no = 0
        for note in measure.findall("note"):
            # Final 15.7.6+ contains two visible notation lanes, but only TAB
            # staff 2 is authoritative playback.  Never count the silent
            # Standard display twin, and identify accompaniment from canonical
            # GSTE metadata rather than presentation/part names.
            if not is_canonical_tab_note(note, tab_part, root):
                continue
            if not _is_generated_accompaniment(note):
                continue
            event_id = (
                note.get(_gste_attr("event-id"))
                or note.findtext("notations/other-notation[@type='gste-event-id']")
            )
            if event_id:
                event_ids.append(event_id.strip())
            imp_text = (
                note.get(_gste_attr("importance"))
                or note.findtext("notations/other-notation[@type='gste-importance']")
            )
            role_text = (
                note.get(_gste_attr("arrangement-role"))
                or note.findtext("notations/other-notation[@type='gste-arrangement-role']")
            )
            try:
                explicit_imp = int(imp_text) if imp_text is not None else None
            except ValueError:
                explicit_imp = None
            functional_meta.append((explicit_imp, role_text))
            if note.find("rest") is not None:
                continue
            fret_text = note.findtext("notations/technical/fret")
            if fret_text is None:
                continue
            try:
                fret = int(float(fret_text))
            except ValueError:
                continue
            total += 1
            per_measure[measure_no] += 1
            measures_with_accompaniment.add(measure_no)
            if fret == 0:
                open_count += 1
            else:
                fretted_count += 1
    if any(imp is not None or role for imp, role in functional_meta):
        functional_points = round(sum(float(imp if imp is not None else 50) / 100.0 for imp, _ in functional_meta), 3)
        functional_roles = dict(Counter((role or "unmarked") for _, role in functional_meta))
    else:
        functional_points, functional_roles = _functional_points_from_ids(event_ids)
    return {
        "accompaniment_notes": total,
        "open_string_notes": open_count,
        "fretted_notes": fretted_count,
        "open_string_note_pct": _pct(open_count, total),
        "fretted_note_pct": _pct(fretted_count, total),
        "measures_with_accompaniment": len(measures_with_accompaniment),
        "per_measure_note_count": dict(sorted(per_measure.items())),
        "event_ids": sorted(set(event_ids)),
        "functional_points": functional_points,
        "functional_roles": functional_roles,
    }


def build_accompaniment_retention_diagnostics(
    windows: tuple[AccompanimentWindow, ...],
    *,
    joint_candidates_json: str | Path,
    arrangement_diagnostics_json: str | Path,
    final_review_json: str | Path | None,
    runtime_timing_json: str | Path | None,
    final_tab: str | Path,
) -> dict:
    generated_events = sum(len(window.events) for window in windows)
    patterns = Counter(window.pattern for window in windows)
    densities = Counter(window.density for window in windows)
    reductions = Counter(window.reduction_level for window in windows)
    reason_counts = Counter(reason for window in windows for reason in window.reasons)
    generated_event_roles = Counter(event.role for window in windows for event in window.events)
    root_only_windows = sum(1 for window in windows if window.pattern == "root")

    candidate_json = _load_json(joint_candidates_json)
    selected_rows = _selected_joint_rows(candidate_json)
    joint_notes = sum(len(row.get("accompaniment", [])) for row in selected_rows)
    joint_open = sum(
        1 for row in selected_rows for note in row.get("accompaniment", [])
        if int(note.get("fret", 0)) == 0
    )
    joint_fretted = joint_notes - joint_open
    candidate_types = Counter(row.get("candidate_type", "UNKNOWN") for row in selected_rows)
    modification_counts = Counter(mod for row in selected_rows for mod in row.get("modifications", []))
    pruned_role_counts = Counter(role for row in selected_rows for role in row.get("pruned_roles", []))
    joint_notes_by_window = {
        row.get("window_id"): len(row.get("accompaniment", [])) for row in selected_rows
    }

    arrangement_diag = _load_json(arrangement_diagnostics_json)
    filter_totals = Counter()
    first_zero_stage = Counter()
    for row in arrangement_diag.get("windows", []):
        for key in (
            "raw_candidates", "after_string_conflict", "after_fret_span",
            "after_stretch", "after_sustain_conflict", "after_dp_transition",
        ):
            filter_totals[key] += int(row.get(key, 0) or 0)
        if row.get("first_zero_stage"):
            first_zero_stage[row["first_zero_stage"]] += 1

    final_stats = _final_export_stats(final_tab)
    final_review = _load_json(final_review_json)
    runtime = _load_json(runtime_timing_json)

    # Window-level generated -> selected loss.  IDs align for the current
    # melody-auto arrangement pipeline and are diagnostic only.
    generated_by_window = {window.window_id: len(window.events) for window in windows}
    window_losses = []
    for window in windows:
        before = generated_by_window[window.window_id]
        after = joint_notes_by_window.get(window.window_id)
        if after is None:
            continue
        window_losses.append({
            "window_id": window.window_id,
            "generated_notes": before,
            "joint_selected_notes": after,
            "delta": after - before,
            "pattern": window.pattern,
            "density": window.density,
            "generation_reduction_level": window.reduction_level,
            "generation_reasons": list(window.reasons),
        })

    generated_ids = {event.event_id for window in windows for event in window.events}
    generated_role_by_id = {event.event_id: event.role for window in windows for event in window.events}
    joint_ids = {
        str(note.get("source_event_id"))
        for row in selected_rows for note in row.get("accompaniment", [])
        if note.get("source_event_id")
    } & generated_ids
    final_ids = set(final_stats.get("event_ids", [])) & generated_ids
    lost_at_joint = generated_ids - joint_ids
    lost_after_joint = joint_ids - final_ids
    lifecycle = {
        "generated_ids": len(generated_ids),
        "joint_selected_ids": len(joint_ids),
        "final_serialized_ids": len(final_ids),
        "lost_at_joint_ids": len(lost_at_joint),
        "lost_after_joint_ids": len(lost_after_joint),
        "lost_at_joint_by_role": dict(Counter(generated_role_by_id.get(i, "unknown") for i in lost_at_joint)),
        "lost_after_joint_by_role": dict(Counter(generated_role_by_id.get(i, "unknown") for i in lost_after_joint)),
        "lost_at_joint_event_ids": sorted(lost_at_joint),
        "lost_after_joint_event_ids": sorted(lost_after_joint),
        "reason_codes": {
            "joint": "EVENT_ID_NOT_CONTINUOUS_THROUGH_JOINT_REVOICING",
            "post_joint": "EVENT_ID_NOT_CONTINUOUS_AFTER_JOINT",
        },
        "metric_status": "DEBUG_ONLY_NOT_A_RETENTION_KPI",
    }

    recommendations: list[dict] = []
    root_pct = _pct(root_only_windows, len(windows))
    joint_retention = _pct(joint_notes, generated_events)
    final_retention = _pct(final_stats["accompaniment_notes"], generated_events)

    # Metric Semantics v2: these names are intentionally explicit and remain
    # stable across future candidate-ID/register changes.  Arrangement -> Joint
    # values are *ratios/coverage* because Joint may select a different-sized or
    # revoiced candidate.  Only Joint -> Final is called retention.
    arrangement_function_points = round(sum(float(event.importance) / 100.0 for window in windows for event in window.events), 3)
    joint_source_ids = [
        str(note.get("source_event_id"))
        for row in selected_rows for note in row.get("accompaniment", [])
        if note.get("source_event_id")
    ]
    joint_notes_data=[n for row in selected_rows for n in row.get("accompaniment", [])]
    joint_function_roles=dict(Counter(n.get("arrangement_role") or n.get("role") or "unmarked" for n in joint_notes_data))
    joint_function_points=round(sum(float(n.get("importance") if n.get("importance") is not None else 50)/100. for n in joint_notes_data),3)
    if joint_notes_data and not any("importance" in n or "arrangement_role" in n for n in joint_notes_data):
        # Read-only compatibility for archived reports. Current writers always
        # include typed fields; no musical algorithm uses ID inference.
        joint_function_points,joint_function_roles=_functional_points_from_ids(joint_source_ids)
    final_function_points = float(final_stats.get("functional_points", 0.0) or 0.0)
    stable_kpis = {
        "metric_semantics_version": "2.0",
        "arrangement_reference_note_count": generated_events,
        "joint_selected_note_count": joint_notes,
        "final_sounding_note_count": final_stats["accompaniment_notes"],
        "arrangement_to_joint_note_count_ratio_pct": _pct(joint_notes, generated_events),
        "arrangement_to_final_note_count_ratio_pct": _pct(final_stats["accompaniment_notes"], generated_events),
        "joint_to_final_note_count_retention_pct": _pct(final_stats["accompaniment_notes"], joint_notes),
        "arrangement_reference_function_points": arrangement_function_points,
        "joint_selected_function_points": joint_function_points,
        "final_sounding_function_points": round(final_function_points, 3),
        "arrangement_to_joint_functional_coverage_pct": _pct(joint_function_points, arrangement_function_points),
        "arrangement_to_final_functional_coverage_pct": _pct(final_function_points, arrangement_function_points),
        "joint_to_final_functional_retention_pct": _pct(final_function_points, joint_function_points),
        "joint_function_roles": joint_function_roles,
        "final_function_roles": final_stats.get("functional_roles", {}),
    }
    open_pct = final_stats["open_string_note_pct"]
    arpeggio_pct = _pct(patterns.get("arpeggio", 0), len(windows))
    recovery_seconds = runtime.get("export_validation_recovery_seconds")
    total_seconds = runtime.get("total_seconds")
    recovery_pct = (
        round(float(recovery_seconds) * 100.0 / float(total_seconds), 1)
        if isinstance(recovery_seconds, (int, float)) and isinstance(total_seconds, (int, float)) and total_seconds
        else None
    )

    if root_pct >= 45:
        recommendations.append({
            "priority": "HIGH", "area": "ARRANGEMENT_GENERATION",
            "finding": f"Root-only windows are {root_pct}% of generated texture.",
            "v0.12.7_direction": "Add intermediate textures such as ROOT_PLUS_GUIDE_TONE, BASS_PLUS_INNER_VOICE and REDUCED_ARPEGGIO; do not map high melody density directly to root-only.",
        })
    if joint_retention < 75:
        recommendations.append({
            "priority": "HIGH", "area": "JOINT_RETENTION",
            "finding": f"Only {joint_retention}% of generated accompaniment-note count remains in the selected joint candidates.",
            "v0.12.7_direction": "Add accompaniment revoicing / alternate voicing candidates before pruning or dropping tones.",
        })
    if open_pct >= 45:
        recommendations.append({
            "priority": "MEDIUM", "area": "OPEN_STRING_TEXTURE",
            "finding": f"{open_pct}% of final accompaniment notes are open strings.",
            "v0.12.7_direction": "Add a soft repeated-open-string texture cost and prefer nearby fretted chord tones when playability is similar; keep open strings legal.",
        })
    if arpeggio_pct < 15:
        recommendations.append({
            "priority": "MEDIUM", "area": "TEXTURE_DIVERSITY",
            "finding": f"Arpeggio windows are only {arpeggio_pct}% of generated windows.",
            "v0.12.7_direction": "Use graded density classes and phrase-level texture continuity so medium/high density does not collapse abruptly to root-only.",
        })
    if recovery_pct is not None and recovery_pct >= 20:
        recommendations.append({
            "priority": "MEDIUM", "area": "PERFORMANCE",
            "finding": f"Export validation/recovery consumes {recovery_pct}% of total runtime.",
            "v0.12.7_direction": "Keep richer-arrangement candidate growth bounded and profile local export recovery before increasing candidate breadth.",
        })
    if not recommendations:
        recommendations.append({
            "priority": "LOW", "area": "BASELINE",
            "finding": "No diagnostic threshold was exceeded.",
            "v0.12.7_direction": "Use musical listening tests and per-window diagnostics to choose the next texture feature.",
        })

    return {
        "version": VERSION,
        "metric_semantics_version": "2.0",
        "metric_contract": {
            "primary_quality_kpis": "stable_kpis",
            "joint_to_final_retention": "Actual accompaniment note/function quantity surviving from selected Joint state to final sounding MusicXML.",
            "arrangement_to_joint_ratio": "Ratio/coverage only, not identity retention: Joint may choose a differently sized/revoiced candidate.",
            "event_identity_continuity": "Debug only; source_event_id may legitimately change during Joint revoicing.",
            "legacy_metric_policy": "Old retention_vs_generated fields are preserved for historical scripts but must not be compared as primary retention across semantic versions.",
        },
        "stable_kpis": stable_kpis,
        "diagnostic_only": False,
        "output_behavior_changed": True,
        "generation": {
            "windows": len(windows),
            "events": generated_events,
            "patterns": dict(patterns),
            "pattern_pct": {key: _pct(value, len(windows)) for key, value in patterns.items()},
            "densities": dict(densities),
            "reduction_levels": {str(k): v for k, v in reductions.items()},
            "event_roles": dict(generated_event_roles),
            "root_only_windows": root_only_windows,
            "root_only_window_pct": root_pct,
            "reasons": dict(reason_counts),
        },
        "joint_selected": {
            "windows_with_selected_candidate": len(selected_rows),
            "accompaniment_notes": joint_notes,
            "retention_vs_generated_pct": joint_retention,
            "open_string_notes": joint_open,
            "fretted_notes": joint_fretted,
            "open_string_note_pct": _pct(joint_open, joint_notes),
            "candidate_types": dict(candidate_types),
            "modifications": dict(modification_counts),
            "pruned_roles": dict(pruned_role_counts),
        },
        "candidate_filtering": {
            **dict(filter_totals),
            "first_zero_stage": dict(first_zero_stage),
        },
        "joint_rejection_audit": arrangement_diag.get("joint_rejection_audit", {}),
        "event_lifecycle": lifecycle,
        "final_export": {
            **final_stats,
            "retention_vs_generated_pct": final_retention,
            "retention_vs_joint_selected_pct": _pct(final_stats["accompaniment_notes"], joint_notes),
        },
        "final_review": final_review.get("counts", {}),
        "runtime": {**runtime, "export_validation_recovery_pct": recovery_pct},
        "window_stage_comparison": window_losses,
        "v0.12.7_recommendations": recommendations,
    }


def write_accompaniment_retention_diagnostics(data: dict, json_path: str | Path, md_path: str | Path) -> tuple[Path, Path]:
    json_output = Path(json_path)
    md_output = Path(md_path)
    json_output.parent.mkdir(parents=True, exist_ok=True)
    md_output.parent.mkdir(parents=True, exist_ok=True)
    json_output.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    gen = data["generation"]
    joint = data["joint_selected"]
    final = data["final_export"]
    runtime = data["runtime"]
    lines = [
        f"# GSTE {VERSION} Accompaniment Retention Diagnostics",
        "",
        "> Metric Semantics v2. Primary KPIs use note counts and functional information. ArrangementEventID continuity is debug-only because legal Joint revoicing may change IDs.",
        "",
        "## Stage summary",
        "",
        "| Stage | Accompaniment notes | Retention vs generated | Open-string share |",
        "|---|---:|---:|---:|",
        f"| Arrangement generation | {gen['events']} | 100.0% | n/a (no string assignment yet) |",
        f"| Joint selected candidates | {joint['accompaniment_notes']} | {joint['retention_vs_generated_pct']:.1f}% | {joint['open_string_note_pct']:.1f}% |",
        f"| Final serialized MusicXML | {final['accompaniment_notes']} | {final['retention_vs_generated_pct']:.1f}% | {final['open_string_note_pct']:.1f}% |",
        "",
        "## Stable KPI schema — Metric Semantics v2",
        "",
        f"- Arrangement reference notes: **{data['stable_kpis']['arrangement_reference_note_count']}**",
        f"- Joint selected notes: **{data['stable_kpis']['joint_selected_note_count']}**",
        f"- Final sounding notes: **{data['stable_kpis']['final_sounding_note_count']}**",
        f"- Joint → Final note-count retention: **{data['stable_kpis']['joint_to_final_note_count_retention_pct']:.1f}%**",
        f"- Joint → Final functional retention: **{data['stable_kpis']['joint_to_final_functional_retention_pct']:.1f}%**",
        f"- Arrangement → Joint note-count ratio (not identity retention): **{data['stable_kpis']['arrangement_to_joint_note_count_ratio_pct']:.1f}%**",
        f"- Arrangement → Joint functional coverage: **{data['stable_kpis']['arrangement_to_joint_functional_coverage_pct']:.1f}%**",
        "",
        "## Generated texture",
        "",
        f"- Windows: **{gen['windows']}**",
        f"- Root-only: **{gen['root_only_windows']} ({gen['root_only_window_pct']:.1f}%)**",
    ]
    for name in sorted(gen["patterns"]):
        lines.append(f"- {name}: **{gen['patterns'][name]} ({gen['pattern_pct'].get(name, 0):.1f}%)**")
    lines += ["", "### Generation reasons", ""]
    for reason, count in sorted(gen["reasons"].items(), key=lambda item: (-item[1], item[0])):
        lines.append(f"- {count} × {reason}")

    lines += [
        "", "## Joint fingering retention", "",
        f"- Selected accompaniment notes: **{joint['accompaniment_notes']}**",
        f"- Fretted / open: **{joint['fretted_notes']} / {joint['open_string_notes']}**",
        f"- Retention vs generated: **{joint['retention_vs_generated_pct']:.1f}%**",
        "", "### Candidate modifications", "",
    ]
    for name, count in sorted(joint["modifications"].items(), key=lambda item: (-item[1], item[0])):
        lines.append(f"- {count} × {name}")
    if not joint["modifications"]:
        lines.append("- None recorded")
    lines += ["", "### Pruned tone roles", ""]
    for name, count in sorted(joint["pruned_roles"].items(), key=lambda item: (-item[1], item[0])):
        lines.append(f"- {count} × {name}")
    if not joint["pruned_roles"]:
        lines.append("- None recorded")

    lines += [
        "", "## Final export", "",
        f"- Final accompaniment notes: **{final['accompaniment_notes']}**",
        f"- Final retention vs generated: **{final['retention_vs_generated_pct']:.1f}%**",
        f"- Final retention vs joint selected: **{final['retention_vs_joint_selected_pct']:.1f}%**",
        f"- Open-string notes: **{final['open_string_notes']} ({final['open_string_note_pct']:.1f}%)**",
        f"- Fretted notes: **{final['fretted_notes']} ({final['fretted_note_pct']:.1f}%)**",
        f"- Measures containing generated accompaniment: **{final['measures_with_accompaniment']}**",
        "", "## ArrangementEventID continuity (DEBUG ONLY — not retention)", "",
        f"- Generated IDs: **{data['event_lifecycle']['generated_ids']}**",
        f"- Joint-selected IDs: **{data['event_lifecycle']['joint_selected_ids']}**",
        f"- Final serialized IDs: **{data['event_lifecycle']['final_serialized_ids']}**",
        f"- Lost at Joint selection: **{data['event_lifecycle']['lost_at_joint_ids']}**",
        f"- Lost after Joint selection: **{data['event_lifecycle']['lost_after_joint_ids']}**",
        "", "## Runtime", "",
        f"- Total: **{runtime.get('total_seconds', 'n/a')} s**",
        f"- Export validation/recovery: **{runtime.get('export_validation_recovery_seconds', 'n/a')} s**",
        f"- Export validation/recovery share: **{runtime.get('export_validation_recovery_pct', 'n/a')}%**",
        "", "## v0.13.5.12.4 decision hints", "",
    ]
    for item in data["v0.12.7_recommendations"]:
        lines.extend([
            f"### {item['priority']} — {item['area']}", "",
            f"- Finding: {item['finding']}",
            f"- Direction: {item['v0.12.7_direction']}", "",
        ])

    lines += [
        "## Window comparison",
        "",
        "| Window | Pattern | Density | Generated | Joint selected | Delta |",
        "|---|---|---|---:|---:|---:|",
    ]
    for row in data["window_stage_comparison"]:
        lines.append(
            f"| {row['window_id']} | {row['pattern']} | {row['density']} | {row['generated_notes']} | {row['joint_selected_notes']} | {row['delta']:+d} |"
        )
    lines.append("")
    md_output.write_text("\n".join(lines), encoding="utf-8")
    return json_output, md_output
