"""Isolated melody auto-arrangement feature maintained in GSTE_Beta_V0.1.3."""

from .pipeline import AutoArrangementOutputs, run_melody_auto_arrangement

__all__ = ["AutoArrangementOutputs", "run_melody_auto_arrangement"]
