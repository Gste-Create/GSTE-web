from __future__ import annotations

from gste.version import VERSION

from pathlib import Path

from .domain import AccompanimentWindow, ChordProgressionResult


def write_chord_review(result: ChordProgressionResult, path: str | Path) -> Path:
    output = Path(path); output.parent.mkdir(parents=True, exist_ok=True)
    average = sum(w.confidence for w in result.window_results) / len(result.window_results)
    lines = [
        f"# GSTE {VERSION} 和弦挑選審查",
        "",
        "## 摘要",
        "",
        "- 輸入模式：僅主旋律",
        f"- 推斷調性：{result.selected_key.name}",
        f"- 調性信心：{result.selected_key.confidence:.0%}",
        f"- 和弦窗口：{len(result.window_results)}",
        f"- 最終進程：{' | '.join(result.selected_chords)}",
        f"- 平均和弦信心：{average:.0%}",
        f"- 低信心窗口：{', '.join(result.low_confidence_windows) or '無'}",
        "",
        "## 調性候選",
        "",
        "| 排名 | 調性 | 分數 | 信心 | 來源 | 警告 |",
        "|---:|---|---:|---:|---|---|",
    ]
    for i, key in enumerate(result.key_candidates, 1):
        lines.append(f"| {i} | {key.name} | {key.score:.3f} | {key.confidence:.0%} | {key.source} | {'; '.join(key.warnings) or '—'} |")
    lines += ["", "## 每窗口候選", "", "| 位置 | 旋律重點音 | 採用 | 候選二 | 候選三 | 信心 | 採用原因 |", "|---|---|---|---|---|---:|---|"]
    for item in result.window_results:
        candidates = list(item.candidates) + [item.selected] * 3
        notes = ", ".join(str(pc) for pc, _ in sorted(item.window.weighted_pitch_classes.items(), key=lambda x: -x[1])[:4]) or "休止"
        lines.append(f"| M{item.window.measure_start} B{item.window.beat_start:g} | {notes} | {item.selected.chord_symbol} | {candidates[1].chord_symbol} | {candidates[2].chord_symbol} | {item.confidence:.0%} | {'; '.join(item.selected.reasons)} |")
    lines += ["", "## 候選分數明細", ""]
    for item in result.window_results:
        lines += [f"### {item.window.window_id}（採用 {item.selected.chord_symbol}）", "", "| 候選 | 旋律 | 強拍 | 長音 | 調性 | 轉移 | 終止 | 複雜度 | 總成本 |", "|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
        for c in item.candidates:
            lines.append(f"| {c.chord_symbol} | {c.melody_fit_score:.1f} | {c.strong_beat_score:.1f} | {c.long_note_score:.1f} | {c.key_score:.1f} | {c.transition_cost:.1f} | {c.cadence_cost:.1f} | {c.complexity_cost:.1f} | {c.total_cost:.1f} |")
        lines.append("")
    output.write_text("\n".join(lines), encoding="utf-8")
    return output


def write_accompaniment_review(windows: tuple[AccompanimentWindow, ...], path: str | Path) -> Path:
    output = Path(path); output.parent.mkdir(parents=True, exist_ok=True)
    lines = [f"# GSTE {VERSION} 伴奏審查", "", "Auto 模式會逐窗口選擇模板；固定模式保留供人工控制與診斷。", "", "| 窗口 | 實際模板 | 旋律密度 | 事件 | 降階 | 原因 |", "|---|---|---|---|---:|---|"]
    for window in windows:
        event_text = ", ".join(f"{e.role}:{e.pitch}@{e.onset:g}" for e in window.events)
        lines.append(f"| {window.window_id} | {window.pattern} | {window.density} | {event_text} | {window.reduction_level} | {'; '.join(window.reasons) or '—'} |")
    lines += ["", "Texture Ladder：Full Arpeggio → Reduced Arpeggio → Bass + Inner Voice → Root + Guide Tone → Root Only → Rest。指法層優先 revoice，再必要時局部降階；主旋律永遠是硬條件。", ""]
    output.write_text("\n".join(lines), encoding="utf-8")
    return output


def write_register_review(path: str | Path, *, joint_report: Path | None, warning: str | None = None) -> Path:
    output = Path(path); output.parent.mkdir(parents=True, exist_ok=True)
    lines = [f"# GSTE {VERSION} 音域與移調審查", "", "- 搜尋順序：原音高 → 降八度 → 升八度 → ±1、±2、±3、±5、±7 半音", "- 採用條件：只有弦位、可演奏率或旋律／伴奏分離明顯改善才改變原調。"]
    if joint_report:
        lines.append(f"- 既有核心詳細報告：`{joint_report.name}`")
    if warning:
        lines.append(f"- 警告：{warning}")
    lines.append("")
    output.write_text("\n".join(lines), encoding="utf-8")
    return output
