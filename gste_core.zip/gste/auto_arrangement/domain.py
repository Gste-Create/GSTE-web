"""Compatibility exports for v0.12.x import paths.

v0.13.1 moves arrangement-domain ownership to :mod:`gste.arrangement.models`.
Existing callers remain supported while the old package is gradually retired.
"""
from gste.arrangement.models.domain import *  # noqa: F401,F403
