"""Compatibility facade for the v0.13 arrangement-layer config."""
from gste.arrangement.auto.config import *  # noqa: F401,F403
