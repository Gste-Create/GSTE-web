VERSION = "0.4 beta"
APP_NAME = "GSTE V0.4 beta"
