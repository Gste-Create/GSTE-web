"""v0.11 compatibility note.

All operational defaults remain at their original call sites so this refactor
does not alter parameter values, evaluation order, or generated output.
"""
