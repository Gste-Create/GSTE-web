"""Playback-expression parameters for final MusicXML serialization.

This module intentionally owns *only* performance loudness.  It must never
change pitch, rhythm, harmony, texture, candidate selection, or fingering.
Values are expressed as target MIDI Note-On velocities (1..127).  The exporter
converts them to MusicXML's note-level ``dynamics`` percentage where 100 means
MIDI forte velocity 90.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class VelocityProfile:
    # Role baselines: melody must remain perceptually in front of accompaniment.
    melody: int = 96
    bass: int = 64
    accompaniment: int = 54

    # Beat accents are deliberately small.  A strong beat should create pulse,
    # not make a multi-note accompaniment mask the melody.
    melody_strong_beat_bonus: int = 4
    bass_strong_beat_bonus: int = 2
    accompaniment_strong_beat_bonus: int = 1
    secondary_beat_bonus: int = 1

    # Safety bounds for MIDI playback.
    minimum: int = 1
    maximum: int = 127


DEFAULT_VELOCITY_PROFILE = VelocityProfile()

# Accompaniment tone roles that act primarily as the bass foundation.
BASS_TONE_ROLES = frozenset({"source_bass", "root", "root_doubling"})
