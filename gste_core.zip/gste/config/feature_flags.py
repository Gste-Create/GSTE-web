"""Public release feature gates.

Keep future routes present at a narrow boundary without exposing incomplete
behaviour to the public Melody/Piano release.  Do not use this module for
musical policy; it is only for product-surface availability.
"""

PUBLIC_ENSEMBLE_ENABLED = True
