"""Configuration namespace reserved for future non-breaking configuration work."""
