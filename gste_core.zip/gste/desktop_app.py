from __future__ import annotations

from gste.version import VERSION

from gste.version import APP_NAME

import os
import shutil
import subprocess
import sys
import threading
import traceback
import tkinter as tk
from pathlib import Path
from gste.exporter.privacy_safe_debug_report import write_privacy_safe_failure_report
from tkinter import filedialog, messagebox, ttk

from gste.conversion_service import ConversionRequest, run_conversion
from gste.core.tuning import resolve_tuning
from gste.pipeline.ensemble_priority import EnsemblePriorityTrack, arrange_ensemble_priority, FIXED_PRIORITY_WEIGHTS
from gste.config.feature_flags import PUBLIC_ENSEMBLE_ENABLED

MODE_DUAL = "dual"
MODE_MELODY = "melody"
MODE_ENSEMBLE = "ensemble"
ENSEMBLE_FAMILIES = ("GUITAR", "BASS")

TEXT = {
    "zh_TW": {
        "language": "語言", "subtitle": "主旋律／雙手鋼琴譜／實驗性團譜 MusicXML → 指彈吉他 TAB",
        "input_mode": "輸入模式", "dual": "雙手譜", "melody": "僅主旋律", "ensemble": "團譜（實驗）",
        "melody_file": "主旋律／右手", "left_file": "左手／伴奏", "choose": "選擇", "output_folder": "輸出資料夾",
        "open_output": "開啟輸出資料夾", "open_score": "開啟完成樂譜", "convert": "開始轉換", "select_xml": "選擇 MusicXML", "select_output": "選擇輸出資料夾",
        "all_files": "所有檔案", "initial": "請選擇輸入 MusicXML。", "dual_status": "雙手譜模式：選擇主旋律／右手與左手／伴奏檔。",
        "melody_status": "僅主旋律模式：可選擇自動生成伴奏或只轉換主旋律指法。", "accompaniment_mode": "伴奏模式", "auto_generated": "自動生成伴奏", "none": "不添加伴奏",
        "ensemble_status": "團譜實驗模式：主旋律檔 + 最多四個伴奏樂器軌；請為每軌指定樂器角色。",
        "ensemble_frame": "團譜伴奏樂器軌（角色權重固定；實驗模式）", "priority": "軌 {n}", "fixed": "角色權重",
        "ensemble_hint": "每軌依樂器角色套用固定Harmony/Bass/Texture/Rhythm權重。團譜功能仍屬實驗性，音樂性保留度須人工確認。",
        "missing_prefix": "請重新選擇：", "missing_melody": "主旋律／右手檔", "missing_left": "左手／伴奏檔", "missing_ensemble": "至少一個團譜伴奏軌",
        "missing_priority": "軌 {n}伴奏檔", "converting": "轉換中，請勿關閉程式……", "success": "轉換完成：{path}",
        "success_box": "轉換完成。\n\n完成樂譜：{path}\n\n詳細診斷資料已收納於 debug 資料夾。", "failed_status": "轉換失敗，請檢查輸入檔案。", "failed_box": "轉換失敗：\n\n{detail}",
        "trace": "完整錯誤記錄：{path}", "dual_required": "雙手譜模式必須選擇左手／伴奏 MusicXML。",
        "ensemble_disabled": "團譜功能已保留於程式架構中，但 Beta V0.1 暫不開放。", "ensemble_required": "團譜模式至少需要一個伴奏軌。",
        "unsupported": "不支援的輸入模式：{mode}", "editor": "編曲索引",
    },
    "ja": {'language': '言語', 'subtitle': 'メロディー／ピアノ両手譜／実験的なアンサンブル MusicXML → フィンガースタイルギター TAB', 'input_mode': '入力モード', 'dual': 'ピアノ両手譜', 'melody': 'メロディーのみ', 'ensemble': 'アンサンブル（実験）', 'melody_file': 'メロディー／右手', 'left_file': '左手／伴奏', 'choose': '参照', 'output_folder': '出力フォルダー', 'open_output': '出力フォルダーを開く', 'open_score': '完成した楽譜を開く', 'convert': '変換開始', 'select_xml': 'MusicXML を選択', 'select_output': '出力フォルダーを選択', 'all_files': 'すべてのファイル', 'initial': '入力する MusicXML を選択してください。', 'dual_status': 'ピアノ両手譜：メロディー／右手と左手／伴奏のファイルを選択してください。', 'melody_status': 'メロディーのみ：自動伴奏を生成するか、メロディーの運指のみを変換します。', 'accompaniment_mode': '伴奏モード', 'auto_generated': '伴奏を自動生成', 'none': '伴奏なし', 'ensemble_status': 'アンサンブル実験モード：メロディーと最大4つの伴奏トラックを選び、楽器の役割を指定してください。', 'ensemble_frame': 'アンサンブル伴奏トラック（役割の重みは固定・実験モード）', 'priority': 'トラック {n}', 'fixed': '役割の重み', 'ensemble_hint': '各トラックには楽器の役割に応じた固定のHarmony/Bass/Texture/Rhythm重みが適用されます。アンサンブル変換機能は引き続き実験段階にあり、音楽的な再現度は人の手で確認する必要があります。', 'missing_prefix': '再選択してください：', 'missing_melody': 'メロディー／右手ファイル', 'missing_left': '左手／伴奏ファイル', 'missing_ensemble': '少なくとも1つの伴奏トラック', 'missing_priority': 'トラック {n} の伴奏ファイル', 'converting': '変換中です。アプリを閉じないでください…', 'success': '変換完了：{path}', 'success_box': '変換が完了しました。\n\n完成した楽譜：{path}\n\n詳細な診断情報は debug フォルダーに保存されています。', 'failed_status': '変換に失敗しました。入力ファイルを確認してください。', 'failed_box': '変換失敗：\n\n{detail}', 'trace': '完全なエラーログ：{path}', 'dual_required': 'ピアノ両手譜モードでは左手／伴奏の MusicXML が必要です。', 'ensemble_disabled': 'アンサンブル機能は内部に残されていますが、現在は利用できません。', 'ensemble_required': 'アンサンブルモードには少なくとも1つの伴奏トラックが必要です。', 'unsupported': '未対応の入力モード：{mode}', 'editor': '編曲リファレンス'},
    "en": {
        "language": "Language", "subtitle": "Melody / two-hand piano / experimental ensemble MusicXML → fingerstyle guitar TAB",
        "input_mode": "Input mode", "dual": "Two-hand piano", "melody": "Melody only", "ensemble": "Ensemble (experimental)",
        "melody_file": "Melody / right hand", "left_file": "Left hand / accompaniment", "choose": "Browse", "output_folder": "Output folder",
        "open_output": "Open output folder", "open_score": "Open finished score", "convert": "Convert", "select_xml": "Select MusicXML", "select_output": "Select output folder",
        "all_files": "All files", "initial": "Select an input MusicXML file.", "dual_status": "Two-hand mode: select the melody/right-hand and left-hand/accompaniment files.",
        "melody_status": "Melody-only mode: choose automatic accompaniment or melody fingering only.", "accompaniment_mode": "Accompaniment mode", "auto_generated": "Auto-generated accompaniment", "none": "No accompaniment",
        "ensemble_status": "Experimental ensemble mode: select a melody file plus up to four accompaniment instrument tracks and assign each role.",
        "ensemble_frame": "Ensemble accompaniment tracks (fixed role weights; experimental)", "priority": "Track {n}", "fixed": "Role weight",
        "ensemble_hint": "Each track uses fixed Harmony/Bass/Texture/Rhythm weights based on its instrument role. Ensemble conversion remains experimental; the degree of musical preservation must be reviewed manually.",
        "missing_prefix": "Please select again: ", "missing_melody": "melody/right-hand file", "missing_left": "left-hand/accompaniment file", "missing_ensemble": "at least one ensemble accompaniment track",
        "missing_priority": "priority {n} accompaniment file", "converting": "Converting. Please do not close GSTE…", "success": "Conversion complete: {path}",
        "success_box": "Conversion complete.\n\nFinished score: {path}\n\nDetailed diagnostics are stored in the debug folder.", "failed_status": "Conversion failed. Check the input files.", "failed_box": "Conversion failed:\n\n{detail}",
        "trace": "Full error log: {path}", "dual_required": "Two-hand mode requires a left-hand/accompaniment MusicXML file.",
        "ensemble_disabled": "Ensemble input remains in the architecture but is unavailable in Beta V0.1.", "ensemble_required": "Ensemble mode requires at least one accompaniment track.",
        "unsupported": "Unsupported input mode: {mode}", "editor": "Arrangement Reference",
    },
}


def _open_folder(path: Path) -> None:
    if sys.platform == "win32": os.startfile(path)  # type: ignore[attr-defined]
    elif sys.platform == "darwin": subprocess.Popen(["open", str(path)])
    else: subprocess.Popen(["xdg-open", str(path)])



def _new_run_dir(base: Path, source: Path) -> Path:
    """Create one self-contained user-facing folder per conversion."""
    base.mkdir(parents=True, exist_ok=True)
    stem = source.stem.replace(" ", "_") or "score"
    candidate = base / f"{stem}_GSTE"
    if not candidate.exists():
        candidate.mkdir(parents=True)
        return candidate
    index = 2
    while True:
        candidate = base / f"{stem}_GSTE_{index}"
        if not candidate.exists():
            candidate.mkdir(parents=True)
            return candidate
        index += 1


def _organize_beta_output(run_dir: Path, final_path: Path, mode: str) -> Path:
    """Keep the user surface small while preserving every engineering artifact."""
    final_user = run_dir / "GSTE_TAB.musicxml"
    if final_path.resolve() != final_user.resolve():
        shutil.copy2(final_path, final_user)

    debug_dir = run_dir / "debug"
    pipeline_dir = debug_dir / "pipeline_output"
    pipeline_dir.mkdir(parents=True, exist_ok=True)

    keep = {"GSTE_TAB.musicxml", "CONVERSION_REPORT.md", "ERROR_REPORT.md", "HUMAN_REVIEW_REPORT.md", "debug"}
    for item in list(run_dir.iterdir()):
        if item.name in keep:
            continue
        target = pipeline_dir / item.name
        if target.exists():
            if target.is_dir(): shutil.rmtree(target)
            else: target.unlink()
        shutil.move(str(item), str(target))

    # Surface only the privacy-safe report for easy user sharing; keep full diagnostics under debug/.
    safe_candidates = list(pipeline_dir.rglob("PRIVACY_SAFE_DEBUG_REPORT.md"))
    if safe_candidates:
        shutil.copy2(safe_candidates[0], run_dir / "PRIVACY_SAFE_DEBUG_REPORT.md")
    safe_json = list(pipeline_dir.rglob("PRIVACY_SAFE_DEBUG_REPORT.json"))
    if safe_json:
        shutil.copy2(safe_json[0], debug_dir / "PRIVACY_SAFE_DEBUG_REPORT.json")

    mode_label = "Piano / two-hand" if mode == MODE_DUAL else "Melody only" if mode == MODE_MELODY else "Ensemble"
    (run_dir / "CONVERSION_REPORT.md").write_text(
        f"# GSTE {VERSION} Conversion Report\n\n"
        "- Status: SUCCESS\n"
        f"- Input mode: {mode_label}\n"
        "- Finished score: `GSTE_TAB.musicxml`\n\n"
        "The conversion completed and the finished score was generated.\n"
        "Please review the score manually before performance, publication, or redistribution.\n\n"
        "For normal use, you only need `GSTE_TAB.musicxml` and this report.\n"
        "Engineering diagnostics are stored in `debug/` and normally do not need to be read.\n",
        encoding="utf-8",
    )
    return final_user


def _write_beta_error(run_dir: Path, detail: str, trace: str, mode: str | None = None) -> Path:
    debug_dir = run_dir / "debug"
    debug_dir.mkdir(parents=True, exist_ok=True)
    trace_path = debug_dir / "ERROR_TRACEBACK.txt"
    trace_path.write_text(trace, encoding="utf-8")
    pipeline_dir = debug_dir / "pipeline_output"
    pipeline_dir.mkdir(parents=True, exist_ok=True)
    for item in list(run_dir.iterdir()):
        if item.name == "debug":
            continue
        target = pipeline_dir / item.name
        if target.exists():
            if target.is_dir(): shutil.rmtree(target)
            else: target.unlink()
        shutil.move(str(item), str(target))
    write_privacy_safe_failure_report(run_dir, error_type="ConversionError", input_mode=mode)
    report = run_dir / "ERROR_REPORT.md"
    report.write_text(
        f"# GSTE {VERSION} Error Report\n\n"
        "- Status: FAILED\n"
        f"- Error: {detail}\n"
        "- Full traceback: `debug/ERROR_TRACEBACK.txt`\n\n"
        "For normal issue reporting, share `PRIVACY_SAFE_DEBUG_REPORT.md` first.\n"
        "Do not share the full `debug/` folder when the score or project is confidential.\n",
        encoding="utf-8",
    )
    from gste.user_reports import write_user_reports
    write_user_reports(run_dir, success=False, detail=detail)
    return report


def run_dual_arrangement(melody: Path, left_hand: Path, output_dir: Path) -> Path:
    return run_conversion(ConversionRequest(kind="piano", melody=melody, left_hand=left_hand, output_dir=output_dir)).tab_musicxml


def run_melody_arrangement(melody: Path, output_dir: Path, accompaniment_mode: str = "AUTO_GENERATED") -> Path:
    return run_conversion(ConversionRequest(kind="melody", melody=melody, output_dir=output_dir, accompaniment_mode=accompaniment_mode)).tab_musicxml


def run_ensemble_arrangement(melody: Path, tracks: tuple[EnsemblePriorityTrack, ...], output_dir: Path) -> Path:
    # Ensemble uses the same public conversion/package authority as Piano and Melody.
    return run_conversion(ConversionRequest(kind="ensemble", melody=melody, output_dir=output_dir, ensemble_tracks=tracks)).tab_musicxml


def run_arrangement(mode: str, melody: Path, output_dir: Path, left_hand: Path | None = None, ensemble_tracks: tuple[EnsemblePriorityTrack, ...] = (), accompaniment_mode: str = "AUTO_GENERATED") -> Path:
    if mode == MODE_MELODY: return run_melody_arrangement(melody, output_dir, accompaniment_mode)
    if mode == MODE_DUAL:
        if left_hand is None: raise ValueError(TEXT["zh_TW"]["dual_required"])
        return run_dual_arrangement(melody, left_hand, output_dir)
    if mode == MODE_ENSEMBLE:
        if not PUBLIC_ENSEMBLE_ENABLED: raise ValueError(TEXT["zh_TW"]["ensemble_disabled"])
        if not ensemble_tracks: raise ValueError(TEXT["zh_TW"]["ensemble_required"])
        return run_ensemble_arrangement(melody, ensemble_tracks, output_dir)
    raise ValueError(TEXT["zh_TW"]["unsupported"].format(mode=mode))


class GsteApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_NAME); self.geometry("860x680"); self.minsize(780, 620)
        self.language_var = tk.StringVar(value="繁體中文")
        self.melody_var = tk.StringVar(); self.left_var = tk.StringVar(); self.mode_var = tk.StringVar(value=MODE_DUAL); self.accompaniment_mode_var = tk.StringVar(value="AUTO_GENERATED")
        self.output_var = tk.StringVar(value=str(Path.home() / "Documents" / "GSTE_Output")); self.status_var = tk.StringVar()
        self.last_tab_path: Path | None = None
        self.ensemble_path_vars = [tk.StringVar() for _ in range(4)]
        self.ensemble_family_vars = [tk.StringVar(value=v) for v in ("GUITAR", "GUITAR", "BASS", "GUITAR")]
        self._build_ui(); self._refresh_language()

    @property
    def lang(self): return {"繁體中文":"zh_TW", "English":"en", "日本語":"ja"}.get(self.language_var.get(), "zh_TW")
    def t(self, key, **kwargs): return TEXT[self.lang][key].format(**kwargs)

    def _build_ui(self) -> None:
        root=ttk.Frame(self,padding=22); root.pack(fill="both",expand=True); root.columnconfigure(1,weight=1); self.root_frame=root
        self.title_label=ttk.Label(root,text=APP_NAME,font=("Segoe UI",18,"bold")); self.title_label.grid(row=0,column=0,columnspan=2,sticky="w",pady=(0,8))
        self.language_label=ttk.Label(root); self.language_label.grid(row=0,column=2,sticky="e",padx=(10,6))
        self.language_combo=ttk.Combobox(root,textvariable=self.language_var,state="readonly",values=("繁體中文","English","日本語"),width=12)
        self.language_combo.grid(row=0,column=3,sticky="e"); self.language_combo.bind("<<ComboboxSelected>>",lambda _e:self._refresh_language())
        self.subtitle_label=ttk.Label(root); self.subtitle_label.grid(row=1,column=0,columnspan=4,sticky="w",pady=(0,18))
        self.mode_frame=ttk.LabelFrame(root,padding=(12,8)); self.mode_frame.grid(row=2,column=0,columnspan=4,sticky="ew",pady=(0,12))
        self.mode_buttons=[]
        for value in (MODE_DUAL,MODE_MELODY,MODE_ENSEMBLE):
            b=ttk.Radiobutton(self.mode_frame,variable=self.mode_var,value=value,command=self._mode_changed)
            if value==MODE_ENSEMBLE and not PUBLIC_ENSEMBLE_ENABLED: b.state(["disabled"])
            b.pack(side="left",padx=(0,18)); self.mode_buttons.append((b,value))
        self.melody_label,self.melody_entry,self.melody_button=self._file_row(root,3,self.melody_var)
        self.left_label,self.left_entry,self.left_button=self._file_row(root,4,self.left_var)
        self.accompaniment_mode_frame=ttk.LabelFrame(root,padding=(12,8)); self.accompaniment_mode_frame.grid(row=5,column=0,columnspan=4,sticky="ew",pady=(4,12))
        self.accompaniment_mode_buttons=[]
        for value in ("AUTO_GENERATED", "NONE"):
            b=ttk.Radiobutton(self.accompaniment_mode_frame, variable=self.accompaniment_mode_var, value=value)
            b.pack(side="left",padx=(0,18)); self.accompaniment_mode_buttons.append((b,value))
        self.ensemble_frame=ttk.LabelFrame(root,padding=(12,8)); self.ensemble_frame.grid(row=6,column=0,columnspan=4,sticky="ew",pady=(4,12)); self.ensemble_frame.columnconfigure(2,weight=1)
        self.ensemble_widgets=[]
        for i,(path_var,family_var) in enumerate(zip(self.ensemble_path_vars,self.ensemble_family_vars),start=1):
            pl=ttk.Label(self.ensemble_frame); pl.grid(row=i-1,column=0,sticky="w",padx=(0,8),pady=4)
            fam=ttk.Combobox(self.ensemble_frame,textvariable=family_var,state="readonly",values=ENSEMBLE_FAMILIES,width=16); fam.grid(row=i-1,column=1,sticky="w",padx=(0,8),pady=4)
            entry=ttk.Entry(self.ensemble_frame,textvariable=path_var); entry.grid(row=i-1,column=2,sticky="ew",padx=(0,8),pady=4)
            button=ttk.Button(self.ensemble_frame,command=lambda v=path_var:self._choose_xml(v)); button.grid(row=i-1,column=3,pady=4)
            hint=ttk.Label(self.ensemble_frame); hint.grid(row=i-1,column=4,sticky="w",padx=(8,0)); self.ensemble_widgets.append((pl,fam,entry,button,hint,i))
        self.ensemble_hint=ttk.Label(self.ensemble_frame,wraplength=740); self.ensemble_hint.grid(row=4,column=0,columnspan=5,sticky="w",pady=(8,0))
        self.output_label=ttk.Label(root); self.output_label.grid(row=7,column=0,sticky="w",pady=8)
        ttk.Entry(root,textvariable=self.output_var).grid(row=7,column=1,columnspan=2,sticky="ew",padx=10,pady=8)
        self.output_button=ttk.Button(root,command=self._choose_output); self.output_button.grid(row=7,column=3,pady=8)
        self.progress=ttk.Progressbar(root,mode="indeterminate"); self.progress.grid(row=8,column=0,columnspan=4,sticky="ew",pady=(18,8))
        ttk.Label(root,textvariable=self.status_var,wraplength=760).grid(row=9,column=0,columnspan=4,sticky="w",pady=(0,16))
        actions=ttk.Frame(root); actions.grid(row=10,column=0,columnspan=4,sticky="e")
        self.open_score_button=ttk.Button(actions,command=self._open_score); self.open_score_button.pack(side="left",padx=(0,10)); self.open_score_button.state(["disabled"])
        self.open_button=ttk.Button(actions,command=self._open_output); self.open_button.pack(side="left",padx=(0,10))
        self.editor_button=ttk.Button(actions,command=self._open_editor); self.editor_button.pack(side="left",padx=(0,10))
        self.convert_button=ttk.Button(actions,command=self._start); self.convert_button.pack(side="left")

    def _open_editor(self):
        from gste.editor.gui import ArrangementEditor
        context = self.last_tab_path.parent / "GSTE_EDITOR_CONTEXT.json" if self.last_tab_path else None
        ArrangementEditor(self, context if context and context.exists() else None, language=self.language_var)

    def _file_row(self,parent,row,variable):
        label=ttk.Label(parent); label.grid(row=row,column=0,sticky="w",pady=8)
        entry=ttk.Entry(parent,textvariable=variable); entry.grid(row=row,column=1,columnspan=2,sticky="ew",padx=10,pady=8)
        button=ttk.Button(parent,command=lambda:self._choose_xml(variable)); button.grid(row=row,column=3,pady=8)
        return label,entry,button

    def _refresh_language(self):
        self.title(APP_NAME); self.language_label.config(text=self.t("language")); self.subtitle_label.config(text=self.t("subtitle")); self.mode_frame.config(text=self.t("input_mode"))
        for b,value in self.mode_buttons: b.config(text=self.t({MODE_DUAL:"dual",MODE_MELODY:"melody",MODE_ENSEMBLE:"ensemble"}[value]))
        self.melody_label.config(text=self.t("melody_file")); self.left_label.config(text=self.t("left_file")); self.melody_button.config(text=self.t("choose")); self.left_button.config(text=self.t("choose"))
        self.accompaniment_mode_frame.config(text=self.t("accompaniment_mode"))
        for b,value in self.accompaniment_mode_buttons: b.config(text=self.t("auto_generated" if value=="AUTO_GENERATED" else "none"))
        self.ensemble_frame.config(text=self.t("ensemble_frame")); self.ensemble_hint.config(text=self.t("ensemble_hint"))
        for pl,_fam,_entry,button,hint,i in self.ensemble_widgets: pl.config(text=self.t("priority",n=i)); button.config(text=self.t("choose")); hint.config(text=self.t("fixed",n=i))
        self.output_label.config(text=self.t("output_folder")); self.output_button.config(text=self.t("choose")); self.open_score_button.config(text=self.t("open_score")); self.open_button.config(text=self.t("open_output")); self.convert_button.config(text=self.t("convert")); self.editor_button.config(text=self.t("editor")); self._mode_changed()

    def _mode_changed(self):
        mode=self.mode_var.get(); dual=mode==MODE_DUAL; ensemble=mode==MODE_ENSEMBLE and PUBLIC_ENSEMBLE_ENABLED
        self.left_entry.state(["!disabled"] if dual else ["disabled"]); self.left_button.state(["!disabled"] if dual else ["disabled"])
        for b,_value in self.accompaniment_mode_buttons: b.state(["!disabled"] if mode==MODE_MELODY else ["disabled"])
        for _pl,fam,entry,button,_hint,_i in self.ensemble_widgets:
            fam.configure(state="readonly" if ensemble else "disabled"); entry.state(["!disabled"] if ensemble else ["disabled"]); button.state(["!disabled"] if ensemble else ["disabled"])
        self.status_var.set(self.t("dual_status" if dual else "melody_status" if mode==MODE_MELODY else "ensemble_status"))

    def _choose_xml(self,variable):
        selected=filedialog.askopenfilename(title=self.t("select_xml"),filetypes=[("MusicXML","*.musicxml *.xml"),(self.t("all_files"),"*.*")])
        if selected: variable.set(selected)
    def _choose_output(self):
        selected=filedialog.askdirectory(title=self.t("select_output"));
        if selected: self.output_var.set(selected)
    def _open_output(self):
        output=Path(self.output_var.get()).expanduser(); output.mkdir(parents=True,exist_ok=True); _open_folder(output)
    def _open_score(self):
        if self.last_tab_path and self.last_tab_path.is_file():
            if sys.platform == "win32": os.startfile(self.last_tab_path)  # type: ignore[attr-defined]
            else: _open_folder(self.last_tab_path.parent)
    def _ensemble_tracks(self):
        tracks=[]
        for i,(path_var,family_var) in enumerate(zip(self.ensemble_path_vars,self.ensemble_family_vars),start=1):
            raw=path_var.get().strip()
            if raw: tracks.append(EnsemblePriorityTrack(Path(raw),family_var.get(),i))
        return tuple(tracks)
    def _start(self):
        melody=Path(self.melody_var.get()); left_hand=Path(self.left_var.get()) if self.left_var.get() else None; output=Path(self.output_var.get()).expanduser(); mode=self.mode_var.get()
        ensemble_tracks=self._ensemble_tracks() if (mode==MODE_ENSEMBLE and PUBLIC_ENSEMBLE_ENABLED) else (); missing=[]
        if not melody.is_file(): missing.append(self.t("missing_melody"))
        if mode==MODE_DUAL and (left_hand is None or not left_hand.is_file()): missing.append(self.t("missing_left"))
        if mode==MODE_ENSEMBLE:
            if not ensemble_tracks: missing.append(self.t("missing_ensemble"))
            for item in ensemble_tracks:
                if not item.path.is_file(): missing.append(self.t("missing_priority",n=item.priority))
        if missing: messagebox.showerror(APP_NAME,self.t("missing_prefix")+"、".join(missing) if self.lang=="zh_TW" else self.t("missing_prefix")+", ".join(missing)); return
        self.convert_button.state(["disabled"]); self.progress.start(12); self.status_var.set(self.t("converting"))
        threading.Thread(target=self._convert_worker,args=(mode,melody,left_hand,ensemble_tracks,output,self.accompaniment_mode_var.get(),self.lang),daemon=True).start()
    def _convert_worker(self,mode,melody,left_hand,ensemble_tracks,output,accompaniment_mode,report_language):
        run_dir = _new_run_dir(output, melody)
        try:
            tab_path = run_arrangement(mode,melody,run_dir,left_hand,ensemble_tracks,accompaniment_mode)
        except Exception as exc:
            report = _write_beta_error(run_dir, str(exc), traceback.format_exc(), mode=mode)
            self._present_reports(run_dir, report_language)
            self.after(0,self._finish_error,f"{exc}\n\n{self.t('trace',path=report)}")
        else:
            self._present_reports(run_dir, report_language)
            self.after(0,self._finish_success,tab_path)
    @staticmethod
    def _present_reports(run_dir, language):
        try:
            from gste.report_presentation import render_reports
            render_reports(run_dir, language=language)
        except Exception:
            # Presentation must never restart or invalidate conversion.
            pass

    def _finish_success(self,tab_path):
        self.last_tab_path=Path(tab_path); self.open_score_button.state(["!disabled"]); self.progress.stop(); self.convert_button.state(["!disabled"]); self.status_var.set(self.t("success",path=tab_path)); messagebox.showinfo(APP_NAME,self.t("success_box",path=tab_path))
    def _finish_error(self,detail):
        self.progress.stop(); self.convert_button.state(["!disabled"]); self.status_var.set(self.t("failed_status")); messagebox.showerror(APP_NAME,self.t("failed_box",detail=detail))


def main(): GsteApp().mainloop()
if __name__ == "__main__": main()
