from __future__ import annotations

from dataclasses import replace

from gste.core.tuning import STANDARD_TUNING, Tuning
from gste.fingering_review.local_reoptimizer import hard_issues
from gste.fingering_review.repair_planner import repair_issue, try_accompaniment_simplification
from gste.fingering_review.review_models import ReviewConfig, ReviewResult
from gste.fingering_review.smoothing import smooth_isolated_positions, smooth_local_hand_comfort
from gste.fingering_review.span_validator import detect_risky_four_fret_spans
from gste.joint_arrangement.models import JointArrangementResult


EXPORT_BLOCKING_JOINT_ISSUES = {
    "MELODY_ACCOMPANIMENT_FRET_DISTANCE",
    "ACTIVE_STRING_OCCUPANCY",
    "DIRECTIONAL_SIMULTANEOUS_FRET_SPAN",
    "BARRE_FRET_SPAN",
    "BARRE_INTERNAL_STRING_RELEASE",
    "BARRE_INTERNAL_LOWER_FRET",
}


def _span_at(result: JointArrangementResult, onset: float) -> int:
    frets = [
        note.fret
        for state in result.selected
        for notes in (state.melody.notes, state.accompaniment.notes)
        for note in notes
        if note.fret > 0 and note.note.start <= onset + 1e-6
        and note.note.start + note.note.duration > onset + 1e-6
    ]
    return max(frets) - min(frets) if frets else 0


def _melody_signature(result: JointArrangementResult):
    return tuple(sorted(
        (n.note.source_event_id, n.note.pitch.midi, n.note.start, n.note.duration)
        for state in result.selected for n in state.melody.notes
    ))


def review_final_fingering(
    score: JointArrangementResult, *, tuning: Tuning = STANDARD_TUNING,
    config: ReviewConfig | None = None,
) -> ReviewResult:
    """v0.12.6.10 three-stage final joint fingering review.

    Pass 1 rebuilds the full sounding hand from the first attack to the last,
    including sustained notes, and repairs physical hard-rule violations.
    Pass 2 looks across the local two-measure position trend and smooths isolated
    excursions. Pass 3 evaluates legal-but-uncomfortable shapes using current
    span plus previous/following position gaps, preferring neighboring-string
    same-pitch relocation. A final hard validation is always run after smoothing.
    """
    config = config or ReviewConfig()
    before_signature = _melody_signature(score)
    current = score
    recorded = []
    attempted_signatures: set[tuple] = set()

    # Pass 1: full-score physical validation and local repair.
    cached_issues = hard_issues(current, config.onset_tolerance, config.maximum_fret_span)
    pass_limit = min(config.maximum_passes, max(4, len(cached_issues) * 2 + 4))
    for _ in range(pass_limit):
        issues = cached_issues
        if not issues:
            break
        issue = issues[0]
        signature = (issue.key, _span_at(current, issue.onset))
        if signature in attempted_signatures:
            recorded.append(issue)
            break
        attempted_signatures.add(signature)
        repaired = repair_issue(current, issue, tuning, config)
        if repaired is None and not config.strict:
            repaired = try_accompaniment_simplification(current, issue, config.maximum_fret_span)
        if repaired is None:
            recorded.append(issue)
            break
        current, status, description = repaired
        validation = hard_issues(current, config.onset_tolerance, config.maximum_fret_span)
        cached_issues = validation
        remaining_match = next((i for i in validation if i.key == issue.key), None)
        recorded.append(replace(
            issue, status=status, repair=description,
            final_value=(remaining_match.final_value if remaining_match else _span_at(current, issue.onset)),
        ))

    remaining = tuple(hard_issues(current, config.onset_tolerance, config.maximum_fret_span))

    # Pass 2: cosmetic/playability smoothing is allowed only after physical
    # legality is established. It never changes melody pitch, rhythm or count.
    smoothing_issues = ()
    smoothing_remaining = ()
    if not remaining:
        current, isolated_fixed, isolated_remaining = smooth_isolated_positions(
            current, tuning=tuning, maximum_fret=config.maximum_fret,
            maximum_repairs=config.maximum_passes,
        )
        current, comfort_fixed, comfort_remaining = smooth_local_hand_comfort(
            current, tuning=tuning, maximum_fret=config.maximum_fret,
            maximum_repairs=config.maximum_passes,
        )
        smoothing_issues = tuple(isolated_fixed) + tuple(comfort_fixed)
        smoothing_remaining = tuple(isolated_remaining) + tuple(comfort_remaining)
        remaining = tuple(hard_issues(current, config.onset_tolerance, config.maximum_fret_span))

    after_signature = _melody_signature(current)
    if after_signature != before_signature:
        raise ValueError("Final fingering review changed melody pitch, rhythm, count, or source identity")

    if config.strict and remaining:
        names = ", ".join(issue.issue_type for issue in remaining)
        raise ValueError(f"Strict final fingering review blocked TAB export: {names}")
    blocking = [issue for issue in remaining if issue.issue_type in EXPORT_BLOCKING_JOINT_ISSUES]
    if blocking:
        names = ", ".join(issue.issue_type for issue in blocking)
        raise ValueError(f"v0.13.3 blocked TAB export with unresolved joint playability (physical): {names}")

    advisories = tuple(detect_risky_four_fret_spans(current, config.onset_tolerance))
    return ReviewResult(
        current, tuple(recorded), remaining, before_signature, after_signature,
        advisories, smoothing_issues, smoothing_remaining,
    )


def validate_final_fingering_hard_rules(
    score: JointArrangementResult, *, config: ReviewConfig | None = None, melody_backbone=None,
) -> ReviewResult:
    """v0.13.5.12.10.1 validation-only final hand gate.

    The arrangement/fingering engines own musical changes.  This final layer
    only verifies the frozen hard hand rules and never repairs, smooths,
    revoices, deletes accompaniment, or changes melody realization.
    """
    config = config or ReviewConfig()
    signature = _melody_signature(score)
    issues = tuple(hard_issues(score, config.onset_tolerance, config.maximum_fret_span, melody_backbone=melody_backbone))
    blocking = tuple(issue for issue in issues if issue.issue_type in EXPORT_BLOCKING_JOINT_ISSUES)
    if blocking:
        names = ", ".join(sorted({issue.issue_type for issue in blocking}))
        raise ValueError(f"FINAL_HAND_HARD_RULE_FAILED: {names}")
    advisories = tuple(detect_risky_four_fret_spans(score, config.onset_tolerance))
    return ReviewResult(
        score=score,
        issues=issues,
        remaining_issues=(),
        melody_signature_before=signature,
        melody_signature_after=signature,
        advisory_issues=advisories,
        smoothing_issues=(),
        smoothing_remaining=(),
    )
