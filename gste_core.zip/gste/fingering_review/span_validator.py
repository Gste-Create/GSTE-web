from __future__ import annotations

from collections import defaultdict

from gste.fingering_review.review_models import ReviewIssue
from gste.joint_arrangement.models import JointArrangementResult
from gste.fingering.canonical_validator import CanonicalHandNote, active_notes_at, validate_canonical_timeline


def _canonical_inventory(result: JointArrangementResult, melody_backbone=None):
    notes = []
    owners = []
    melody_timing = melody_backbone.by_id() if melody_backbone is not None else None
    for state_index, state in enumerate(result.selected):
        for role, candidates in (("melody", state.melody.notes), ("accompaniment", state.accompaniment.notes)):
            for note in candidates:
                if role == "melody" and melody_timing is not None:
                    event_id = str(note.note.source_event_id or "")
                    locked = melody_timing.get(event_id)
                    if locked is None:
                        raise ValueError(f"FINAL_LOCKED_TIMING_UNKNOWN_MELODY_EVENT:{event_id}")
                    start, end = float(locked.attack), float(locked.release)
                else:
                    start = float(note.note.start)
                    end = float(note.note.start + note.note.duration)
                notes.append(CanonicalHandNote(
                    role=role, string=note.string, fret=note.fret,
                    start=start, end=end,
                    pitch=note.note.pitch.midi, measure=state.measure,
                    source_id=note.note.source_event_id,
                ))
                owners.append((state_index, state, role, note))
    return tuple(notes), tuple(owners)


def _canonical_physical_issues(result: JointArrangementResult, tolerance: float = 1e-6, maximum_distance: int = 4, melody_backbone=None):
    notes, owners = _canonical_inventory(result, melody_backbone)
    issues = validate_canonical_timeline(notes, maximum_fret_distance=maximum_distance, tolerance=tolerance)
    out = []
    melody_timing = melody_backbone.by_id() if melody_backbone is not None else None
    for issue in issues:
        def _owner_active(o):
            role, note = o[2], o[3]
            if role == "melody" and melody_timing is not None:
                locked = melody_timing.get(str(note.note.source_event_id or ""))
                if locked is None:
                    return False
                start, end = float(locked.attack), float(locked.release)
            else:
                start, end = float(note.note.start), float(note.note.start + note.note.duration)
            return start <= issue.time + tolerance and end > issue.time + tolerance
        active_owners = [o for o in owners if _owner_active(o)]
        owner = next((o for o in active_owners if o[2] == "accompaniment"), active_owners[0] if active_owners else owners[0])
        state_index, state, _, _ = owner
        out.append((issue, state_index, state))
    return out


def onset_groups(result: JointArrangementResult, tolerance: float = 1e-6):
    """Return the complete sounding left-hand shape at every attack time.

    v0.12.6.7 keeps the full-score review but uses an incremental sweep rather
    than rescanning every note for every onset. Sustained notes are therefore
    still included without restoring the v0.12.6.3 performance problem.
    """
    all_entries: list[tuple[int, str, object]] = []
    for state_index, state in enumerate(result.selected):
        for role, notes in (("melody", state.melody.notes), ("accompaniment", state.accompaniment.notes)):
            all_entries.extend((state_index, role, note) for note in notes)
    all_entries.sort(key=lambda entry: (entry[2].note.start, entry[0], entry[1], entry[2].string))
    attacks = sorted({round(entry[2].note.start / tolerance) * tolerance for entry in all_entries})
    groups = []
    active: list[tuple[int, str, object]] = []
    cursor = 0
    for onset in attacks:
        active = [
            entry for entry in active
            if entry[2].note.start + entry[2].note.duration > onset + tolerance
        ]
        while cursor < len(all_entries) and all_entries[cursor][2].note.start <= onset + tolerance:
            entry = all_entries[cursor]
            if entry[2].note.start + entry[2].note.duration > onset + tolerance:
                active.append(entry)
            cursor += 1
        groups.append((onset, list(active)))
    return groups


def _snapshot_span(entries):
    fretted = [note for _, _, note in entries if note.fret > 0]
    if not fretted:
        return 0, 4, None, "empty_or_open"
    low = min(note.fret for note in fretted)
    high = max(note.fret for note in fretted)
    span = high - low
    highest_fret_string = min(note.string for note in fretted if note.fret == high)
    highest_sounding_string = min(note.string for note in fretted)
    lowest_sounding_string = max(note.string for note in fretted)
    if highest_fret_string == highest_sounding_string:
        return span, 4, highest_fret_string, "highest_string"
    if highest_fret_string == lowest_sounding_string:
        return span, 2, highest_fret_string, "lowest_string"
    return span, 3, highest_fret_string, "middle_string"


def detect_directional_simultaneous_spans(
    result: JointArrangementResult, tolerance: float = 1e-6, melody_backbone=None,
) -> list[ReviewIssue]:
    issues=[]
    for violation, state_index, state in _canonical_physical_issues(result, tolerance, melody_backbone=melody_backbone):
        if violation.violation_type not in {"SIMULTANEOUS_FRET_SPAN", "DIRECTIONAL_SIMULTANEOUS_FRET_SPAN"}:
            continue
        issues.append(ReviewIssue(
            "DIRECTIONAL_SIMULTANEOUS_FRET_SPAN", state.measure,
            violation.time - state.start + 1.0, violation.time, state_index,
            original_value=int(violation.span or 0), final_value=int(violation.span or 0),
            conflict_string=violation.highest_fret_string,
            repair=f"allowed_span={violation.allowed_span}; highest_fret_position={violation.position}",
        ))
    return issues


def detect_simultaneous_fret_spans(
    result: JointArrangementResult, tolerance: float = 1e-6, maximum_span: int = 3,
) -> list[ReviewIssue]:
    """Legacy generic span reporter retained for diagnostics/tests."""
    issues: list[ReviewIssue] = []
    for onset, entries in onset_groups(result, tolerance):
        frets = [note.fret for _, _, note in entries if note.fret > 0]
        if not frets or max(frets) - min(frets) <= maximum_span:
            continue
        state_index = entries[0][0]
        state = result.selected[state_index]
        issues.append(ReviewIssue(
            "SIMULTANEOUS_FRET_SPAN", state.measure, onset - state.start + 1.0,
            onset, state_index, original_value=max(frets) - min(frets),
            final_value=max(frets) - min(frets),
        ))
    return issues


def detect_risky_four_fret_spans(
    result: JointArrangementResult, tolerance: float = 1e-6,
) -> list[ReviewIssue]:
    """Only directionally legal four-fret shapes remain advisory in v0.12.6.7."""
    issues: list[ReviewIssue] = []
    for onset, entries in onset_groups(result, tolerance):
        span, allowed, highest_string, position = _snapshot_span(entries)
        if span != 4 or allowed != 4:
            continue
        state_index = entries[0][0]
        state = result.selected[state_index]
        issues.append(ReviewIssue(
            "SIMULTANEOUS_FRET_SPAN", state.measure, onset - state.start + 1.0,
            onset, state_index, original_value=4, final_value=4,
            conflict_string=highest_string,
            repair=f"directionally_legal_advisory; highest_fret_position={position}",
        ))
    return issues


def detect_melody_accompaniment_distances(
    result: JointArrangementResult, tolerance: float = 1e-6, maximum_distance: int = 4, melody_backbone=None,
) -> list[ReviewIssue]:
    issues=[]
    for violation, state_index, state in _canonical_physical_issues(result, tolerance, maximum_distance, melody_backbone=melody_backbone):
        if violation.violation_type != "MELODY_ACCOMPANIMENT_FRET_DISTANCE":
            continue
        issues.append(ReviewIssue(
            "MELODY_ACCOMPANIMENT_FRET_DISTANCE", state.measure,
            violation.time - state.start + 1.0, violation.time, state_index,
            original_value=int(violation.distance or 0), final_value=int(violation.distance or 0),
            conflict_string=violation.string,
        ))
    return issues


def detect_active_string_conflicts(
    result: JointArrangementResult, tolerance: float = 1e-6, melody_backbone=None,
) -> list[ReviewIssue]:
    issues=[]
    for violation, state_index, state in _canonical_physical_issues(result, tolerance, melody_backbone=melody_backbone):
        if violation.violation_type != "ACTIVE_STRING_OCCUPANCY":
            continue
        issues.append(ReviewIssue(
            "ACTIVE_STRING_OCCUPANCY", state.measure,
            violation.time - state.start + 1.0, violation.time, state_index,
            original_value=int(violation.span or 0), final_value=int(violation.span or 0),
            conflict_string=violation.string,
        ))
    return issues
