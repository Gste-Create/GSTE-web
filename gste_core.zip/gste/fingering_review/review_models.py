from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from gste.joint_arrangement.models import JointArrangementResult


class ReviewStatus(str, Enum):
    PASS = "PASS"
    AUTO_FIXED = "AUTO_FIXED"
    ACCOMPANIMENT_SIMPLIFIED = "ACCOMPANIMENT_SIMPLIFIED"
    LOCAL_REOPTIMIZED = "LOCAL_REOPTIMIZED"
    UNRESOLVED = "UNRESOLVED"


@dataclass(frozen=True)
class ReviewConfig:
    strict: bool = False
    onset_tolerance: float = 1e-6
    maximum_passes: int = 32
    maximum_fret: int = 18
    # v0.12.5.3 preserves the v0.12.4 playable boundary.  Four-fret shapes are
    # review risks, not automatic accompaniment-deletion failures; five-fret
    # and wider shapes remain hard violations.
    maximum_fret_span: int = 4


@dataclass(frozen=True)
class ReviewIssue:
    issue_type: str
    measure: int
    beat: float
    onset: float
    state_index: int
    original_value: int | None = None
    final_value: int | None = None
    barre_fret: int | None = None
    barre_strings: tuple[int, ...] = ()
    conflict_string: int | None = None
    required_fret: int | None = None
    status: ReviewStatus = ReviewStatus.UNRESOLVED
    repair: str = ""

    @property
    def key(self) -> tuple:
        return (self.issue_type, round(self.onset, 6), self.barre_fret, self.conflict_string)


@dataclass(frozen=True)
class ReviewResult:
    score: JointArrangementResult
    issues: tuple[ReviewIssue, ...]
    remaining_issues: tuple[ReviewIssue, ...]
    melody_signature_before: tuple[tuple[str | None, int, float, float], ...]
    melody_signature_after: tuple[tuple[str | None, int, float, float], ...]
    advisory_issues: tuple[ReviewIssue, ...] = ()
    smoothing_issues: tuple[ReviewIssue, ...] = ()
    smoothing_remaining: tuple[ReviewIssue, ...] = ()

    @property
    def passed(self) -> bool:
        return not self.remaining_issues and self.melody_signature_before == self.melody_signature_after

    @property
    def degraded(self) -> bool:
        return bool(self.remaining_issues) or any(
            issue.status == ReviewStatus.ACCOMPANIMENT_SIMPLIFIED for issue in self.issues
        )

    @property
    def outcome(self) -> str:
        if self.remaining_issues or self.melody_signature_before != self.melody_signature_after:
            return "FAIL"
        if any(issue.status == ReviewStatus.ACCOMPANIMENT_SIMPLIFIED for issue in self.issues):
            return "DEGRADED"
        if self.advisory_issues or self.smoothing_remaining:
            return "PASS_WITH_ADVISORIES"
        return "PASS"
