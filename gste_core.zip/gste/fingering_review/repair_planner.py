from __future__ import annotations

from dataclasses import replace

from gste.core.fretboard import midi_to_string_fret, position_block_for_fret
from gste.arrangement.importance import parse_auto_importance
from gste.fingering_review.local_reoptimizer import hard_issues, replace_window_from_candidate_layers
from gste.fingering_review.review_models import ReviewIssue, ReviewStatus
from gste.joint_arrangement.models import JointArrangementResult
from gste.joint_arrangement.optimizer import evaluate_transition


ACCOMPANIMENT_REMOVAL_COST = 1000.0
MELODY_RELOCATION_COST = 120.0
FRET_RELOCATION_COST = 3.0
HIGH_FRET_RELOCATION_COST = 10.0
HAND_CENTRE_SEPARATION_COST = 12.0


def _replace_note(result, state_index, role, old, new=None):
    states = list(result.selected)
    state = states[state_index]
    if role == "melody":
        notes = tuple(new if n == old else n for n in state.melody.notes)
        states[state_index] = replace(state, melody=replace(state.melody, notes=notes), finger_assignment=())
    else:
        indices = [i for i, n in enumerate(state.accompaniment.notes) if n != old]
        notes = tuple(state.accompaniment.notes[i] for i in indices)
        roles = tuple(state.accompaniment.tone_roles[i] for i in indices if i < len(state.accompaniment.tone_roles))
        if new is not None:
            notes = tuple(new if n == old else n for n in state.accompaniment.notes)
            roles = state.accompaniment.tone_roles
        output_bass = min((n.note.pitch.midi for n in notes), default=None)
        accompaniment = replace(
            state.accompaniment, notes=notes, tone_roles=roles, output_bass_pitch=output_bass,
            candidate_type="F_FINAL_REVIEW_REPAIR",
            modifications=(*state.accompaniment.modifications, "FINAL_REVIEW_REPAIR"),
            pruning_reasons=(*state.accompaniment.pruning_reasons, "final_fingering_review"),
        )
        states[state_index] = replace(state, accompaniment=accompaniment, finger_assignment=())
    return replace(result, selected=tuple(states))


def _issue_entries(result, issue):
    entries = []
    for state_index, state in enumerate(result.selected):
        for role, notes in (("melody", state.melody.notes), ("accompaniment", state.accompaniment.notes)):
            for note in notes:
                if (note.note.start <= issue.onset + 1e-6
                        and note.note.start + note.note.duration > issue.onset + 1e-6):
                    entries.append((state_index, role, note))
    return entries


def _transition_risk(result, state_index):
    risk = 0.0
    if state_index > 0:
        risk += evaluate_transition(result.selected[state_index - 1], result.selected[state_index])[0]
    if state_index + 1 < len(result.selected):
        risk += evaluate_transition(result.selected[state_index], result.selected[state_index + 1])[0]
    return risk


def _accompaniment_count(result, state_index):
    lo = max(0, state_index - 1)
    hi = min(len(result.selected), state_index + 2)
    return sum(len(state.accompaniment.notes) for state in result.selected[lo:hi])


def _fretted_centre(state):
    frets = sorted(
        note.fret
        for notes in (state.melody.notes, state.accompaniment.notes)
        for note in notes
        if note.fret > 0
    )
    if not frets:
        return 0.0
    middle = len(frets) // 2
    return float(frets[middle]) if len(frets) % 2 else (frets[middle - 1] + frets[middle]) / 2.0


def _local_shape_cost(result, state_index):
    """Score the complete previous/current/next hand window.

    Open strings are deliberately neutral: they release a finger but do not
    drag the left-hand centre towards fret zero.  What matters is whether the
    remaining fretted notes and the adjacent shapes become easier.
    """
    lo = max(0, state_index - 1)
    hi = min(len(result.selected), state_index + 2)
    centres = [_fretted_centre(state) for state in result.selected[lo:hi]]
    movement = sum(abs(a - b) for a, b in zip(centres, centres[1:]))
    separation = 0.0
    span = 0.0
    for state in result.selected[lo:hi]:
        melody = [n.fret for n in state.melody.notes if n.fret > 0]
        accompaniment = [n.fret for n in state.accompaniment.notes if n.fret > 0]
        all_frets = melody + accompaniment
        if all_frets:
            span += max(all_frets) - min(all_frets)
        if melody and accompaniment:
            separation += abs(sum(melody) / len(melody) - sum(accompaniment) / len(accompaniment))
    return 3.0 * movement + 8.0 * span + HAND_CENTRE_SEPARATION_COST * separation


def _repair_score(original, trial, state_index, role, old, new):
    """Lower is better; preserve orchestration before cosmetic comfort."""
    accompaniment_loss = max(
        0, _accompaniment_count(original, state_index) - _accompaniment_count(trial, state_index)
    )
    change_cost = ACCOMPANIMENT_REMOVAL_COST * accompaniment_loss
    if role == "melody":
        change_cost += MELODY_RELOCATION_COST
    if new is not None:
        change_cost += FRET_RELOCATION_COST * abs(new.fret - old.fret)
        # Do not send a low-position accompaniment to fret 8/12 merely to make
        # one instantaneous span report disappear.  An open-string equivalent
        # is legal and receives no automatic reward or punishment.
        if role == "accompaniment" and new.fret >= 8 and new.fret > old.fret:
            change_cost += HIGH_FRET_RELOCATION_COST * (new.fret - max(old.fret, 7))
    return change_cost + _local_shape_cost(trial, state_index) + _transition_risk(trial, state_index)


def _improves(result, trial, issue, maximum_span=4):
    """Require a repaired *complete score*, not a repaired isolated note.

    Candidate acceptance is lexicographic: fewer hard issues first, then a
    better previous/current/next transition.  A repair may never introduce a
    new issue elsewhere or leave the target issue hidden behind a zero value.
    """
    before = hard_issues(result, maximum_span=maximum_span)
    after = hard_issues(trial, maximum_span=maximum_span)
    if any(item.key == issue.key for item in after) or len(after) >= len(before):
        return False
    if {item.key for item in after} - {item.key for item in before}:
        return False
    touched = min(issue.state_index, len(trial.selected) - 1)
    # Accompaniment removal remains available only through the explicit,
    # last-resort simplifier.  Open strings are valid same-pitch positions and
    # are judged by the resulting complete three-shape window.
    if _accompaniment_count(trial, touched) < _accompaniment_count(result, touched):
        return False
    return _transition_risk(trial, touched) <= _transition_risk(result, touched) + 4.0


def try_same_pitch_relocation(
    result, issue, tuning, maximum_fret=18, maximum_span=4, *, accompaniment_only=False,
):
    entries = _issue_entries(result, issue)
    # Accompaniment is changed first. Melody fingering may move only afterwards.
    candidates = []
    for state_index, role, note in sorted(entries, key=lambda x: (x[1] == "melody", x[2].fret), reverse=False):
        if accompaniment_only and role != "accompaniment":
            continue
        occupied = {n.string for si, _, n in entries if si == state_index and n != note}
        for string, fret in midi_to_string_fret(note.note.pitch.midi, max_fret=maximum_fret, tuning=tuning):
            if string in occupied or (string, fret) == (note.string, note.fret):
                continue
            moved = replace(note, string=string, fret=fret, position_block=position_block_for_fret(fret))
            trial = _replace_note(result, state_index, role, note, moved)
            if _improves(result, trial, issue, maximum_span):
                candidates.append((
                    _repair_score(result, trial, state_index, role, note, moved),
                    role == "melody",
                    trial,
                    f"Moved {role} MIDI {note.note.pitch.midi} from string {note.string}/fret {note.fret} to string {string}/fret {fret}",
                ))
    if candidates:
        _, _, trial, message = min(candidates, key=lambda item: (item[1], item[0], item[3]))
        return trial, ReviewStatus.AUTO_FIXED, message
    return None


def try_accompaniment_simplification(result, issue, maximum_span=4):
    current = result
    entries = [entry for entry in _issue_entries(current, issue) if entry[1] == "accompaniment"]
    # V0.13.5.11: AUTO_MELODY carries Arrangement importance in the
    # source-event lineage. Final Review uses the same value before the legacy
    # role ladder. Piano/source notes have no marker and therefore preserve the
    # historical ordering unchanged.
    priority = {"root_doubling": 0, "fill": 1, "fifth": 2, "extension": 3, "third": 4, "root": 5, "source_bass": 6}
    ranked = []
    for state_index, role, note in entries:
        state = current.selected[state_index]
        try:
            idx = state.accompaniment.notes.index(note)
            tone_role = state.accompaniment.tone_roles[idx] if idx < len(state.accompaniment.tone_roles) else "fill"
        except ValueError:
            tone_role = "fill"
        auto_importance=note.note.importance
        ranked.append((auto_importance, priority.get(tone_role, 3), state_index, role, note, tone_role))
    for _, _, state_index, role, note, tone_role in sorted(
        ranked, key=lambda item: (
            item[0] is None,
            item[0] if item[0] is not None else item[1],
            item[1], -item[4].fret, item[4].string, item[4].note.pitch.midi,
        ),
    ):
        trial = _replace_note(current, state_index, role, note, None)
        # Deliberate local simplification is the only repair allowed to lose an
        # accompaniment note.  It still must solve the target without creating
        # another hard issue or disturbing the rest of the score.
        before = hard_issues(current, maximum_span=maximum_span)
        after = hard_issues(trial, maximum_span=maximum_span)
        if (not any(item.key == issue.key for item in after)
                and len(after) < len(before)
                and not ({item.key for item in after} - {item.key for item in before})):
            return trial, ReviewStatus.ACCOMPANIMENT_SIMPLIFIED, f"Removed accompaniment {tone_role} MIDI {note.note.pitch.midi}"
    return None


def repair_issue(result, issue, tuning, config):
    accompaniment_only = issue.issue_type in {
        "MELODY_ACCOMPANIMENT_FRET_DISTANCE", "ACTIVE_STRING_OCCUPANCY",
    }
    relocated = try_same_pitch_relocation(
        result, issue, tuning, config.maximum_fret, config.maximum_fret_span,
        accompaniment_only=accompaniment_only,
    )
    if relocated:
        return relocated
    # V0.13.5.11: repair/revoice before deletion. For AUTO_MELODY the local
    # reoptimizer can now descend the approved musical degradation ladder.
    reoptimized = replace_window_from_candidate_layers(result, issue.state_index, issue.key, config.maximum_fret_span)
    if reoptimized is not None:
        return reoptimized, ReviewStatus.LOCAL_REOPTIMIZED, "Replaced current window through the V0.13.5.11 realization/degradation ladder"
    simplified = try_accompaniment_simplification(result, issue, config.maximum_fret_span)
    if simplified:
        return simplified
    return None
