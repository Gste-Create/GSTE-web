from __future__ import annotations

from dataclasses import dataclass, replace
from statistics import median

from gste.core.fretboard import midi_to_string_fret, position_block_for_fret
from gste.core.tuning import STANDARD_TUNING, Tuning
from gste.fingering_review.review_models import ReviewIssue, ReviewStatus
from gste.joint_arrangement.models import JointArrangementResult



@dataclass(frozen=True)
class SmoothingProposal:
    """A same-pitch fingering candidate. No physical legality is decided here."""

    score: JointArrangementResult
    issue: ReviewIssue
    description: str
    quality_before: float
    quality_after: float
    preference_rank: tuple

    @property
    def improves_quality(self) -> bool:
        return self.quality_after < self.quality_before - 1e-6


def _state_fretted_center(state) -> float | None:
    frets = [
        n.fret for notes in (state.melody.notes, state.accompaniment.notes)
        for n in notes if n.fret > 0
    ]
    return None if not frets else float(median(frets))


def _near(value: float | None, target: float, tolerance: float = 2.0) -> bool:
    return value is not None and abs(value - target) <= tolerance


def _local_reference_center(result: JointArrangementResult, state_index: int) -> float | None:
    centers = []
    for index in range(max(0, state_index - 3), state_index):
        center = _state_fretted_center(result.selected[index])
        if center is not None:
            centers.append(center)
    return None if not centers else float(median(centers))


def _lookahead_centers(result: JointArrangementResult, state_index: int, max_events: int = 3) -> list[float]:
    centers: list[float] = []
    current_measure = result.selected[state_index].measure
    for index in range(state_index + 1, min(len(result.selected), state_index + 1 + max_events)):
        state = result.selected[index]
        # The look-ahead is intentionally local: no more than one measure beyond
        # the current event, so a later phrase change cannot justify an isolated jump.
        if state.measure > current_measure + 1:
            break
        center = _state_fretted_center(state)
        if center is not None:
            centers.append(center)
    return centers


def _melody_attack_groups(result: JointArrangementResult):
    groups: dict[float, list[tuple[int, object]]] = {}
    for state_index, state in enumerate(result.selected):
        for note in state.melody.notes:
            groups.setdefault(round(note.note.start, 6), []).append((state_index, note))
    return [(onset, groups[onset]) for onset in sorted(groups)]


def _attack_center(entries) -> float | None:
    frets = [note.fret for _, note in entries if note.fret > 0]
    return None if not frets else float(median(frets))


def _two_measure_region(result: JointArrangementResult, groups, group_index: int) -> tuple[list[float], list[float], int]:
    """Return stable centers around an attack using a two-measure horizon.

    The review uses the current measure together with one neighboring measure
    on each side as *candidate evidence*, but no decision is allowed to rely on
    material farther than one measure away.  This lets the reviewer recognize
    a real sustained position change across a barline while still exposing a
    single 2F->8F->3F excursion as an outlier.
    """
    _, entries = groups[group_index]
    current_measure = result.selected[entries[0][0]].measure
    before: list[float] = []
    after: list[float] = []
    for i, (_, group) in enumerate(groups):
        if i == group_index:
            continue
        measure = result.selected[group[0][0]].measure
        if measure < current_measure - 1 or measure > current_measure + 1:
            continue
        center = _attack_center(group)
        if center is None:
            continue
        if i < group_index:
            before.append(center)
        else:
            after.append(center)
    return before[-12:], after[:12], current_measure


def detect_isolated_position_excursions(
    result: JointArrangementResult, *, minimum_jump: float = 3.0, lookahead_events: int = 12,
    tuning: Tuning = STANDARD_TUNING, maximum_fret: int = 18,
) -> list[ReviewIssue]:
    """Find note-level position outliers using a two-measure hand-position trend.

    v0.12.6.7 replaces the old three-attack look-ahead.  The established region
    is inferred from attacks in the current/previous measure and the decision is
    checked against the rest of the current/next measure.  A high-fret note is
    therefore left alone when later attacks continue in that new region, but is
    actionable when the surrounding phrase returns to the former hand position.
    """
    groups = _melody_attack_groups(result)
    issues: list[ReviewIssue] = []
    for group_index, (onset, entries) in enumerate(groups):
        before, after, _ = _two_measure_region(result, groups, group_index)
        if not before or not after:
            continue
        # Keep the reference robust against one preceding outlier.
        reference = float(median(before))
        # The forward trend decides whether the apparent jump is actually a
        # legitimate position change across the next bar.
        future_centers = after[:lookahead_events]
        for state_index, note in entries:
            if note.fret <= 0 or abs(note.fret - reference) < minimum_jump:
                continue
            returns = sum(_near(center, reference) for center in future_centers)
            continues_new = sum(_near(center, float(note.fret)) for center in future_centers)
            if returns == 0 or continues_new >= returns:
                continue
            adjacent = [
                (string, fret)
                for string, fret in midi_to_string_fret(
                    note.note.pitch.midi, max_fret=maximum_fret, tuning=tuning
                )
                if abs(string - note.string) in (1, 2)
                and abs(fret - reference) + 1e-6 < abs(note.fret - reference)
            ]
            if not adjacent:
                continue
            state = result.selected[state_index]
            issues.append(ReviewIssue(
                "ISOLATED_POSITION_EXCURSION", state.measure,
                note.note.start - state.start + 1.0, note.note.start, state_index,
                original_value=int(round(abs(note.fret - reference))),
                final_value=int(round(abs(note.fret - reference))),
                conflict_string=note.string,
                repair=(
                    f"two_measure_reference={reference:.2f}; "
                    f"forward_attacks={len(future_centers)}; "
                    f"returns={returns}; continues_new={continues_new}"
                ),
            ))
    return issues

def _melody_movement_cost(result: JointArrangementResult, onset: float, radius: int = 3) -> float:
    groups = _melody_attack_groups(result)
    index = next((i for i, (attack, _) in enumerate(groups) if abs(attack - onset) <= 1e-6), None)
    if index is None:
        return 0.0
    lo = max(0, index - radius)
    hi = min(len(groups), index + radius + 1)
    centers = [_attack_center(group) for _, group in groups[lo:hi]]
    active = [center for center in centers if center is not None]
    return sum(abs(a - b) for a, b in zip(active, active[1:]))

def _replace_melody_note(result: JointArrangementResult, state_index: int, old, new) -> JointArrangementResult:
    states = list(result.selected)
    state = states[state_index]
    notes = tuple(new if note == old else note for note in state.melody.notes)
    states[state_index] = replace(
        state, melody=replace(state.melody, notes=notes), finger_assignment=(),
    )
    return replace(result, selected=tuple(states))


def _movement_cost(result: JointArrangementResult, state_index: int) -> float:
    lo = max(0, state_index - 2)
    hi = min(len(result.selected), state_index + 4)
    centers = [_state_fretted_center(state) for state in result.selected[lo:hi]]
    active = [center for center in centers if center is not None]
    return sum(abs(a - b) for a, b in zip(active, active[1:]))


def _neighbor_rank(old_string: int, new_string: int) -> tuple[int, int]:
    distance = abs(old_string - new_string)
    # +/-1 strings first, then +/-2, then any remaining legal same-pitch position.
    bucket = 0 if distance == 1 else 1 if distance == 2 else 2
    return bucket, distance


def propose_isolated_position_excursion(
    result: JointArrangementResult, issue: ReviewIssue, *, tuning: Tuning = STANDARD_TUNING,
    maximum_fret: int = 18,
) -> tuple[SmoothingProposal, ...]:
    """Propose same-pitch alternatives for an isolated excursion.

    This function has no physical-rule knowledge. It only generates equivalent
    string/fret realizations and reports their local movement quality.
    """
    if issue.issue_type != "ISOLATED_POSITION_EXCURSION":
        return ()
    state = result.selected[issue.state_index]
    targets = [
        note for note in state.melody.notes
        if abs(note.note.start - issue.onset) <= 1e-6 and note.string == issue.conflict_string
    ]
    if not targets:
        return ()
    old = targets[0]
    before_cost = _melody_movement_cost(result, issue.onset)
    proposals = []
    for string, fret in midi_to_string_fret(old.note.pitch.midi, max_fret=maximum_fret, tuning=tuning):
        if (string, fret) == (old.string, old.fret):
            continue
        moved = replace(old, string=string, fret=fret, position_block=position_block_for_fret(fret))
        trial = _replace_melody_note(result, issue.state_index, old, moved)
        after_cost = _melody_movement_cost(trial, issue.onset)
        proposals.append(SmoothingProposal(
            score=trial, issue=issue,
            description=(
                f"Smoothed isolated melody MIDI {old.note.pitch.midi}: "
                f"string {old.string}/fret {old.fret} -> string {moved.string}/fret {moved.fret}; "
                f"local movement {before_cost:.2f}->{after_cost:.2f}"
            ),
            quality_before=before_cost, quality_after=after_cost,
            preference_rank=(_neighbor_rank(old.string, string), after_cost, abs(fret-old.fret), fret),
        ))
    return tuple(sorted(proposals, key=lambda item: item.preference_rank))


def smooth_isolated_position_excursion(
    result: JointArrangementResult, issue: ReviewIssue, *, tuning: Tuning = STANDARD_TUNING,
    maximum_fret: int = 18,
) -> tuple[JointArrangementResult, ReviewIssue] | None:
    """Move an isolated melody note to a nearer same-pitch string position.

    Physical validity has priority.  Among valid repairs, neighboring strings
    are preferred before wider string changes, then the option with the lowest
    local hand movement is selected.
    """
    from gste.fingering_review.local_reoptimizer import hard_issues

    if issue.issue_type != "ISOLATED_POSITION_EXCURSION":
        return None
    state = result.selected[issue.state_index]
    target_notes = [
        note for note in state.melody.notes
        if abs(note.note.start - issue.onset) <= 1e-6 and note.string == issue.conflict_string
    ]
    if not target_notes:
        return None
    old = target_notes[0]
    before_hard = {item.key for item in hard_issues(result)}
    before_cost = _melody_movement_cost(result, issue.onset)
    candidates = []
    for string, fret in midi_to_string_fret(old.note.pitch.midi, max_fret=maximum_fret, tuning=tuning):
        if (string, fret) == (old.string, old.fret):
            continue
        moved = replace(old, string=string, fret=fret, position_block=position_block_for_fret(fret))
        trial = _replace_melody_note(result, issue.state_index, old, moved)
        after_hard = {item.key for item in hard_issues(trial)}
        if after_hard - before_hard:
            continue
        after_cost = _melody_movement_cost(trial, issue.onset)
        if after_cost >= before_cost - 1e-6:
            continue
        candidates.append((
            _neighbor_rank(old.string, string), after_cost, abs(fret - old.fret), fret,
            trial, moved,
        ))
    if not candidates:
        return None
    _, after_cost, _, _, trial, moved = min(candidates, key=lambda item: item[:4])
    repaired_issue = replace(
        issue,
        status=ReviewStatus.AUTO_FIXED,
        final_value=0,
        repair=(
            f"Smoothed isolated melody MIDI {old.note.pitch.midi}: "
            f"string {old.string}/fret {old.fret} -> string {moved.string}/fret {moved.fret}; "
            f"local movement {before_cost:.2f}->{after_cost:.2f}"
        ),
    )
    return trial, repaired_issue


def repair_position_outliers_in_measures(
    result: JointArrangementResult, measures: set[int], *, tuning: Tuning = STANDARD_TUNING,
    maximum_fret: int = 18, maximum_repairs: int = 24,
) -> JointArrangementResult:
    """Best-effort same-pitch relocation for export-failing measures.

    This is the last in-memory recovery before serialization.  It never changes
    melody pitch/rhythm and only accepts a move that does not introduce a new
    hard issue.  Neighboring strings are preferred by the normal smoothing
    scorer.
    """
    current = result
    for _ in range(maximum_repairs):
        issues = [
            issue for issue in detect_isolated_position_excursions(
                current, tuning=tuning, maximum_fret=maximum_fret
            ) if issue.measure in measures
        ]
        changed = False
        for issue in issues:
            outcome = smooth_isolated_position_excursion(
                current, issue, tuning=tuning, maximum_fret=maximum_fret
            )
            if outcome is not None:
                current, _ = outcome
                changed = True
                break
        if not changed:
            break
    return current


def repair_measure_melody_toward_neighbor_region(
    result: JointArrangementResult, measures: set[int], *, tuning: Tuning = STANDARD_TUNING,
    maximum_fret: int = 18,
) -> JointArrangementResult:
    """Conservative last-resort relocation inside export-failing measures.

    Unlike the outlier detector, this can act when serialization reveals a
    conflict that was invisible in the in-memory sounding model.  Every move is
    same-pitch and is accepted only if it moves toward the median hand region of
    the neighboring measures without creating a new in-memory hard violation.
    """
    from gste.fingering_review.local_reoptimizer import hard_issues

    current = result
    neighbor_centers = [
        _state_fretted_center(state) for state in current.selected
        if state.measure not in measures
        and any(abs(state.measure - measure) <= 1 for measure in measures)
    ]
    neighbor_centers = [center for center in neighbor_centers if center is not None]
    if not neighbor_centers:
        return current
    reference = float(median(neighbor_centers))
    baseline = {issue.key for issue in hard_issues(current)}
    for state_index, state in enumerate(tuple(current.selected)):
        if state.measure not in measures:
            continue
        for old in tuple(current.selected[state_index].melody.notes):
            if old.fret <= 0:
                continue
            options = []
            for string, fret in midi_to_string_fret(old.note.pitch.midi, max_fret=maximum_fret, tuning=tuning):
                if (string, fret) == (old.string, old.fret):
                    continue
                if abs(string - old.string) > 2:
                    continue
                if abs(fret - reference) >= abs(old.fret - reference) - 1e-6:
                    continue
                moved = replace(old, string=string, fret=fret, position_block=position_block_for_fret(fret))
                trial = _replace_melody_note(current, state_index, old, moved)
                new_hard = {issue.key for issue in hard_issues(trial)}
                if new_hard - baseline:
                    continue
                options.append((_neighbor_rank(old.string, string), abs(fret-reference), fret, trial))
            if options:
                *_, current = min(options, key=lambda item: item[:-1])
                baseline = {issue.key for issue in hard_issues(current)}
    return current


def smooth_isolated_positions(
    result: JointArrangementResult, *, tuning: Tuning = STANDARD_TUNING,
    maximum_fret: int = 18, maximum_repairs: int = 32,
) -> tuple[JointArrangementResult, tuple[ReviewIssue, ...], tuple[ReviewIssue, ...]]:
    """Run the v0.12.6.7 two-measure second review pass until no improving local repair exists."""
    current = result
    repaired: list[ReviewIssue] = []
    attempted: set[tuple] = set()
    for _ in range(maximum_repairs):
        detected = detect_isolated_position_excursions(
            current, tuning=tuning, maximum_fret=maximum_fret,
        )
        issue = next((item for item in detected if item.key not in attempted), None)
        if issue is None:
            break
        attempted.add(issue.key)
        outcome = smooth_isolated_position_excursion(
            current, issue, tuning=tuning, maximum_fret=maximum_fret,
        )
        if outcome is None:
            continue
        current, repaired_issue = outcome
        repaired.append(repaired_issue)
        # A successful repair changes the local context; allow fresh detection.
        attempted.clear()
    remaining = tuple(detect_isolated_position_excursions(
        current, tuning=tuning, maximum_fret=maximum_fret,
    ))
    return current, tuple(repaired), remaining


# ---------------------------------------------------------------------------
# v0.12.6.10 local hand-comfort review
# ---------------------------------------------------------------------------

def _sounding_snapshot_at(result: JointArrangementResult, onset: float, tolerance: float = 1e-6):
    """Return every selected note physically sounding at ``onset``.

    This mirrors the final export-integrity concept: sustained notes are part of
    the left-hand shape even when they did not attack in the current window.
    """
    entries = []
    for state_index, state in enumerate(result.selected):
        for role, notes in (("melody", state.melody.notes), ("accompaniment", state.accompaniment.notes)):
            for note in notes:
                if note.note.start <= onset + tolerance and note.note.start + note.note.duration > onset + tolerance:
                    entries.append((state_index, role, note))
    return entries


def _snapshot_span_and_center(entries) -> tuple[int, float | None]:
    frets = [note.fret for _, _, note in entries if note.fret > 0]
    if not frets:
        return 0, None
    return max(frets) - min(frets), float(median(frets))


def _measure_reference_center(result: JointArrangementResult, measure: int) -> float | None:
    centers = [
        _state_fretted_center(state) for state in result.selected
        if state.measure == measure
    ]
    values = [center for center in centers if center is not None]
    return None if not values else float(median(values))


def _neighbor_measure_centers(result: JointArrangementResult, measure: int) -> tuple[float | None, float | None]:
    """Use the nearest populated preceding/following measure as position anchors."""
    previous = None
    following = None
    for distance in (1, 2):
        if previous is None:
            previous = _measure_reference_center(result, measure - distance)
        if following is None:
            following = _measure_reference_center(result, measure + distance)
    return previous, following


def _comfort_score(result: JointArrangementResult, onset: float, measure: int) -> tuple[float, int, float, float]:
    entries = _sounding_snapshot_at(result, onset)
    span, center = _snapshot_span_and_center(entries)
    previous, following = _neighbor_measure_centers(result, measure)
    if center is None:
        return 0.0, span, 0.0, 0.0
    prev_gap = 0.0 if previous is None else abs(center - previous)
    next_gap = 0.0 if following is None else abs(center - following)
    # Span dominates, but a one-note excursion that leaves and immediately
    # returns to the established position receives an additional penalty.
    return 4.0 * span + 2.0 * prev_gap + 2.0 * next_gap, span, prev_gap, next_gap


def detect_local_hand_comfort_outliers(
    result: JointArrangementResult, *, threshold: float = 3.0,
) -> list[ReviewIssue]:
    """Detect legal-but-uncomfortable shapes using span + two-sided position gaps.

    v0.12.6.10 deliberately keeps this separate from hard physical legality.
    A candidate is interesting when the instantaneous fretted span is already
    three frets or more and either neighboring position is also three frets or
    more away, or when both neighboring position gaps are at least three frets.
    """
    issues: list[ReviewIssue] = []
    attacks = sorted({round(note.note.start, 6) for state in result.selected for note in state.melody.notes})
    for onset in attacks:
        entries = _sounding_snapshot_at(result, onset)
        if not entries:
            continue
        owner_index = min((index for index, _, note in entries if abs(note.note.start - onset) <= 1e-6), default=entries[0][0])
        measure = result.selected[owner_index].measure
        score, span, prev_gap, next_gap = _comfort_score(result, onset, measure)
        trigger = (span >= threshold and (prev_gap >= threshold or next_gap >= threshold)) or (
            prev_gap >= threshold and next_gap >= threshold
        )
        if not trigger:
            continue
        fretted = [(index, role, note) for index, role, note in entries if note.fret > 0]
        if not fretted:
            continue
        max_fret = max(note.fret for _, _, note in fretted)
        # The span outlier is the highest-fret note, not necessarily the highest pitch.
        outliers = [entry for entry in fretted if entry[2].fret == max_fret]
        state_index, role, outlier = min(outliers, key=lambda entry: (entry[1] != "melody", entry[2].string))
        state = result.selected[state_index]
        issues.append(ReviewIssue(
            "LOCAL_HAND_COMFORT_OUTLIER", measure,
            onset - state.start + 1.0, onset, state_index,
            original_value=int(round(max(span, prev_gap, next_gap))),
            final_value=int(round(max(span, prev_gap, next_gap))),
            conflict_string=outlier.string,
            required_fret=outlier.fret,
            repair=(
                f"span={span}; previous_gap={prev_gap:.2f}; following_gap={next_gap:.2f}; "
                f"comfort_score={score:.2f}; span_outlier_role={role}"
            ),
        ))
    return issues


def _replace_any_note(result: JointArrangementResult, state_index: int, role: str, old, moved) -> JointArrangementResult:
    states = list(result.selected)
    state = states[state_index]
    if role == "melody":
        notes = tuple(moved if note == old else note for note in state.melody.notes)
        states[state_index] = replace(state, melody=replace(state.melody, notes=notes), finger_assignment=())
    else:
        notes = tuple(moved if note == old else note for note in state.accompaniment.notes)
        states[state_index] = replace(
            state, accompaniment=replace(state.accompaniment, notes=notes), finger_assignment=(),
        )
    return replace(result, selected=tuple(states))


def propose_local_hand_comfort_outlier(
    result: JointArrangementResult, issue: ReviewIssue, *, tuning: Tuning = STANDARD_TUNING,
    maximum_fret: int = 18,
) -> tuple[SmoothingProposal, ...]:
    """Propose same-pitch alternatives for a local hand-shape outlier.

    Physical legality is intentionally not evaluated here. The caller must use
    the authoritative Final Physical Validator before accepting any proposal.
    """
    if issue.issue_type != "LOCAL_HAND_COMFORT_OUTLIER":
        return ()
    snapshot = _sounding_snapshot_at(result, issue.onset)
    targets = [
        (index, role, note) for index, role, note in snapshot
        if index == issue.state_index and note.string == issue.conflict_string
        and (issue.required_fret is None or note.fret == issue.required_fret)
    ]
    if not targets:
        return ()
    state_index, role, old = targets[0]
    measure = result.selected[state_index].measure
    before_score, before_span, before_prev, before_next = _comfort_score(result, issue.onset, measure)
    proposals = []
    for string, fret in midi_to_string_fret(old.note.pitch.midi, max_fret=maximum_fret, tuning=tuning):
        delta_string = string - old.string
        if delta_string == 0 or abs(delta_string) > 2:
            continue
        moved = replace(old, string=string, fret=fret, position_block=position_block_for_fret(fret))
        trial = _replace_any_note(result, state_index, role, old, moved)
        after_score, after_span, after_prev, after_next = _comfort_score(trial, issue.onset, measure)
        direction_rank = 0 if delta_string == -1 else 1 if delta_string == 1 else 2 if delta_string == -2 else 3
        proposals.append(SmoothingProposal(
            score=trial, issue=issue,
            description=(
                f"Comfort-smoothed {role} MIDI {old.note.pitch.midi}: "
                f"string {old.string}/fret {old.fret} -> string {moved.string}/fret {moved.fret}; "
                f"span {before_span}->{after_span}; prev_gap {before_prev:.2f}->{after_prev:.2f}; "
                f"next_gap {before_next:.2f}->{after_next:.2f}; score {before_score:.2f}->{after_score:.2f}"
            ),
            quality_before=before_score, quality_after=after_score,
            preference_rank=(direction_rank, after_score, after_span, abs(fret-old.fret), fret),
        ))
    return tuple(sorted(proposals, key=lambda item: item.preference_rank))


def smooth_local_hand_comfort_outlier(
    result: JointArrangementResult, issue: ReviewIssue, *, tuning: Tuning = STANDARD_TUNING,
    maximum_fret: int = 18,
) -> tuple[JointArrangementResult, ReviewIssue] | None:
    """Try same-pitch neighboring-string positions for the actual span outlier.

    Search priority is higher adjacent string first, then the other adjacent
    string, then +/-2 strings.  A move is accepted only if no new hard issue is
    introduced and the combined span/previous/next-position score improves.
    """
    from gste.fingering_review.local_reoptimizer import hard_issues

    if issue.issue_type != "LOCAL_HAND_COMFORT_OUTLIER":
        return None
    snapshot = _sounding_snapshot_at(result, issue.onset)
    targets = [
        (index, role, note) for index, role, note in snapshot
        if index == issue.state_index and note.string == issue.conflict_string
        and (issue.required_fret is None or note.fret == issue.required_fret)
    ]
    if not targets:
        return None
    state_index, role, old = targets[0]
    baseline_hard = {item.key for item in hard_issues(result)}
    measure = result.selected[state_index].measure
    before_score, before_span, before_prev, before_next = _comfort_score(result, issue.onset, measure)
    options = []
    for string, fret in midi_to_string_fret(old.note.pitch.midi, max_fret=maximum_fret, tuning=tuning):
        delta_string = string - old.string
        if delta_string == 0 or abs(delta_string) > 2:
            continue
        moved = replace(old, string=string, fret=fret, position_block=position_block_for_fret(fret))
        trial = _replace_any_note(result, state_index, role, old, moved)
        trial_hard = {item.key for item in hard_issues(trial)}
        if trial_hard - baseline_hard:
            continue
        after_score, after_span, after_prev, after_next = _comfort_score(trial, issue.onset, measure)
        if after_score >= before_score - 1e-6:
            continue
        # User-requested preference: try moving the high-fret note to the next
        # higher-pitched string first. Guitar string numbers decrease upward.
        direction_rank = 0 if delta_string == -1 else 1 if delta_string == 1 else 2 if delta_string == -2 else 3
        options.append((direction_rank, after_score, after_span, abs(fret-old.fret), fret, trial, moved, after_prev, after_next))
    if not options:
        return None
    _, after_score, after_span, _, _, trial, moved, after_prev, after_next = min(options, key=lambda item: item[:5])
    return trial, replace(
        issue, status=ReviewStatus.AUTO_FIXED,
        final_value=int(round(max(after_span, after_prev, after_next))),
        repair=(
            f"Comfort-smoothed {role} MIDI {old.note.pitch.midi}: "
            f"string {old.string}/fret {old.fret} -> string {moved.string}/fret {moved.fret}; "
            f"span {before_span}->{after_span}; prev_gap {before_prev:.2f}->{after_prev:.2f}; "
            f"next_gap {before_next:.2f}->{after_next:.2f}; score {before_score:.2f}->{after_score:.2f}"
        ),
    )


def smooth_local_hand_comfort(
    result: JointArrangementResult, *, tuning: Tuning = STANDARD_TUNING,
    maximum_fret: int = 18, maximum_repairs: int = 32,
) -> tuple[JointArrangementResult, tuple[ReviewIssue, ...], tuple[ReviewIssue, ...]]:
    current = result
    repaired: list[ReviewIssue] = []
    attempted: set[tuple] = set()
    for _ in range(maximum_repairs):
        detected = detect_local_hand_comfort_outliers(current)
        issue = next((item for item in detected if item.key not in attempted), None)
        if issue is None:
            break
        attempted.add(issue.key)
        outcome = smooth_local_hand_comfort_outlier(current, issue, tuning=tuning, maximum_fret=maximum_fret)
        if outcome is None:
            continue
        current, fixed = outcome
        repaired.append(fixed)
        attempted.clear()
    remaining = tuple(detect_local_hand_comfort_outliers(current))
    return current, tuple(repaired), remaining


def repair_span_outliers_in_measures(
    result: JointArrangementResult, measures: set[int], *, tuning: Tuning = STANDARD_TUNING,
    maximum_fret: int = 18, maximum_repairs: int = 32,
) -> JointArrangementResult:
    """Aggressive local hard-physical repair for export-failing measures.

    Unlike cosmetic smoothing this starts from the real hard issue set and can
    relocate either melody or accompaniment on the same pitch. It prioritizes
    the note at the maximum fret of the illegal sounding shape and neighboring
    strings before any wider movement.
    """
    from gste.fingering_review.local_reoptimizer import hard_issues
    from gste.fingering_review.repair_planner import repair_issue
    from gste.fingering_review.review_models import ReviewConfig

    current = result
    config = ReviewConfig(strict=False, maximum_fret=maximum_fret)
    for _ in range(maximum_repairs):
        issues = [item for item in hard_issues(current) if item.measure in measures]
        if not issues:
            break
        issue = issues[0]
        outcome = repair_issue(current, issue, tuning, config)
        if outcome is None:
            break
        current = outcome[0]
    return current
