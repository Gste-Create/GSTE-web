from __future__ import annotations

from dataclasses import replace

from gste.fingering_review.barre_validator import detect_barre_spans, detect_internal_barre_conflicts
from gste.fingering_review.span_validator import (
    detect_active_string_conflicts,
    detect_melody_accompaniment_distances,
    detect_directional_simultaneous_spans,
)
from gste.joint_arrangement.models import JointArrangementResult


def hard_issues(result: JointArrangementResult, tolerance: float = 1e-6, maximum_span: int = 4, melody_backbone=None):
    return [
        *detect_active_string_conflicts(result, tolerance, melody_backbone=melody_backbone),
        *detect_melody_accompaniment_distances(result, tolerance, maximum_span, melody_backbone=melody_backbone),
        *detect_directional_simultaneous_spans(result, tolerance, melody_backbone=melody_backbone),
        *detect_barre_spans(result, tolerance),
        *detect_internal_barre_conflicts(result, tolerance),
    ]


def replace_window_from_candidate_layers(result: JointArrangementResult, state_index: int, issue_key: tuple, maximum_span: int = 4):
    """Repair string/fret realization without changing accompaniment music.

    Whole-pattern degradation is Joint-owned. Review may only relocate the
    same music here; its separate hard-conflict repair may remove one note.
    """
    if state_index >= len(result.candidate_layers):
        return None
    baseline_issues = hard_issues(result, maximum_span=maximum_span)
    baseline = len(baseline_issues)
    selected = list(result.selected)
    original = selected[state_index]
    # Review repairs realization only. Musical degradation belongs to Joint;
    # deleting a conflicting note is handled separately by the hard-issue repair.
    candidates = [c for c in result.candidate_layers[state_index] if c != original]
    candidates.sort(key=lambda c: c.local_cost)
    acc_sig = lambda state: sorted((n.note.source_event_id, n.note.pitch.midi, n.note.start, n.note.duration) for n in state.accompaniment.notes)

    for candidate in candidates:
        # Melody identity, pitch, rhythm and event order are immutable.
        old_sig = sorted((n.note.source_event_id, n.note.pitch.midi, n.note.start, n.note.duration) for n in original.melody.notes)
        new_sig = sorted((n.note.source_event_id, n.note.pitch.midi, n.note.start, n.note.duration) for n in candidate.melody.notes)
        if old_sig != new_sig:
            continue
        if acc_sig(candidate) != acc_sig(original):
            continue

        selected[state_index] = candidate
        trial = replace(result, selected=tuple(selected))
        after = hard_issues(trial, maximum_span=maximum_span)
        if (len(after) < baseline
                and all(i.key != issue_key for i in after)
                and not ({i.key for i in after} - {i.key for i in baseline_issues})):
            return trial
    return None
