from __future__ import annotations

# V0.13.5.11 Melody-only realization ladder. Higher rank = richer texture.
_TEXTURE_RANK = {
    "LEGACY_SAFE": 0,
    "ROOT": 1,
    "ROOT_GUIDE": 2,
    "SPARSE_ARPEGGIO": 3,
    "ARPEGGIO": 4,
}


def is_auto_melody_state(state) -> bool:
    return any(n.note.importance is not None for n in state.accompaniment.notes)


def texture_from_state(state) -> str | None:
    ids = [str(n.note.source_event_id or "") for n in state.accompaniment.notes]
    joined = "|".join(ids).upper()
    for texture in ("LEGACY_SAFE", "SPARSE_ARPEGGIO", "ROOT_GUIDE", "ARPEGGIO", "ROOT"):
        if f"AUTO_{texture}_" in joined or f":{texture}:" in joined:
            return texture
    # Joint-created reductions keep AUTOIMP but may lose the original SRCVAR.
    ctype = str(getattr(state.accompaniment, "candidate_type", "") or "").upper()
    if "BASS_GUIDE" in ctype:
        return "ROOT_GUIDE"
    if "BASS_ONLY" in ctype or len(state.accompaniment.notes) == 1:
        return "ROOT"
    return None


def texture_rank(state) -> int | None:
    texture = texture_from_state(state)
    return _TEXTURE_RANK.get(texture) if texture is not None else None


def degradation_sort_key(original, candidate) -> tuple:
    """Same texture/alternate fingering first, then one musical level at a time.

    LEGACY_SAFE is always last and is considered only after the modern ladder.
    """
    o_rank = texture_rank(original)
    c_rank = texture_rank(candidate)
    if o_rank is None or c_rank is None:
        return (99, 99, 99, candidate.local_cost)
    if c_rank > o_rank:
        return (98, c_rank, -len(candidate.accompaniment.notes), candidate.local_cost)
    same_count = len(candidate.accompaniment.notes) == len(original.accompaniment.notes)
    # 0: same musical texture, alternate fingering/voicing with no information loss.
    if c_rank == o_rank and same_count:
        return (0, 0, 0, candidate.local_cost)
    # 1: explicit modern texture degradation, one level at a time.
    if 0 < c_rank < o_rank:
        return (1, o_rank - c_rank, -len(candidate.accompaniment.notes), candidate.local_cost)
    # 2: generic same-texture note pruning is later than a musical texture step.
    if c_rank == o_rank:
        return (2, len(original.accompaniment.notes) - len(candidate.accompaniment.notes), -len(candidate.accompaniment.notes), candidate.local_cost)
    # 3: LEGACY_SAFE is the final candidate before melody-only.
    if c_rank == 0:
        return (3, 0, -len(candidate.accompaniment.notes), candidate.local_cost)
    return (97, 0, -len(candidate.accompaniment.notes), candidate.local_cost)


def approved_degradation(original, candidate) -> bool:
    """AUTO_MELODY may keep the same texture or move downward, never upward."""
    if not (is_auto_melody_state(original) and is_auto_melody_state(candidate)):
        return False
    o_rank = texture_rank(original)
    c_rank = texture_rank(candidate)
    return o_rank is not None and c_rank is not None and c_rank <= o_rank
