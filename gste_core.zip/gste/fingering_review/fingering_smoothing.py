from __future__ import annotations

from dataclasses import dataclass, replace

from gste.core.tuning import STANDARD_TUNING, Tuning
from gste.fingering_review.final_reviewer import validate_final_fingering_hard_rules
from gste.fingering_review.review_models import ReviewConfig, ReviewIssue, ReviewStatus
from gste.fingering_review.smoothing import (
    detect_isolated_position_excursions,
    detect_local_hand_comfort_outliers,
    propose_isolated_position_excursion,
    propose_local_hand_comfort_outlier,
)
from gste.joint_arrangement.models import JointArrangementResult


@dataclass(frozen=True)
class FingeringSmoothingResult:
    """Transactional post-Joint, pre-validation fingering-only refinement."""

    score: JointArrangementResult
    immutable_signature_before: tuple
    immutable_signature_after: tuple
    fixed_issues: tuple[ReviewIssue, ...] = ()
    remaining_issues: tuple[ReviewIssue, ...] = ()
    rejected_proposals: int = 0


def immutable_musical_signature(score: JointArrangementResult) -> tuple:
    """Freeze musical identity while deliberately excluding string/fret realization."""
    items: list[tuple] = []
    for state_index, state in enumerate(score.selected):
        for note in state.melody.notes:
            items.append((
                state_index, "melody", note.note.source_event_id, note.note.pitch.midi,
                round(note.note.start, 9), round(note.note.duration, 9),
            ))
        tone_roles = tuple(getattr(state.accompaniment, "tone_roles", ()) or ())
        for note_index, note in enumerate(state.accompaniment.notes):
            role = tone_roles[note_index] if note_index < len(tone_roles) else "accompaniment"
            items.append((
                state_index, f"accompaniment:{role}", note.note.source_event_id, note.note.pitch.midi,
                round(note.note.start, 9), round(note.note.duration, 9),
            ))
    return tuple(sorted(items, key=repr))


def _validator_accepts(
    candidate: JointArrangementResult, *, config: ReviewConfig, melody_backbone=None,
) -> bool:
    """Ask the one authoritative physical validator; define no physical rules here."""
    try:
        validate_final_fingering_hard_rules(
            candidate, config=config, melody_backbone=melody_backbone,
        )
    except ValueError:
        return False
    return True


def _transactional_pass(
    score: JointArrangementResult, *, detector, proposer, tuning: Tuning,
    maximum_fret: int, maximum_repairs: int, validator_config: ReviewConfig,
    melody_backbone=None,
) -> tuple[JointArrangementResult, tuple[ReviewIssue, ...], tuple[ReviewIssue, ...], int]:
    """Detect -> Propose -> authoritative Validator -> Compare -> Commit/Rollback."""
    current = score
    repaired: list[ReviewIssue] = []
    attempted: set[tuple] = set()
    rejected = 0

    for _ in range(maximum_repairs):
        detected = detector(current, tuning=tuning, maximum_fret=maximum_fret) if detector is detect_isolated_position_excursions else detector(current)
        issue = next((item for item in detected if item.key not in attempted), None)
        if issue is None:
            break
        attempted.add(issue.key)

        proposals = proposer(current, issue, tuning=tuning, maximum_fret=maximum_fret)
        accepted = None
        for proposal in proposals:
            # Immutable identity is checked before physical validation so a broken
            # proposer can never be mistaken for a merely unplayable candidate.
            if immutable_musical_signature(proposal.score) != immutable_musical_signature(current):
                raise ValueError(
                    "FINGERING_SMOOTHING_IMMUTABLE_SIGNATURE_FAILED: proposal changed "
                    "event identity, pitch, time, duration, role, note count, or Joint-window ownership"
                )
            # Smoothing does not know any physical rule. Only the same validator
            # used by Final Review is allowed to approve this temporary candidate.
            if not _validator_accepts(proposal.score, config=validator_config, melody_backbone=melody_backbone):
                rejected += 1
                continue
            # Compare is quality-only and happens after legality is approved.
            if not proposal.improves_quality:
                rejected += 1
                continue
            accepted = proposal
            break

        if accepted is None:
            # Mandatory fallback: keep the exact Joint/current fingering.
            continue

        current = accepted.score
        repaired.append(replace(
            issue, status=ReviewStatus.AUTO_FIXED, final_value=0, repair=accepted.description,
        ))
        attempted.clear()

    remaining = detector(current, tuning=tuning, maximum_fret=maximum_fret) if detector is detect_isolated_position_excursions else detector(current)
    return current, tuple(repaired), tuple(remaining), rejected


def smooth_final_fingering(
    score: JointArrangementResult, *, tuning: Tuning = STANDARD_TUNING,
    maximum_fret: int = 18, maximum_repairs: int = 24,
    validator_config: ReviewConfig | None = None, melody_backbone=None,
) -> FingeringSmoothingResult:
    """Transactional fingering smoothing with Joint-result fallback.

    Authority is intentionally narrow:
      Detect: local fingering outliers only.
      Propose: same-pitch string/fret alternatives only.
      Compare: position/shape continuity only.

    Physical legality is owned exclusively by validate_final_fingering_hard_rules().
    A rejected proposal is rolled back by construction because the current score
    is never replaced until the authoritative validator and quality comparison pass.
    """
    config = validator_config or ReviewConfig()
    before = immutable_musical_signature(score)
    current = score
    fixed: list[ReviewIssue] = []
    rejected = 0

    current, pass_fixed, _, pass_rejected = _transactional_pass(
        current, detector=detect_isolated_position_excursions,
        proposer=propose_isolated_position_excursion, tuning=tuning,
        maximum_fret=maximum_fret, maximum_repairs=maximum_repairs,
        validator_config=config, melody_backbone=melody_backbone,
    )
    fixed.extend(pass_fixed); rejected += pass_rejected

    current, pass_fixed, _, pass_rejected = _transactional_pass(
        current, detector=detect_local_hand_comfort_outliers,
        proposer=propose_local_hand_comfort_outlier, tuning=tuning,
        maximum_fret=maximum_fret, maximum_repairs=maximum_repairs,
        validator_config=config, melody_backbone=melody_backbone,
    )
    fixed.extend(pass_fixed); rejected += pass_rejected

    after = immutable_musical_signature(current)
    if after != before:
        raise ValueError(
            "FINGERING_SMOOTHING_IMMUTABLE_SIGNATURE_FAILED: smoothing changed "
            "event identity, pitch, time, duration, role, note count, or Joint-window ownership"
        )

    remaining = tuple(detect_isolated_position_excursions(current, tuning=tuning, maximum_fret=maximum_fret)) + tuple(detect_local_hand_comfort_outliers(current))
    return FingeringSmoothingResult(
        score=current, immutable_signature_before=before, immutable_signature_after=after,
        fixed_issues=tuple(fixed), remaining_issues=remaining, rejected_proposals=rejected,
    )
