from __future__ import annotations

from collections import defaultdict

from gste.fingering_review.review_models import ReviewIssue
from gste.fingering_review.span_validator import onset_groups
from gste.joint_arrangement.models import JointArrangementResult


def _barres(entries) -> list[tuple[int, tuple[int, ...]]]:
    by_fret: dict[int, list[int]] = defaultdict(list)
    for _, _, note in entries:
        if note.fret > 0:
            by_fret[note.fret].append(note.string)
    found: list[tuple[int, tuple[int, ...]]] = []
    for fret, raw_strings in by_fret.items():
        strings = sorted(set(raw_strings))
        run: list[int] = []
        for string in strings:
            if run and string != run[-1] + 1:
                if len(run) >= 2:
                    found.append((fret, tuple(run)))
                run = []
            run.append(string)
        if len(run) >= 2:
            found.append((fret, tuple(run)))
    return found


def detect_barre_spans(result: JointArrangementResult, tolerance: float = 1e-6) -> list[ReviewIssue]:
    issues: list[ReviewIssue] = []
    for onset, entries in onset_groups(result, tolerance):
        fretted = [note.fret for _, _, note in entries if note.fret > 0]
        for fret, strings in _barres(entries):
            span = max(fretted, default=fret) - fret
            if span >= 4:
                state_index = entries[0][0]
                state = result.selected[state_index]
                issues.append(ReviewIssue(
                    "BARRE_FRET_SPAN", state.measure, onset - state.start + 1.0, onset, state_index,
                    original_value=span, final_value=span, barre_fret=fret, barre_strings=strings,
                ))
    return issues


def detect_internal_barre_conflicts(result: JointArrangementResult, tolerance: float = 1e-6) -> list[ReviewIssue]:
    groups = onset_groups(result, tolerance)
    issues: list[ReviewIssue] = []
    for index in range(1, len(groups) - 1):
        onset, middle = groups[index]
        previous_barres = set(_barres(groups[index - 1][1]))
        following_barres = set(_barres(groups[index + 1][1]))
        positions = {note.string: note.fret for _, _, note in middle}
        for fret, strings in sorted(previous_barres & following_barres):
            if len(strings) < 3:
                continue
            maintained = [s for s in strings if positions.get(s) == fret]
            if len(maintained) < 2:
                continue
            for string in strings[1:-1]:
                required = positions.get(string)
                if required is None or required >= fret:
                    continue
                state_index = middle[0][0]
                state = result.selected[state_index]
                issue_type = "BARRE_INTERNAL_STRING_RELEASE" if required == 0 else "BARRE_INTERNAL_LOWER_FRET"
                issues.append(ReviewIssue(
                    issue_type, state.measure, onset - state.start + 1.0, onset, state_index,
                    barre_fret=fret, barre_strings=strings, conflict_string=string, required_fret=required,
                ))
    return issues
