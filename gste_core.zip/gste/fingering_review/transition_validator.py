"""Three-event transition checks are implemented by ``barre_validator``.

This module is kept as an explicit extension point for the later one-beat and
full-measure transition searches required by the v0.12.5 specification.
"""

from .barre_validator import detect_internal_barre_conflicts

__all__ = ["detect_internal_barre_conflicts"]
