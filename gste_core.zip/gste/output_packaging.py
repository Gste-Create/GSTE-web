"""Single user-facing output package writer for GUI, CLI and batch.

GUI format is the canonical package surface. Route-specific engineering artifacts
are preserved under debug/pipeline_output; entry points may not invent their own
layout.
"""
from __future__ import annotations
from pathlib import Path
import shutil
from gste.version import VERSION

ROOT_KEEP = {"GSTE_NOTATION_MAP.json","GSTE_TAB.musicxml", "CONVERSION_REPORT.md", "ERROR_REPORT.md", "PRIVACY_SAFE_DEBUG_REPORT.md", "EVENT_LIFECYCLE_TRACE.md", "HUMAN_REVIEW_REPORT.md", "MEASURE_LOCATION_GUIDE.md", "debug"}

def package_success(run_dir: str|Path, final_path: str|Path, *, mode_label: str) -> Path:
    run = Path(run_dir); final = Path(final_path)
    user_tab = run / "GSTE_TAB.musicxml"
    if final.exists() and final.resolve() != user_tab.resolve(): shutil.copy2(final, user_tab)
    identity_map=final.with_suffix('.notation.json')
    if identity_map.exists():shutil.copy2(identity_map,run/'GSTE_NOTATION_MAP.json')
    debug = run / "debug"; pipeline = debug / "pipeline_output"; pipeline.mkdir(parents=True, exist_ok=True)
    for item in list(run.iterdir()):
        if item.name in ROOT_KEEP: continue
        target = pipeline / item.name
        if target.exists(): shutil.rmtree(target) if target.is_dir() else target.unlink()
        shutil.move(str(item), str(target))
    for name in ("PRIVACY_SAFE_DEBUG_REPORT.md", "EVENT_LIFECYCLE_TRACE.md"):
        candidates = list(pipeline.rglob(name))
        if candidates: shutil.copy2(candidates[0], run/name)
    for name in ("PRIVACY_SAFE_DEBUG_REPORT.json", "EVENT_LIFECYCLE_TRACE.json"):
        candidates = list(pipeline.rglob(name))
        if candidates: shutil.copy2(candidates[0], debug/name)
    # Observer-only artifact provenance.  Record the actual writer/rewrite/copy
    # chain so debugging never has to infer provenance from filenames.
    trace = {
        "04_PRE_FINAL_REVIEW_TAB.musicxml": {
            "writer": "gste.exporter.joint_tab_xml_exporter.write_joint_tab_musicxml",
            "rewrite": ["_move_gste_debug_metadata_out_of_notations", "normalize_playback_hazards"],
        },
        "05_TAB.musicxml": {
            "writer": "gste.exporter.joint_tab_xml_exporter.write_joint_tab_musicxml",
            "postprocessors": ["gste.exporter.public_musicxml_sanitizer.sanitize_public_musicxml"],
        },
        "GSTE_TAB.musicxml": {
            "writer": "gste.output_packaging.package_success",
            "source": str(final.name),
            "operation": "copy2" if final.resolve() != user_tab.resolve() else "same_path",
            "postprocessors": [],
        },
    }
    (debug / "ARTIFACT_TRACE.json").write_text(__import__("json").dumps(trace, ensure_ascii=False, indent=2), encoding="utf-8")
    verdict="UNAVAILABLE"
    monitor=debug/"UNIFIED_RUNTIME_MONITOR.json"
    if monitor.exists():
        try: verdict=__import__("json").loads(monitor.read_text(encoding="utf-8")).get("contract",{}).get("verdict","UNAVAILABLE")
        except (ValueError,OSError): pass
    (run/"CONVERSION_REPORT.md").write_text(
        f"# {VERSION} Conversion Report\n\n- Status: SUCCESS\n- Contract verdict: {verdict}\n- Input mode: {mode_label}\n- Finished score: `GSTE_TAB.musicxml`\n\n"
        "The conversion completed and the finished score was generated.\n"
        "Please review the score manually before performance, publication, or redistribution.\n\n"
        "For normal use, you only need `GSTE_TAB.musicxml` and this report.\n"
        "Privacy-safe diagnostics are available at `PRIVACY_SAFE_DEBUG_REPORT.md` and `EVENT_LIFECYCLE_TRACE.md`.\n"
        "Full engineering diagnostics are stored in `debug/pipeline_output/`.\n", encoding="utf-8")
    from gste.user_reports import write_user_reports
    write_user_reports(run, success=True)
    return user_tab

def package_failure(run_dir: str|Path, *, mode_label: str, detail: str|None=None, traceback_text: str|None=None) -> Path:
    run=Path(run_dir); debug=run/"debug"; pipeline=debug/"pipeline_output"; pipeline.mkdir(parents=True,exist_ok=True)
    if traceback_text: (debug/"ERROR_TRACEBACK.txt").write_text(traceback_text,encoding="utf-8")
    for item in list(run.iterdir()):
        if item.name in {"debug", "ERROR_REPORT.md", "PRIVACY_SAFE_DEBUG_REPORT.md", "EVENT_LIFECYCLE_TRACE.md"}: continue
        target=pipeline/item.name
        if target.exists(): shutil.rmtree(target) if target.is_dir() else target.unlink()
        shutil.move(str(item),str(target))
    for name in ("PRIVACY_SAFE_DEBUG_REPORT.md", "EVENT_LIFECYCLE_TRACE.md"):
        candidates=list(pipeline.rglob(name))
        if candidates: shutil.copy2(candidates[0],run/name)
    for name in ("PRIVACY_SAFE_DEBUG_REPORT.json", "EVENT_LIFECYCLE_TRACE.json"):
        candidates=list(pipeline.rglob(name))
        if candidates: shutil.copy2(candidates[0],debug/name)
    report=run/"ERROR_REPORT.md"
    report.write_text(f"# {VERSION} Error Report\n\n- Status: FAILED\n- Input mode: {mode_label}\n- Error: {detail or 'ConversionError'}\n\nFull traceback: `debug/ERROR_TRACEBACK.txt`\n\nShare the privacy-safe reports first; the original score is not required for most pipeline failures.\n",encoding="utf-8")
    from gste.user_reports import write_user_reports
    write_user_reports(run, success=False, detail=detail)
    return report
