from __future__ import annotations

from dataclasses import dataclass, field

from gste.input.project_models import PianoSplitProject


@dataclass(frozen=True)
class AlignmentIssue:
    code: str
    message: str
    fatal: bool = True


@dataclass(frozen=True)
class AlignmentResult:
    project: PianoSplitProject
    issues: list[AlignmentIssue] = field(default_factory=list)

    @property
    def is_aligned(self) -> bool:
        return not any(issue.fatal for issue in self.issues)
