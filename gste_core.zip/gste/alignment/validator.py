from __future__ import annotations

from gste.alignment.models import AlignmentIssue, AlignmentResult
from gste.input.project_models import PianoSplitProject, TrackData


def _time_signature_signature(track: TrackData) -> list[tuple[float, int, int, int]]:
    rows=[]
    last=None
    for item in sorted(track.time_signatures,key=lambda x:x.start):
        meter=(item.beats,item.beat_type)
        if meter!=last: rows.append((item.start,*meter,item.measure));last=meter
    return rows


def validate_strict_alignment(project: PianoSplitProject, tolerance: float = 1e-6) -> AlignmentResult:
    """Validate that separately exported right/left-hand XML files share a timeline."""
    melody = project.melody
    left = project.left_hand
    issues: list[AlignmentIssue] = []

    if set(melody.measure_starts) != set(left.measure_starts):
        issues.append(AlignmentIssue("measure_set", "Melody and left-hand files do not contain the same measure numbers."))

    for measure in sorted(set(melody.measure_starts) & set(left.measure_starts)):
        if abs(melody.measure_starts[measure] - left.measure_starts[measure]) > tolerance:
            issues.append(AlignmentIssue("measure_start", f"Measure {measure} starts at different absolute times."))
        if abs(melody.measure_lengths[measure] - left.measure_lengths[measure]) > tolerance:
            issues.append(AlignmentIssue("measure_length", f"Measure {measure} has different lengths in the two files."))

    if abs(melody.duration_quarters - left.duration_quarters) > tolerance:
        issues.append(
            AlignmentIssue(
                "total_duration",
                f"Total duration differs: melody={melody.duration_quarters:g}, left_hand={left.duration_quarters:g} quarters.",
            )
        )

    if _time_signature_signature(melody) != _time_signature_signature(left):
        issues.append(AlignmentIssue("time_signature", "Time-signature maps differ between melody and left-hand files."))

    for warning in melody.warnings:
        issues.append(AlignmentIssue("melody_parse_warning", warning, fatal=False))
    for warning in left.warnings:
        issues.append(AlignmentIssue("left_parse_warning", warning, fatal=False))

    return AlignmentResult(project=project, issues=issues)
