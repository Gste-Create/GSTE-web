"""Shared physical grid; never shift or truncate source events."""
from dataclasses import replace

def common_timeline(tracks, tolerance=1e-6):
    starts={}; lengths={}; issues=[]; meters={}
    for track in tracks:
        for m,s in track.measure_starts.items():
            length=track.measure_lengths[m]
            for field, value, table in (("measure_start",s,starts),("measure_length",length,lengths)):
                if m in table and abs(table[m]-value)>tolerance:
                    issues.append({"track_id":track.track_id,"measure":m,"code":field,"expected":table[m],"actual":value})
                else: table[m]=value
            active=[x for x in track.time_signatures if x.start<=s+tolerance]
            if active:
                ts=max(active,key=lambda x:x.start); meter=(ts.beats,ts.beat_type)
                if m in meters and meters[m]!=meter:
                    issues.append({"track_id":track.track_id,"measure":m,"code":"meter","expected":meters[m],"actual":meter})
                else: meters[m]=meter
    ordered=sorted(starts,key=starts.get)
    for a,b in zip(ordered,ordered[1:]):
        if abs(starts[a]+lengths[a]-starts[b])>tolerance:
            issues.append({"code":"grid_gap_or_overlap","measure":b})
    end=max((starts[m]+lengths[m] for m in starts),default=0.)
    rows=[]
    for t in tracks:
        bad=[x for x in issues if x.get("track_id")==t.track_id]
        if abs(t.duration_quarters-max((t.measure_starts[m]+t.measure_lengths[m] for m in t.measure_starts),default=0.))>tolerance:
            bad.append({"code":"track_duration","track_id":t.track_id,"actual":t.duration_quarters});issues.extend(bad[-1:])
        for n in t.notes:
            if n.start < -tolerance or n.start+n.duration>end+tolerance:
                x={"code":"event_outside_grid","track_id":t.track_id,"event_id":n.source_event_id};bad.append(x);issues.append(x)
        rows.append({"track_id":t.track_id,"status":"FAIL" if bad else "PASS","original_measure_count":len(t.measure_starts),"original_duration":t.duration_quarters,"empty_extension_measures":sorted(set(starts)-set(t.measure_starts)),"issues":bad})
    report={"status":"FAIL" if issues else "PASS","common_measure_count":len(starts),"common_duration":end,"tracks":rows,"issues":issues,"policy":"EXTEND_EMPTY_COVERAGE_ONLY; SOURCE_EVENTS_UNCHANGED"}
    if issues: return None,report
    from gste.input.project_models import TimeSignatureChange
    changes=[];last=None
    for m in ordered:
        if m in meters and meters[m]!=last:
            last=meters[m];changes.append(TimeSignatureChange(starts[m],*last,m))
    grid={"measure_starts":starts,"measure_lengths":lengths,"time_signatures":changes,"duration_quarters":end,"measure_display_labels":{m:str(m) for m in ordered}}
    return tuple(replace(t,**grid) for t in tracks),report
