"""Advisory musical-structure signals for future arrangement decisions."""

from gste.structure.analysis import analyze_structure, build_arrangement_signals, detect_structural_boundaries
from gste.structure.models import ArrangementSignal, PhraseRole, StructuralBoundary, StructureAnalysis
from gste.structure.event_boundaries import EventBoundaryCandidate, build_event_boundary_candidates

__all__ = [
    "ArrangementSignal",
    "PhraseRole",
    "StructuralBoundary",
    "StructureAnalysis",
    "analyze_structure",
    "build_arrangement_signals",
    "detect_structural_boundaries",
    "EventBoundaryCandidate",
    "build_event_boundary_candidates",
]
