"""Only authority for meter groups, onset accents and SOURCE/AUTO boundaries.

Times are absolute quarter units. Physical source measures are never resized.
Unknown meter uses one explicit UNKNOWN coverage group, not invented 4/4.
"""
from dataclasses import dataclass
from math import isfinite

@dataclass(frozen=True)
class MetricGroup:
    group_id: str
    measure: int
    start: float
    end: float
    numerator: int | None
    denominator: int | None
    metric_source: str
    accent: float

@dataclass(frozen=True)
class AnalysisWindow:
    window_id: str
    measure: int
    start: float
    end: float
    group_refs: tuple[str, ...]


def canonical_window_id(measure, index):
    return f"M{measure}_W{index}"


def build_metric_groups(starts, lengths, signatures):
    groups=[]
    for measure, start in sorted(starts.items(), key=lambda x:x[1]):
        length=lengths[measure]
        active=[s for s in signatures if s.start <= start+1e-9]
        ts=max(active, key=lambda s:s.start) if active else None
        if ts and (ts.beats <= 0 or ts.beat_type <= 0):
            raise ValueError("Invalid source time signature")
        compound=bool(ts and ts.beat_type == 8 and ts.beats >= 6 and ts.beats % 3 == 0)
        step=(3 if compound else 1)*4/ts.beat_type if ts else length
        if length <= 0:
            continue
        offset=0.; index=1
        count=ts.beats//3 if compound else (ts.beats if ts else 1)
        while offset < length-1e-9:
            end=min(length,offset+step)
            accent=1.0 if index == 1 else (0.75 if count%2 == 0 and index == count//2+1 else 0.5)
            groups.append(MetricGroup(f"M{measure}_G{index}",measure,start+offset,start+end,
                ts.beats if ts else None,ts.beat_type if ts else None,
                "EXPLICIT" if ts else "UNKNOWN",accent))
            offset=end; index+=1
    return tuple(groups)


def build_analysis_windows(timeline, target_quarters=2.0, *, purpose="harmony"):
    """Target is a preferred span, never permission to split a metric group.

    Texture observes single compound beats. Harmony packs whole groups up to
    the target (default 12/8: 1.5; default 4/4: 2). Unknown meter retains the
    historical target slicing, explicitly marked UNKNOWN in metric groups.
    """
    if not isfinite(target_quarters) or target_quarters <= 0:
        raise ValueError("window target must be finite and positive")
    if purpose not in {"harmony", "texture"}:
        raise ValueError("Unknown analysis window purpose")
    windows=[]
    for measure in sorted(timeline.measure_starts):
        groups=[g for g in timeline.metric_groups if g.measure == measure]
        index=1; pending=[]
        def emit(items):
            nonlocal index
            windows.append(AnalysisWindow(canonical_window_id(measure,index),measure,
                items[0].start,items[-1].end,tuple(g.group_id for g in items)))
            index+=1
        if groups and groups[0].metric_source == "UNKNOWN":
            start=groups[0].start; stop=groups[-1].end
            while start < stop-1e-9:
                end=min(stop,start+target_quarters)
                windows.append(AnalysisWindow(canonical_window_id(measure,index),measure,start,end,(groups[0].group_id,)))
                start=end;index+=1
            continue
        for g in groups:
            compound=g.denominator == 8 and g.numerator >= 6 and g.numerator%3 == 0
            if pending and (g.end-pending[0].start > target_quarters+1e-9 or purpose == "texture" and compound):
                emit(pending);pending=[]
            pending.append(g)
        if pending: emit(pending)
    return tuple(windows)


@dataclass(frozen=True)
class MetricContext:
    """Source onset facts, independent of any consumer's analysis window.

    UNKNOWN uses neutral 0.5 evidence and never claims a strong beat. Explicit
    group onsets use the canonical group accent; interior onsets use 0.25.
    This deliberately does not infer syncopation, tuplets or harmonic roles.
    """
    group_id: str | None
    group_start: float | None
    group_end: float | None
    group_accent: float | None
    onset_accent: float
    is_group_onset: bool
    position_in_group: float | None
    meter_type: str
    metric_source: str

    @property
    def is_strong_beat(self) -> bool:
        return self.metric_source == "EXPLICIT" and self.is_group_onset and self.onset_accent >= 0.75


def metric_context_at(time, timeline) -> MetricContext:
    """Query absolute quarter time on TrackData or its immutable group tuple.

    Groups are half-open: a boundary belongs to the following group. Callers
    must pass the complete timeline so sustained notes retain original onset
    context. Empty groups mean explicitly unavailable meter; a populated grid
    with no coverage raises rather than inventing a window-relative beat.
    """
    if not isfinite(time):
        raise ValueError("metric onset must be finite")
    groups = getattr(timeline, "metric_groups", timeline)
    if not groups:
        return MetricContext(None, None, None, None, 0.5, False, None, "UNKNOWN", "UNKNOWN")
    group = next((g for g in groups if abs(time - g.start) < 1e-6), None)
    if group is None:
        group = next((g for g in groups if g.start <= time < g.end), None)
    if group is None:
        raise ValueError(f"Metric timeline does not cover onset {time}")
    position = max(0.0, time - group.start)
    if group.metric_source == "UNKNOWN":
        return MetricContext(group.group_id, group.start, group.end, None, 0.5,
                             False, position, "UNKNOWN", "UNKNOWN")
    onset = abs(time - group.start) < 1e-6
    compound = group.denominator == 8 and group.numerator >= 6 and group.numerator % 3 == 0
    return MetricContext(group.group_id, group.start, group.end, group.accent,
                         group.accent if onset else 0.25, onset, position,
                         "COMPOUND" if compound else "SIMPLE", group.metric_source)
