from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum


class PhraseRole(StrEnum):
    OPENING = "opening"
    CONTINUATION = "continuation"
    CADENTIAL = "cadential"
    RELEASE = "release"


@dataclass(frozen=True)
class StructuralBoundary:
    time: float
    score: float
    reasons: tuple[str, ...]
    measure: int | None = None
    hard: bool = False


@dataclass(frozen=True)
class ArrangementSignal:
    start: float
    duration: float
    phrase_role: PhraseRole
    boundary_before: float
    boundary_after: float
    chord_change_suitability: float
    position_change_suitability: float
    accompaniment_density: float
    preserve_melody: bool = True
    notes: tuple[str, ...] = field(default_factory=tuple)

    @property
    def end(self) -> float:
        return self.start + self.duration


@dataclass(frozen=True)
class StructureAnalysis:
    boundaries: tuple[StructuralBoundary, ...]
    signals: tuple[ArrangementSignal, ...]
    melody_complete_required: bool = True
    playability_required: bool = True
    advisory_only: bool = True
