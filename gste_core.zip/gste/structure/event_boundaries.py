"""Advisory event-boundary candidates for the future dynamic-window stage."""
from __future__ import annotations

from dataclasses import dataclass, replace

from gste.input.project_models import TrackData


@dataclass(frozen=True)
class EventBoundaryCandidate:
    boundary_id: str
    time: float
    measure: int
    confidence: float
    reasons: tuple[str, ...]
    forced: bool
    fixed_two_beat_retained: bool
    neighbouring_event_ids: tuple[str, ...]
    next_time: float | None = None


def _measure_for_time(track: TrackData, time: float) -> int:
    return max((number for number, start in track.measure_starts.items() if start <= time + 1e-6), default=1)


def _fixed_two_beat_times(track: TrackData) -> set[float]:
    # Legacy function/field name retained for debug compatibility only.
    from gste.structure.metric import build_analysis_windows
    return {round(w.start, 6) for w in build_analysis_windows(track)}


def build_event_boundary_candidates(right_hand: TrackData, left_hand: TrackData) -> list[EventBoundaryCandidate]:
    """Create inspectable boundary hints without changing the fixed-window flow."""
    events = [*right_hand.events, *left_hand.events]
    fixed = _fixed_two_beat_times(right_hand)
    times = set(fixed) | {round(event.start, 6) for event in events}
    times |= {round(start, 6) for start in right_hand.measure_starts.values()}
    candidates: list[EventBoundaryCandidate] = []
    for index, time in enumerate(sorted(times), start=1):
        matching = [event for event in events if abs(event.start - time) <= 1e-6]
        reasons: list[str] = []
        forced = abs(time) <= 1e-6
        if forced:
            reasons.append("piece_start")
        if any(abs(start - time) <= 1e-6 for start in right_hand.measure_starts.values()):
            reasons.append("measure_start")
        if any(event.kind == "note" and not event.is_rest and event.event_id.startswith(right_hand.track_id + ":") for event in matching):
            reasons.append("right_hand_note_onset")
        if any(event.kind == "note" and not event.is_rest and event.event_id.startswith(left_hand.track_id + ":") for event in matching):
            reasons.append("left_hand_note_onset")
        if any(event.kind == "note" and event.is_rest for event in matching):
            reasons.append("rest_onset")
        retained = time in fixed
        if retained:
            reasons.append("common_metric_window_boundary")
        confidence = 1.0 if forced else min(
            (0.42 if "measure_start" in reasons else 0.0)
            + (0.26 if "right_hand_note_onset" in reasons else 0.0)
            + (0.26 if "left_hand_note_onset" in reasons else 0.0)
            + (0.08 if "rest_onset" in reasons else 0.0)
            + (0.12 if retained else 0.0), 0.99,
        )
        candidates.append(EventBoundaryCandidate(
            boundary_id=f"EB{index:03d}", time=time, measure=_measure_for_time(right_hand, time),
            confidence=round(confidence, 3), reasons=tuple(reasons), forced=forced,
            fixed_two_beat_retained=retained,
            neighbouring_event_ids=tuple(event.event_id for event in matching),
        ))
    return [replace(candidate, next_time=candidates[index + 1].time if index + 1 < len(candidates) else None)
            for index, candidate in enumerate(candidates)]
