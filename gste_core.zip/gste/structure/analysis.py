from __future__ import annotations

from collections import defaultdict

from gste.core.models import NoteEvent
from gste.harmony.windows import HarmonyWindow
from gste.input.project_models import PianoSplitProject
from gste.structure.models import ArrangementSignal, PhraseRole, StructuralBoundary, StructureAnalysis

_EPS = 1e-9


def _clamp(value: float) -> float:
    return max(0.0, min(1.0, value))


def _measure_at(project: PianoSplitProject, time: float) -> int | None:
    result = None
    for measure, start in sorted(project.melody.measure_starts.items()):
        if start <= time + _EPS:
            result = measure
        else:
            break
    return result


def _melody_gap_boundaries(notes: list[NoteEvent], minimum_gap: float = 0.25) -> list[tuple[float, float, str]]:
    ordered = sorted(notes, key=lambda n: (n.start, n.pitch.midi))
    results: list[tuple[float, float, str]] = []
    for previous, current in zip(ordered, ordered[1:]):
        gap = current.start - (previous.start + previous.duration)
        if gap >= minimum_gap - _EPS:
            results.append((current.start, _clamp(0.55 + 0.25 * min(gap, 1.0)), "melody_rest"))
    return results


def _long_note_releases(notes: list[NoteEvent], threshold: float = 1.5) -> list[tuple[float, float, str]]:
    return [
        (note.start + note.duration, _clamp(0.45 + 0.12 * min(note.duration, 3.0)), "long_note_release")
        for note in notes
        if note.duration >= threshold
    ]


def _bass_changes(notes: list[NoteEvent]) -> list[tuple[float, float, str]]:
    by_start: dict[float, list[NoteEvent]] = defaultdict(list)
    for note in notes:
        by_start[note.start].append(note)
    events = [(time, min(group, key=lambda n: n.pitch.midi).pitch.midi % 12) for time, group in sorted(by_start.items())]
    results: list[tuple[float, float, str]] = []
    previous_pc = None
    for time, pitch_class in events:
        if previous_pc is not None and pitch_class != previous_pc:
            results.append((time, 0.52, "bass_change"))
        previous_pc = pitch_class
    return results


def detect_structural_boundaries(project: PianoSplitProject) -> tuple[StructuralBoundary, ...]:
    duration = project.melody.duration_quarters
    evidence: dict[float, list[tuple[float, str, bool]]] = defaultdict(list)
    evidence[0.0].append((1.0, "piece_start", True))
    evidence[duration].append((1.0, "piece_end", True))

    for measure, start in project.melody.measure_starts.items():
        if start > _EPS:
            evidence[start].append((0.42, "measure_boundary", False))

    for time, score, reason in _melody_gap_boundaries(project.melody.notes):
        evidence[time].append((score, reason, False))
    for time, score, reason in _long_note_releases(project.melody.notes):
        if time <= duration + _EPS:
            evidence[time].append((score, reason, False))
    for time, score, reason in _bass_changes(project.left_hand.notes):
        evidence[time].append((score, reason, False))

    boundaries: list[StructuralBoundary] = []
    for time in sorted(evidence):
        items = evidence[time]
        # Independent-evidence combination: several moderate cues create a strong boundary.
        combined = 1.0
        for score, _, _ in items:
            combined *= 1.0 - _clamp(score)
        score = 1.0 - combined
        reasons = tuple(dict.fromkeys(reason for _, reason, _ in items))
        hard = any(hard for _, _, hard in items)
        boundaries.append(
            StructuralBoundary(
                time=time,
                score=1.0 if hard else _clamp(score),
                reasons=reasons,
                measure=_measure_at(project, time),
                hard=hard,
            )
        )
    return tuple(boundaries)


def _nearest_score(boundaries: tuple[StructuralBoundary, ...], time: float, tolerance: float = 0.125) -> float:
    matches = [boundary.score for boundary in boundaries if abs(boundary.time - time) <= tolerance]
    return max(matches, default=0.0)


def _window_role(index: int, windows: list[HarmonyWindow], before: float, after: float) -> PhraseRole:
    if index == 0 or before >= 0.8:
        return PhraseRole.OPENING
    if index == len(windows) - 1:
        return PhraseRole.RELEASE
    if after >= 0.72:
        return PhraseRole.CADENTIAL
    return PhraseRole.CONTINUATION


def build_arrangement_signals(
    project: PianoSplitProject,
    windows: list[HarmonyWindow],
    boundaries: tuple[StructuralBoundary, ...],
) -> tuple[ArrangementSignal, ...]:
    signals: list[ArrangementSignal] = []
    for index, window in enumerate(windows):
        before = _nearest_score(boundaries, window.start)
        after = _nearest_score(boundaries, window.end)
        role = _window_role(index, windows, before, after)
        note_count = len(window.melody_notes)
        density = note_count / max(window.duration, 0.25)

        chord_change = _clamp(0.15 + 0.7 * before)
        position_change = _clamp(0.1 + 0.75 * before)
        if any(note.duration >= window.duration * 0.75 for note in window.melody_notes):
            position_change = _clamp(position_change + 0.12)

        base_density = 0.55
        if role == PhraseRole.OPENING:
            base_density = 0.45
        elif role == PhraseRole.CADENTIAL:
            base_density = 0.4
        elif role == PhraseRole.RELEASE:
            base_density = 0.25
        # Busy melody gets thinner accompaniment. This is advisory and cannot delete melody notes.
        accompaniment_density = _clamp(base_density - 0.08 * max(density - 1.5, 0.0))

        notes: list[str] = ["advisory_only", "melody_must_remain_complete", "playability_is_hard_constraint"]
        if before >= 0.65:
            notes.append("preferred_change_point")
        if role in {PhraseRole.CADENTIAL, PhraseRole.RELEASE}:
            notes.append("reduce_accompaniment_density")

        signals.append(
            ArrangementSignal(
                start=window.start,
                duration=window.duration,
                phrase_role=role,
                boundary_before=before,
                boundary_after=after,
                chord_change_suitability=chord_change,
                position_change_suitability=position_change,
                accompaniment_density=accompaniment_density,
                notes=tuple(notes),
            )
        )
    return tuple(signals)


def analyze_structure(project: PianoSplitProject, windows: list[HarmonyWindow]) -> StructureAnalysis:
    boundaries = detect_structural_boundaries(project)
    signals = build_arrangement_signals(project, windows, boundaries)
    return StructureAnalysis(boundaries=boundaries, signals=signals)
