from __future__ import annotations

"""Lightweight CAGED helpers for fingering selection.

This module intentionally starts with a pragmatic, fret-window based model.
It is not meant to be a complete music-theory engine yet; instead it gives
DP a guitarist-like bias: prefer to keep a phrase inside a nearby CAGED-shaped
region instead of jumping across unrelated fretboard areas.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class CagedRegion:
    shape: str
    low_fret: int
    high_fret: int

    @property
    def center_fret(self) -> float:
        return (self.low_fret + self.high_fret) / 2


# The windows overlap because real positions overlap. A fret can belong to more
# than one conceptual shape, so caged_shape_for_fret chooses the closest center.
CAGED_REGIONS: tuple[CagedRegion, ...] = (
    CagedRegion("C", 0, 3),
    CagedRegion("A", 3, 6),
    CagedRegion("G", 5, 8),
    CagedRegion("E", 7, 10),
    CagedRegion("D", 10, 13),
    CagedRegion("C", 12, 15),
    CagedRegion("A", 15, 18),
    CagedRegion("G", 17, 20),
)


CAGED_ORDER: tuple[str, ...] = ("C", "A", "G", "E", "D")


def caged_shape_for_fret(fret: int) -> str:
    """Return the most likely CAGED shape label for a fret.

    Open strings are treated as the low C-region because they often function as
    open-position resources. Frets above the defined windows continue the CAGED
    cycle approximately every five shapes.
    """
    if fret < 0:
        return "unknown"

    if fret <= CAGED_REGIONS[-1].high_fret:
        matching = [region for region in CAGED_REGIONS if region.low_fret <= fret <= region.high_fret]
        if matching:
            # Prefer the lower-position shape on overlaps. This mirrors the
            # MVP position-window logic and keeps phrase planning predictable.
            return matching[0].shape

    # Approximate high frets beyond the current MVP max_fret.
    index = max(0, round((fret - 12) / 3)) % len(CAGED_ORDER)
    return CAGED_ORDER[index]


def caged_region_for_fret(fret: int) -> CagedRegion | None:
    """Return the closest region object for reporting/planning."""
    if fret < 0:
        return None
    return min(CAGED_REGIONS, key=lambda region: min(abs(fret - region.low_fret), abs(fret - region.high_fret), abs(fret - region.center_fret)))


def shape_distance(left: str | None, right: str | None) -> int:
    """Circular distance in the CAGED cycle.

    Same shape = 0, neighboring shape in the CAGED cycle = 1. Unknown shapes
    are treated as moderately far so they do not dominate the optimizer.
    """
    if not left or not right or left == "unknown" or right == "unknown":
        return 2
    if left == right:
        return 0
    try:
        li = CAGED_ORDER.index(left)
        ri = CAGED_ORDER.index(right)
    except ValueError:
        return 2
    raw = abs(li - ri)
    return min(raw, len(CAGED_ORDER) - raw)
