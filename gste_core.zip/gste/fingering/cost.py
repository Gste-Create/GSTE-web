from __future__ import annotations

from gste.control import get_value
from gste.core.models import FingeringCandidate
from gste.fingering.caged import shape_distance


def score_candidate(candidate: FingeringCandidate) -> float:
    cost = 0.0

    if candidate.string in (1, 2, 3):
        cost += float(get_value("fingering.upper_string_reward", -3.0))
    elif candidate.string == 4:
        cost += float(get_value("fingering.middle_string_cost", 0.0))
    else:
        cost += float(get_value("fingering.lower_string_cost", 4.0))

    if candidate.fret == 0:
        cost += float(get_value("fingering.open_string_reward", -1.0))
    elif 1 <= candidate.fret <= 7:
        cost += float(get_value("fingering.low_fret_reward", -2.0))
    elif 8 <= candidate.fret <= 12:
        cost += float(get_value("fingering.mid_fret_cost", 0.0))
    elif 13 <= candidate.fret <= 17:
        cost += float(get_value("fingering.high_fret_cost", 3.0))
    else:
        cost += float(get_value("fingering.unusable_fret_cost", 9999.0))

    if candidate.caged_shape in {"C", "A", "G", "E", "D"}:
        cost += float(get_value("fingering.caged_shape_reward", -0.25))
    return cost


def score_transition(previous: FingeringCandidate, current: FingeringCandidate) -> float:
    cost = 0.0
    string_distance = abs(previous.string - current.string)
    fret_distance = abs(previous.fret - current.fret)
    position_distance = abs(previous.position_block - current.position_block)

    if string_distance == 0:
        cost += float(get_value("fingering.same_string_cost", 0.0))
    elif string_distance == 1:
        cost += float(get_value("fingering.adjacent_string_cost", 1.0))
    else:
        cost += float(get_value("fingering.far_string_cost", 3.0))

    if position_distance == 0:
        cost += float(get_value("fingering.same_position_reward", -2.0))
    elif position_distance == 1:
        cost += float(get_value("fingering.adjacent_position_cost", 1.0))
    elif position_distance == 2:
        cost += float(get_value("fingering.two_position_cost", 4.0))
    else:
        cost += float(get_value("fingering.far_position_cost", 10.0))

    if fret_distance > int(get_value("fingering.large_fret_jump_threshold", 7)):
        cost += float(get_value("fingering.large_fret_jump_cost", 5.0))

    caged_distance = shape_distance(previous.caged_shape, current.caged_shape)
    if caged_distance == 0:
        cost += float(get_value("fingering.same_caged_shape_reward", -1.5))
    elif caged_distance == 1:
        cost += float(get_value("fingering.caged_distance_1_cost", 0.5))
    elif caged_distance == 2:
        cost += float(get_value("fingering.caged_distance_2_cost", 2.0))
    else:
        cost += float(get_value("fingering.caged_far_cost", 4.0))
    return cost
