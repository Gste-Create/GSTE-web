from __future__ import annotations

from dataclasses import dataclass, field

from gste.harmony.models import ChordFamily


@dataclass(frozen=True)
class ChordShape:
    """A concrete left-hand realization for one chord family.

    ``frets`` maps guitar string number (1=highest) to fret. Missing strings are
    unused/muted. A melody note may temporarily replace an accompaniment tone;
    therefore the shape stores essential and optional strings separately.
    """

    name: str
    family: ChordFamily
    position: int
    frets: dict[int, int]
    fingers: dict[int, int] = field(default_factory=dict)
    essential_strings: frozenset[int] = frozenset()
    optional_strings: frozenset[int] = frozenset()
    barre_fret: int | None = None

    @property
    def open_strings(self) -> frozenset[int]:
        return frozenset(string for string, fret in self.frets.items() if fret == 0)

    @property
    def occupied_fingers(self) -> frozenset[int]:
        return frozenset(finger for finger in self.fingers.values() if finger > 0)

    @property
    def fret_span(self) -> int:
        fretted = [fret for fret in self.frets.values() if fret > 0]
        return 0 if not fretted else max(fretted) - min(fretted)


def shape_transition_cost(previous: ChordShape, current: ChordShape) -> float:
    """Estimate both vertical position movement and horizontal hand reconfiguration."""

    cost = 1.4 * abs(previous.position - current.position)
    shared_strings = set(previous.frets) & set(current.frets)

    for string in shared_strings:
        previous_fret = previous.frets[string]
        current_fret = current.frets[string]
        if previous_fret == current_fret:
            cost -= 0.8  # anchor/common tone
        else:
            cost += min(abs(previous_fret - current_fret), 5) * 0.35

    released = set(previous.frets) - set(current.frets)
    added = set(current.frets) - set(previous.frets)
    cost += 0.45 * (len(released) + len(added))

    if previous.barre_fret != current.barre_fret:
        if previous.barre_fret is None or current.barre_fret is None:
            cost += 1.5
        else:
            cost += 0.8

    cost += 0.35 * max(current.fret_span - 3, 0)
    return max(cost, 0.0)
