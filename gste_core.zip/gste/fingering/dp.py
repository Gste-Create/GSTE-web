from __future__ import annotations

from gste.core.models import FingeringCandidate, FingeringPath, NoteEvent
from gste.core.tuning import STANDARD_TUNING, Tuning
from gste.fingering.candidates import generate_candidates
from gste.fingering.cost import score_candidate, score_transition


def find_best_fingering(
    notes: list[NoteEvent],
    tuning: Tuning = STANDARD_TUNING,
    max_candidates: int = 5,
    max_fret: int = 17,
) -> FingeringPath:
    """Select the best fingering path using dynamic programming.

    Each note first keeps up to ``max_candidates`` playable string/fret options.
    DP then chooses the globally lowest-cost path, considering both per-note
    comfort and transitions between neighboring notes.
    """
    if not notes:
        return FingeringPath(candidates=[], total_cost=0.0, warnings=[], candidate_layers=[])

    all_candidates = [
        generate_candidates(note, max_fret=max_fret, tuning=tuning, max_candidates=max_candidates)
        for note in notes
    ]
    warnings: list[str] = []

    for index, candidates in enumerate(all_candidates):
        if not candidates:
            warnings.append(f"No playable candidate for note index {index}.")
            return FingeringPath(candidates=[], total_cost=float("inf"), warnings=warnings, candidate_layers=all_candidates)

    dp: list[dict[FingeringCandidate, tuple[float, FingeringCandidate | None]]] = []

    first_layer: dict[FingeringCandidate, tuple[float, FingeringCandidate | None]] = {}
    for candidate in all_candidates[0]:
        first_layer[candidate] = (score_candidate(candidate), None)
    dp.append(first_layer)

    for i in range(1, len(all_candidates)):
        layer: dict[FingeringCandidate, tuple[float, FingeringCandidate | None]] = {}

        for current in all_candidates[i]:
            best_cost = float("inf")
            best_previous: FingeringCandidate | None = None

            for previous, (previous_cost, _) in dp[i - 1].items():
                total = (
                    previous_cost
                    + score_candidate(current)
                    + score_transition(previous, current)
                )
                if total < best_cost:
                    best_cost = total
                    best_previous = previous

            layer[current] = (best_cost, best_previous)

        dp.append(layer)

    last_candidate, (total_cost, _) = min(dp[-1].items(), key=lambda item: item[1][0])

    path: list[FingeringCandidate] = [last_candidate]
    current = last_candidate

    for i in range(len(dp) - 1, 0, -1):
        previous = dp[i][current][1]
        if previous is None:
            break
        path.append(previous)
        current = previous

    path.reverse()

    return FingeringPath(candidates=path, total_cost=total_cost, warnings=warnings, candidate_layers=all_candidates)
