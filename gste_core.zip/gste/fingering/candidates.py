from __future__ import annotations

from gste.core.fretboard import midi_to_string_fret, position_block_for_fret
from gste.core.tuning import STANDARD_TUNING, Tuning
from gste.core.models import FingeringCandidate, NoteEvent
from gste.fingering.cost import score_candidate
from gste.fingering.caged import caged_shape_for_fret


def generate_candidates(
    note: NoteEvent,
    max_fret: int = 17,
    tuning: Tuning = STANDARD_TUNING,
    max_candidates: int | None = 5,
) -> list[FingeringCandidate]:
    """Generate playable string/fret candidates for one note.

    Candidates are scored locally, sorted from most to least preferred, and
    optionally truncated. Keeping several candidates instead of one is the
    foundation for the later melody + bass joint optimizer.
    """
    candidates: list[FingeringCandidate] = []

    for string, fret in midi_to_string_fret(note.pitch.midi, max_fret=max_fret, tuning=tuning):
        position = position_block_for_fret(fret)
        shape = caged_shape_for_fret(fret)
        base = FingeringCandidate(
            note=note,
            string=string,
            fret=fret,
            position_block=position,
            caged_shape=shape,
        )
        candidates.append(
            FingeringCandidate(
                note=note,
                string=string,
                fret=fret,
                position_block=position,
                caged_shape=shape,
                cost=score_candidate(base),
            )
        )

    candidates.sort(key=lambda c: (c.cost, c.position_block, c.fret, c.string))
    if max_candidates is not None and max_candidates > 0:
        return candidates[:max_candidates]
    return candidates
