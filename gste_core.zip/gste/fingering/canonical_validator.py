from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable


@dataclass(frozen=True)
class CanonicalHandNote:
    """Source-independent note used by every physical hand validator.

    `start`/`end` are absolute score times. String 1 is the highest/thinnest
    guitar string. Open strings remain part of string occupancy but are
    excluded from fretted-span and melody/accompaniment fret-distance costs.
    """
    role: str
    string: int
    fret: int
    start: float
    end: float
    pitch: int | None = None
    measure: int | None = None
    voice: str | int | None = None
    source_id: str | None = None


@dataclass(frozen=True)
class CanonicalHandViolation:
    violation_type: str
    time: float
    measure: int | None = None
    string: int | None = None
    span: int | None = None
    allowed_span: int | None = None
    highest_fret_string: int | None = None
    position: str | None = None
    distance: int | None = None
    melody_fret: int | None = None
    accompaniment_fret: int | None = None
    frets: tuple[int, ...] = ()
    active_notes: tuple[CanonicalHandNote, ...] = ()


def is_active_at(note: CanonicalHandNote, time: float, tolerance: float = 1e-6) -> bool:
    """Canonical GSTE sustain/active-hand contract.

    A note is physically sounding on the half-open interval [start, end).
    Fretted notes therefore continue to occupy the left hand until release.
    Open strings remain sounding/occupy their string, but never contribute to
    fretted-span or melody/accompaniment fret-distance calculations.
    """
    return note.start <= time + tolerance and note.end > time + tolerance


def active_notes_at(
    notes: Iterable[CanonicalHandNote], time: float, tolerance: float = 1e-6,
) -> tuple[CanonicalHandNote, ...]:
    """Return the one canonical sounding-hand snapshot used by every layer."""
    return tuple(n for n in notes if is_active_at(n, time, tolerance))


def timeline_boundaries(notes: Iterable[CanonicalHandNote]) -> tuple[float, ...]:
    """Every sounding-state boundary, not only note attacks.

    End boundaries are required because removing a high/low string can change
    which 4/3/2 directional allowance applies to the remaining fretted hand.
    """
    values = {round(float(n.start), 6) for n in notes}
    values.update(round(float(n.end), 6) for n in notes)
    return tuple(sorted(values))


def validate_canonical_snapshot(
    active_notes: Iterable[CanonicalHandNote],
    time: float,
    *,
    maximum_fret_distance: int = 4,
) -> tuple[CanonicalHandViolation, ...]:
    active = tuple(active_notes)
    if not active:
        return ()
    measure = max(active, key=lambda n: (n.start, -(n.measure or 0))).measure
    violations: list[CanonicalHandViolation] = []

    # Same string can sound only one fret at a time. Open + fretted on the same
    # string is also impossible while both serialized durations are active.
    by_string: dict[int, list[CanonicalHandNote]] = {}
    for note in active:
        by_string.setdefault(note.string, []).append(note)
    for string, string_notes in sorted(by_string.items()):
        frets = tuple(sorted({n.fret for n in string_notes}))
        if len(frets) > 1:
            violations.append(CanonicalHandViolation(
                'ACTIVE_STRING_OCCUPANCY', time, measure=measure, string=string,
                span=max(frets)-min(frets), frets=frets, active_notes=active,
            ))

    # 4/3/2 directional fretted-span invariant. Open strings do not participate
    # in the span and can never legalise a remote fretted shape such as 0/2/10.
    fretted = tuple(n for n in active if n.fret > 0)
    if fretted:
        low = min(n.fret for n in fretted)
        high = max(n.fret for n in fretted)
        span = high - low
        highest_fret_string = min(n.string for n in fretted if n.fret == high)
        highest_sounding_string = min(n.string for n in fretted)
        lowest_sounding_string = max(n.string for n in fretted)
        if highest_fret_string == highest_sounding_string:
            allowed, position = 4, 'highest_string'
        elif highest_fret_string == lowest_sounding_string:
            allowed, position = 2, 'lowest_string'
        else:
            allowed, position = 3, 'middle_string'
        if span > allowed:
            kind = 'SIMULTANEOUS_FRET_SPAN' if span >= 5 else 'DIRECTIONAL_SIMULTANEOUS_FRET_SPAN'
            violations.append(CanonicalHandViolation(
                kind, time, measure=measure, span=span, allowed_span=allowed,
                highest_fret_string=highest_fret_string, position=position,
                active_notes=active,
            ))

    # Melody/accompaniment relative position. This is a hard joint rule in the
    # current GSTE specification, separate from ordinary horizontal shift cost.
    melody = tuple(n for n in active if n.role == 'melody' and n.fret > 0)
    accompaniment = tuple(n for n in active if n.role == 'accompaniment' and n.fret > 0)
    if melody and accompaniment:
        distance, m, a = max(
            ((abs(m.fret-a.fret), m, a) for m in melody for a in accompaniment),
            key=lambda item: item[0],
        )
        if distance > maximum_fret_distance:
            violations.append(CanonicalHandViolation(
                'MELODY_ACCOMPANIMENT_FRET_DISTANCE', time, measure=a.measure or measure,
                string=a.string, distance=distance, melody_fret=m.fret,
                accompaniment_fret=a.fret, active_notes=active,
            ))
    return tuple(violations)


def validate_canonical_timeline(
    notes: Iterable[CanonicalHandNote],
    *,
    maximum_fret_distance: int = 4,
    tolerance: float = 1e-6,
) -> tuple[CanonicalHandViolation, ...]:
    """Single source of truth for all Candidate/Final/XML physical validation."""
    all_notes = tuple(notes)
    violations: list[CanonicalHandViolation] = []
    seen: set[tuple] = set()
    for time in timeline_boundaries(all_notes):
        active = active_notes_at(all_notes, time, tolerance)
        for issue in validate_canonical_snapshot(active, time, maximum_fret_distance=maximum_fret_distance):
            key = (
                issue.violation_type, round(issue.time, 6), issue.measure, issue.string,
                issue.span, issue.allowed_span, issue.distance,
            )
            if key not in seen:
                seen.add(key)
                violations.append(issue)
    return tuple(violations)


def validate_near_identical_attack_groups(
    notes: Iterable[CanonicalHandNote],
    *,
    attack_tolerance_quarters: float = 0.002,
    maximum_fret_distance: int = 4,
) -> tuple[CanonicalHandViolation, ...]:
    """Validate only attacks that are numerically near-identical.

    This replaces the old coarse 1/16-note bucket.  Notation/analysis grids
    (normally 1/32 note) are metadata only and must never turn sequential notes
    into simultaneous hand shapes.  ``attack_tolerance_quarters`` is intended
    only for float/serialization jitter (roughly 1-2 MusicXML ticks).
    """
    all_notes = tuple(notes)
    if not all_notes:
        return ()
    ordered = sorted(all_notes, key=lambda n: (float(n.start), n.measure or 0, n.string, n.fret))
    groups: list[list[CanonicalHandNote]] = []
    for note in ordered:
        if not groups or abs(float(note.start) - float(groups[-1][0].start)) > attack_tolerance_quarters:
            groups.append([note])
        else:
            groups[-1].append(note)
    out: list[CanonicalHandViolation] = []
    seen: set[tuple] = set()
    for group in groups:
        if len(group) < 2:
            continue
        time = min(n.start for n in group)
        for issue in validate_canonical_snapshot(group, time, maximum_fret_distance=maximum_fret_distance):
            key=(issue.violation_type, issue.measure, issue.span, issue.allowed_span, issue.distance, tuple(sorted((n.string,n.fret) for n in group)))
            if key not in seen:
                seen.add(key); out.append(issue)
    return tuple(out)
