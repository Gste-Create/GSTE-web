"""Phrase-scale, voice-aware melody-path beam search (v0.11.9)."""
from __future__ import annotations

from dataclasses import replace
from statistics import median

from gste.input.project_models import TrackData
from gste.melody_extraction.models import MelodyCandidate, MelodyExtractionDecision, MelodyExtractionResult, MelodyPathResult, MelodyPathSegment
from gste.melody_extraction.role_analysis import group_by_onset, role_for, score_note


def _voice_map(track: TrackData) -> dict[tuple[int, float, int, float], str | None]:
    """Recover MusicXML voice labels without changing the public NoteEvent model."""
    return {(e.measure or 0, round(e.start, 6), e.pitch_midi or -1, round(e.duration or 0.0, 6)): e.voice
            for e in track.events if e.kind == "note" and not e.is_rest and e.pitch_midi is not None}


def _key(note, voices):
    return (note.measure or 0, round(note.start, 6), note.pitch.midi, round(note.duration, 6))


def _transition(previous, current, voices, *, boundary: bool, register_stable: bool = False) -> tuple[float, tuple[str, ...]]:
    interval = abs(current.pitch.midi - previous.pitch.midi)
    cost = interval * (0.48 if register_stable else 0.22) + ((10.0 if register_stable else 2.4) if interval > 12 else 0.0) + ((18.0 if register_stable else 0.0) if interval > 19 else 0.0)
    reasons = ["interval"]
    pv, cv = voices.get(_key(previous, voices)), voices.get(_key(current, voices))
    if pv and cv and pv == cv:
        cost -= 3.0; reasons.append("same_voice_continuity")
    elif pv and cv and pv != cv:
        cost += 1.5 if boundary else 8.0; reasons.append("voice_switch" if boundary else "mid_phrase_voice_switch")
    if current.start - previous.start <= 2.0 and pv and cv and pv != cv:
        cost += 8.0; reasons.append("short_term_switch_risk")
    return cost, tuple(reasons)


def _segments(groups):
    """Safe baseline: two measures per path segment, boundaries are switch-friendly."""
    out, current, start_measure = [], [], None
    for group in groups:
        measure = group[0].measure or 1
        if current and start_measure is not None and measure - start_measure >= 2:
            out.append(current); current = []; start_measure = measure
        if start_measure is None: start_measure = measure
        current.append(group)
    if current: out.append(current)
    return out


def extract_melody_path(track: TrackData, *, beam_width: int = 12, alternatives: int = 3, register_stable: bool = False) -> MelodyPathResult:
    groups = group_by_onset(track.notes)
    if not groups:
        empty = MelodyExtractionResult(track, replace(track, track_id="melody_role_analysis", role="melody", notes=[]), (), 0, 0, 0, policy="phrase_path_beam_dp_register_stable" if register_stable else "phrase_path_beam_dp")
        return MelodyPathResult(empty, (), 0.0, None, 1.0, segments=())
    voices = _voice_map(track); median_duration = median([n.duration for n in track.notes])
    # A whole-piece voice role is deliberately only a tie-breaker.  It helps a
    # clear main line survive an ambiguous crossing but never overrides a real
    # phrase hand-off, rest, or local contour.
    voice_evidence: dict[str, float] = {}
    for group in groups:
        for note in group:
            voice = voices.get(_key(note, voices))
            if voice:
                note_score, _ = score_note(note, group, measure_start=track.measure_starts.get(note.measure or 1, 0.0))
                voice_evidence[voice] = voice_evidence.get(voice, 0.0) + max(note_score, 0.0)
    preferred_voice = max(voice_evidence, key=voice_evidence.get) if voice_evidence else None
    scored, candidates, decisions, kept, segment_reports = {}, [], [], [], []
    for index, segment in enumerate(_segments(groups), start=1):
        layers = []
        for group in segment:
            values = []
            for note in group:
                score, reasons = score_note(note, group, measure_start=track.measure_starts.get(note.measure or 1, 0.0))
                # A voice label is evidence only. Continuity dominates it after initialization.
                voice = voices.get(_key(note, voices))
                if voice is not None:
                    # The label is deliberately a soft prior: it only breaks
                    # an otherwise musically similar opening tie. Continuity,
                    # rhythm and phrase costs decide every later onset.
                    score += 12.0 if voice == "1" else 0.15
                    reasons = (*reasons, "xml_voice_available")
                    if preferred_voice and voice == preferred_voice:
                        score += 1.25
                        reasons = (*reasons, "global_voice_role_prior")
                scored[id(note)] = (score, reasons); values.append(note)
            onset = group[0].start
            active = [n for n in track.notes if n.start < onset and n.start + n.duration > onset + 1e-6]
            for note in active:
                if id(note) not in scored:
                    score, reasons = score_note(note, [note], measure_start=track.measure_starts.get(note.measure or 1, 0.0))
                    scored[id(note)] = (score + 1.5, (*reasons, "sustained_line_continuation"))
            layers.append([*values, *[n for n in active if n not in values]])
        # All path ranking below is a cost: lower is always better.  The local
        # role analyser returns a desirability score, hence its sign inversion.
        beam = [(-scored[id(note)][0], (note,), ()) for note in layers[0]]
        for layer in layers[1:]:
            expanded = []
            for prior_score, path, trail in beam:
                for note in layer:
                    transition, reasons = _transition(path[-1], note, voices, boundary=False, register_stable=register_stable)
                    # Penalize a held top pedal when the candidate is an active inner line.
                    pedal = 0.0
                    if note.duration >= max(2.0, median_duration * 2) and note.pitch.midi >= path[-1].pitch.midi and note.start > path[-1].start:
                        pedal = 3.0; reasons = (*reasons, "held_upper_pedal_risk")
                    expanded.append((prior_score - scored[id(note)][0] + transition + pedal, (*path, note), (*trail, reasons)))
            expanded.sort(key=lambda item: (item[0], tuple(n.pitch.midi for n in item[1])))
            beam = expanded[:beam_width]
        beam.sort(key=lambda item: (item[0], tuple(n.pitch.midi for n in item[1])))
        best_score, best_path, best_trail = beam[0]
        second_score = beam[1][0] if len(beam) > 1 else None
        gap = (second_score - best_score) if second_score is not None else 3.0
        confidence = max(0.0, min(1.0, gap / max(abs(best_score), 6.0)))
        alternatives_data = tuple(tuple((n.measure or 0, n.start, n.pitch.midi, voices.get(_key(n, voices))) for n in path) for _, path, _ in beam[:alternatives])
        selected_ids = {id(n) for n in best_path}
        for group, selected in zip(segment, best_path):
            decisions.append(MelodyExtractionDecision(selected.start, selected, tuple(n for n in group if n is not selected), "phrase_path_beam_dp"))
            kept.append(selected)
            total = sum(max(scored[id(n)][0], 0.1) for n in group)
            for note in group:
                score, reasons = scored[id(note)]
                local_confidence = max(0.0, min(1.0, max(score, 0.0) / total))
                candidates.append(MelodyCandidate(note, role_for(score, id(note) in selected_ids, local_confidence), score, local_confidence, reasons, note.pitch.midi == max(n.pitch.midi for n in group), voices.get(_key(note, voices))))
        component_counts = {"local_role_cost": 0.0, "transition_cost": 0.0, "global_voice_role_prior": 0.0}
        for note in best_path:
            component_counts["local_role_cost"] -= scored[id(note)][0]
            if preferred_voice and voices.get(_key(note, voices)) == preferred_voice:
                component_counts["global_voice_role_prior"] -= 1.25
        for previous, current in zip(best_path, best_path[1:]):
            component_counts["transition_cost"] += _transition(previous, current, voices, boundary=False, register_stable=register_stable)[0]
        # A 15% normalised margin is intentionally an advisory threshold: it
        # reports genuinely close routes without labelling every musical choice
        # low-confidence merely because a long phrase has a large total cost.
        segment_reports.append(MelodyPathSegment(index, segment[0][0].measure or 1, segment[-1][0].measure or 1, best_score, second_score, confidence, "MELODY_ROLE_AMBIGUOUS" if confidence < .15 else None, alternatives_data, tuple(voices.get(_key(n, voices)) for n in best_path), component_counts))
    unique = []
    seen = set()
    for note in kept:
        token = _key(note, voices)
        if token not in seen: seen.add(token); unique.append(note)
    melody = replace(track, track_id="melody_phrase_path", role="melody", notes=unique, warnings=[*track.warnings, "v0.11.9 phrase-scale melody path selected; accompaniment pipeline is unchanged."])
    extraction = MelodyExtractionResult(track, melody, tuple(decisions), len(track.notes), len(unique), len(track.notes)-len(unique), policy="phrase_path_beam_dp_register_stable" if register_stable else "phrase_path_beam_dp")
    best_total = sum(s.best_score for s in segment_reports); second_total = sum(s.second_score or s.best_score + 3 for s in segment_reports)
    return MelodyPathResult(extraction, tuple(candidates), best_total, second_total, second_total-best_total, segments=tuple(segment_reports))
