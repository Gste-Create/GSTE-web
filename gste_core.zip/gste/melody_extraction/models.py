from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from gste.core.models import NoteEvent
from gste.input.project_models import TrackData


@dataclass(frozen=True)
class MelodyExtractionDecision:
    onset: float
    kept_note: NoteEvent
    omitted_notes: tuple[NoteEvent, ...]
    rule: str = "highest_pitch_at_onset"


@dataclass(frozen=True)
class MelodyExtractionResult:
    source_track: TrackData
    melody_track: TrackData
    decisions: tuple[MelodyExtractionDecision, ...]
    source_note_count: int
    kept_note_count: int
    omitted_note_count: int
    policy: str = "highest_pitch_at_each_onset"
    advisory_only: bool = False

    @property
    def kept_ratio(self) -> float:
        return 1.0 if self.source_note_count == 0 else self.kept_note_count / self.source_note_count


class MelodyRole(StrEnum):
    PRIMARY_MELODY = "PRIMARY_MELODY"
    PROBABLE_MELODY = "PROBABLE_MELODY"
    AMBIGUOUS_UPPER_VOICE = "AMBIGUOUS_UPPER_VOICE"
    ACCOMPANIMENT_OR_DECORATION = "ACCOMPANIMENT_OR_DECORATION"


@dataclass(frozen=True)
class MelodyCandidate:
    note: NoteEvent
    role: MelodyRole
    score: float
    confidence: float
    reasons: tuple[str, ...] = ()
    is_highest_at_onset: bool = False
    source_voice: str | None = None

@dataclass(frozen=True)
class MelodyPathSegment:
    index: int
    start_measure: int
    end_measure: int
    best_score: float
    second_score: float | None
    confidence: float
    flag: str | None
    alternatives: tuple[tuple[tuple[int, float, int, str | None], ...], ...]
    primary_voices: tuple[str | None, ...]
    cost_breakdown: dict[str, float] | None = None


@dataclass(frozen=True)
class MelodyPathResult:
    extraction: MelodyExtractionResult
    candidates: tuple[MelodyCandidate, ...]
    best_path_score: float
    second_path_score: float | None
    confidence_gap: float
    fallback_used: bool = False
    segments: tuple[MelodyPathSegment, ...] = ()
