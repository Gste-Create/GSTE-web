from __future__ import annotations

from dataclasses import replace

from gste.input.project_models import TrackData
from gste.melody_extraction.models import MelodyExtractionDecision, MelodyExtractionResult


def extract_source_identity(track: TrackData) -> MelodyExtractionResult:
    """AUTO_MELODY-only identity extractor.

    The user's melody score is authoritative.  Do not run piano role/voice
    inference on it.  Preserve every structural source attack exactly; grace
    notes remain auditable in TrackData.events and are removed later by the
    shared grace-normalization step without changing the structural timeline.
    """
    structural = [n for n in track.notes if n.duration > 0]
    melody_track = replace(
        track,
        track_id="melody_source_identity",
        role="melody",
        notes=sorted(structural, key=lambda n: (n.start, n.pitch.midi, n.duration)),
        warnings=[*track.warnings, "v0.13.5.12.6.2 AUTO_MELODY source-identity passthrough; piano melody extraction bypassed."],
    )
    decisions = tuple(
        MelodyExtractionDecision(n.start, n, (), "source_identity_passthrough")
        for n in melody_track.notes
    )
    return MelodyExtractionResult(
        source_track=track,
        melody_track=melody_track,
        decisions=decisions,
        source_note_count=len(structural),
        kept_note_count=len(structural),
        omitted_note_count=0,
        policy="source_identity_passthrough",
    )
