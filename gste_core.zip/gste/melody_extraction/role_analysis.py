"""Explainable, rule-based melody-role scoring for a piano right hand."""
from __future__ import annotations

from collections import defaultdict

from gste.core.models import NoteEvent
from gste.melody_extraction.models import MelodyCandidate, MelodyRole


def group_by_onset(notes: list[NoteEvent]) -> list[list[NoteEvent]]:
    groups: dict[float, list[NoteEvent]] = defaultdict(list)
    for note in notes:
        groups[round(note.start, 6)].append(note)
    return [groups[key] for key in sorted(groups)]


def score_note(note: NoteEvent, group: list[NoteEvent], *, measure_start: float = 0.0) -> tuple[float, tuple[str, ...]]:
    highest = max(item.pitch.midi for item in group)
    score = 0.0
    reasons: list[str] = []
    if note.pitch.midi == highest:
        score += 2.0; reasons.append("highest_at_onset")
    elif note.pitch.midi >= highest - 5:
        score += 1.0; reasons.append("near_upper_voice")
    if note.duration >= 1.0:
        score += 2.0; reasons.append("stable_duration")
    elif note.duration >= 0.5:
        score += 0.8; reasons.append("medium_duration")
    else:
        score -= 1.2; reasons.append("short_note_decoration_risk")
    beat = (note.start - measure_start) % 1.0
    if abs(beat) < 1e-6:
        score += 0.7; reasons.append("strong_beat")
    if note.duration <= 0.25 and note.pitch.midi == highest:
        score -= 1.0; reasons.append("brief_high_note_risk")
    if note.duration >= 2.0 and note.pitch.midi == highest and len(group) > 1:
        # A held top chord tone is often a right-hand pad while a lower voice
        # carries the moving tune.  This is evidence, never a hard exclusion.
        score -= 1.5; reasons.append("held_upper_chord_tone_risk")
    return score, tuple(reasons)


def role_for(score: float, selected: bool, confidence: float) -> MelodyRole:
    if selected and confidence >= 0.72:
        return MelodyRole.PRIMARY_MELODY
    if selected:
        return MelodyRole.PROBABLE_MELODY
    if score >= 1.5 or confidence >= 0.35:
        return MelodyRole.AMBIGUOUS_UPPER_VOICE
    return MelodyRole.ACCOMPANIMENT_OR_DECORATION
