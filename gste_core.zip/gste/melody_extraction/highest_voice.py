from __future__ import annotations

from dataclasses import replace

from gste.input.project_models import TrackData
from gste.melody_extraction.models import MelodyExtractionDecision, MelodyExtractionResult


def extract_highest_voice(track: TrackData, *, onset_tolerance: float = 1e-6) -> MelodyExtractionResult:
    """Reduce a polyphonic right-hand track to one highest note per onset.

    This intentionally simple MVP policy does not claim to identify an inner-voice
    melody. Source notes remain available in the result for audit and reporting.
    """
    ordered = sorted(track.notes, key=lambda n: (n.start, -n.pitch.midi, -n.duration))
    groups: list[list] = []
    for note in ordered:
        if not groups or abs(note.start - groups[-1][0].start) > onset_tolerance:
            groups.append([note])
        else:
            groups[-1].append(note)

    decisions: list[MelodyExtractionDecision] = []
    kept = []
    for group in groups:
        ranked = sorted(group, key=lambda n: (n.pitch.midi, n.duration), reverse=True)
        winner = ranked[0]
        omitted = tuple(note for note in ranked[1:])
        kept.append(winner)
        decisions.append(MelodyExtractionDecision(onset=winner.start, kept_note=winner, omitted_notes=omitted))

    melody_track = replace(
        track,
        track_id="melody_reduced",
        role="melody",
        notes=sorted(kept, key=lambda n: (n.start, n.pitch.midi)),
        warnings=[
            *track.warnings,
            "MVP melody reduction applied: retained only the highest pitched note at each onset.",
        ],
    )
    return MelodyExtractionResult(
        source_track=track,
        melody_track=melody_track,
        decisions=tuple(decisions),
        source_note_count=len(track.notes),
        kept_note_count=len(kept),
        omitted_note_count=len(track.notes) - len(kept),
    )
