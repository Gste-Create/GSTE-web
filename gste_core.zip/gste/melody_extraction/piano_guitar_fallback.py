"""Auditable SOURCE_PIANO fallback for octave-doubled / extreme right-hand writing.

This module never changes a source note's pitch.  It may select a different
source note at the same onset (prefer the lower member of an octave doubling)
or classify an isolated extreme event as secondary material.  It is invoked
only after the normal melody path proves that no global guitar transform is
physically valid.
"""
from __future__ import annotations
from dataclasses import replace
from gste.input.project_models import TrackData
from gste.melody_extraction.melody_path import extract_melody_path


def extract_guitar_feasible_piano_melody(track: TrackData):
    base = extract_melody_path(track, beam_width=18, alternatives=5, register_stable=True)
    groups: dict[float, list] = {}
    for n in track.notes:
        groups.setdefault(round(float(n.start), 6), []).append(n)
    selected = list(base.extraction.melody_track.notes)
    out = []
    actions = []
    for i, note in enumerate(selected):
        group = groups.get(round(float(note.start), 6), [note])
        # If the source explicitly contains an octave-equivalent note at this
        # onset, prefer the lower source member in the guitar-feasibility retry.
        same_pc_lower = [n for n in group if n.pitch.midi < note.pitch.midi and (note.pitch.midi - n.pitch.midi) % 12 == 0]
        if same_pc_lower:
            replacement = max(same_pc_lower, key=lambda n: n.pitch.midi)
            actions.append({"measure": note.measure, "start": note.start, "action": "SELECT_LOWER_SOURCE_OCTAVE_DOUBLING",
                            "from_midi": note.pitch.midi, "to_midi": replacement.pitch.midi,
                            "from_event": note.source_event_id, "to_event": replacement.source_event_id})
            out.append(replacement)
            continue
        prev_pitch = out[-1].pitch.midi if out else None
        next_pitch = selected[i+1].pitch.midi if i+1 < len(selected) else None
        # A lone event >19 semitones above both neighboring selected source
        # events, with no octave partner, is treated as secondary/ornamental.
        # We omit it rather than inventing a locally octave-shifted melody note.
        if prev_pitch is not None and next_pitch is not None and (
            (note.pitch.midi - prev_pitch > 19 and note.pitch.midi - next_pitch > 19)
            or (note.pitch.midi >= 100 and prev_pitch < 90)
        ):
            actions.append({"measure": note.measure, "start": note.start, "action": "CLASSIFY_ISOLATED_EXTREME_AS_SECONDARY",
                            "pitch_midi": note.pitch.midi, "event": note.source_event_id})
            continue
        out.append(note)
    melody = replace(base.extraction.melody_track, track_id="piano_guitar_feasible_melody", notes=out,
                     warnings=[*base.extraction.melody_track.warnings,
                               "v0.13.4 SOURCE_PIANO guitar-feasibility fallback selected source octave-doubling members; no source pitch was altered."])
    return melody, tuple(actions), base
