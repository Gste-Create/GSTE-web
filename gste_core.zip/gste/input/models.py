from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum


class InputKind(StrEnum):
    """User-facing source categories supported by the GSTE roadmap."""

    LEAD_SHEET = "lead_sheet"
    KEYBOARD_SCORE = "keyboard_score"
    BAND_SCORE = "band_score"
    EXISTING_TAB = "existing_tab"
    MELODY_XML = "melody_xml"


@dataclass(frozen=True)
class InputProfile:
    """Normalized description of an input before conversion starts.

    `source_kind` describes where the score came from. `normalized_kind`
    describes what the current executable pipeline can consume after manual or
    automatic preprocessing.
    """

    source_kind: InputKind
    normalized_kind: InputKind
    requires_manual_review: bool = False
    selected_parts: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()
    metadata: dict[str, str] = field(default_factory=dict)
