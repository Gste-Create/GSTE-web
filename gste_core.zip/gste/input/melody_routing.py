from __future__ import annotations
from dataclasses import dataclass
from typing import Literal
MelodyRoute=Literal["MELODY_RECOMPUTE_FINGERING","MELODY_USE_SOURCE_FINGERING"]
@dataclass(frozen=True)
class MelodyRouteDecision:
    route: MelodyRoute
    user_selected_source_fingering: bool
    reason: str

def resolve_melody_route(*, use_source_fingering: bool=False)->MelodyRouteDecision:
    if use_source_fingering:
        return MelodyRouteDecision("MELODY_USE_SOURCE_FINGERING",True,"User explicitly selected the source fingering as usable; validation/fallback remains separate.")
    return MelodyRouteDecision("MELODY_RECOMPUTE_FINGERING",False,"Default route ignores source fingering quality and recomputes fingering.")
