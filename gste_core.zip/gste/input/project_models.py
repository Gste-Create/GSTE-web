from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from gste.core.models import NoteEvent
from gste.input.musical_events import MusicalEvent


@dataclass(frozen=True)
class TimeSignatureChange:
    start: float
    beats: int
    beat_type: int
    measure: int

    @property
    def measure_quarters(self) -> float:
        return self.beats * (4.0 / self.beat_type)


@dataclass(frozen=True)
class KeySignatureChange:
    """Literal source declaration; missing mode is not an implied major key."""
    start: float
    measure: int
    fifths: int | None
    mode: str | None
    mode_explicit: bool

    @property
    def declared_key(self) -> tuple[int, str] | None:
        if self.fifths is None or not self.mode_explicit or self.mode not in {"major", "minor"}:
            return None
        return ((7*self.fifths+(9 if self.mode=="minor" else 0))%12,self.mode)


@dataclass(frozen=True)
class TrackData:
    track_id: str
    role: str
    source_file: Path
    notes: list[NoteEvent]
    measure_starts: dict[int, float]
    measure_lengths: dict[int, float]
    time_signatures: list[TimeSignatureChange]
    duration_quarters: float
    warnings: list[str] = field(default_factory=list)
    events: list[MusicalEvent] = field(default_factory=list)
    # MusicXML display labels are presentation metadata only. Internal measure
    # identity/time uses physical document order so repeated/non-numeric labels
    # can never overwrite timeline state.
    measure_display_labels: dict[int, str] = field(default_factory=dict)

    # Compatibility view: populated only by an explicit supported initial mode.
    declared_key: tuple[int, str] | None = None
    key_signatures: tuple[KeySignatureChange, ...] = ()
    # Original signature facts stay unchanged when a working track is transposed.
    pitch_transposition_semitones: int = 0

    # Derived only by the shared source-grid authority; immutable group records.
    metric_groups: tuple = field(init=False, default=())

    def __post_init__(self):
        if self.key_signatures:
            initial=self.initial_key_signature
            object.__setattr__(self,"declared_key",initial.declared_key if initial else None)
        from gste.structure.metric import build_metric_groups
        object.__setattr__(self, "metric_groups", build_metric_groups(
            self.measure_starts, self.measure_lengths, self.time_signatures))

    @property
    def initial_key_signature(self) -> KeySignatureChange | None:
        initial=[s for s in self.key_signatures if abs(s.start) <= 1e-9]
        return initial[-1] if initial else None

    @property
    def measure_count(self) -> int:
        return len(self.measure_starts)


@dataclass(frozen=True)
class PianoSplitProject:
    melody: TrackData
    left_hand: TrackData
