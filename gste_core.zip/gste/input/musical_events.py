"""Lossless-for-audit MusicXML event records used before musical reduction.

This module deliberately stores source events rather than interpreting them as
melody or harmony.  Later versions may make decisions from these records, but
v0.11.1 must not use them to change the existing arrangement algorithm.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class MusicalEvent:
    """One direct MusicXML measure event on the shared quarter-note timeline.

    ``source_xml`` preserves the complete original element for audit, including
    notation that this version does not yet understand.
    """

    event_id: str
    kind: str
    start: float
    duration: float | None
    measure: int
    order: int
    voice: str | None = None
    staff: str | None = None
    pitch_midi: int | None = None
    is_rest: bool = False
    is_chord_tone: bool = False
    tie_types: tuple[str, ...] = ()
    chord_id: str | None = None
    is_grace: bool = False
    source_xml: str = ""
