from __future__ import annotations

from dataclasses import dataclass
from dataclasses import replace

from gste.core.models import NoteEvent, Pitch
from gste.core.tuning import STANDARD_TUNING, Tuning
from gste.fingering.dp import find_best_fingering


@dataclass(frozen=True)
class ShiftResult:
    semitone_shift: int
    score: float
    warnings: list[str]


def transpose_notes(notes: list[NoteEvent], semitone_shift: int) -> list[NoteEvent]:
    return [
        replace(
            note,
            pitch=Pitch(
                midi=note.pitch.midi + semitone_shift,
                name=f"{note.pitch.name or note.pitch.midi}{semitone_shift:+d}",
            ),
            string=None,
            fret=None,
        )
        for note in notes
    ]


def find_best_shift(notes: list[NoteEvent], candidate_shifts: range = range(-12, 1), tuning: Tuning = STANDARD_TUNING) -> ShiftResult:
    """Find a practical whole-melody transposition for fingerstyle TAB MVP.

    This MVP scores each candidate shift by running the existing DP fingering
    engine. Unplayable notes receive a very large penalty. Lower cost is better.
    """
    if not notes:
        return ShiftResult(semitone_shift=0, score=0.0, warnings=["No notes provided."])

    best: ShiftResult | None = None
    for shift in candidate_shifts:
        shifted_notes = transpose_notes(notes, shift)
        path = find_best_fingering(shifted_notes, tuning=tuning)
        warning_penalty = len(path.warnings) * 1000
        score = path.total_cost + warning_penalty
        result = ShiftResult(semitone_shift=shift, score=score, warnings=path.warnings)
        if best is None or result.score < best.score:
            best = result

    assert best is not None
    return best
