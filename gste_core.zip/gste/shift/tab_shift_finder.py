from __future__ import annotations

from dataclasses import dataclass, replace

from gste.core.fretboard import position_block_for_fret
from gste.core.models import FingeringCandidate, FingeringPath, NoteEvent, Pitch
from gste.core.tuning import STANDARD_TUNING, Tuning
from gste.fingering.cost import score_candidate, score_transition
from gste.shift.shift_finder import ShiftResult, find_best_shift, transpose_notes


@dataclass(frozen=True)
class TabShiftPathResult:
    semitone_shift: int
    path: FingeringPath
    used_fallback: bool


def shift_tab_notes_same_strings(notes: list[NoteEvent], semitone_shift: int, max_fret: int = 17, tuning: Tuning = STANDARD_TUNING) -> FingeringPath:
    """Shift an existing TAB by moving frets on the same strings.

    A semitone shift maps directly to a fret delta when the string is preserved:
    1st string fret 12 shifted by -5 becomes 1st string fret 7. This preserves
    the original TAB shape as much as possible. If any note would leave the
    playable fret range, the returned path has infinite cost and warnings.
    """
    candidates: list[FingeringCandidate] = []
    warnings: list[str] = []

    for index, note in enumerate(notes):
        if note.string is None or note.fret is None:
            warnings.append(f"Missing TAB fingering for note index {index}.")
            return FingeringPath(candidates=[], total_cost=float("inf"), warnings=warnings)

        # Preserve the physical string while recalculating the fret from the
        # target pitch and selected tuning. In standard tuning this equals
        # note.fret + semitone_shift; in Drop D/custom tuning it correctly
        # accounts for changed open-string pitches.
        target_midi = note.pitch.midi + semitone_shift
        try:
            new_fret = target_midi - tuning.open_midi(note.string)
        except KeyError:
            warnings.append(f"Invalid string {note.string} for selected tuning at note index {index}.")
            return FingeringPath(candidates=[], total_cost=float("inf"), warnings=warnings)
        if new_fret < 0 or new_fret > max_fret:
            warnings.append(
                f"Shift {semitone_shift:+d} makes note index {index} invalid: "
                f"string {note.string}, fret {new_fret}."
            )
            return FingeringPath(candidates=[], total_cost=float("inf"), warnings=warnings)

        shifted_note = replace(
            note,
            pitch=Pitch(
                midi=target_midi,
                name=f"{note.pitch.name or note.pitch.midi}{semitone_shift:+d}",
            ),
            fret=new_fret,
        )
        candidates.append(
            FingeringCandidate(
                note=shifted_note,
                string=note.string,
                fret=new_fret,
                position_block=position_block_for_fret(new_fret),
            )
        )

    total_cost = 0.0
    for i, candidate in enumerate(candidates):
        total_cost += score_candidate(candidate)
        if i > 0:
            total_cost += score_transition(candidates[i - 1], candidate)

    return FingeringPath(candidates=candidates, total_cost=total_cost, warnings=warnings)


def find_best_tab_shift(
    notes: list[NoteEvent],
    candidate_shifts: range = range(-12, 1),
    max_fret: int = 17,
    allow_fallback: bool = True,
    tuning: Tuning = STANDARD_TUNING,
) -> TabShiftPathResult:
    """Find the best shift for an existing TAB score.

    First, try preserving the original strings and TAB shape. If no same-string
    shift is playable and allow_fallback is true, fall back to the melody-mode
    shift finder plus DP fingering regeneration.
    """
    best_shift = 0
    best_path: FingeringPath | None = None

    for shift in candidate_shifts:
        path = shift_tab_notes_same_strings(notes, shift, max_fret=max_fret, tuning=tuning)
        if path.total_cost == float("inf"):
            continue
        if best_path is None or path.total_cost < best_path.total_cost:
            best_shift = shift
            best_path = path

    if best_path is not None:
        return TabShiftPathResult(semitone_shift=best_shift, path=best_path, used_fallback=False)

    if not allow_fallback:
        return TabShiftPathResult(
            semitone_shift=0,
            path=FingeringPath(candidates=[], total_cost=float("inf"), warnings=["No playable same-string TAB shift found."]),
            used_fallback=False,
        )

    melody_notes = [replace(note, string=None, fret=None) for note in notes]
    shift_result: ShiftResult = find_best_shift(melody_notes, candidate_shifts=candidate_shifts, tuning=tuning)
    shifted_notes = transpose_notes(melody_notes, shift_result.semitone_shift)

    from gste.fingering.dp import find_best_fingering

    fallback_path = find_best_fingering(shifted_notes, tuning=tuning)
    fallback_path = replace(
        fallback_path,
        warnings=[
            *fallback_path.warnings,
            "Same-string TAB shift was not playable; regenerated fingering with DP fallback.",
            *shift_result.warnings,
        ],
    )
    return TabShiftPathResult(semitone_shift=shift_result.semitone_shift, path=fallback_path, used_fallback=True)
