from __future__ import annotations

from dataclasses import dataclass

from gste.core.models import NoteEvent


@dataclass(frozen=True)
class MelodyAnalysis:
    lowest_midi: int
    highest_midi: int
    lowest_fret: int | None
    highest_fret: int | None
    note_count: int


def analyze_melody(notes: list[NoteEvent]) -> MelodyAnalysis:
    if not notes:
        raise ValueError("Cannot analyze an empty note list.")

    midi_values = [note.pitch.midi for note in notes]
    frets = [note.fret for note in notes if note.fret is not None]

    return MelodyAnalysis(
        lowest_midi=min(midi_values),
        highest_midi=max(midi_values),
        lowest_fret=min(frets) if frets else None,
        highest_fret=max(frets) if frets else None,
        note_count=len(notes),
    )
