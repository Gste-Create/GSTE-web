from __future__ import annotations

import xml.etree.ElementTree as ET


def physical_measure_extent(measure: ET.Element, *, divisions: float, expected_quarters: float | None) -> float:
    """Return the physical MusicXML cursor extent of one measure in quarter notes.

    This is the single low-level rule used by Parser, Exporter and independent
    Export Integrity. Meter is context/minimum only; it never replaces the
    actual note/backup/forward cursor extent. Grace notes are zero-time and
    chord members do not advance the cursor.
    """
    divisions = max(float(divisions), 1.0)
    cursor = 0.0
    furthest = 0.0
    for element in list(measure):
        if element.tag in {"backup", "forward"}:
            amount = float(element.findtext("duration", "0") or 0.0) / divisions
            cursor += amount if element.tag == "forward" else -amount
            cursor = max(0.0, cursor)
            furthest = max(furthest, cursor)
            continue
        if element.tag != "note":
            continue
        if element.find("grace") is not None or element.find("chord") is not None:
            continue
        duration = float(element.findtext("duration", "0") or 0.0) / divisions
        cursor += duration
        furthest = max(furthest, cursor)
    return max(furthest, float(expected_quarters)) if expected_quarters is not None else furthest
