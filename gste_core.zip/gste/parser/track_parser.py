from __future__ import annotations

from pathlib import Path
from dataclasses import replace
import xml.etree.ElementTree as ET

from gste.core.models import NoteEvent
from gste.input.musical_events import MusicalEvent
from gste.input.project_models import KeySignatureChange, TimeSignatureChange, TrackData
from gste.parser.musicxml_parser import _pitch_to_midi, _strip_namespace
from gste.parser.physical_timeline import physical_measure_extent




def _merge_tie_chain_durations(notes: list[NoteEvent], events: list[MusicalEvent]) -> list[NoteEvent]:
    """Return structural notes with tie chains collapsed into one sounding interval.

    The parser remains the only authority for melody time.  Tie continuation
    XML elements are notation segments, not new structural attacks.  A tie-start
    note therefore keeps its original ``source_event_id`` but its duration is
    extended through every contiguous stop/start continuation of the same
    voice+pitch.
    """
    note_events = [
        e for e in events
        if e.kind == "note" and not e.is_rest and not e.is_grace
        and e.pitch_midi is not None and e.duration is not None
    ]
    by_signature: dict[tuple[int, float, int], list[MusicalEvent]] = {}
    for event in note_events:
        key=(event.measure, round(float(event.start), 9), int(event.pitch_midi))
        by_signature.setdefault(key, []).append(event)
    ordered=sorted(note_events, key=lambda e:(e.start,e.measure,e.order))
    out=[]
    for note in notes:
        key=(note.measure or 0, round(float(note.start),9), int(note.pitch.midi))
        candidates=by_signature.get(key, [])
        start_event=next((e for e in candidates if "start" in e.tie_types), None)
        if start_event is None:
            out.append(note); continue
        release=float(note.start)+float(note.duration)
        voice=start_event.voice
        cursor=release
        # A tie continuation must begin exactly where the previous segment ends.
        # Use a tiny parser tolerance only for decimal conversion noise.
        while True:
            cont=next((e for e in ordered
                       if e is not start_event
                       and e.voice == voice
                       and int(e.pitch_midi or -999) == int(note.pitch.midi)
                       and "stop" in e.tie_types
                       and abs(float(e.start)-cursor) <= 1e-9), None)
            if cont is None:
                break
            seg=float(cont.duration or 0.0)
            cursor=float(cont.start)+seg
            release=max(release,cursor)
            if "start" not in cont.tie_types:
                break
            start_event=cont
        out.append(replace(note, duration=max(0.0, release-float(note.start))))
    return out

def _measure_number(measure: ET.Element, fallback: int) -> int:
    text = measure.attrib.get("number")
    try:
        return int(text) if text else fallback
    except ValueError:
        return fallback


def parse_musicxml_track(path: str | Path, *, track_id: str, role: str) -> TrackData:
    """Parse the first MusicXML part as one independently exported track.

    The parser supports simultaneous chord tones, rests, backup/forward cursor
    movement, divisions changes, and time-signature metadata. All times are in
    quarter-note units so separately exported tracks can share one timeline.
    """
    xml_path = Path(path)
    if not xml_path.exists():
        raise FileNotFoundError(xml_path)

    root = ET.parse(xml_path).getroot()
    _strip_namespace(root)
    parts = root.findall("part")
    if not parts:
        raise ValueError(f"No <part> elements found in {xml_path}")

    notes: list[NoteEvent] = []
    events: list[MusicalEvent] = []
    measure_starts: dict[int, float] = {}
    measure_lengths: dict[int, float] = {}
    measure_display_labels: dict[int, str] = {}
    time_signatures: list[TimeSignatureChange] = []
    key_signatures: list[KeySignatureChange] = []
    warnings: list[str] = []

    divisions = 1.0
    beats = 4
    beat_type = 4
    absolute_measure_start = 0.0

    # v0.13.5.13.5: immutable source identity is assigned exactly once,
    # in raw MusicXML <note> document order. Display measure/time/pitch are data,
    # never part of identity.
    source_measures = parts[0].findall("measure")
    source_note_serial = 0

    for measure_index, measure in enumerate(source_measures, start=1):
        # v0.13.5.15.5.4 sandbox: internal measure identity is the physical
        # MusicXML <measure> document order. Display labels (e.g. 0, 20X1)
        # are presentation metadata and must never key timeline dictionaries.
        number = measure_index
        measure_display_labels[number] = str(measure.attrib.get("number", measure_index))
        measure_starts[number] = absolute_measure_start
        cursor = 0.0
        last_note_onset = 0.0
        furthest_cursor = 0.0

        attributes = measure.find("attributes")
        if attributes is not None:
            divisions_text = attributes.findtext("divisions")
            if divisions_text:
                divisions = float(divisions_text)
            time_element = attributes.find("time")
            if time_element is not None:
                new_beats = int(time_element.findtext("beats", str(beats)))
                new_beat_type = int(time_element.findtext("beat-type", str(beat_type)))
                if new_beats != beats or new_beat_type != beat_type or not time_signatures:
                    beats, beat_type = new_beats, new_beat_type
                    time_signatures.append(
                        TimeSignatureChange(
                            start=absolute_measure_start,
                            beats=beats,
                            beat_type=beat_type,
                            measure=number,
                        )
                    )

        for element_order, element in enumerate(list(measure), start=1):
            duration_text = element.findtext("duration")
            raw_duration = float(duration_text) if duration_text else None
            event_duration = raw_duration / divisions if raw_duration is not None else None
            is_note = element.tag == "note"
            if is_note:
                source_note_serial += 1
            source_note_id = f"{track_id}:N{source_note_serial:06d}" if is_note else f"{track_id}:X{measure_index:04d}:{element_order:04d}"
            is_chord_tone = is_note and element.find("chord") is not None
            event_onset = last_note_onset if is_chord_tone else cursor
            pitch_element = element.find("pitch") if is_note else None
            tie_types = tuple(sorted({
                tie.attrib.get("type", "")
                for tie in [*element.findall("tie"), *element.findall("notations/tied")]
                if tie.attrib.get("type")
            })) if is_note else ()
            is_grace = is_note and element.find("grace") is not None
            if is_grace:
                event_duration = 0.0
            chord_id = f"{track_id}:M{number}:T{event_onset:g}" if is_note else None
            resolved_event_id = source_note_id
            events.append(
                MusicalEvent(
                    event_id=resolved_event_id,
                    kind=element.tag,
                    start=absolute_measure_start + event_onset,
                    duration=event_duration,
                    measure=number,
                    order=element_order,
                    voice=element.findtext("voice") if is_note else None,
                    staff=element.findtext("staff") if is_note else None,
                    pitch_midi=_pitch_to_midi(pitch_element).midi if pitch_element is not None else None,
                    is_rest=is_note and element.find("rest") is not None,
                    is_chord_tone=is_chord_tone,
                    tie_types=tie_types,
                    chord_id=chord_id,
                    is_grace=is_grace,
                    source_xml=ET.tostring(element, encoding="unicode"),
                )
            )
            if element.tag == "attributes":
                for key in element.findall("key"):
                    fifths_text=key.findtext("fifths")
                    mode_element=key.find("mode")
                    mode=(mode_element.text or "").strip().lower() if mode_element is not None else None
                    key_signatures.append(KeySignatureChange(
                        absolute_measure_start+cursor,number,
                        int(fifths_text) if fifths_text is not None else None,
                        mode or None,mode_element is not None))
                    if mode_element is not None and mode not in {"major","minor"}:
                        warnings.append(f"Measure {number}: key mode {mode or '(empty)'} is not a supported major/minor declaration.")
                continue
            if element.tag in {"backup", "forward"}:
                duration_text = element.findtext("duration")
                amount = (float(duration_text) if duration_text else 0.0) / divisions
                cursor += amount if element.tag == "forward" else -amount
                cursor = max(cursor, 0.0)
                furthest_cursor = max(furthest_cursor, cursor)
                continue
            if element.tag != "note":
                continue

            # v0.13.5.12.4: MusicXML grace notes are zero-time decorative
            # notation for the structural timeline.  They may omit <duration>
            # (or some exporters may include one), but they must never advance
            # the parser cursor or inflate measure_starts.
            is_grace = element.find("grace") is not None
            raw_duration = 0.0 if is_grace else (float(duration_text) if duration_text else divisions)
            duration = raw_duration / divisions
            is_chord_tone = element.find("chord") is not None
            onset = last_note_onset if is_chord_tone else cursor
            if not is_chord_tone:
                last_note_onset = onset

            is_rest = element.find("rest") is not None
            # A note carrying tie-stop is a continuation segment, not a new
            # structural attack.  This includes the middle segment of a chain
            # (stop+start).  Its immutable Source Event remains in `events`;
            # `_merge_tie_chain_durations` extends the chain head through it.
            # Keeping stop+start here as a second NoteEvent would create two
            # overlapping Canonical sounding identities for one explicit tie.
            is_tie_continuation = element.find("tie[@type='stop']") is not None
            pitch_element = element.find("pitch")
            if not is_rest and not is_tie_continuation and pitch_element is not None:
                resolved_event_id = source_note_id
                notes.append(
                    NoteEvent(
                        pitch=_pitch_to_midi(pitch_element),
                        start=absolute_measure_start + onset,
                        duration=duration,
                        measure=number,
                        source_event_id=resolved_event_id,
                    )
                )

            if not is_chord_tone and not is_grace:
                cursor += duration
                furthest_cursor = max(furthest_cursor, cursor)

        # v0.13.5.15.4: if the source has never declared a meter, do not
        # invent a 4/4 measure grid. The MusicXML cursor is the timeline.
        metered = bool(time_signatures)
        expected_length = beats * (4.0 / beat_type) if metered else None
        actual_length = physical_measure_extent(
            measure, divisions=divisions, expected_quarters=expected_length
        )
        measure_lengths[number] = actual_length
        if metered and abs(actual_length - expected_length) > 1e-6:
            warnings.append(
                f"Measure {number} occupies {actual_length:g} quarters; time signature implies {expected_length:g}."
            )
        absolute_measure_start += actual_length

    if not notes:
        raise ValueError(f"No pitched notes found in {xml_path}")

    # v0.13.5.13.3: freeze the real sounding duration at parse time.  Downstream
    # layers must never discover a longer tie release on their own.
    notes = _merge_tie_chain_durations(notes, events)

    return TrackData(
        track_id=track_id,
        role=role,
        source_file=xml_path,
        notes=notes,
        measure_starts=measure_starts,
        measure_lengths=measure_lengths,
        time_signatures=time_signatures,
        duration_quarters=absolute_measure_start,
        warnings=warnings,
        events=events,
        measure_display_labels=measure_display_labels,
        key_signatures=tuple(key_signatures),
    )
