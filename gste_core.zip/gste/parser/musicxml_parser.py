from __future__ import annotations

from pathlib import Path
import xml.etree.ElementTree as ET

from gste.core.models import NoteEvent, Pitch

_STEP_TO_SEMITONE = {
    "C": 0,
    "D": 2,
    "E": 4,
    "F": 5,
    "G": 7,
    "A": 9,
    "B": 11,
}


def _strip_namespace(root: ET.Element) -> None:
    """Remove XML namespaces in-place so simple tag searches work."""
    for elem in root.iter():
        if "}" in elem.tag:
            elem.tag = elem.tag.split("}", 1)[1]


def _pitch_to_midi(pitch_element: ET.Element) -> Pitch:
    step = pitch_element.findtext("step")
    octave_text = pitch_element.findtext("octave")
    alter_text = pitch_element.findtext("alter")

    if step is None or octave_text is None:
        raise ValueError("Pitch element must contain step and octave.")
    if step not in _STEP_TO_SEMITONE:
        raise ValueError(f"Unsupported pitch step: {step}")

    alter = int(float(alter_text)) if alter_text is not None else 0
    octave = int(octave_text)
    midi = (octave + 1) * 12 + _STEP_TO_SEMITONE[step] + alter

    name = step
    if alter == 1:
        name += "#"
    elif alter == -1:
        name += "b"
    elif alter:
        name += f"{alter:+}"
    name += str(octave)

    return Pitch(midi=midi, name=name)
