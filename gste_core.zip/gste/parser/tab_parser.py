from __future__ import annotations

from pathlib import Path
import xml.etree.ElementTree as ET

from gste.core.models import NoteEvent, Pitch
from gste.parser.musicxml_parser import _pitch_to_midi, _strip_namespace


def parse_tab_musicxml(path: str | Path) -> list[NoteEvent]:
    """Parse pitched notes plus TAB string/fret data from MusicXML.

    The parser supports the common MusicXML layout used by MuseScore and many
    guitar-score exporters, where TAB information is stored at:

        note/notations/technical/string
        note/notations/technical/fret

    Duration and start are returned in quarter-note units, matching
    parse_musicxml_track(). Chords are preserved as separate notes sharing the
    same onset; rests and tie stop-only notes are skipped.
    """
    xml_path = Path(path)
    if not xml_path.exists():
        raise FileNotFoundError(xml_path)

    root = ET.parse(xml_path).getroot()
    _strip_namespace(root)

    notes: list[NoteEvent] = []
    current_start = 0.0
    divisions = 1.0

    parts = root.findall("part")
    if not parts:
        raise ValueError("No <part> elements found in MusicXML file.")

    for measure_index, measure in enumerate(parts[0].findall("measure"), start=1):
        measure_number_text = measure.attrib.get("number")
        try:
            measure_number = int(measure_number_text) if measure_number_text else measure_index
        except ValueError:
            measure_number = measure_index

        attributes = measure.find("attributes")
        if attributes is not None:
            divisions_text = attributes.findtext("divisions")
            if divisions_text:
                divisions = float(divisions_text)

        for note_element in measure.findall("note"):
            duration_text = note_element.findtext("duration")
            raw_duration = float(duration_text) if duration_text else divisions
            duration = raw_duration / divisions

            is_chord_tone = note_element.find("chord") is not None
            is_rest = note_element.find("rest") is not None
            tied_stop_only = (
                note_element.find("tie[@type='stop']") is not None
                and note_element.find("tie[@type='start']") is None
            )

            if not is_rest and not tied_stop_only:
                pitch_element = note_element.find("pitch")
                string_text = note_element.findtext("notations/technical/string")
                fret_text = note_element.findtext("notations/technical/fret")
                if pitch_element is not None and string_text is not None and fret_text is not None:
                    try:
                        string = int(string_text)
                        fret = int(fret_text)
                    except ValueError as exc:
                        raise ValueError(f"Invalid TAB string/fret value in {xml_path}.") from exc

                    notes.append(
                        NoteEvent(
                            pitch=_pitch_to_midi(pitch_element),
                            start=current_start,
                            duration=duration,
                            measure=measure_number,
                            string=string,
                            fret=fret,
                        )
                    )

            if not is_chord_tone:
                current_start += duration

    if not notes:
        raise ValueError("No TAB notes with string/fret found in MusicXML file.")

    return notes


def has_tab_fingerings(path: str | Path) -> bool:
    """Return True when a MusicXML file appears to contain TAB string/fret data."""
    xml_path = Path(path)
    if not xml_path.exists():
        raise FileNotFoundError(xml_path)

    root = ET.parse(xml_path).getroot()
    _strip_namespace(root)
    return root.find(".//notations/technical/string") is not None and root.find(".//notations/technical/fret") is not None
