"""Bounded, read-only presentation layer for existing user reports.

No conversion or diagnostic callbacks are made here. Rendering errors never retry conversion.
"""
from pathlib import Path
import re

LANGS = {'zh_TW','en','ja'}
TEXT = {
'zh_TW': {'title':'轉換結果總覽','success':'成功','failure':'失敗','summary':'結果摘要','locations':'診斷記錄的位置','caution':'以下為搜尋候選或檢查器記錄的位置，並非已確認的唯一根因。','next':'建議下一步','next_text':'先確認原譜音域、允許品格與八度配置；若仍失敗，將隱私安全除錯報告提供給開發者。','review':'人工檢查清單','review_note':'此清單是需要檢視的記錄，不等於已證實的編曲錯誤。','conversion':'轉換摘要','privacy':'隱私安全除錯摘要','raw':'原始診斷內容（保留以利追查）','none':'未提供可核對的位置','more':'其餘記錄請參閱下方原始診斷。','reason':'失敗原因','stage':'失敗階段'},
'en': {'title':'Conversion overview','success':'Succeeded','failure':'Failed','summary':'Summary','locations':'Recorded diagnostic locations','caution':'These locations belong to search candidates or review records; they are not proven unique root causes.','next':'Suggested next steps','next_text':'Check source pitch range, allowed frets, and octave options. If the issue persists, share the privacy-safe debug report with the developer.','review':'Manual review checklist','review_note':'Review entries are not confirmed arrangement errors.','conversion':'Conversion summary','privacy':'Privacy-safe debug summary','raw':'Original diagnostics (preserved for troubleshooting)','none':'No verifiable location was recorded','more':'See the original diagnostics below for additional entries.','reason':'Failure reason','stage':'Failure stage'},
'ja': {'title':'変換結果の概要','success':'成功','failure':'失敗','summary':'結果の概要','locations':'診断で記録された位置','caution':'以下は探索候補や検査結果の位置であり、唯一の根本原因と確定したものではありません。','next':'推奨される対応','next_text':'原譜の音域、使用可能なフレット数、オクターブ設定を確認してください。解決しない場合は、個人情報に配慮したデバッグレポートを開発者に共有してください。','review':'手動確認リスト','review_note':'確認対象は編曲ミスが確定した箇所ではありません。','conversion':'変換の概要','privacy':'プライバシー配慮型デバッグ概要','raw':'元の診断内容（調査用に保持）','none':'確認可能な位置情報はありません','more':'残りの記録は以下の元の診断を参照してください。','reason':'失敗理由','stage':'失敗した段階'}
}

def render_reports(run_dir, *, language='zh_TW'):
    """Present existing reports without touching the diagnostic files or conversion state."""
    root=Path(run_dir)
    t=TEXT.get(language,TEXT['zh_TW'])
    names={'ERROR_REPORT.md':('title','failure'), 'HUMAN_REVIEW_REPORT.md':('review',None), 'CONVERSION_REPORT.md':('conversion',None), 'PRIVACY_SAFE_DEBUG_REPORT.md':('privacy',None)}
    for filename,(heading,status) in names.items():
        path=root/filename
        if not path.is_file(): continue
        original=path.read_text(encoding='utf-8')
        # Idempotent: do not nest wrappers when presentation is run again.
        marker='<!-- GSTE_REPORT_PRESENTATION_V1 -->'
        if marker in original:
            original=original.split('<!-- GSTE_ORIGINAL_REPORT_START -->',1)[-1]
            original=original.rsplit('<!-- GSTE_ORIGINAL_REPORT_END -->',1)[0].strip('\n')
        original=original.strip('\n')
        locations=[]
        if filename=='ERROR_REPORT.md':
            for line in original.splitlines():
                if line.startswith('- ') and ('原譜小節' in line or 'measure' in line.lower()):
                    locations.append(line)
        pre=[marker, f'# {t[heading]}', '',f'**GSTE · {language}**', '']
        if status:
            pre += [f'**{t["summary"]}：{t[status]}**','',f'> {t["caution"]}','']
            for label,key in [('失敗階段：','stage'),('直接原因：','reason')]:
                found=next((line[len(label):].strip() for line in original.splitlines() if line.startswith(label)),None)
                if found:
                    translated={'NO_VALID_GLOBAL_TRANSFORM':{'en':'No valid global transform was found.','ja':'有効な全体変換候補が見つかりませんでした。'},'UNSPELLABLE_NOTATED_DURATION':{'en':'Some durations cannot be represented in notation.','ja':'一部の音価を楽譜に表記できません。'}}
                    for code,local in translated.items():
                        if code in found: found=local.get(language,found)
                    pre += [f'**{t[key]}:** {found}','']
            if locations:
                pre += [f'## {t["locations"]}','']+locations[:12]+['']
                if len(locations)>12: pre += [f'*{t["more"]}*','']
            else: pre += [f'{t["none"]}','']
            pre += [f'## {t["next"]}', '', t['next_text'], '']
        elif filename=='HUMAN_REVIEW_REPORT.md':
            pre += [f'> {t["review_note"]}','']
        pre += [f'## {t["raw"]}', '', '<!-- GSTE_ORIGINAL_REPORT_START -->',original,'<!-- GSTE_ORIGINAL_REPORT_END -->','']
        path.write_text('\n'.join(pre),encoding='utf-8')
