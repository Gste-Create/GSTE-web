from __future__ import annotations

from pathlib import Path

from gste.arrangement.auto.config import AutoArrangementConfig, DEFAULT_CONFIG
from gste.arrangement.auto.service import analyze_and_arrange_melody


class MelodyOnlySourceAdapter:
    """Melody-only front end feeding the shared guitar arrangement core.

    The adapter owns source-specific analysis entry only. Guitar accompaniment
    realization is delegated to :mod:`gste.arrangement.guitar`.
    """

    instrument_family = "MELODY_ONLY"

    def analyze(
        self,
        notes,
        source: str | Path,
        *,
        pattern: str = "auto",
        config: AutoArrangementConfig = DEFAULT_CONFIG,
    ):
        return analyze_and_arrange_melody(
            notes,
            source,
            pattern=pattern,
            config=config,
        )
