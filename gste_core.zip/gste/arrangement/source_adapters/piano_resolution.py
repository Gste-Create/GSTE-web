from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class BassResolution:
    primary_pitch: int | None
    repaired: bool
    reason: str


def _raw_primary(analysis):
    return analysis.bass_sequence[0] if analysis.bass_sequence else None


def resolve_bass_primaries(analyses) -> tuple[BassResolution,...]:
    """Repair only isolated register excursions using source-note alternatives.

    The resolver never invents pitches.  It may replace the first attack's bass
    with another actual bass attack from the same window when the first value
    jumps >12 semitones away from both neighbouring windows and an alternative
    in the current window restores voice continuity.
    """
    raw=[_raw_primary(a) for a in analyses]
    out=[]
    for i,a in enumerate(analyses):
        primary=raw[i]
        if primary is None or i==0 or i==len(analyses)-1 or raw[i-1] is None or raw[i+1] is None:
            out.append(BassResolution(primary,False,"RAW_PRIMARY")); continue
        prev,nxt=raw[i-1],raw[i+1]
        neighbour_consistent=abs(prev-nxt)<=7
        isolated=abs(primary-prev)>12 and abs(primary-nxt)>12 and neighbour_consistent
        if not isolated:
            out.append(BassResolution(primary,False,"RAW_PRIMARY")); continue
        alternatives=sorted(set(a.bass_sequence))
        if not alternatives:
            out.append(BassResolution(primary,False,"RAW_PRIMARY")); continue
        target=(prev+nxt)/2.0
        best=min(alternatives,key=lambda p:(abs(p-target),abs(p-primary)))
        if best!=primary and abs(best-prev)<=7 and abs(best-nxt)<=7:
            out.append(BassResolution(best,True,"ISOLATED_REGISTER_EXCURSION_REPAIRED_FROM_SAME_WINDOW_SOURCE"))
        else:
            out.append(BassResolution(primary,False,"NO_SAFE_CONTINUITY_REPAIR"))
    return tuple(out)


def classify_bass_harmony_role(pitch_class:int|None, root:int, *, previous_pc:int|None=None, next_pc:int|None=None) -> tuple[str,str]:
    if pitch_class is None:
        return "UNKNOWN","NO_BASS"
    interval=(pitch_class-root)%12
    if interval==0:return "ROOT","CHORD_TONE"
    if interval in (3,4):return "THIRD","INVERSION_CHORD_TONE"
    if interval in (6,7,8):return "FIFTH","INVERSION_CHORD_TONE"
    if interval in (10,11):return "SEVENTH","INVERSION_CHORD_TONE"
    if previous_pc is not None and next_pc is not None:
        # Pedal: same non-chord bass persists while harmony moves.
        if pitch_class==previous_pc==next_pc:
            return "NON_CHORD_OR_EXTENSION","PEDAL_BASS_CANDIDATE"
        # Passing/approach: semitone/whole-tone connection between neighbours.
        d1=min((pitch_class-previous_pc)%12,(previous_pc-pitch_class)%12)
        d2=min((next_pc-pitch_class)%12,(pitch_class-next_pc)%12)
        if d1<=2 and d2<=2:
            return "NON_CHORD_OR_EXTENSION","PASSING_OR_APPROACH_BASS_CANDIDATE"
    return "NON_CHORD_OR_EXTENSION","UNRESOLVED_NON_CHORD_BASS"
