from __future__ import annotations
from gste.arrangement.canonical import BassIntent

class BassSourceAdapter:
    instrument_family="BASS"
    def analyze_track(self, track, *, user_weight: float=1.0):
        notes=sorted(track.notes, key=lambda n:(n.start,n.pitch.midi))
        out=[]
        for i,n in enumerate(notes):
            nxt=notes[i+1].pitch.midi if i+1<len(notes) else n.pitch.midi
            d=nxt-n.pitch.midi
            motion="STATIC_BASS" if d==0 else ("STEPWISE_BASS" if abs(d)<=2 else "MOVING_BASS")
            out.append(BassIntent(f"BASS:{i:05d}",n.start,n.duration,n.pitch.midi,n.pitch.midi%12,motion,"STRUCTURAL",confidence=min(1.0,user_weight),sequence=(n.pitch.midi,),reasons=("Dedicated bass-family track supplied structural bass evidence.",)))
        return tuple(out)
