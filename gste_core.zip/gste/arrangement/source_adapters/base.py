from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol, Any

@dataclass(frozen=True)
class InstrumentContribution:
    instrument_id: str
    instrument_family: str
    user_weight: float = 1.0
    payload: Any = None

class SourceAdapter(Protocol):
    instrument_family: str
    def analyze(self, *args, **kwargs): ...
