from __future__ import annotations
from gste.arrangement.canonical import RhythmIntent, TextureIntent

class RhythmGuitarSourceAdapter:
    instrument_family="GUITAR"
    def analyze_track(self, track, *, user_weight: float=1.0):
        groups={}
        for n in track.notes: groups.setdefault(round(n.start,6),[]).append(n)
        onsets=sorted(groups)
        if not onsets: return (),()
        start=onsets[0]; end=max(n.start+n.duration for n in track.notes); dur=max(.25,end-start)
        sizes=tuple(len(groups[x]) for x in onsets)
        pattern="CHORD_PULSE" if max(sizes,default=0)>=2 else "SINGLE_LINE_PULSE"
        r=RhythmIntent("GUITAR:ALL",start,dur,tuple(round(x-start,6) for x in onsets),sizes,"SD3",confidence=min(1.0,user_weight))
        t=TextureIntent("GUITAR:ALL",start,dur,pattern,"SD3",True,confidence=min(1.0,user_weight),reasons=("Rhythm-guitar adapter exports rhythmic/texture intent, not literal guitar fingering.",))
        return (r,),(t,)
