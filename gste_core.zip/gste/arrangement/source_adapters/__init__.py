"""Source-adapter public API with lazy concrete-adapter loading.

Only contracts are imported eagerly. Concrete instrument adapters are loaded on
first access so adding future band/orchestra adapters cannot create package
initialization cycles.
"""
from .base import SourceAdapter, InstrumentContribution

_LAZY = {
    "PianoAccompanimentAdapter": (".piano", "PianoAccompanimentAdapter"),
    "PianoAnalysisBundle": (".piano", "PianoAnalysisBundle"),
    "EnsembleSourceAdapter": (".ensemble", "EnsembleSourceAdapter"),
    "EnsembleTrackSpec": (".ensemble", "EnsembleTrackSpec"),
    "BassSourceAdapter": (".bass", "BassSourceAdapter"),
    "RhythmGuitarSourceAdapter": (".rhythm_guitar", "RhythmGuitarSourceAdapter"),
    "StringSectionSourceAdapter": (".strings", "StringSectionSourceAdapter"),
    "MelodyOnlySourceAdapter": (".melody_only", "MelodyOnlySourceAdapter"),
}


def __getattr__(name):
    if name not in _LAZY:
        raise AttributeError(name)
    from importlib import import_module
    module_name, attr_name = _LAZY[name]
    value = getattr(import_module(module_name, __name__), attr_name)
    globals()[name] = value
    return value


__all__ = [
    "SourceAdapter", "InstrumentContribution",
    "PianoAccompanimentAdapter", "PianoAnalysisBundle",
    "EnsembleSourceAdapter", "EnsembleTrackSpec",
    "BassSourceAdapter", "RhythmGuitarSourceAdapter",
    "StringSectionSourceAdapter", "MelodyOnlySourceAdapter",
]
