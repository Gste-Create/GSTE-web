from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class EnsembleTrackSpec:
    track_id: str
    instrument_family: str
    user_weight: float = 1.0

class EnsembleSourceAdapter:
    """Multi-track front door for future band/orchestra scores.

    v0.13.6 establishes weighted contributions without forcing literal notes into
    the guitar layer. Individual family adapters own preprocessing; intent fusion
    is deliberately source-independent.
    """
    instrument_family="ENSEMBLE"
    def __init__(self, adapters: dict[str, object] | None=None):
        self.adapters=adapters or {}
    def analyze_tracks(self, tracks: dict[str, object], specs: tuple[EnsembleTrackSpec,...]):
        result=[]
        for spec in specs:
            adapter=self.adapters.get(spec.instrument_family)
            if adapter is None or spec.track_id not in tracks:
                continue
            fn=getattr(adapter,"analyze_track",None)
            if fn is not None:
                result.append((spec,fn(tracks[spec.track_id],user_weight=spec.user_weight)))
        return tuple(result)
