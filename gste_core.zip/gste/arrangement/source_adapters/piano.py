from __future__ import annotations
from dataclasses import asdict, dataclass
from gste.arrangement.canonical import HarmonyIntent,BassIntent,RhythmIntent,TextureIntent,CanonicalArrangementIntent,SourceEvidence
from gste.arrangement.guitar.harmony_adapter import build_chord_intent
from gste.arrangement.source.analyzer import analyze_piano_source_patterns
from gste.phrase_understanding import build_phrase_understanding
from gste import tonality
from gste.arrangement.canonical.model import SourceTone
from .piano_resolution import resolve_bass_primaries, classify_bass_harmony_role

@dataclass(frozen=True)
class PianoAnalysisBundle:
    harmony: tuple[HarmonyIntent,...]
    bass: tuple[BassIntent,...]
    rhythm: tuple[RhythmIntent,...]
    texture: tuple[TextureIntent,...]
    canonical: tuple[CanonicalArrangementIntent,...]
    phrase_plan: object
    tonality_analysis: tonality.TonalityAnalysis | None = None


def analyze_piano_accompaniment(project, *, quarters_per_window:float=2.0, chord_top_k:int=3, minimum_context_measures:int=2):
    key_analysis=tonality.analyze_tonality(project.melody.notes,project.melody)
    analyses=analyze_piano_source_patterns(project,quarters_per_window=quarters_per_window,chord_top_k=chord_top_k)
    phrases=build_phrase_understanding(project,analyses,minimum_measures=minimum_context_measures)
    phrase_by_window={wid:p for p in phrases.phrases for wid in p.window_ids}
    bass_resolutions=resolve_bass_primaries(analyses)
    resolved_pcs=[r.primary_pitch%12 if r.primary_pitch is not None else None for r in bass_resolutions]

    hs=[]; bs=[]; rs=[]; ts=[]; cs=[]
    for i,a in enumerate(analyses):
        root=phrases.harmonic_roots[i] if i<len(phrases.harmonic_roots) else a.root_pitch_class
        quality=phrases.harmonic_qualities[i] if i<len(phrases.harmonic_qualities) else a.chord_quality
        symbol=phrases.harmonic_symbols[i] if i<len(phrases.harmonic_symbols) else (a.chord_symbol if root==a.root_pitch_class else f"PC{root}:{quality}")
        harmony_resolution_reason=(phrases.harmony_resolution_reasons[i] if i<len(phrases.harmony_resolution_reasons) else "LOCAL_ANALYSIS")
        primary=bass_resolutions[i].primary_pitch
        bpc=resolved_pcs[i]
        prev_pc=resolved_pcs[i-1] if i>0 else None
        next_pc=resolved_pcs[i+1] if i+1<len(resolved_pcs) else None
        role,bass_context=classify_bass_harmony_role(bpc,root,previous_pc=prev_pc,next_pc=next_pc)

        chord=build_chord_intent(
            chord_symbol=symbol,root_pc=root,quality=quality,bass_motion=a.bass_motion,
            source_bass_pc=bpc,
            bass_policy_override=("LOCK_ROOT_BASS" if phrases.structural_bass_flags[i] else None),
        )
        required=tuple(sorted((root+j)%12 for j in chord.required_intervals))
        optional=tuple(sorted((root+j)%12 for j in chord.optional_intervals))
        color=tuple(sorted((root+j)%12 for j in chord.color_intervals))

        # Chord-tone inversions and context-supported pedal/passing bass are structural.
        structural=(
            "STRUCTURAL" if (
                phrases.structural_bass_flags[i]
                or role in {"ROOT","THIRD","FIFTH","SEVENTH"}
                or bass_context in {"PEDAL_BASS_CANDIDATE","PASSING_OR_APPROACH_BASS_CANDIDATE"}
            ) else "NON_STRUCTURAL"
        )
        h=HarmonyIntent(
            a.window_id,a.start,a.duration,root,symbol,quality,a.harmony_confidence,
            required,optional,color,role,
            reasons=("Harmony is estimated from the complete harmonic window; bass pitch never directly defines chord root.",)
        )
        b_reasons=["Bass voice is tracked independently before Bass/Harmony relation resolution.",f"Bass context={bass_context}."]
        if bass_resolutions[i].repaired:
            b_reasons.append("Isolated register excursion was repaired using an actual bass attack from the same source window.")
        b=BassIntent(
            a.window_id,a.start,a.duration,primary,bpc,a.bass_motion,structural,role,
            min(1.0,max(.35,a.pattern_confidence)),a.bass_sequence,tuple(b_reasons)
        )
        r=RhythmIntent(a.window_id,a.start,a.duration,a.rhythm_pattern,a.attack_sizes,a.density,accent_positions=((0.0,) if a.rhythm_pattern else ()),confidence=a.pattern_confidence)
        t=TextureIntent(a.window_id,a.start,a.duration,a.pattern_type,a.density,a.pattern_type in {"BASS_CHORD_PULSE","ROOT_PULSE","ARPEGGIO","TRIPLET_ARPEGGIO","COMPOUND_ARPEGGIO","ALBERTI_BASS"},phrase_by_window.get(a.window_id).phrase_id if a.window_id in phrase_by_window else "",a.pattern_confidence,a.reasons)
        ev=SourceEvidence(project.left_hand.role,project.left_hand.track_id,min(a.harmony_confidence,a.pattern_confidence),1.0,{"local_window":a.window_id,"bass_resolution":bass_resolutions[i].reason,"bass_context":bass_context}, tuple(n.event_id for n in a.notes))
        c=CanonicalArrangementIntent(
            a.window_id,h,b,r,t,phrase_by_window.get(a.window_id),(ev,),
            {
                "harmony_note_evidence": [asdict(row) for row in a.harmony_note_evidence],
                "metric_group_refs": list(a.metric_group_refs),
                "metric_group_patterns": list(a.metric_group_patterns),
                "metric_group_attack_counts": list(a.metric_group_attack_counts),
                "repeated_metric_pattern": a.repeated_metric_pattern,
                "bass_policy":chord.bass_policy,
                "minimum_context_measures":minimum_context_measures,
                "bass_resolution":bass_resolutions[i].reason,
                "bass_context":bass_context,
                "harmony_root_smoothed":root!=a.root_pitch_class,
                "harmony_family_context_resolved": (root!=a.root_pitch_class or quality!=a.chord_quality),
                "harmony_resolution_reason": harmony_resolution_reason,
            }, observations=a.notes, functional_roles=a.functional_role_sequence,
            source_tones=tuple(SourceTone(o.event_id,o.onset,o.duration,o.pitch,o.measure or 1,
                "bass" if o.is_bass else "chord_tone") for o in a.notes
                if o.event_id not in {n.source_event_id for n in project.left_hand.notes
                    if str(n.arrangement_role or "").startswith("melody_priority_")})
        )
        hs.append(h);bs.append(b);rs.append(r);ts.append(t);cs.append(c)
    return tuple(analyses), PianoAnalysisBundle(tuple(hs),tuple(bs),tuple(rs),tuple(ts),tuple(cs),phrases,key_analysis)

class PianoAccompanimentAdapter:
    instrument_family="PIANO_ACCOMPANIMENT"
    def analyze(self,project,**kwargs): return analyze_piano_accompaniment(project,**kwargs)
