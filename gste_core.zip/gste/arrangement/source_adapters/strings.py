from __future__ import annotations
from gste.arrangement.canonical import RhythmIntent, TextureIntent

class StringSectionSourceAdapter:
    instrument_family="STRINGS"
    def analyze_track(self, track, *, user_weight: float=1.0):
        groups={}
        for n in track.notes: groups.setdefault(round(n.start,6),[]).append(n)
        onsets=sorted(groups)
        if not onsets: return (),()
        start=onsets[0]; end=max(n.start+n.duration for n in track.notes); dur=max(.25,end-start)
        sizes=tuple(len(groups[x]) for x in onsets)
        texture="SUSTAINED_HARMONY" if sum(n.duration for n in track.notes)/max(1,len(track.notes))>=1.0 else "MOVING_INNER_VOICE"
        return ((RhythmIntent("STRINGS:ALL",start,dur,tuple(round(x-start,6) for x in onsets),sizes,"SD2",confidence=min(1.0,user_weight)),), (TextureIntent("STRINGS:ALL",start,dur,texture,"SD2",False,confidence=min(1.0,user_weight)),))
