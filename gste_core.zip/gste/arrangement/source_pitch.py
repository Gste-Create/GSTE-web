"""Generic Source-at-Attack realization policy; no producer dispatch.

Whole physical measure owns one octave shift, chosen before per-window
candidate generation. Candidates may thin/drop attacks; never add source tones.
"""
from collections import defaultdict
from dataclasses import replace
from gste.arrangement.canonical.model import SourcePitchRef
from gste.arrangement.models import AccompanimentEvent, ArrangementCandidate


def select_measure_octaves(rows, *, low=40, high=81):
    groups=defaultdict(dict)
    for row in rows:
        for tone in row.source_tones:
            if not tone.event_id or tone.duration <= 0:
                raise ValueError("SOURCE_PITCH_INVALID_MATERIAL")
            groups[tone.measure][tone.event_id]=tone
    shifts={}
    for measure,tones in groups.items():
        pitches=[t.pitch for t in tones.values()]
        # One common shift, never independent bass/upper-register mapping.
        # Prefer retaining playable material, then a central guitar register.
        def rank(shift):
            playable=[p+shift for p in pitches if low <= p+shift <= high]
            distance=sum(abs(p-55) for p in playable)/max(1,len(playable))
            return (-len(playable),distance,abs(shift),shift)
        shifts[measure]=min(range(-48,49,12),key=rank)
    return shifts


def constrain_source_candidates(intent,row,candidates,octaves):
    material=defaultdict(list)
    for tone in row.source_tones:
        shift=octaves[tone.measure]
        if 40 <= tone.pitch+shift <= 81:
            material[round(tone.onset,6)].append(tone)
    def event(tone,index,duration=None):
        shift=octaves[tone.measure]
        return AccompanimentEvent(
            f"{intent.intent_id}:SOURCE_TONE:{tone.event_id}",intent.window_id,tone.onset,
            min(tone.duration,duration) if duration is not None else tone.duration,
            tone.role,tone.pitch+shift,96 if tone.role=='bass' else 80,True,0,intent.chord_symbol,
            source_pitch_ref=SourcePitchRef(tone.event_id,tone.onset,tone.pitch,
                f"M{tone.measure}",shift))
    out=[];seen=set()
    for candidate in candidates:
        events=[];used=set()
        for requested in candidate.events:
            allowed=[t for t in material.get(round(requested.onset,6),()) if t.event_id not in used]
            if not allowed:continue
            tone=min(allowed,key=lambda t:(abs(t.pitch+octaves[t.measure]-requested.pitch),t.event_id))
            used.add(tone.event_id);events.append(event(tone,len(events),requested.duration))
        signature=tuple((e.onset,e.pitch,e.duration) for e in events)
        if signature in seen:continue
        seen.add(signature)
        out.append(replace(candidate,events=tuple(events),metadata={**candidate.metadata,
            'source_pitch_policy':'SOURCE_AT_ATTACK','octave_grouping':'MEASURE',
            'measure_octave_shifts':dict(octaves)},reasons=(*candidate.reasons,'Source-at-attack tones; common measure octave.')))
    # Source tones are formal musical intent, not a raw Source->Joint bypass.
    # Add rich/shell/single-tone reductions at original attacks. Joint retains
    # its existing choice/pruning policy; full attack coverage is NOT mandatory.
    for name,limit in [('ALL',None),('SHELL',2),('SINGLE',1)]:
        events=[]
        for _,tones in sorted(material.items()):
            ordered=sorted(tones,key=lambda t:(t.role!='bass',-t.pitch,t.event_id))
            for tone in ordered if limit is None else ordered[:limit]:events.append(event(tone,len(events)))
        out.append(ArrangementCandidate(intent.intent_id+':SOURCE_MATERIAL:'+name,intent.intent_id,
            intent.window_id,intent.texture,0,tuple(events),0,0,
            reasons=('Source-at-attack musical material; optional attack coverage.',),
            metadata={'source_pitch_policy':'SOURCE_AT_ATTACK','octave_grouping':'MEASURE',
                      'measure_octave_shifts':dict(octaves)}))
    return tuple(out)


def audit_source_pitch_notes(notes):
    groups={};violations=[];checked=0
    for note in notes:
        ref=note.source_pitch_ref
        if ref is None:continue
        checked+=1
        if abs(note.start-ref.onset)>1e-6 or note.pitch.midi != ref.pitch+ref.octave_shift+ref.key_shift:
            violations.append({'event_id':ref.event_id,'reason':'SOURCE_TONE_OR_ONSET_CHANGED'})
        if ref.octave_shift%12:
            violations.append({'event_id':ref.event_id,'reason':'NON_OCTAVE_SHIFT'})
        value=(ref.octave_shift,ref.key_shift)
        if ref.group_id in groups and groups[ref.group_id]!=value:
            violations.append({'event_id':ref.event_id,'reason':'GROUP_OCTAVE_INCONSISTENT'})
        groups[ref.group_id]=value
    return {'status':'FAIL' if violations else 'PASS','checked_notes':checked,
            'groups':groups,'violations':violations,'attack_coverage_required':False}
