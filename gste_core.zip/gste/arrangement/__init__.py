"""Independent arrangement-layer public API (v0.13.1).

The package re-exports the legacy v0.8 arrangement-cost symbols so older
callers continue to work after ``gste.arrangement`` changed from a module to a
package.  v0.13.3 adds explicit melody-auto and piano-source input routes.
"""
from .legacy_cost import ArrangementState, arrangement_transition_cost, local_arrangement_cost
from .models import (
    ArrangementCandidate, ArrangementIntent, ArrangementPlan, SourceArrangementPlan,
    SourceMode, TextureLevel,
)
from .routing import ArrangementRouteDecision, resolve_arrangement_route
from .engine.service import build_auto_arrangement_plan, build_source_arrangement_plan

__all__ = [
    "ArrangementState", "arrangement_transition_cost", "local_arrangement_cost",
    "ArrangementIntent", "ArrangementCandidate", "ArrangementPlan", "SourceArrangementPlan",
    "SourceMode", "TextureLevel", "ArrangementRouteDecision", "resolve_arrangement_route",
    "build_auto_arrangement_plan", "build_source_arrangement_plan",
]
