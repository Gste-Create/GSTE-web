from __future__ import annotations

"""Unified accompaniment boundary used by every source adapter.

Source-specific analyzers may infer harmony/bass/texture differently, but they
must leave that layer as ArrangementIntent -> ArrangementCandidate.  Joint
never needs to know whether the material came from Piano LH or synthetic
melody-derived accompaniment.
"""

from dataclasses import dataclass, replace
from typing import Iterable

from gste.arrangement.models import ArrangementIntent, ArrangementCandidate
from gste.core.models import NoteEvent, Pitch
from gste.input.project_models import TrackData


@dataclass(frozen=True)
class AccompanimentContract:
    source_kind: str
    intents: tuple[ArrangementIntent, ...]
    candidate_groups: tuple[tuple[ArrangementCandidate, ...], ...]
    selected_candidates: tuple[ArrangementCandidate, ...]
    accompaniment_data: object | None = None


def normalize_accompaniment_plan(plan, *, source_kind: str) -> AccompanimentContract:
    """Validate and freeze the one source-independent accompaniment contract."""
    intents = tuple(plan.intents)
    groups = tuple(tuple(g) for g in plan.candidate_groups)
    selected = tuple(plan.selected_candidates)
    if not (len(intents) == len(groups) == len(selected)):
        raise ValueError(
            f"ACCOMPANIMENT_CONTRACT_LENGTH_MISMATCH:{source_kind}:"
            f"intents={len(intents)} groups={len(groups)} selected={len(selected)}"
        )
    seen_windows: set[str] = set()
    for intent, group, chosen in zip(intents, groups, selected):
        if not isinstance(intent, ArrangementIntent):
            raise TypeError(f"ACCOMPANIMENT_INTENT_TYPE_INVALID:{source_kind}:{type(intent).__name__}")
        if intent.window_id in seen_windows:
            raise ValueError(f"ACCOMPANIMENT_WINDOW_DUPLICATE:{source_kind}:{intent.window_id}")
        seen_windows.add(intent.window_id)
        if not group:
            raise ValueError(f"ACCOMPANIMENT_CANDIDATE_GROUP_EMPTY:{source_kind}:{intent.window_id}")
        for candidate in group:
            if not isinstance(candidate, ArrangementCandidate):
                raise TypeError(f"ACCOMPANIMENT_CANDIDATE_TYPE_INVALID:{source_kind}:{type(candidate).__name__}")
            if candidate.metadata.get("source_candidate_type") == "SOURCE_EXACT":
                raise ValueError(f"SOURCE_ABSTRACTION_RUNTIME_SOURCE_EXACT_FORBIDDEN:{intent.window_id}:{candidate.candidate_id}")
            if candidate.window_id != intent.window_id or candidate.intent_id != intent.intent_id:
                raise ValueError(
                    f"ACCOMPANIMENT_CANDIDATE_LINEAGE_MISMATCH:{source_kind}:{intent.window_id}:"
                    f"candidate={candidate.candidate_id}"
                )
            for event in candidate.events:
                if event.window_id != intent.window_id:
                    raise ValueError(
                        f"ACCOMPANIMENT_EVENT_WINDOW_MISMATCH:{source_kind}:{intent.window_id}:{event.event_id}"
                    )
                if event.duration <= 0:
                    raise ValueError(f"ACCOMPANIMENT_EVENT_DURATION_INVALID:{source_kind}:{event.event_id}")
        if chosen.window_id != intent.window_id or chosen.intent_id != intent.intent_id:
            raise ValueError(f"ACCOMPANIMENT_SELECTED_LINEAGE_MISMATCH:{source_kind}:{intent.window_id}")
    return AccompanimentContract(source_kind, intents, groups, selected, getattr(plan,"accompaniment_data",None))


def contract_summary(contract: AccompanimentContract) -> dict:
    events = [e for g in contract.candidate_groups for c in g for e in c.events]
    roles: dict[str, int] = {}
    textures: dict[str, int] = {}
    for group in contract.candidate_groups:
        for candidate in group:
            textures[candidate.texture] = textures.get(candidate.texture, 0) + 1
            for event in candidate.events:
                roles[event.role] = roles.get(event.role, 0) + 1
    return {
        "schema_version": "ACCOMPANIMENT_CANDIDATES_V1",
        "status": "PASS",
        "source_kind": contract.source_kind,
        "intent_count": len(contract.intents),
        "candidate_group_count": len(contract.candidate_groups),
        "candidate_count": sum(len(g) for g in contract.candidate_groups),
        "candidate_event_count": len(events),
        "roles": roles,
        "textures": textures,
        "contract": "ArrangementIntent -> ArrangementCandidate",
    }


def contract_to_joint_bundle(contract: AccompanimentContract, template: TrackData):
    """Adapt the unified contract to Joint's current TrackData + variants boundary."""
    measure_starts = sorted(template.measure_starts.items(), key=lambda x: x[1], reverse=True)

    def to_note(event, variant: str) -> NoteEvent:
        measure = next((m for m, start in measure_starts if event.onset >= start - 1e-9), None)
        return NoteEvent(
            Pitch(event.pitch), start=event.onset, duration=event.duration, measure=measure,
            source_event_id=event.event_id, importance=getattr(event, "importance", None),
            arrangement_role=getattr(event, "role", None), source_type=contract.source_kind,
            source_variant=variant, texture_family=variant,
            intent_id=event.intent_id, candidate_id=event.candidate_id, pattern_type=event.pattern_type,
            provenance=event.provenance, preserve_rhythm=event.preserve_rhythm, attack_loss=event.attack_loss,
            source_pitch_ref=event.source_pitch_ref, allow_revoice=event.source_pitch_ref is None,
        )

    variants_by_window = {}
    baseline_candidates = []
    for intent, group, selected in zip(contract.intents, contract.candidate_groups, contract.selected_candidates):
        dedup = []
        signatures = set()
        for candidate in group:
            variant = str(candidate.metadata.get("register_policy") or candidate.metadata.get("guitar_texture") or candidate.metadata.get("source_candidate_type") or candidate.texture or "ACCOMPANIMENT")
            # Generic musical loss at the boundary; Joint sees no instrument
            # or pattern-specific rules. Count missing attacks, not source notes.
            expected = set(round(float(x)+intent.start, 6) for x in intent.rhythm_pattern) if intent.preserve_source_rhythm else set()
            actual = {round(e.onset, 6) for e in candidate.events}
            if expected:
                variant += f"_ATTACKLOSS_{len(expected-actual):03d}"
            signature = tuple((round(e.onset, 6), round(e.duration, 6), int(e.pitch), str(e.role)) for e in candidate.events)
            if signature in signatures:
                continue
            signatures.add(signature)
            notes = tuple(to_note(e, variant) for e in candidate.events)
            dedup.append((variant, notes))
        if not dedup:
            variant = str(selected.metadata.get("register_policy") or selected.metadata.get("guitar_texture") or selected.metadata.get("source_candidate_type") or selected.texture or "SELECTED")
            dedup = [(variant, tuple(to_note(e, variant) for e in selected.events))]
        variants_by_window[intent.window_id] = tuple(dedup)

        baseline = next((c for c in group if c.metadata.get("source_candidate_type") == "GUITAR_BASELINE_V01355"), None)
        baseline_candidates.append(baseline or selected)

    notes = [
        to_note(event, str(candidate.metadata.get("register_policy") or candidate.metadata.get("guitar_texture") or candidate.metadata.get("source_candidate_type") or candidate.texture or "BASELINE"))
        for candidate in baseline_candidates for event in candidate.events
    ]
    notes.sort(key=lambda note: (note.start, note.pitch.midi, note.duration))
    from gste.input.musical_events import MusicalEvent
    events = [MusicalEvent(n.source_event_id, "note", n.start, n.duration, n.measure, i, pitch_midi=n.pitch.midi) for i,n in enumerate(notes)]
    return replace(template, track_id="arrangement_generated", notes=notes, events=events, role="accompaniment"), variants_by_window


def audit_selected_lineage(contract, result):
    """Observer-only: unknown candidates/mutated semantics fail at first loss."""
    known={c.candidate_id:(i,c) for i,g in zip(contract.intents,contract.candidate_groups) for c in g}
    from gste.arrangement.source_pitch import audit_source_pitch_notes
    checked=[f.note for w in result.selected for f in w.accompaniment.notes]
    pitch_audit=audit_source_pitch_notes(checked)
    if pitch_audit["violations"]:
        raise ValueError("ACCOMPANIMENT_SOURCE_PITCH_MUTATION:"+str(pitch_audit["violations"]))
    records=[]
    for window in result.selected:
        for fingering in window.accompaniment.notes:
            note=fingering.note
            if str(note.arrangement_role or '').startswith('melody_priority_'):
                records.append({'event_id':note.source_event_id,'origin':'MELODY_PRIORITY_POOL'})
                continue
            if note.candidate_id not in known:
                raise ValueError('ACCOMPANIMENT_UNKNOWN_CANDIDATE:'+str(note.source_event_id))
            intent,candidate=known[note.candidate_id]
            original=next((e for e in candidate.events if e.event_id==note.source_event_id),None)
            if original is not None and original.source_pitch_ref is not None:
                ref=note.source_pitch_ref
                expected=original.source_pitch_ref
                if ref is None or (ref.event_id,ref.onset,ref.pitch,ref.group_id,ref.octave_shift)!=(expected.event_id,expected.onset,expected.pitch,expected.group_id,expected.octave_shift):
                    raise ValueError("ACCOMPANIMENT_SOURCE_REFERENCE_LOST")
            if (note.intent_id,note.pattern_type,note.provenance) != (intent.intent_id,intent.pattern_type,intent.provenance):
                raise ValueError('ACCOMPANIMENT_SEMANTIC_PROVENANCE_MUTATION:'+str(note.source_event_id))
            records.append({'event_id':note.source_event_id,'intent_id':note.intent_id,
                'candidate_id':note.candidate_id,'pattern_type':note.pattern_type,'provenance':note.provenance,
                'pitch':note.pitch.midi,'onset':note.start,'duration':note.duration,'source_pitch_ref':note.source_pitch_ref})
    return {'status':'PASS','selected_event_count':len(records),'events':records,'source_pitch_audit':pitch_audit}
