from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


InputRoute = Literal["AUTO_MELODY", "SOURCE_PIANO", "SOURCE_ENSEMBLE"]


@dataclass(frozen=True)
class ArrangementRouteDecision:
    route: InputRoute
    source_mode: str
    reason: str



def expected_route_for_source(accompaniment_source: str) -> InputRoute:
    """Single authority mapping a provenance label to its expected input route."""
    if accompaniment_source in {"synthetic_from_melody_grid", "none"}:
        return "AUTO_MELODY"
    if accompaniment_source in {"independent_score", "piano_left_hand"}:
        return "SOURCE_PIANO"
    if accompaniment_source in {"ensemble_score", "band_score", "orchestra_score"}:
        return "SOURCE_ENSEMBLE"
    raise ValueError("Unknown accompaniment_source: " + str(accompaniment_source))

def resolve_arrangement_route(*, accompaniment_source: str) -> ArrangementRouteDecision:
    """Resolve the input route without exposing source details to the engine."""
    if accompaniment_source == "synthetic_from_melody_grid":
        return ArrangementRouteDecision(
            route="AUTO_MELODY",
            source_mode="AUTO_GENERATED",
            reason="Synthetic accompaniment was produced by the melody-only Auto route.",
        )
    if accompaniment_source == "none":
        return ArrangementRouteDecision(
            route="AUTO_MELODY",
            source_mode="NONE",
            reason="Melody-only fingering mode; accompaniment generation is explicitly disabled.",
        )
    if accompaniment_source in {"independent_score", "piano_left_hand"}:
        return ArrangementRouteDecision(
            route="SOURCE_PIANO",
            source_mode="SOURCE_MAPPED",
            reason="An independent accompaniment score is present; analyze it as source material.",
        )
    if accompaniment_source in {"ensemble_score", "band_score", "orchestra_score"}:
        return ArrangementRouteDecision(route="SOURCE_ENSEMBLE", source_mode="SOURCE_MAPPED", reason="A multi-instrument accompaniment score is present; family adapters will export weighted canonical intents.")
    raise ValueError("Unknown accompaniment_source: " + str(accompaniment_source))
