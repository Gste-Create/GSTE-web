"""The sole musical accompaniment boundary BEFORE guitar arrangement.

Canonical rows contain musical intent, never candidate/string/fret decisions.
Source evidence is diagnostic lineage; realization must not dispatch on it.
"""
from dataclasses import dataclass, replace
from math import isfinite
from gste.arrangement.canonical import CanonicalArrangementIntent
from gste.arrangement.models import ArrangementIntent

SCHEMA_VERSION = "ACCOMPANIMENT_DATA_V1"

@dataclass(frozen=True)
class AccompanimentData:
    windows: tuple[CanonicalArrangementIntent, ...]
    preserve_rhythm: bool
    schema_version: str = SCHEMA_VERSION
    source_pitch_policy: str = "FREE"
    octave_grouping: str = "MEASURE"

    def __post_init__(self):
        if self.source_pitch_policy not in {"FREE", "SOURCE_AT_ATTACK"}:
            raise ValueError("ACCOMPANIMENT_SOURCE_PITCH_POLICY")
        if self.octave_grouping != "MEASURE":
            raise ValueError("ACCOMPANIMENT_OCTAVE_GROUPING_UNSUPPORTED")
        seen = set()
        for c in self.windows:
            if not isinstance(c, CanonicalArrangementIntent):
                raise TypeError("ACCOMPANIMENT_DATA_ROW_TYPE")
            if c.window_id in seen:
                raise ValueError("ACCOMPANIMENT_DATA_DUPLICATE_WINDOW:" + c.window_id)
            seen.add(c.window_id)
            for part in (c.harmony,c.bass,c.rhythm,c.texture):
                if (part.window_id,part.start,part.duration) != (c.window_id,c.harmony.start,c.harmony.duration):
                    raise ValueError("ACCOMPANIMENT_DATA_COMPONENT_GRID_MISMATCH:"+c.window_id)
            if not isfinite(c.harmony.start) or not isfinite(c.harmony.duration) or c.harmony.duration <= 0:
                raise ValueError("ACCOMPANIMENT_DATA_TIME_INVALID:"+c.window_id)
            if len(c.rhythm.rhythm_pattern) != len(c.rhythm.attack_sizes):
                raise ValueError("ACCOMPANIMENT_DATA_ATTACK_SIZE_MISMATCH:"+c.window_id)
            if any(not isfinite(t) or t < 0 or t >= c.harmony.duration+1e-6 for t in c.rhythm.rhythm_pattern):
                raise ValueError("ACCOMPANIMENT_DATA_ATTACK_OUTSIDE_WINDOW:"+c.window_id)
            if not c.evidence or any(not e.source_id for e in c.evidence):
                raise ValueError("ACCOMPANIMENT_DATA_PROVENANCE_MISSING:"+c.window_id)
            if any(not isinstance(size,int) or isinstance(size,bool) or size<=0 for size in c.rhythm.attack_sizes):
                raise ValueError("ACCOMPANIMENT_DATA_ATTACK_SIZE_INVALID:"+c.window_id)
            if c.functional_roles and len(c.functional_roles)!=sum(c.rhythm.attack_sizes):
                raise ValueError("ACCOMPANIMENT_DATA_FUNCTIONAL_ROLE_COUNT_MISMATCH:"+c.window_id)
            for e in c.evidence:
                if not isfinite(e.confidence) or not 0 <= e.confidence <= 1 or not isfinite(e.user_weight) or e.user_weight < 0:
                    raise ValueError("ACCOMPANIMENT_DATA_EVIDENCE_WEIGHT_INVALID:"+c.window_id)
            for tone in c.source_tones:
                if not tone.event_id or not isfinite(tone.onset) or not isfinite(tone.duration) or tone.duration <= 0:
                    raise ValueError("ACCOMPANIMENT_SOURCE_TONE_INVALID")
                if not c.harmony.start-1e-9 <= tone.onset < c.harmony.start+c.harmony.duration-1e-9:
                    raise ValueError("ACCOMPANIMENT_SOURCE_TONE_WINDOW")
            if not c.texture.pattern_type:
                raise ValueError("ACCOMPANIMENT_DATA_PATTERN_MISSING:"+c.window_id)


def to_arrangement_intent(c, *, texture, reduction, preserve_rhythm):
    return ArrangementIntent(
        intent_id="ACC:"+c.window_id, source_mode="CANONICAL",
        window_id=c.window_id, start=c.harmony.start, duration=c.harmony.duration,
        chord_symbol=c.harmony.chord_symbol, root_pitch_class=c.harmony.root_pitch_class,
        chord_quality=c.harmony.quality, texture=texture, density=c.rhythm.density,
        reduction_level=reduction, bass_motion=c.bass.motion,
        preserve_source_rhythm=preserve_rhythm, source_confidence=c.harmony.confidence,
        reasons=c.texture.reasons, metadata=dict(c.metadata), pattern_type=c.texture.pattern_type,
        attack_sizes=c.rhythm.attack_sizes, functional_roles=c.functional_roles,
        rhythm_pattern=c.rhythm.rhythm_pattern, bass_sequence=c.bass.bass_sequence, provenance=c.evidence,
    )


def bind_candidate_lineage(intent, candidates):
    return tuple(replace(c, metadata={**c.metadata, **{k:v for k,v in intent.metadata.items() if k in {"metric_group_refs", "metric_group_patterns", "metric_group_attack_counts", "repeated_metric_pattern"}},"generation_core":"arrangement.engine"}, events=tuple(replace(e, intent_id=intent.intent_id,
        candidate_id=c.candidate_id, pattern_type=intent.pattern_type,
        provenance=intent.provenance, preserve_rhythm=intent.preserve_source_rhythm,
        attack_loss=len({round(intent.start+t,6) for t in intent.rhythm_pattern}-{round(e.onset,6) for e in c.events}) if intent.preserve_source_rhythm else 0) for e in c.events)) for c in candidates)
