from __future__ import annotations

from dataclasses import dataclass

from gste.control import get_value


@dataclass(frozen=True)
class AutoArrangementConfig:
    window_quarters: float = float(get_value("harmony.window_quarters", 2.0))
    candidates_per_window: int = int(get_value("harmony.candidates_per_window", 3))
    pattern: str = "auto"
    low_confidence_threshold: float = float(get_value("harmony.low_confidence_threshold", 0.60))
    key_conflict_margin: float = float(get_value("harmony.key_conflict_margin", 0.12))
    diminished_complexity_cost: float = float(get_value("harmony.diminished_complexity_cost", 5.0))


DEFAULT_CONFIG = AutoArrangementConfig()
