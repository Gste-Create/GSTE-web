from __future__ import annotations

from statistics import mean

from gste.arrangement.canonical import (
    BassIntent, CanonicalArrangementIntent, HarmonyIntent, PhraseIntent,
    RhythmIntent, SectionIntent, SourceEvidence, TextureIntent,
)
from gste.arrangement.guitar.texture_policy import melody_density
from gste.arrangement.models import ArrangementIntent, ChordProgressionResult
from gste.harmony.library import QUALITY_INTERVALS

_DENSITY_ACTIVITY = {"MD0": 0.10, "MD1": 0.28, "MD2": 0.48, "MD3": 0.72, "MD4": 0.92}

def _nearest_root_bass(root_pc: int) -> int:
    values=[m for m in range(40,53) if m%12==root_pc]
    return min(values, key=lambda m: abs(m-47)) if values else 47

from gste.arrangement.auto.rhythm import auto_rhythm_attacks

def _phrase_for(index: int, results) -> PhraseIntent:
    phrase_index=index//2
    lo=phrase_index*2; hi=min(len(results),lo+2)
    rows=results[lo:hi]
    densities=[melody_density(r.window) for r in rows]
    activity=mean(_DENSITY_ACTIVITY[d] for d in densities) if densities else .5
    # High melody activity means high phrase energy but *lower accompaniment density*.
    primary="ROOT_GUIDE" if activity>=.72 else ("SPARSE_ARPEGGIO" if activity>=.40 else "ARPEGGIO")
    start=rows[0].window.start; end=rows[-1].window.start+rows[-1].window.duration
    return PhraseIntent(
        phrase_id=f"AUTO_PHRASE_{phrase_index+1:03d}", start=start, duration=end-start,
        window_ids=tuple(r.window.window_id for r in rows), energy_level=activity,
        transition_score=(.65 if lo and results[lo-1].selected.chord_symbol != rows[0].selected.chord_symbol else .2),
        transition_reasons=(("HARMONIC_PHRASE_ENTRY",) if lo else ("SONG_ENTRY",)),
        primary_texture=primary, secondary_texture="ROOT_GUIDE", accent_texture="COMPACT_BLOCK",
    )

def _section_for(index: int, results) -> SectionIntent:
    # Four harmony windows (~2 phrases) form a conservative section context.
    section_index=index//4; lo=section_index*4; hi=min(len(results),lo+4); rows=results[lo:hi]
    activities=[_DENSITY_ACTIVITY[melody_density(r.window)] for r in rows]
    pitches=[n.midi for r in rows for n in r.window.melody_notes]
    register=(mean(pitches) if pitches else 60.0)
    activity=mean(activities) if activities else .5
    energy=max(0.0,min(1.0,.72*activity+.28*max(0.0,min(1.0,(register-55.0)/16.0))))
    role="CLIMAX" if energy>=.78 else ("HIGH_ENERGY" if energy>=.60 else ("MID_ENERGY" if energy>=.35 else "LOW_ENERGY"))
    start=rows[0].window.start; end=rows[-1].window.start+rows[-1].window.duration
    return SectionIntent(f"AUTO_SECTION_{section_index+1:03d}",start,end-start,energy,role,.62,("MELODY_ACTIVITY_AND_REGISTER",))

def _melody_window_pressure(window, attacks: tuple[float, ...]) -> tuple[int, float, float]:
    """Return (max_polyphony, attack_occupancy, pitch_span) for realization guidance.

    This describes melody pressure only; it does not decide fingering legality.
    """
    notes=list(window.melody_notes)
    if not notes:
        return 0, 0.0, 0.0
    points=sorted({window.start, window.start+window.duration, *[n.onset for n in notes], *[n.onset+n.duration for n in notes]})
    probes=[(a+b)/2 for a,b in zip(points,points[1:]) if b>a+1e-9]
    max_poly=max((sum(1 for n in notes if n.onset <= t < n.onset+n.duration) for t in probes), default=1)
    abs_attacks=[window.start+float(a) for a in attacks]
    occupied=sum(1 for t in abs_attacks if any(n.onset <= t < n.onset+n.duration for n in notes))
    occupancy=occupied/max(1,len(abs_attacks))
    pitches=[n.midi for n in notes]
    return max_poly, occupancy, float(max(pitches)-min(pitches))



def _snap_generated_attack(value: float, duration: float) -> float:
    """Snap AUTO-only attacks to a conventional binary/triplet notation grid.

    This never changes source melody time.  It only prevents generated fill
    attacks from inventing decimal timings (for example 0.11 or 0.16 quarter)
    that have no conventional MusicXML spelling.
    """
    value=max(0.0,min(float(duration),float(value)))
    points={0.0,float(duration)}
    for denom in (32,24):
        step=1.0/denom
        count=int(float(duration)/step)+1
        points.update(i*step for i in range(count+1) if i*step <= float(duration)+1e-9)
    return round(min(points,key=lambda x:(abs(x-value),x)),9)

def _melody_gap_profile(window) -> tuple[float, tuple[float, ...]]:
    """Return uncovered-time ratio and safe accompaniment fill onsets.

    Fill attacks are proposed only inside clearly audible melody gaps.  They are
    relative to the harmony window because RhythmIntent uses relative attacks.
    """
    start=float(window.start); end=start+float(window.duration)
    intervals=[]
    for n in window.melody_notes:
        a=max(start,float(n.onset)); b=min(end,float(n.onset)+max(0.0,float(n.duration)))
        if b>a:
            intervals.append((a,b))
    if not intervals:
        return 1.0, (0.0,)
    intervals.sort()
    merged=[]
    for a,b in intervals:
        if not merged or a>merged[-1][1]+1e-6:
            merged.append([a,b])
        else:
            merged[-1][1]=max(merged[-1][1],b)
    covered=sum(b-a for a,b in merged)
    duration=max(1e-6,end-start)
    rest_ratio=max(0.0,min(1.0,1.0-covered/duration))
    gaps=[]
    cursor=start
    minimum_gap=max(0.30,min(0.65,duration*0.16))
    for a,b in merged:
        if a-cursor>=minimum_gap:
            gaps.append((cursor,a))
        cursor=max(cursor,b)
    if end-cursor>=minimum_gap:
        gaps.append((cursor,end))
    attacks=[]
    for a,b in gaps[:3]:
        # Place the response shortly after the gap opens, never exactly on the
        # preceding melody release.
        onset=a+min(0.16,max(0.06,(b-a)*0.22))
        attacks.append(_snap_generated_attack(max(0.0,onset-start), duration))
    return round(rest_ratio,4), tuple(attacks)


def build_melody_canonical_intents(progression: ChordProgressionResult, *, timeline=None) -> tuple[CanonicalArrangementIntent, ...]:
    results=progression.window_results; out=[]
    for i,result in enumerate(results):
        w=result.window; chord=result.selected; density=melody_density(w)
        metric = {"metric_group_refs": [g.group_id for g in timeline.metric_groups
                    if g.start < w.start+w.duration-1e-9 and g.end > w.start+1e-9],
                  "metric_trace_status": "SOURCE_GRID"} if timeline is not None else {
                    "metric_group_refs": [], "metric_trace_status": "TIMELINE_NOT_PROVIDED"}
        required,optional=QUALITY_INTERVALS.get(chord.quality,(frozenset({0}),frozenset({7})))
        required_pcs=tuple(sorted({(chord.root_pitch_class+x)%12 for x in set(required)|{0}}))
        optional_pcs=tuple(sorted({(chord.root_pitch_class+x)%12 for x in optional}))
        harmony=HarmonyIntent(w.window_id,w.start,w.duration,chord.root_pitch_class,chord.chord_symbol,chord.quality,result.confidence,required_pcs,optional_pcs,(),"GENERATED_ROOT",(f"Auto harmony {chord.chord_symbol} from melody context.",))
        bass_pitch=_nearest_root_bass(chord.root_pitch_class)
        bass=BassIntent(w.window_id,w.start,w.duration,bass_pitch,chord.root_pitch_class,"ROOT_ANCHOR","GENERATED_STRUCTURAL_BASS","ROOT",max(.55,result.confidence*.82),(bass_pitch,),("Generated bass is a proposal; Joint may revoice by octave while preserving function.",))
        attacks=auto_rhythm_attacks(w,density,timeline.metric_groups) if w.melody_notes and timeline is not None else ()
        max_polyphony, attack_occupancy, pitch_span = _melody_window_pressure(w, attacks)
        melody_rest_ratio, melody_gap_fill_attacks = _melody_gap_profile(w)
        rhythm=RhythmIntent(w.window_id,w.start,w.duration,attacks,tuple(1 for _ in attacks),"SD1" if density in {"MD3","MD4"} else ("SD2" if density=="MD2" else "SD3"),0.0,((0.0,) if attacks else ()),.72)
        family="ROOT_PULSE" if density in {"MD3","MD4"} else ("BASS_CHORD_PULSE" if density=="MD2" else "ARPEGGIO")
        if not w.melody_notes: family="REST"
        phrase=_phrase_for(i,results); section=_section_for(i,results)
        texture=TextureIntent(w.window_id,w.start,w.duration,family,rhythm.density,True,phrase.phrase_id,.72,(f"Melody density {density}; accompaniment counter-density inferred upstream.",f"Section energy {section.energy_level:.2f} ({section.role})."))
        evidence=(SourceEvidence("MELODY_ONLY","AUTO_INFERENCE",result.confidence,1.0,{"density":density,"section_role":section.role}),)
        out.append(CanonicalArrangementIntent(w.window_id,harmony,bass,rhythm,texture,phrase,evidence,{**metric,"input_route":"AUTO_MELODY","melody_density":density,"section_energy":section.energy_level,"section_role":section.role,"melody_register":(mean([n.midi for n in w.melody_notes]) if w.melody_notes else 60.0),"melody_max_polyphony":max_polyphony,"melody_attack_occupancy":round(attack_occupancy,4),"melody_pitch_span":round(pitch_span,3),"melody_rest_ratio":melody_rest_ratio,"melody_gap_fill_attacks":melody_gap_fill_attacks,"harmonic_function":chord.harmonic_function},section))
    return tuple(out)

def canonical_to_arrangement_intent(c, texture, reduction):
    """Import compatibility: canonical mapping has one owner."""
    from gste.arrangement.data_contract import to_arrangement_intent
    return to_arrangement_intent(c,texture=texture,reduction=reduction,preserve_rhythm=False)
