"""Historical AUTO import boundary; the canonical contract has one producer."""
def build_auto_intents(progression, pattern='auto'):
    from gste.arrangement.guitar.service import build_melody_arrangement_plan
    return build_melody_arrangement_plan(progression,pattern).intents
