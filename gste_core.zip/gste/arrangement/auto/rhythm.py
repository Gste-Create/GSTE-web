"""Shared meter-aware onset policy for AUTO and editor requests.

Absolute quarter-note time is the only clock. Metric groups come exclusively
from structure.metric; UNKNOWN deliberately does not imply 4/4.
"""
from __future__ import annotations

import math


def rhythm_attacks(start, duration, metric_groups, *, pattern_type='ARPEGGIO',
                   density='medium', end=None):
    """Return window-relative onset offsets, respecting source metric groups.

    For a compound group, medium density places three eighth-note onsets;
    for a simple group, medium places two eighth-note onsets per quarter beat.
    Low density uses group starts; high density subdivides by quarter-quarter.
    UNKNOWN uses neutral time spacing, without manufacturing metric accents.
    """
    start=float(start); stop=start+float(duration) if end is None else min(start+float(duration),float(end))
    if stop<=start+1e-9 or pattern_type=='REST': return ()
    groups=tuple(sorted((g for g in metric_groups if g.end>start+1e-9 and g.start<stop-1e-9),key=lambda g:g.start))
    if not groups: raise ValueError('Metric groups missing for requested rhythm span')
    if pattern_type in ('ROOT','ROOT_GUIDE','COMPACT_BLOCK'):
        return (0.0,)
    if density not in ('low','medium','high'):
        raise ValueError('Unsupported rhythm density')
    attacks=[]
    for group in groups:
        lo=max(start,group.start);hi=min(stop,group.end)
        if hi<=lo+1e-9:continue
        if density=='low':
            # Do not insert a new strong beat when the edit begins mid-group.
            if group.start>=start-1e-7:attacks.append(group.start)
            continue
        step=0.25 if density=='high' else 0.5
        # Grid origin is the source metric-group boundary, never the edit window.
        first=max(0,math.ceil((lo-group.start-1e-8)/step))
        for k in range(first,int(math.ceil((hi-group.start)/step))+1):
            t=group.start+k*step
            if lo-1e-8<=t<hi-1e-8:attacks.append(t)
    return tuple(sorted({round(t-start,7) for t in attacks if start-1e-8<=t<stop-1e-8}))


def auto_rhythm_attacks(window, density, metric_groups):
    """AUTO counter-density translated to the same metric rhythm policy."""
    level='low' if density in ('MD3','MD4') else ('medium' if density=='MD2' else 'high')
    return rhythm_attacks(window.start,window.duration,metric_groups,density=level)
