from __future__ import annotations

from pathlib import Path

from gste.control import get_value
from gste.structure import metric
from gste import tonality
from gste.harmony.windows import canonical_window_id

from gste.core.models import NoteEvent
from gste.input.project_models import TrackData
from gste.harmony.library import QUALITY_INTERVALS

from .config import AutoArrangementConfig, DEFAULT_CONFIG
from gste.arrangement.models import (
    ChordCandidate, ChordProgressionResult, ChordWindow, KeyCandidate,
    WeightedNote, WindowResult,
)

_NAMES = ("C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B")
_MAJOR = (0, 2, 4, 5, 7, 9, 11)
_MINOR = (0, 2, 3, 5, 7, 8, 10)
_MAJOR_QUALITIES = ("major", "minor", "minor", "major", "major", "minor", "diminished")
_MINOR_QUALITIES = ("minor", "diminished", "major", "minor", "minor", "major", "major")
_FUNCTIONS = ("tonic", "predominant", "tonic", "predominant", "dominant", "tonic", "dominant")
_ROMAN_MAJOR = ("I", "ii", "iii", "IV", "V", "vi", "vii°")
_ROMAN_MINOR = ("i", "ii°", "III", "iv", "v", "VI", "VII")


def _measure_at(time: float, timeline: TrackData) -> tuple[int, float, float]:
    """Map canonical absolute quarter time to the source-score measure grid."""
    ordered = sorted(timeline.measure_starts.items(), key=lambda item: item[1])
    chosen = ordered[0]
    for item in ordered:
        if item[1] <= time + 1e-9:
            chosen = item
        else:
            break
    number, mstart = chosen
    return number, mstart, timeline.measure_lengths[number]


def _beat_position(time: float, timeline: TrackData) -> tuple[int, float]:
    number, mstart, _ = _measure_at(time, timeline)
    return number, time - mstart + 1.0


def detect_keys(notes: list[NoteEvent], source: str | Path, timeline: TrackData) -> tuple[KeyCandidate, ...]:
    """Legacy import facade; shared tonality owns all ranking and evidence."""
    return tonality.analyze_tonality(notes,timeline).candidates


def build_windows(notes: list[NoteEvent], timeline: TrackData, window_quarters: float = 2.0) -> tuple[ChordWindow, ...]:
    """Build analysis windows strictly inside source-score measure boundaries."""
    end = max(n.start + n.duration for n in notes)
    windows: list[ChordWindow] = []
    from gste.structure.metric import build_analysis_windows
    for span in build_analysis_windows(timeline, window_quarters):
        measure = span.measure
        mstart = timeline.measure_starts[measure]
        mstop = mstart + timeline.measure_lengths[measure]
        start, stop = span.start, span.end
        weighted_notes: list[WeightedNote] = []
        pcs: dict[int, float] = {}
        for note in notes:
            if note.start >= stop or note.start + note.duration <= start:
                continue
            overlap = min(note.start + note.duration, stop) - max(note.start, start)
            context = metric.metric_context_at(note.start, timeline)
            strong = context.is_strong_beat
            short = overlap <= 0.5
            weight = 0.8 if strong and short else 1.0 if strong else 0.35 if short else 0.65
            if note.duration <= 0.125:
                weight = 0.10
            weight *= max(overlap, 0.125)
            item = WeightedNote(note.pitch.midi, note.pitch.midi % 12, note.start, overlap, weight, strong, note.source_event_id, context)
            weighted_notes.append(item)
            pcs[item.pitch_class] = pcs.get(item.pitch_class, 0.0) + weight
        beat_start = start - mstart + 1.0
        beat_end = stop - mstart + 1.0
        phrase_end = abs(stop - mstop) < 1e-9 or stop >= end - 1e-6
        windows.append(ChordWindow(
            span.window_id, measure, beat_start, measure, beat_end,
            start, stop - start, tuple(weighted_notes), pcs,
            phrase_end, stop >= end - 1e-6,
        ))
    return tuple(windows)

def _quality_symbol(root: int, quality: str) -> str:
    suffix = {
        "major": "", "minor": "m", "diminished": "dim",
        "dominant7": "7", "maj7": "maj7", "minor7": "m7",
        "half_diminished7": "m7b5", "diminished7": "dim7",
        "sus2": "sus2", "sus4": "sus4",
    }.get(quality, f"({quality})")
    return _NAMES[root] + suffix


def _candidate_specs(key: KeyCandidate):
    """V0.2.2 chord vocabulary without progression-template bias.

    Keep the seven diatonic triads as the stable baseline, add their diatonic
    seventh colours, suspended alternatives, and (in minor) the harmonic-minor
    V/V7 dominant.  Candidate expansion is deliberately separate from future
    cadence/style/progression modelling.
    """
    intervals = _MINOR if key.mode == "minor" else _MAJOR
    qualities = _MINOR_QUALITIES if key.mode == "minor" else _MAJOR_QUALITIES
    romans = _ROMAN_MINOR if key.mode == "minor" else _ROMAN_MAJOR
    seventh_major = ("maj7", "minor7", "minor7", "maj7", "dominant7", "minor7", "half_diminished7")
    seventh_minor = ("minor7", "half_diminished7", "maj7", "minor7", "minor7", "maj7", "dominant7")
    seventh = seventh_minor if key.mode == "minor" else seventh_major
    out=[]
    for degree,(interval,triad,roman) in enumerate(zip(intervals,qualities,romans),start=1):
        function=_FUNCTIONS[degree-1]
        out.append((degree, interval, triad, roman, function, "diatonic_triad"))
        out.append((degree, interval, seventh[degree-1], roman+"7", function, "diatonic_seventh"))
        # Suspensions are colour alternatives, not a new progression grammar.
        if triad != "diminished":
            out.append((degree, interval, "sus2", roman+"sus2", function, "suspension"))
            out.append((degree, interval, "sus4", roman+"sus4", function, "suspension"))
    if key.mode == "minor":
        # Harmonic-minor dominant: raised leading tone gives V and V7.
        out.append((5, 7, "major", "V", "dominant", "harmonic_minor_dominant"))
        out.append((5, 7, "dominant7", "V7", "dominant", "harmonic_minor_dominant"))
        # Leading-tone diminished seventh is a standard harmonic-minor colour.
        out.append((7, 11, "diminished7", "vii°7", "dominant", "harmonic_minor_leading_tone"))
    # Stable de-duplication while preserving baseline-first ordering.
    seen=set(); unique=[]
    for item in out:
        sig=(item[0],item[1],item[2])
        if sig not in seen:
            seen.add(sig); unique.append(item)
    return tuple(unique)


def _candidate_set(window: ChordWindow, key: KeyCandidate, config: AutoArrangementConfig) -> tuple[ChordCandidate, ...]:
    result=[]
    total_weight=sum(window.weighted_pitch_classes.values()) or 1.0
    extension_cost={
        "diatonic_triad": 0.0,
        "diatonic_seventh": float(get_value("harmony.seventh_complexity_cost", 2.4)),
        "suspension": float(get_value("harmony.suspension_complexity_cost", 2.0)),
        "harmonic_minor_dominant": float(get_value("harmony.harmonic_minor_dominant_cost", 0.8)),
        "harmonic_minor_leading_tone": float(get_value("harmony.diminished7_complexity_cost", 3.0)),
    }
    for degree,interval,quality,roman,function,family in _candidate_specs(key):
        root=(key.tonic+interval)%12
        required,optional=QUALITY_INTERVALS.get(quality,(frozenset({0}),frozenset({7})))
        tones={(root+i)%12 for i in set(required)|set(optional)|{0}}
        melody_fit=float(get_value("harmony.melody_fit_weight",30.0))*sum(w for pc,w in window.weighted_pitch_classes.items() if pc in tones)/total_weight
        strong_total=max(sum(n.weight for n in window.melody_notes if n.strong_beat),1e-9)
        strong_fit=float(get_value("harmony.strong_beat_fit_weight",20.0))*sum(n.weight for n in window.melody_notes if n.strong_beat and n.pitch_class in tones)/strong_total
        long_total=max(sum(n.weight for n in window.melody_notes if n.duration>=1),1e-9)
        long_fit=float(get_value("harmony.long_note_fit_weight",15.0))*sum(n.weight for n in window.melody_notes if n.duration>=1 and n.pitch_class in tones)/long_total
        conflicts=sum(n.weight for n in window.melody_notes if (n.strong_beat or n.duration>=1) and n.pitch_class not in tones)
        complexity=extension_cost[family]
        if quality in {"diminished","diminished7"}:
            complexity += config.diminished_complexity_cost
        if degree==3: complexity += float(get_value("harmony.degree_3_complexity",2.0))
        elif degree==2: complexity += float(get_value("harmony.degree_2_complexity",1.0))
        # V0.2.5 chord-selection improvement: colour tones must be structural.
        # A brief passing B must not turn an otherwise sufficient C triad into
        # Cmaj7 merely because the larger chord contains one extra pitch class.
        color_intervals={"dominant7":{10},"maj7":{11},"minor7":{10},"half_diminished7":{10},"diminished7":{9},"sus2":{2},"sus4":{5}}.get(quality,set())
        color_pcs={(root+i)%12 for i in color_intervals}
        structural_color=sum(
            n.weight for n in window.melody_notes
            if n.pitch_class in color_pcs and (n.strong_beat or n.duration >= 0.75)
        ) / total_weight
        passing_color=sum(
            n.weight for n in window.melody_notes
            if n.pitch_class in color_pcs and not (n.strong_beat or n.duration >= 0.75)
        ) / total_weight
        color_reward=(
            float(get_value("harmony.structural_color_tone_reward",10.0))*structural_color
            + float(get_value("harmony.passing_color_tone_reward",1.5))*passing_color
        )
        if color_pcs and structural_color < float(get_value("harmony.color_tone_min_structural_support",0.08)):
            complexity += float(get_value("harmony.unsupported_color_penalty",4.0))

        # If a simple root triad already explains every structural melody note,
        # make an extension/suspension prove why its extra colour is necessary.
        if family in {"diatonic_seventh", "suspension"}:
            triad_quality = (_MINOR_QUALITIES if key.mode == "minor" else _MAJOR_QUALITIES)[degree-1]
            triad_required, triad_optional = QUALITY_INTERVALS.get(triad_quality,(frozenset({0}),frozenset({7})))
            triad_tones={(root+i)%12 for i in set(triad_required)|set(triad_optional)|{0}}
            structural_notes=[n for n in window.melody_notes if n.strong_beat or n.duration >= 0.75]
            if structural_notes and all(n.pitch_class in triad_tones for n in structural_notes):
                complexity += float(get_value("harmony.triad_sufficiency_penalty",3.5))

        # In minor, V/V7 earns leading-tone support only when the raised seventh
        # is structurally present; a tiny chromatic passing note is insufficient.
        leading_pc=(key.tonic+11)%12
        leading_support=sum(
            n.weight for n in window.melody_notes
            if n.pitch_class == leading_pc and (n.strong_beat or n.duration >= 0.75)
        ) / total_weight
        leading_reward=(float(get_value("harmony.minor_dominant_leading_tone_reward",12.0))*leading_support if family=="harmonic_minor_dominant" else 0.0)
        utility=melody_fit+strong_fit+long_fit+float(get_value("harmony.base_utility",10.0))+color_reward+leading_reward-float(get_value("harmony.conflict_penalty",12.0))*conflicts-complexity
        reasons=(f"{roman} / {function}",f"weighted melody fit {melody_fit:.1f}/30",f"vocabulary {family}",f"structural color {structural_color:.3f}")
        result.append(ChordCandidate(_quality_symbol(root,quality),root,quality,degree,function,melody_fit,strong_fit,long_fit,10.0,complexity_cost=complexity,total_cost=-utility,reasons=reasons))
    return tuple(sorted(result,key=lambda c:(c.total_cost,c.scale_degree,c.chord_symbol)))


def _transition(previous: ChordCandidate, current: ChordCandidate) -> float:
    pair = (previous.harmonic_function, current.harmonic_function)
    # Functional cadence evidence, not a progression template: in minor, a
    # major V/V7 resolving to i gets an extra reward over natural-minor v -> i.
    if (previous.scale_degree == 5 and previous.quality in {"major", "dominant7"}
            and current.scale_degree == 1 and current.quality in {"minor", "minor7"}):
        return (float(get_value("harmony.transition_functional_reward", -3.0))
                + float(get_value("harmony.minor_dominant_resolution_reward", -4.0)))
    if pair in {("tonic", "predominant"), ("predominant", "dominant"), ("dominant", "tonic")}:
        return float(get_value("harmony.transition_functional_reward", -3.0))
    if pair in {("tonic", "dominant"), ("tonic", "tonic"), ("predominant", "tonic")}:
        return float(get_value("harmony.transition_neutral", 0.0))
    if pair == ("dominant", "predominant"):
        return float(get_value("harmony.transition_reverse_penalty", 3.0))
    return float(get_value("harmony.transition_other_penalty", 1.0))


def optimize_progression(notes: list[NoteEvent], source: str | Path, timeline: TrackData, config: AutoArrangementConfig = DEFAULT_CONFIG) -> ChordProgressionResult:
    key_analysis = tonality.analyze_tonality(notes,timeline)
    keys = key_analysis.candidates
    if not keys:
        raise ValueError("No melody evidence for AUTO key selection")
    key = keys[0]
    windows = build_windows(notes, timeline, config.window_quarters)
    layers = [_candidate_set(window, key, config) for window in windows]
    costs: list[list[float]] = []
    parents: list[list[int]] = []
    for i, layer in enumerate(layers):
        row, parent_row = [], []
        for candidate in layer:
            cadence = float(get_value("harmony.song_end_tonic_reward", -4.0)) if windows[i].is_song_end and candidate.scale_degree == 1 else 0.0
            if i == 0:
                row.append(candidate.total_cost + cadence)
                parent_row.append(-1)
            else:
                options = [(costs[i-1][j] + _transition(prev, candidate) + candidate.total_cost + cadence, j) for j, prev in enumerate(layers[i-1])]
                best, parent = min(options)
                row.append(best)
                parent_row.append(parent)
        costs.append(row); parents.append(parent_row)
    index = min(range(len(layers[-1])), key=lambda j: costs[-1][j])
    path: list[int] = []
    for i in range(len(layers)-1, -1, -1):
        path.append(index)
        index = parents[i][index]
    path.reverse()
    results = []
    lows = []
    for i, selected_index in enumerate(path):
        selected = layers[i][selected_index]
        ranked = sorted(layers[i], key=lambda c: c.total_cost)[:max(3, config.candidates_per_window)]
        gap = ranked[1].total_cost - ranked[0].total_cost if len(ranked) > 1 else 20.0
        hit = max(0.0, min(1.0, selected.melody_fit_score / 30.0))
        confidence = max(0.35, min(0.95, 0.45 + gap / 35.0 + 0.25 * hit + 0.15 * key.confidence))
        if confidence < config.low_confidence_threshold:
            lows.append(windows[i].window_id)
        results.append(WindowResult(windows[i], tuple(ranked), selected, confidence))
    selected_chords = tuple(r.selected.chord_symbol for r in results)
    alternatives = tuple(tuple(layer[j].chord_symbol for layer, j in zip(layers, indices)) for indices in []) 
    return ChordProgressionResult(key, keys, tuple(results), selected_chords, min(costs[-1]), alternatives, tuple(lows), key_analysis)
