from __future__ import annotations

from pathlib import Path

from gste.core.models import NoteEvent
from gste.input.project_models import TrackData
from gste.arrangement.models import ArrangementPlan
from .config import AutoArrangementConfig, DEFAULT_CONFIG
from .harmony import optimize_progression
from gste.arrangement.guitar.service import build_melody_arrangement_plan


def analyze_and_arrange_melody(
    notes: list[NoteEvent],
    source: str | Path,
    *,
    pattern: str = "auto",
    config: AutoArrangementConfig = DEFAULT_CONFIG,
    timeline: TrackData | None = None,
) -> ArrangementPlan:
    """Analyze melody, then enter the shared guitar arrangement core."""
    if timeline is None:
        from gste.input_formats.router import parse_source_track
        timeline = parse_source_track(source, track_id="auto_source", role="melody_source")
    progression = optimize_progression(notes, source, timeline, config)
    return build_melody_arrangement_plan(progression, pattern, melody_data=timeline)
