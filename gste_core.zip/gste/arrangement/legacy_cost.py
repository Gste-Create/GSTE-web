from __future__ import annotations

from dataclasses import dataclass

from gste.fingering.shapes import ChordShape, shape_transition_cost
from gste.harmony.models import ChordFamilyCandidate


@dataclass(frozen=True)
class ArrangementState:
    """One harmonic-window candidate after melody feasibility has passed."""

    harmony: ChordFamilyCandidate
    shape: ChordShape
    melody_cost: float
    accompaniment_loss: float
    melody_complete: bool = True


def local_arrangement_cost(state: ArrangementState) -> float:
    if not state.melody_complete:
        return float("inf")
    # Melody playability dominates; accompaniment loss remains deliberately cheap.
    harmonic_reward = state.harmony.total_score
    return state.melody_cost + 0.7 * state.accompaniment_loss - harmonic_reward


def arrangement_transition_cost(previous: ArrangementState, current: ArrangementState) -> float:
    cost = shape_transition_cost(previous.shape, current.shape)
    if previous.harmony.family == current.harmony.family:
        cost -= 0.75
    else:
        cost += 1.0
    return max(cost, 0.0)
