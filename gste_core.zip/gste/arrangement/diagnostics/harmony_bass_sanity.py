from __future__ import annotations
from gste.version import VERSION

from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path
import json
import re
from typing import Any


@dataclass(frozen=True)
class SanityIssue:
    severity: str
    category: str
    code: str
    window_id: str
    measure: int | None
    message: str
    evidence: dict[str, Any]
    suggested_action: str


def _measure_of(analysis) -> int | None:
    for note in getattr(analysis, "notes", ()):
        if getattr(note, "measure", None) is not None:
            return int(note.measure)
    m = re.search(r"M(\d+)", str(getattr(analysis, "window_id", "")))
    return int(m.group(1)) if m else None


def _upper_pcs(analysis) -> set[int]:
    return {
        int(note.pitch_class) % 12
        for note in getattr(analysis, "notes", ())
        if not bool(getattr(note, "is_bass", False))
    }


def _jaccard(a: set[int], b: set[int]) -> float:
    if not a and not b:
        return 1.0
    union = a | b
    return len(a & b) / len(union) if union else 0.0


def _selected_has_bass_pc(candidate, pc: int | None) -> bool:
    if pc is None:
        return True
    events = tuple(getattr(candidate, "events", ()))
    if not events:
        return False
    bass_events = [e for e in events if str(getattr(e, "role", "")).lower() == "bass"]
    pool = bass_events or sorted(events, key=lambda e: int(getattr(e, "pitch", 999)))[:1]
    return any(int(getattr(e, "pitch", -999)) % 12 == pc % 12 for e in pool)


def _severity_weight(severity: str) -> int:
    return {"RED": 5, "YELLOW": 2, "GREEN": 0}.get(severity, 0)


def build_harmony_bass_sanity(plan) -> dict[str, Any]:
    analyses = tuple(getattr(plan, "analyses", ()) or ())
    bundle = getattr(plan, "analysis_bundle", None)
    selected = tuple(getattr(plan, "selected_candidates", ()) or ())
    canonical = tuple(getattr(bundle, "canonical", ()) or ()) if bundle is not None else ()

    issues: list[SanityIssue] = []
    if not analyses or not canonical:
        return {
            "version": VERSION,
            "status": "NO_DATA",
            "summary": {},
            "issues": [],
        }

    for i, (analysis, intent) in enumerate(zip(analyses, canonical)):
        wid = analysis.window_id
        measure = _measure_of(analysis)
        h = intent.harmony
        b = intent.bass

        # 1) Analyzer admits uncertainty: this is the highest-value review signal.
        if h.confidence < 0.60:
            issues.append(SanityIssue(
                "RED", "HARMONY", "HARMONY_CONFIDENCE_VERY_LOW", wid, measure,
                f"Harmony confidence is very low ({h.confidence:.2f}).",
                {"chord": h.chord_symbol, "confidence": h.confidence},
                "Inspect this window together with the previous and next measure; if the surrounding harmony is stable, prefer context smoothing or widen the harmonic evidence window.",
            ))
        elif h.confidence < 0.75:
            issues.append(SanityIssue(
                "YELLOW", "HARMONY", "HARMONY_CONFIDENCE_LOW", wid, measure,
                f"Harmony confidence is low ({h.confidence:.2f}).",
                {"chord": h.chord_symbol, "confidence": h.confidence},
                "Review only if this window also has a bass-relation or continuity warning; otherwise keep it as a low-priority audit item.",
            ))

        # 2) Bass is deliberately independent from root; non-chord/unknown is suspicious, not automatically wrong.
        if b.chord_role == "UNKNOWN" and b.primary_pitch is not None:
            issues.append(SanityIssue(
                "YELLOW", "BASS_HARMONY", "BASS_RELATION_UNKNOWN", wid, measure,
                "Bass/harmony relation is unknown.",
                {"bass_pitch": b.primary_pitch, "bass_pc": b.pitch_class, "chord": h.chord_symbol},
                "Check whether this is a passing/pedal bass. If repeated across adjacent windows, add/strengthen bass-line context classification rather than forcing the chord root to follow the bass.",
            ))
        elif b.chord_role == "NON_CHORD_OR_EXTENSION":
            bass_context = str(getattr(intent, "metadata", {}).get("bass_context", "UNRESOLVED_NON_CHORD_BASS"))
            context_explained = bass_context in {"PEDAL_BASS_CANDIDATE", "PASSING_OR_APPROACH_BASS_CANDIDATE"}
            severity = "RED" if (b.structural_role == "STRUCTURAL" and h.confidence >= 0.80 and not context_explained) else "YELLOW"
            code = "STRUCTURAL_NON_CHORD_BASS" if severity == "RED" else ("CONTEXTUAL_NON_CHORD_BASS" if context_explained else "NON_CHORD_BASS")
            issues.append(SanityIssue(
                severity, "BASS_HARMONY", code, wid, measure,
                "Bass is outside the currently detected chord family.",
                {"bass_pitch": b.primary_pitch, "bass_pc": b.pitch_class, "chord": h.chord_symbol, "harmony_confidence": h.confidence, "bass_structural_role": b.structural_role, "bass_context": bass_context},
                "If context already identifies pedal/passing motion, review only when adjacent windows also disagree. Otherwise test slash-chord or harmony re-analysis before changing the root.",
            ))

        # 3) Isolated harmonic root anomaly: neighbours agree, centre differs.
        if 0 < i < len(canonical) - 1:
            prev_h = canonical[i - 1].harmony
            next_h = canonical[i + 1].harmony
            if prev_h.root_pitch_class == next_h.root_pitch_class != h.root_pitch_class:
                severity = "RED" if h.confidence < 0.72 else "YELLOW"
                issues.append(SanityIssue(
                    severity, "HARMONY", "ISOLATED_ROOT_ANOMALY", wid, measure,
                    "Chord root differs from both neighbouring windows while the neighbours agree.",
                    {"previous_root_pc": prev_h.root_pitch_class, "current_root_pc": h.root_pitch_class, "next_root_pc": next_h.root_pitch_class, "current_confidence": h.confidence},
                    "Compare the full 2-measure context. If upper harmony stays similar, increase harmonic-continuity weight; if there is a real cadence/transition, keep the local result.",
                ))

        # 4) Possible bass-driven root misread. v0.13.5.10 requires multiple
        # independent signals so normal inversions/moving bass do not flood review.
        if i > 0:
            prev_a = analyses[i - 1]
            prev_c = canonical[i - 1]
            upper_sim = _jaccard(_upper_pcs(prev_a), _upper_pcs(analysis))
            bass_changed = prev_c.bass.pitch_class is not None and b.pitch_class is not None and prev_c.bass.pitch_class != b.pitch_class
            root_changed = prev_c.harmony.root_pitch_class != h.root_pitch_class
            root_follows_bass = b.pitch_class is not None and h.root_pitch_class == b.pitch_class
            isolated_against_next = False
            if i + 1 < len(canonical):
                isolated_against_next = canonical[i + 1].harmony.root_pitch_class == prev_c.harmony.root_pitch_class != h.root_pitch_class
            strong = upper_sim >= 0.90 and bass_changed and root_changed and root_follows_bass and h.confidence < 0.72
            moderate = upper_sim >= 0.85 and bass_changed and root_changed and root_follows_bass and h.confidence < 0.78 and isolated_against_next
            if strong or moderate:
                severity = "RED" if strong and isolated_against_next and h.confidence < 0.65 else "YELLOW"
                issues.append(SanityIssue(
                    severity, "BASS_HARMONY", "POSSIBLE_BASS_DRIVEN_ROOT", wid, measure,
                    "Upper harmony remains highly similar while bass and detected root move together.",
                    {"upper_pc_similarity": round(upper_sim, 3), "previous_root_pc": prev_c.harmony.root_pitch_class, "current_root_pc": h.root_pitch_class, "previous_bass_pc": prev_c.bass.pitch_class, "current_bass_pc": b.pitch_class, "confidence": h.confidence, "neighbours_support_previous_root": isolated_against_next},
                    "Review as a likely inversion/moving-bass ambiguity. Do not force the root to the bass; prefer the surrounding upper harmony when candidate evidence is weak.",
                ))

        # 5) Bass voice continuity: large one-window excursion and return is suspicious.
        if 0 < i < len(canonical) - 1:
            p0, p1, p2 = canonical[i - 1].bass.primary_pitch, b.primary_pitch, canonical[i + 1].bass.primary_pitch
            if p0 is not None and p1 is not None and p2 is not None:
                jump = abs(p1 - p0)
                returns = abs(p2 - p0) <= 5
                bass_resolution = str(getattr(intent, "metadata", {}).get("bass_resolution", ""))
                if jump > 12 and returns and "REPAIRED" not in bass_resolution:
                    severity = "RED" if jump > 19 else "YELLOW"
                    issues.append(SanityIssue(
                        severity, "BASS", "BASS_REGISTER_EXCURSION", wid, measure,
                        f"Bass jumps {jump} semitones and immediately returns near the previous register.",
                        {"previous_bass": p0, "current_bass": p1, "next_bass": p2, "jump_semitones": jump},
                        "Check voice tracking. Prefer register-continuous bass unless the source score clearly contains the octave displacement.",
                    ))

        # 6) Arrangement loss: structural bass identity disappeared after the guitar decision.
        if i < len(selected) and b.structural_role == "STRUCTURAL" and b.pitch_class is not None:
            cand = selected[i]
            if not _selected_has_bass_pc(cand, b.pitch_class):
                issues.append(SanityIssue(
                    "RED", "ARRANGEMENT", "STRUCTURAL_BASS_OMITTED", wid, measure,
                    "Structural bass pitch class is missing from the selected guitar accompaniment.",
                    {"bass_pc": b.pitch_class, "bass_pitch": b.primary_pitch, "selected_candidate_type": cand.metadata.get("source_candidate_type"), "selected_texture": cand.texture},
                    "Keep the analyzed BassIntent; fix the guitar voicing/pattern realization or bass-lock policy rather than changing the chord analysis.",
                ))

    # Collapse duplicate code/window pairs generated by overlapping heuristics.
    dedup: dict[tuple[str, str], SanityIssue] = {}
    for issue in issues:
        key = (issue.window_id, issue.code)
        previous = dedup.get(key)
        if previous is None or _severity_weight(issue.severity) > _severity_weight(previous.severity):
            dedup[key] = issue
    issues = sorted(dedup.values(), key=lambda x: (_measure_of(type("A", (), {"notes": (), "window_id": x.window_id})()) or 999999, x.window_id, -_severity_weight(x.severity), x.code))

    counts = Counter(i.severity for i in issues)
    category_counts = Counter(i.category for i in issues)
    n = max(1, len(canonical))
    red_ratio = counts["RED"] / n
    yellow_ratio = counts["YELLOW"] / n
    penalty = counts["RED"] * 5 + counts["YELLOW"] * 2
    overall = max(0, round(100 - 100 * penalty / max(5 * n, 1)))
    status = (
        "REVIEW_REQUIRED" if red_ratio > 0.05 else
        ("PASS_WITH_REVIEW" if red_ratio >= 0.02 or yellow_ratio > 0.20 else "PASS")
    )

    # Category scores are intentionally simple and auditable, not a music-theory truth score.
    category_scores = {}
    for category in ("HARMONY", "BASS", "BASS_HARMONY", "ARRANGEMENT"):
        cissues = [i for i in issues if i.category == category]
        cpen = sum(_severity_weight(i.severity) for i in cissues)
        category_scores[category] = max(0, round(100 - 100 * cpen / max(5 * n, 1)))

    return {
        "version": VERSION,
        "purpose": "Find high-value Harmony/Bass contradictions with contextual suppression of normal inversions, passing bass, and local variation.",
        "status": status,
        "summary": {
            "windows": len(canonical),
            "red": counts["RED"],
            "yellow": counts["YELLOW"],
            "red_ratio": round(red_ratio, 4),
            "yellow_ratio": round(yellow_ratio, 4),
            "overall_health": overall,
            "category_scores": category_scores,
            "category_issue_counts": dict(category_counts),
        },
        "issues": [asdict(i) for i in issues],
    }


def write_harmony_bass_sanity_report(plan, json_path: str | Path, md_path: str | Path) -> tuple[Path, Path]:
    data = build_harmony_bass_sanity(plan)
    json_path = Path(json_path)
    md_path = Path(md_path)
    json_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    s = data.get("summary", {})
    lines = [
        f"# GSTE {VERSION} Harmony/Bass Sanity Report",
        "",
        f"**Status:** {data.get('status', 'NO_DATA')}",
        f"**Overall health:** {s.get('overall_health', 'N/A')}/100",
        f"**Windows:** {s.get('windows', 0)} | **RED:** {s.get('red', 0)} | **YELLOW:** {s.get('yellow', 0)}",
        "",
        "> RED/YELLOW means the result is internally suspicious and worth review. It does not by itself prove the chord is musically wrong.",
        "",
        "## Fast Review Order",
        "",
        "1. Review **RED** items first.",
        "2. Prioritize `STRUCTURAL_BASS_OMITTED`, unresolved `STRUCTURAL_NON_CHORD_BASS`, `HARMONY_CONFIDENCE_VERY_LOW`, and RED `POSSIBLE_BASS_DRIVEN_ROOT`.",
        "3. Review YELLOW only when several warnings occur in the same/adjacent measure.",
        "4. Fix the layer named by `category`: ANALYSIS for Harmony/Bass, ARRANGEMENT for omitted output.",
        "",
        "## Issues",
        "",
        "| Level | Measure | Window | Category | Code | What to check |",
        "|---|---:|---|---|---|---|",
    ]
    for issue in data.get("issues", []):
        action = str(issue.get("suggested_action", "")).replace("|", "/")
        lines.append(f"| {issue['severity']} | {issue.get('measure') or ''} | {issue['window_id']} | {issue['category']} | {issue['code']} | {action} |")
    if not data.get("issues"):
        lines.append("| GREEN |  |  |  | NO_SUSPICIOUS_WINDOWS | No action required. |")
    lines += ["", "## Category Health", ""]
    for key, value in (s.get("category_scores") or {}).items():
        lines.append(f"- {key}: **{value}/100**")
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return json_path, md_path
