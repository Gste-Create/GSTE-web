from __future__ import annotations
from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class WeightedIntent:
    instrument_id: str
    family: str
    user_weight: float
    confidence: float
    intent: Any
    @property
    def effective_weight(self): return max(0.0,self.user_weight)*max(0.0,self.confidence)

def fuse_weighted_intents(items):
    """Return contributions in deterministic priority order.

    v0.13.6 intentionally exposes rather than hides conflicts. Later releases can
    add domain-specific Harmony/Bass/Texture mergers without changing adapters.
    """
    return tuple(sorted(items,key=lambda x:(-x.effective_weight,x.instrument_id)))
