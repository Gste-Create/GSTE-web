"""Deprecated compatibility facade for v0.13.5.2 Phase 1.

The active melody-only candidate core moved to :mod:`gste.arrangement.guitar`.
Keep these names temporarily so older callers/tests/plugins do not break while
we remove the duplicated arrangement-engine implementation.
"""
from __future__ import annotations

from gste.arrangement.guitar.candidate_factory import (
    generate_melody_candidate_group as generate_candidate_group,
    melody_candidate_to_window as candidate_to_window,
)

__all__ = ["generate_candidate_group", "candidate_to_window"]
