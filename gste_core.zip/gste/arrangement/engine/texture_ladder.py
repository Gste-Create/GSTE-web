"""Deprecated melody texture compatibility facade.

Active policy and event realization moved to :mod:`gste.arrangement.guitar` in
v0.13.5.2 Phase 1.  Public names are retained temporarily for regression tests
and third-party/local scripts.
"""
from __future__ import annotations

from gste.arrangement.models import AccompanimentWindow, ChordProgressionResult
from gste.arrangement.guitar.pattern_generator import generate_melody_pattern
from gste.arrangement.guitar.texture_policy import (
    melody_density as _melody_density,
    choose_melody_texture as _auto_pattern,
)

SUPPORTED_PATTERNS = (
    "auto", "root", "root_guide", "bass_chord", "bass_inner",
    "reduced_arpeggio", "arpeggio",
)


def _events_for_pattern(window, chord, pattern: str, reduction: int):
    return list(generate_melody_pattern(window, chord, pattern, reduction))


def generate_accompaniment(progression, pattern='auto'):
    from gste.arrangement.guitar.service import build_melody_arrangement_plan
    return build_melody_arrangement_plan(progression,pattern).selected_windows
