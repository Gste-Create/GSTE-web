"""One guitar realization engine for every accompaniment producer."""
from dataclasses import dataclass, replace
from types import SimpleNamespace
from gste.arrangement.data_contract import AccompanimentData, to_arrangement_intent, bind_candidate_lineage
from gste.arrangement.guitar.harmony_adapter import build_chord_intent
from gste.arrangement.guitar.melody_position import estimate_melody_hand_windows
from gste.arrangement.guitar.guitar_state import estimate_guitar_state, constrain_texture_to_guitar_state
from gste.arrangement.guitar.texture_policy import choose_texture_plan
from gste.arrangement.source.candidate_generator import generate_source_candidate_group
from gste.arrangement.guitar.melody_texture_coordinator import coordinate_melody_texture
from gste.arrangement.prefilter import prefilter_melody_candidate_families
from gste.arrangement.guitar.candidate_factory import generate_unified_melody_candidate_group
from gste.arrangement.guitar.texture_policy import melody_density
from gste.arrangement.auto.canonical_intent import _melody_gap_profile, _melody_window_pressure
from gste.arrangement.models import WeightedNote, ArrangementCandidate

@dataclass(frozen=True)
class RealizationPlan:
    intents: tuple
    candidate_groups: tuple
    selected_candidates: tuple
    accompaniment_data: AccompanimentData


def melody_occupancy(melody_data, window):
    notes=[n for n in melody_data.notes if n.start < window.start+window.duration-1e-9 and n.start+n.duration > window.start+1e-9]
    rate=sum(window.start-1e-9 <= n.start < window.start+window.duration-1e-9 for n in notes)/max(.25,window.duration)
    overlap=max((sum(n.start<=t<n.start+n.duration for n in notes) for t in {n.start for n in notes}),default=0)
    pressure=min(1., .65*min(1.,rate/2.5)+.35*min(1.,max(0,overlap-1)/1.5))
    return {'score':pressure,'budget':'HIGH' if pressure<.38 else ('MEDIUM' if pressure<.62 else 'LOW')}


def arrange(melody_data, accompaniment_data: AccompanimentData):
    """Consume exactly melody + canonical accompaniment. No source dispatch.

    preserve_rhythm is a musical constraint applicable to any producer.
    Evidence/source identifiers never choose guitar policy.
    """
    if not isinstance(accompaniment_data, AccompanimentData):
        raise TypeError("ARRANGEMENT_REQUIRES_ACCOMPANIMENT_DATA")
    from gste.editor.session import apply_editor_requests
    accompaniment_data = apply_editor_requests(melody_data, accompaniment_data)
    rows=accompaniment_data.windows
    known_ids={n.source_event_id for n in melody_data.notes if n.source_event_id}
    known_ids.update(n.event_id for c in rows for n in c.observations)
    unknown={eid for c in rows for e in c.evidence for eid in e.event_ids if eid not in known_ids}
    if unknown:
        raise ValueError("ACCOMPANIMENT_DATA_UNKNOWN_SOURCE_EVENTS:"+str(sorted(unknown)))
    from gste.arrangement.source_pitch import select_measure_octaves, constrain_source_candidates
    source_octaves=select_measure_octaves(tuple(c for c in rows if not c.metadata.get("editor_free_pitch"))) if accompaniment_data.source_pitch_policy == "SOURCE_AT_ATTACK" else {}
    base=tuple(to_arrangement_intent(c,texture=c.texture.pattern_type,reduction=0,
                preserve_rhythm=(accompaniment_data.preserve_rhythm or bool(c.metadata.get("editor_request_indices")))) for c in rows)
    project=SimpleNamespace(melody=melody_data)
    hands=estimate_melody_hand_windows(project,base)
    intents=[]; groups=[]; selected=[]
    previous_texture=None; previous_phrase=None; previous_center=None; previous_shape=None
    for c, raw, hand in zip(rows,base,hands):
        if c.texture.pattern_type == 'REST':
            intent=replace(raw,texture='REST')
            candidate=ArrangementCandidate(intent.intent_id+':REST',intent.intent_id,intent.window_id,'REST',0,(),0,0)
            group=bind_candidate_lineage(intent,(candidate,))
            intents.append(intent);groups.append(group);selected.append(group[0])
            continue
        occupancy=melody_occupancy(melody_data,raw)
        pressure=occupancy['score'];budget=occupancy['budget']
        weighted=tuple(WeightedNote(n.pitch.midi,n.pitch.midi%12,n.start,n.duration,1.,False) for n in melody_data.notes
            if n.start < raw.start+raw.duration and n.start+n.duration > raw.start)
        context=SimpleNamespace(start=raw.start,duration=raw.duration,melody_notes=weighted)
        poly,occupation,span=_melody_window_pressure(context,c.rhythm.rhythm_pattern)
        rest,fills=_melody_gap_profile(context)
        c=replace(c,metadata={**c.metadata,'melody_density':melody_density(context),
            'melody_register':sum(n.midi for n in weighted)/len(weighted) if weighted else 60.,
            'melody_max_polyphony':poly,'melody_attack_occupancy':occupation,'melody_pitch_span':span,
            'melody_rest_ratio':rest,'melody_gap_fill_attacks':fills})
        density=int(c.rhythm.density.removeprefix('SD'))
        chord=build_chord_intent(chord_symbol=c.harmony.chord_symbol,root_pc=c.harmony.root_pitch_class,
            quality=c.harmony.quality,bass_motion=c.bass.motion,source_bass_pc=c.bass.pitch_class,
            bass_policy_override=c.metadata.get('bass_policy'))
        phrase=c.phrase; phrase_id=phrase.phrase_id if phrase else None
        boundary=previous_phrase is not None and phrase_id != previous_phrase
        plan=choose_texture_plan(chord=chord,source_pattern=c.texture.pattern_type,
            melody_budget=budget,source_density=density,phrase_position=phrase.window_ids.index(c.window_id) if phrase else 0,
            previous_texture=None if boundary else previous_texture,repeated_texture_count=0,
            phrase_primary_texture=phrase.primary_texture if phrase else None,
            transition_score=phrase.transition_score if phrase else 0.,phrase_boundary=boundary,phrase_contrast=0.)
        state=estimate_guitar_state(chord,hand,previous_center=previous_center,previous_shape=previous_shape)
        plan=constrain_texture_to_guitar_state(plan,state)
        coordination=coordinate_melody_texture(c,plan.texture)
        requested=c.metadata.get('requested_texture')
        target=requested or coordination.primary_texture
        plan=replace(plan,texture=target,max_simultaneous_notes={'ROOT':1,'ROOT_GUIDE':2,'SPARSE_ARPEGGIO':1,'ARPEGGIO':1}.get(target,plan.max_simultaneous_notes))
        if requested:
            coordination=replace(coordination,primary_texture=requested,candidate_textures=(requested,))
        intent=replace(raw,texture=plan.texture,metadata={**c.metadata,'texture_budget':budget,
            'melody_occupancy_score':round(pressure,4),'phrase_id':phrase_id,'guitar_state_capacity':state.chord_string_capacity})
        rhythm=tuple(c.rhythm.rhythm_pattern)
        prefilter=prefilter_melody_candidate_families(c,plan.texture,coordinated_textures=coordination.candidate_textures)
        if requested:
            prefilter=replace(prefilter,survivors=(requested,))
        group=generate_unified_melody_candidate_group(intent,c,chord,plan,prefilter=prefilter,
            melody_hand_window=hand,coordination=coordination)
        # Rhythm locking is a semantic constraint, available to EVERY producer.
        # Add full-pulse/release alternatives; never dispatch on source labels.
        if accompaniment_data.preserve_rhythm or c.metadata.get("editor_add_attacks"):
            retention=generate_source_candidate_group(intent,None,None,guitar_chord=chord,guitar_plan=plan,
                rhythm_pattern=rhythm,melody_hand_center=hand.center_fret,
                melody_hand_center_confidence=hand.confidence,include_legacy_mapping_candidates=False,
                arranger_policy='UNIFIED',melody_budget=budget,source_density=density)
            group=tuple(retention)+tuple(group)
        if accompaniment_data.source_pitch_policy == "SOURCE_AT_ATTACK" and not c.metadata.get("editor_free_pitch"):
            group=constrain_source_candidates(intent,c,group,source_octaves)
        from gste.editor.session import constrain_edit_candidates
        group = constrain_edit_candidates(c, group)
        from gste.arrangement.guitar.candidate_factory import generate_melody_double_stop_candidates
        group = generate_melody_double_stop_candidates(intent, c, chord, group)
        group=tuple(replace(x,texture=x.texture.upper()) for x in group)
        group=bind_candidate_lineage(intent,group)
        chosen=group[0]
        intents.append(intent);groups.append(group);selected.append(chosen)
        previous_texture=plan.texture;previous_phrase=phrase_id;previous_center=hand.center_fret;previous_shape=state.selected_shape
    result = RealizationPlan(tuple(intents),tuple(groups),tuple(selected),accompaniment_data)
    from gste.editor.session import CURRENT as editor_current
    if editor_current.get() is not None: editor_current.get().observe_candidates(result)
    return result


def build_auto_arrangement_plan(progression, pattern='auto'):
    from gste.arrangement.guitar.service import build_melody_arrangement_plan
    return build_melody_arrangement_plan(progression,pattern)


def build_source_arrangement_plan(project, **kwargs):
    from gste.arrangement.source.service import analyze_and_map_piano_source
    return analyze_and_map_piano_source(project,**kwargs)
