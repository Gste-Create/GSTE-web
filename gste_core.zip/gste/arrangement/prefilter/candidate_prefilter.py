from __future__ import annotations

from dataclasses import dataclass


_TEXTURES = ("ROOT", "ROOT_GUIDE", "SPARSE_ARPEGGIO", "ARPEGGIO")
_STRUCTURAL = {"ROOT", "ROOT_GUIDE"}
_MOTION = {"SPARSE_ARPEGGIO", "ARPEGGIO"}


@dataclass(frozen=True)
class MelodyCandidatePrefilterDecision:
    """Bounded *proposal* set for AUTO_MELODY before expensive Guitar realization.

    This is intentionally not a selector.  It may reject clearly incompatible
    families and rank the survivors, but Joint Arrangement DP remains the owner
    of the final choice.
    """

    survivors: tuple[str, ...]
    rejected: tuple[str, ...]
    scores: tuple[tuple[str, float], ...]
    beam_size: int
    confidence: float
    reasons: tuple[str, ...]

    def score_for(self, texture: str) -> float:
        return dict(self.scores).get(texture, -999.0)


def _phrase_position(canonical) -> tuple[int, int]:
    phrase = getattr(canonical, "phrase", None)
    ids = tuple(getattr(phrase, "window_ids", ()) or ())
    try:
        return ids.index(canonical.window_id), len(ids)
    except (ValueError, AttributeError):
        return 0, max(1, len(ids))


def prefilter_melody_candidate_families(canonical, primary_texture: str, coordinated_textures=None) -> MelodyCandidatePrefilterDecision:
    """Use already-computed melody context to bound AUTO_MELODY candidate families.

    Rules are deliberately conservative:
    * never produce a single-family answer;
    * preserve structural + motion diversity whenever both are musically viable;
    * only hard-reject full ARPEGGIO for very dense melody with effectively one
      accompaniment attack;
    * keep 2 families when evidence is decisive, otherwise 3.

    Piano/source candidates never call this function.
    """

    density = str(getattr(canonical, "metadata", {}).get("melody_density", "MD2"))
    section_role = str(getattr(canonical, "metadata", {}).get("section_role", "MID_ENERGY"))
    section_energy = float(getattr(canonical, "metadata", {}).get("section_energy", 0.5) or 0.5)
    harmony_conf = float(getattr(getattr(canonical, "harmony", None), "confidence", 0.6) or 0.6)
    attack_count = len(tuple(getattr(getattr(canonical, "rhythm", None), "rhythm_pattern", ()) or ()))
    phrase_pos, phrase_len = _phrase_position(canonical)
    phrase_ending = phrase_len > 1 and phrase_pos == phrase_len - 1

    scores = {"ROOT": 0.46, "ROOT_GUIDE": 0.70, "SPARSE_ARPEGGIO": 0.66, "ARPEGGIO": 0.60}
    reasons: list[str] = []
    hard_rejected: set[str] = set()

    density_adjust = {
        "MD0": {"ROOT": -0.28, "ROOT_GUIDE": -0.04, "SPARSE_ARPEGGIO": 0.18, "ARPEGGIO": 0.38},
        "MD1": {"ROOT": -0.18, "ROOT_GUIDE": 0.00, "SPARSE_ARPEGGIO": 0.20, "ARPEGGIO": 0.27},
        "MD2": {"ROOT": -0.04, "ROOT_GUIDE": 0.12, "SPARSE_ARPEGGIO": 0.20, "ARPEGGIO": 0.03},
        "MD3": {"ROOT": 0.20, "ROOT_GUIDE": 0.30, "SPARSE_ARPEGGIO": 0.06, "ARPEGGIO": -0.24},
        "MD4": {"ROOT": 0.34, "ROOT_GUIDE": 0.36, "SPARSE_ARPEGGIO": -0.02, "ARPEGGIO": -0.55},
    }.get(density, {})
    for texture, delta in density_adjust.items():
        scores[texture] += delta
    reasons.append(f"MELODY_DENSITY_{density}")

    if attack_count >= 3:
        scores["SPARSE_ARPEGGIO"] += 0.08
        scores["ARPEGGIO"] += 0.10
    elif attack_count <= 1:
        scores["ROOT"] += 0.08
        scores["ROOT_GUIDE"] += 0.08
        scores["ARPEGGIO"] -= 0.12

    if section_role in {"HIGH_ENERGY", "CLIMAX"} or section_energy >= 0.66:
        scores["ROOT_GUIDE"] += 0.05
        scores["SPARSE_ARPEGGIO"] += 0.08
        scores["ARPEGGIO"] += 0.06
        reasons.append("SECTION_ENERGY_LIFT")
    elif section_role == "LOW_ENERGY" or section_energy <= 0.28:
        scores["ROOT"] += 0.07
        scores["ARPEGGIO"] -= 0.04
        reasons.append("LOW_SECTION_ENERGY")

    if phrase_ending:
        scores["ROOT_GUIDE"] += 0.09
        scores["SPARSE_ARPEGGIO"] += 0.05
        scores["ARPEGGIO"] -= 0.03
        reasons.append("PHRASE_ENDING_STABILITY")

    if primary_texture in scores:
        # Primary intent is evidence, not a lock.  Small bonus only.
        scores[primary_texture] += 0.10
        reasons.append(f"PRIMARY_INTENT_HINT_{primary_texture}")

    if density == "MD4" and attack_count <= 1:
        hard_rejected.add("ARPEGGIO")
        reasons.append("HARD_FILTER_ARPEGGIO_DENSE_MELODY_NO_RHYTHMIC_SPACE")

    eligible = [t for t in _TEXTURES if t not in hard_rejected]
    if coordinated_textures:
        coordinated = tuple(t for t in coordinated_textures if t in _TEXTURES)
        if coordinated:
            eligible = [t for t in eligible if t in coordinated]
            reasons.append("V013512_COORDINATED_TEXTURE_LADDER")
    ranked = sorted(eligible, key=lambda t: (-scores[t], _TEXTURES.index(t)))
    margin = (scores[ranked[0]] - scores[ranked[1]]) if len(ranked) > 1 else 0.0

    # Dynamic beam: decisive/high-confidence contexts use 2; ambiguous contexts 3.
    confidence = max(0.0, min(1.0, 0.65 * harmony_conf + 0.35 * min(1.0, abs(margin) / 0.25)))
    beam_size = 2 if (harmony_conf >= 0.72 and margin >= 0.12) else 3
    beam_size = min(beam_size, len(ranked))
    survivors = list(ranked[:beam_size])

    # Diversity guard: Joint must normally receive both a structural and a motion
    # answer, otherwise pre-filtering would silently become pre-selection.
    if len(survivors) >= 2:
        if not any(t in _STRUCTURAL for t in survivors):
            best_struct = next((t for t in ranked if t in _STRUCTURAL), None)
            if best_struct:
                survivors[-1] = best_struct
                reasons.append("DIVERSITY_GUARD_STRUCTURAL")
        motion_available = any(t in _MOTION for t in eligible)
        if motion_available and not any(t in _MOTION for t in survivors):
            best_motion = next((t for t in ranked if t in _MOTION), None)
            if best_motion:
                survivors[-1] = best_motion
                reasons.append("DIVERSITY_GUARD_MOTION")

    # Deduplicate after diversity replacement and refill to beam size by rank.
    deduped: list[str] = []
    for t in survivors:
        if t not in deduped:
            deduped.append(t)
    for t in ranked:
        if len(deduped) >= beam_size:
            break
        if t not in deduped:
            deduped.append(t)
    survivors = deduped
    rejected = tuple(t for t in _TEXTURES if t not in survivors)
    ordered_scores = tuple((t, round(scores[t], 6)) for t in sorted(_TEXTURES, key=lambda x: (-scores[x], _TEXTURES.index(x))))
    return MelodyCandidatePrefilterDecision(
        survivors=tuple(survivors), rejected=rejected, scores=ordered_scores,
        beam_size=beam_size, confidence=round(confidence, 6), reasons=tuple(reasons),
    )
