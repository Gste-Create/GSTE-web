"""Candidate search-space control policies.

V0.13.5.11 initially enables these policies only for AUTO_MELODY.
Source/Piano routes remain regression-control paths and bypass this package.
"""
from .candidate_prefilter import MelodyCandidatePrefilterDecision, prefilter_melody_candidate_families

__all__ = ["MelodyCandidatePrefilterDecision", "prefilter_melody_candidate_families"]
