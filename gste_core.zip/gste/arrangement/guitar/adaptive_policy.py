from __future__ import annotations

from dataclasses import dataclass

from gste.control import get_value


@dataclass(frozen=True)
class AdaptiveMotionPolicy:
    """Source-neutral motion policy conditioned on melody activity."""

    name: str = 'ADAPTIVE_MOTION_POLICY_V0135133'

    def right_hand_grammars(self, *, texture: str, activity_class: str = 'NORMAL', density: str = 'MD2') -> tuple[str, ...]:
        if texture not in {'ARPEGGIO', 'SPARSE_ARPEGGIO'}:
            return ('AUTO',)
        # T121 is the normal guitar accompaniment grammar. 3121 is intentionally
        # reserved for low-activity texture so it does not compete with melody.
        grammars = list(get_value("melody_only.normal_grammars", ["T121_A", "T121_B", "T121_C"]))
        if activity_class in {'SPARSE', 'VERY_SPARSE', 'RESTFUL'} or density in {'MD0', 'MD1'}:
            grammars.extend(str(x) for x in get_value("melody_only.sparse_extra_grammars", ["3121_A"]) if str(x) not in grammars)
        return tuple(grammars)

    def condition_attacks(
        self,
        *,
        texture: str,
        attacks: tuple[float, ...],
        density: str,
        attack_occupancy: float,
        activity_class: str,
        fill_attacks: tuple[float, ...] = (),
        max_motion_attacks: int | None = None,
    ) -> tuple[float, ...]:
        """Avoid shadowing every beat when melody itself is eighth-note busy."""
        base = tuple(attacks) or (0.0,)
        if max_motion_attacks is None:
            max_motion_attacks = int(get_value("melody_only.max_motion_attacks", 3))
        if texture not in {'SPARSE_ARPEGGIO', 'ARPEGGIO'}:
            return base

        busy = density in {'MD3', 'MD4'} or activity_class in {'BUSY', 'VERY_BUSY'} or attack_occupancy >= float(get_value("melody_only.busy_attack_occupancy", 0.72))
        if busy:
            # Keep one anchor plus genuine gaps, rather than following every
            # inferred beat/attack. This is a musical density policy, not a hard
            # legality rule.
            merged = [base[0]]
            for onset in fill_attacks:
                if all(abs(onset - existing) > 1e-6 for existing in merged):
                    merged.append(float(onset))
            busy_cap = int(get_value("melody_only.busy_max_motion_attacks", 2))
            return tuple(sorted(merged)[: max(1, min(busy_cap, max_motion_attacks))])

        if fill_attacks:
            merged = sorted(set(float(x) for x in (base[:1] + tuple(fill_attacks))))
            return tuple(merged[:max_motion_attacks])
        return base[:max_motion_attacks]


ADAPTIVE_MOTION_POLICY = AdaptiveMotionPolicy()
