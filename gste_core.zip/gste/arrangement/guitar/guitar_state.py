from __future__ import annotations

from dataclasses import dataclass, replace
from itertools import combinations

from gste.control import get_value
from gste.core.fretboard import midi_to_string_fret
from gste.core.tuning import STANDARD_TUNING
from .model import ChordIntent, GuitarTexturePlan

MAX_SHAPE_CANDIDATES = int(get_value("guitar_state.max_shape_candidates", 8))
MAX_FRET_SPAN = int(get_value("guitar_state.max_fret_span", 4))
COMMON_FINGER_REWARD = float(get_value("guitar_state.common_finger_reward", 1.25))
POSITION_MOVE_COST = float(get_value("guitar_state.position_move_cost_per_fret", 0.18))
FINGER_REASSIGN_COST = float(get_value("guitar_state.finger_reassign_cost", 0.35))
OPEN_STRING_REWARD = float(get_value("guitar_state.open_string_reward", 0.20))
ROOT_BASS_REWARD = float(get_value("guitar_state.root_bass_reward", 0.65))
UNKNOWN_SHAPE_COST = float(get_value("guitar_state.unknown_shape_cost", 0.45))
SHAPE_DEFORMATION_COST = float(get_value("guitar_state.shape_deformation_cost", 0.85))
SHAPE_TRANSLATION_COST = float(get_value("guitar_state.shape_translation_cost_per_fret", 0.08))
SHAPE_TRANSLATION_REWARD = float(get_value("guitar_state.shape_translation_reward", 0.55))
GUIDE_SLIDE_REWARD = float(get_value("guitar_state.guide_slide_reward", 0.55))
BASS_STEP_COST = float(get_value("guitar_state.bass_step_cost", 0.08))
BASS_LEAP_COST = float(get_value("guitar_state.bass_leap_cost", 0.22))
BASS_CONTINUITY_REWARD = float(get_value("guitar_state.bass_continuity_reward", 0.35))

@dataclass(frozen=True)
class EarlyShapeCandidate:
    """Concrete pre-Joint chord shape anchored to the melody hand region.

    Positions are real (string, fret, pitch-class) choices, but this is still
    advisory: it does not reserve a final string/finger for the melody and does
    not replace Joint/Fingering legality checks.
    """
    shape_id: str
    positions: tuple[tuple[int, int, int], ...]
    finger_mapping: tuple[tuple[int, int, int], ...]
    center_fret: float
    fret_span: int
    open_strings: int
    root_bass: bool
    shape_family: str
    static_cost: float
    retained_fingers: int = 0
    transition_cost: float = 0.0
    total_prejoint_cost: float = 0.0
    shape_deformation: float = 0.0
    shape_translation: int = 0
    guide_slides: int = 0
    bass_position: tuple[int, int, int] | None = None
    bass_line_cost: float = 0.0

@dataclass(frozen=True)
class GuitarStateProfile:
    center_fret: float | None
    low_fret: float | None
    high_fret: float | None
    confidence: float
    chord_string_capacity: int
    root_bass_available: bool
    recommended_max_texture: str
    shape_pressure: float
    continuity_distance: float
    reasons: tuple[str, ...]
    shape_candidates: tuple[EarlyShapeCandidate, ...] = ()
    selected_shape: EarlyShapeCandidate | None = None
    common_finger_retention: int = 0
    shape_transition_cost: float = 0.0
    shape_deformation: float = 0.0
    shape_translation: int = 0
    guide_slides: int = 0
    bass_line_cost: float = 0.0

_STABLE = ("ROOT", "ROOT_GUIDE", "SPARSE_ARPEGGIO", "ARPEGGIO")

def _pitch_classes(chord: ChordIntent) -> set[int]:
    intervals = set(chord.required_intervals) | set(chord.optional_intervals) | set(chord.color_intervals)
    intervals.add(0)
    return {(chord.root_pc + i) % 12 for i in intervals}

def _finger_map(positions):
    fretted=sorted((s,f) for s,f,_ in positions if f>0)
    if not fretted: return ()
    base=min(f for _,f in fretted)
    by_fret={}
    for s,f in fretted: by_fret.setdefault(f,[]).append(s)
    out=[]
    for f in sorted(by_fret):
        strings=sorted(by_fret[f]); finger=min(4,max(1,f-base+1))
        if len(strings)>=2 and max(strings)-min(strings)<=2: finger=1
        out.extend((s,f,finger) for s in strings)
    return tuple(sorted(out))

def _family(positions):
    frets=[f for _,f,_ in positions if f>0]
    opens=sum(1 for _,f,_ in positions if f==0)
    if opens>=2: return "OPEN"
    if len(positions)<=2: return "SHELL"
    if not frets: return "OPEN"
    span=max(frets)-min(frets)
    return "COMPACT" if span<=2 else ("EXTENDED" if span<=4 else "UNKNOWN")

def _enumerate_shapes(chord, center, low, high):
    pcs=_pitch_classes(chord); zone_low=max(0,int(low)-2); zone_high=min(18,int(high)+2)
    per_string={s:[] for s in range(1,7)}
    for midi in range(40,89):
        if midi%12 not in pcs: continue
        for s,f in midi_to_string_fret(midi,max_fret=18,tuning=STANDARD_TUNING):
            if f==0 or zone_low<=f<=zone_high:
                item=(int(s),int(f),int(midi%12))
                if item not in per_string[int(s)]: per_string[int(s)].append(item)
    # Keep the nearest concrete position per pitch-class/string to bound search.
    for s in per_string:
        per_string[s]=sorted(per_string[s], key=lambda x:(0 if x[1]==0 else abs(x[1]-center),x[1]))[:3]
    pool=[]
    for size in (2,3,4):
        for strings in combinations(range(1,7),size):
            choices=[per_string[s] for s in strings]
            if any(not x for x in choices): continue
            # bounded Cartesian product
            combos=[()]
            for opts in choices:
                combos=[c+(o,) for c in combos for o in opts][:80]
            for pos in combos:
                if chord.root_pc not in {pc for _,_,pc in pos}: continue
                frets=[f for _,f,_ in pos if f>0]
                span=0 if not frets else max(frets)-min(frets)
                if span>MAX_FRET_SPAN: continue
                root_bass=any(pc==chord.root_pc and s in (4,5,6) for s,_,pc in pos)
                opens=sum(f==0 for _,f,_ in pos)
                nonopen=[f for _,f,_ in pos if f>0]
                ccenter=float(center if not nonopen else sum(nonopen)/len(nonopen))
                fam=_family(pos)
                # Fret height is state, not difficulty. Melody compatibility is enforced by the search zone.
                static=0.22*span - OPEN_STRING_REWARD*opens
                static += -ROOT_BASS_REWARD if root_bass else (0.55 if chord.bass_policy=="LOCK_ROOT_BASS" else 0.0)
                static += UNKNOWN_SHAPE_COST if fam=="UNKNOWN" else 0.0
                bass_pc = chord.source_bass_pc if chord.source_bass_pc is not None else chord.root_pc
                bass_opts=[x for x in pos if x[2] == bass_pc] or [x for x in pos if x[2] == chord.root_pc]
                bass=min(bass_opts, key=lambda x: STANDARD_TUNING.open_midi(x[0])+x[1]) if bass_opts else min(pos, key=lambda x: STANDARD_TUNING.open_midi(x[0])+x[1])
                pool.append(EarlyShapeCandidate("",tuple(sorted(pos)),_finger_map(pos),round(ccenter,3),span,opens,root_bass,fam,round(static,4),bass_position=bass))
    unique={x.positions:x for x in pool}
    ranked=sorted(unique.values(), key=lambda x:(x.static_cost,-len(x.positions),x.positions))[:MAX_SHAPE_CANDIDATES]
    return tuple(replace(x,shape_id=f"GS{i+1}") for i,x in enumerate(ranked))

def _shape_geometry(mapping):
    """Relative fretted geometry; open strings are intentionally exempt."""
    if not mapping:
        return {}
    base=min(f for _,f,_ in mapping)
    return {(s,fg): f-base for s,f,fg in mapping}

def _bass_midi(shape):
    if shape is None or shape.bass_position is None:
        return None
    s,f,_=shape.bass_position
    return STANDARD_TUNING.open_midi(s)+f

def _with_transition(candidate, previous):
    if previous is None:
        return replace(candidate,total_prejoint_cost=candidate.static_cost)
    prev=set(previous.finger_mapping); cur=set(candidate.finger_mapping)
    retained=len(prev & cur)
    prev_by={(s,fg):f for s,f,fg in previous.finger_mapping}
    cur_by={(s,fg):f for s,f,fg in candidate.finger_mapping}
    shared_keys=set(prev_by)&set(cur_by)
    slide_offsets=[cur_by[k]-prev_by[k] for k in shared_keys if cur_by[k] != prev_by[k]]
    guide_slides=sum(1 for d in slide_offsets if 0 < abs(d) <= 4)

    # Shape translation: same finger/string geometry moves together.  A clean
    # translation is deliberately cheaper than re-forming a chord in-place.
    pg=_shape_geometry(previous.finger_mapping); cg=_shape_geometry(candidate.finger_mapping)
    common_geom=set(pg)&set(cg)
    deformation=(sum(abs(pg[k]-cg[k]) for k in common_geom)/len(common_geom)) if common_geom else float(max(len(pg),len(cg),1))
    translation=0
    if common_geom and deformation <= 0.25 and len(common_geom) >= min(2, len(pg), len(cg)):
        offsets=[cur_by[k]-prev_by[k] for k in common_geom]
        if offsets and max(offsets)-min(offsets) <= 1:
            translation=int(round(sum(offsets)/len(offsets)))

    reassigned=max(0,len(cur)-retained-guide_slides)
    if translation:
        movement=SHAPE_TRANSLATION_COST*abs(translation)-SHAPE_TRANSLATION_REWARD
    else:
        movement=POSITION_MOVE_COST*abs(candidate.center_fret-previous.center_fret)
    deformation_cost=SHAPE_DEFORMATION_COST*deformation

    pm=_bass_midi(previous); cm=_bass_midi(candidate)
    bass_cost=0.0
    if pm is not None and cm is not None:
        interval=abs(cm-pm)
        if interval <= 2:
            bass_cost=BASS_STEP_COST*interval-BASS_CONTINUITY_REWARD
        elif interval <= 5:
            bass_cost=BASS_STEP_COST*interval
        else:
            bass_cost=BASS_STEP_COST*5+BASS_LEAP_COST*(interval-5)

    cost=(movement + deformation_cost + FINGER_REASSIGN_COST*reassigned
          - COMMON_FINGER_REWARD*retained - GUIDE_SLIDE_REWARD*guide_slides + bass_cost)
    return replace(candidate,retained_fingers=retained,guide_slides=guide_slides,
                   shape_deformation=round(deformation,4),shape_translation=translation,
                   bass_line_cost=round(bass_cost,4),transition_cost=round(cost,4),
                   total_prejoint_cost=round(candidate.static_cost+cost,4))

def estimate_guitar_state(chord: ChordIntent, melody_hand_window, *, previous_center: float | None = None, previous_shape: EarlyShapeCandidate | None = None) -> GuitarStateProfile:
    center=getattr(melody_hand_window,"center_fret",None); low=getattr(melody_hand_window,"low_fret",None); high=getattr(melody_hand_window,"high_fret",None)
    confidence=float(getattr(melody_hand_window,"confidence",0.0) or 0.0)
    if center is None:
        return GuitarStateProfile(None,None,None,confidence,0,False,"ROOT_GUIDE",0.5,0.0,("NO_MELODY_HAND_CENTER",))
    center=float(center); low=float(low if low is not None else center); high=float(high if high is not None else center)
    zone_low=max(0.0,low-1.5); zone_high=min(18.0,high+1.5); pcs=_pitch_classes(chord)
    usable=set(); root=False
    for midi in range(40,89):
        if midi%12 not in pcs: continue
        for s,f in midi_to_string_fret(midi,max_fret=18,tuning=STANDARD_TUNING):
            if f==0 or zone_low<=f<=zone_high:
                usable.add(int(s)); root |= (midi%12==chord.root_pc and s in (4,5,6))
    shapes=tuple(_with_transition(x,previous_shape) for x in _enumerate_shapes(chord,center,low,high))
    selected=min(shapes,key=lambda x:x.total_prejoint_cost) if shapes else None
    span=max(0.0,high-low); continuity=abs(center-float(previous_center)) if previous_center is not None else 0.0
    pressure=max(0.0,span-3.0)*0.12  # melody occupancy; absolute hand travel is not itself difficulty
    pressure += 0.22 if len(usable)<=3 else (0.10 if len(usable)==4 else 0.0)
    pressure += 0.15 if chord.bass_policy=="LOCK_ROOT_BASS" and not root else 0.0
    if selected is None: pressure += 0.18
    else:
        if selected.fret_span>=4: pressure += 0.10
        # Resource pressure follows actual state change, not absolute fret height.
        pressure += min(0.18, 0.06*selected.shape_deformation)
        pressure += min(0.12, max(0.0, selected.bass_line_cost)*0.08)
        if selected.shape_translation:
            pressure -= 0.08
        if selected.retained_fingers>=1:
            pressure -= min(0.14,0.045*selected.retained_fingers)
        if selected.guide_slides>=1:
            pressure -= min(0.08,0.03*selected.guide_slides)
    pressure=max(0.0,min(1.0,pressure)); capacity=len(usable)
    if confidence>=0.58 and (pressure>=0.55 or capacity<=3): ceiling="ROOT_GUIDE"
    elif confidence>=0.58 and (pressure>=0.28 or capacity==4): ceiling="SPARSE_ARPEGGIO"
    else: ceiling="ARPEGGIO"
    reasons=[f"GUITAR_STATE_FIRST capacity={capacity}, span={span:.2f}, pressure={pressure:.2f}.",f"Melody hand center={center:.2f}; continuity_distance={continuity:.2f}.",f"Root bass {'available' if root else 'not confirmed'} in current hand zone."]
    if selected:
        reasons += [f"PREJOINT_ACTUAL_SHAPE {selected.shape_id} family={selected.shape_family} positions={selected.positions}.",f"COMMON_FINGER_RETENTION retained={selected.retained_fingers}; guide_slides={selected.guide_slides}; translation={selected.shape_translation}; deformation={selected.shape_deformation:.2f}; bass_line_cost={selected.bass_line_cost:.2f}; shape_transition_cost={selected.transition_cost:.2f}."]
    else: reasons += ["PREJOINT_ACTUAL_SHAPE none; defer exact recovery to Joint/Fingering."]
    reasons += [f"Texture ceiling={ceiling} before musical texture commitment."]
    return GuitarStateProfile(center,low,high,confidence,capacity,root,ceiling,round(pressure,4),round(continuity,4),tuple(reasons),shapes,selected,(selected.retained_fingers if selected else 0),(selected.transition_cost if selected else 0.0),(selected.shape_deformation if selected else 0.0),(selected.shape_translation if selected else 0),(selected.guide_slides if selected else 0),(selected.bass_line_cost if selected else 0.0))

def constrain_texture_to_guitar_state(plan: GuitarTexturePlan, state: GuitarStateProfile) -> GuitarTexturePlan:
    texture=plan.texture
    if texture=="REST": return replace(plan,reasons=tuple(plan.reasons)+state.reasons)
    if texture=="COMPACT_BLOCK": texture=state.recommended_max_texture if state.confidence>=0.58 else "SPARSE_ARPEGGIO"
    elif texture in _STABLE and state.recommended_max_texture in _STABLE and _STABLE.index(texture)>_STABLE.index(state.recommended_max_texture): texture=state.recommended_max_texture
    max_notes={"ROOT":1,"ROOT_GUIDE":2,"SPARSE_ARPEGGIO":1,"ARPEGGIO":1,"COMPACT_BLOCK":3,"REST":0}[texture]
    action="GUITAR_STATE_FIRST_TEXTURE_REDUCED" if texture!=plan.texture else "GUITAR_STATE_FIRST_TEXTURE_ACCEPTED"
    return replace(plan,texture=texture,max_simultaneous_notes=max_notes,reasons=tuple(plan.reasons)+state.reasons+(action,))
