from __future__ import annotations

from dataclasses import dataclass
from statistics import median

from gste.core.fretboard import midi_to_string_fret
from gste.core.tuning import STANDARD_TUNING


@dataclass(frozen=True)
class MelodyHandWindow:
    window_id: str
    center_fret: float
    low_fret: float
    high_fret: float
    confidence: float
    note_count: int
    reason: str


def _candidate_frets(midi: int) -> list[int]:
    positions = [
        fret for string, fret in midi_to_string_fret(midi, max_fret=18, tuning=STANDARD_TUNING)
        if string in (1, 2, 3, 4)
    ]
    return sorted(set(positions))


def estimate_melody_hand_windows(project, intents) -> tuple[MelodyHandWindow, ...]:
    """Estimate a stable melody hand centre before accompaniment realization.

    This is deliberately a coarse *arrangement* position estimate, not final
    fingering.  It uses only legal melody fret locations and smooths them across
    adjacent windows so the guitar-arrangement layer can choose octave/inversion
    registers before Joint Arrangement is asked to solve the exact fingering.
    """
    out: list[MelodyHandWindow] = []
    previous = 3.0
    for intent in intents:
        start = float(intent.start)
        end = start + float(intent.duration)
        notes = [
            note for note in project.melody.notes
            if note.start < end - 1e-9 and note.start + note.duration > start + 1e-9
        ]
        chosen: list[float] = []
        for note in sorted(notes, key=lambda n: (n.start, -n.pitch.midi)):
            frets = _candidate_frets(note.pitch.midi)
            if not frets:
                continue
            # Prefer continuity, but above the fifth fret strongly avoid an open
            # string pretending to share a high-position hand centre.
            def cost(fret: int) -> tuple[float, float]:
                open_penalty = 0.0 if fret > 0 or previous < 5 else 3.0 + 0.6 * (previous - 5)
                return (abs(fret - previous) + open_penalty, float(fret))
            chosen.append(float(min(frets, key=cost)))
        if chosen:
            raw = float(median(chosen))
            center = 0.68 * raw + 0.32 * previous
            low, high = min(chosen), max(chosen)
            confidence = min(1.0, 0.48 + 0.12 * len(chosen))
            reason = "LEGAL_MELODY_FRET_MEDIAN_WITH_CONTINUITY"
        else:
            center = previous
            low = high = previous
            confidence = 0.25
            reason = "NO_MELODY_ATTACK_USE_PREVIOUS_CENTER"
        out.append(MelodyHandWindow(
            window_id=intent.window_id,
            center_fret=round(center, 3),
            low_fret=round(float(low), 3),
            high_fret=round(float(high), 3),
            confidence=round(confidence, 3),
            note_count=len(chosen),
            reason=reason,
        ))
        previous = center
    return tuple(out)


def estimate_melody_hand_windows_from_progression(progression) -> tuple[MelodyHandWindow, ...]:
    """Estimate Melody-only hand windows directly from harmony-window melody notes.

    V0.13.5.11 counterpart of ``estimate_melody_hand_windows(project, intents)``.
    It is deliberately advisory: final fingering remains owned by Joint/Fingering.
    This route is used only by AUTO_MELODY and does not alter Piano/source analysis.
    """
    out: list[MelodyHandWindow] = []
    previous = 3.0
    for result in progression.window_results:
        window = result.window
        chosen: list[float] = []
        for note in sorted(window.melody_notes, key=lambda n: (n.onset, -n.midi)):
            frets = _candidate_frets(note.midi)
            if not frets:
                continue
            def cost(fret: int) -> tuple[float, float]:
                open_penalty = 0.0 if fret > 0 or previous < 5 else 3.0 + 0.6 * (previous - 5)
                return (abs(fret - previous) + open_penalty, float(fret))
            chosen.append(float(min(frets, key=cost)))
        if chosen:
            raw = float(median(chosen))
            center = 0.68 * raw + 0.32 * previous
            low, high = min(chosen), max(chosen)
            confidence = min(1.0, 0.48 + 0.12 * len(chosen))
            reason = "AUTO_MELODY_LEGAL_FRET_MEDIAN_WITH_CONTINUITY"
        else:
            center = previous
            low = high = previous
            confidence = 0.25
            reason = "AUTO_MELODY_NO_NOTE_USE_PREVIOUS_CENTER"
        out.append(MelodyHandWindow(
            window_id=window.window_id, center_fret=round(center, 3),
            low_fret=round(float(low), 3), high_fret=round(float(high), 3),
            confidence=round(confidence, 3), note_count=len(chosen), reason=reason,
        ))
        previous = center
    return tuple(out)
