"""AUTO analysis adapter; all realization uses the common two-data engine."""
from dataclasses import dataclass, replace
from types import SimpleNamespace
from gste.core.models import NoteEvent, Pitch
from gste.arrangement.models import ArrangementPlan
from gste.arrangement.auto.canonical_intent import build_melody_canonical_intents
from gste.arrangement.data_contract import AccompanimentData
from .texture_policy import choose_texture_plan
from gste.arrangement.models import AccompanimentWindow

@dataclass(frozen=True)
class GuitarArrangementDecisionEngine:
    def decide_texture(self, **kwargs):
        return choose_texture_plan(**kwargs)
DEFAULT_GUITAR_ARRANGEMENT_ENGINE=GuitarArrangementDecisionEngine()


def build_melody_arrangement_plan(progression, pattern='auto', *, melody_data=None):
    from gste.arrangement.engine.service import arrange
    canonical=build_melody_canonical_intents(progression,timeline=melody_data)
    if pattern != 'auto':
        patterns={'arpeggio':'ARPEGGIO','bass_chord':'BASS_CHORD_PULSE','reduced_arpeggio':'ARPEGGIO',
                  'bass_inner':'BASS_CHORD_PULSE','root_guide':'ROOT_PULSE','root':'ROOT_PULSE'}
        if pattern not in patterns: raise ValueError('Unsupported accompaniment pattern: '+pattern)
        canonical=tuple(replace(c,texture=replace(c.texture,pattern_type=patterns[pattern]),metadata={**c.metadata,'requested_texture':{'root':'ROOT','root_guide':'ROOT_GUIDE','arpeggio':'ARPEGGIO','reduced_arpeggio':'SPARSE_ARPEGGIO','bass_inner':'ROOT_GUIDE','bass_chord':'ROOT_GUIDE'}[pattern]}) for c in canonical)
    if melody_data is not None:
        canonical=tuple(replace(c,evidence=tuple(replace(e,event_ids=tuple(
            n.source_event_id for n in melody_data.notes if n.source_event_id and
            n.start < c.harmony.start+c.harmony.duration and n.start+n.duration > c.harmony.start)) for e in c.evidence)) for c in canonical)
    data=AccompanimentData(canonical,preserve_rhythm=False)
    notes={ (n.midi,n.onset,n.duration):NoteEvent(Pitch(n.midi),n.onset,n.duration)
        for r in progression.window_results for n in r.window.melody_notes }
    melody=melody_data if melody_data is not None else SimpleNamespace(notes=list(notes.values()))
    plan=arrange(melody,data)
    windows=tuple(AccompanimentWindow(c.window_id,c.texture,i.density,c.reduction_level,c.events,c.reasons) for c,i in zip(plan.selected_candidates,plan.intents))
    return ArrangementPlan(progression,plan.intents,plan.candidate_groups,plan.selected_candidates,windows,plan.accompaniment_data.windows,plan.accompaniment_data)
