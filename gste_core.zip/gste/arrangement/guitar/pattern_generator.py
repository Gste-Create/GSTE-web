from __future__ import annotations

from gste.harmony.library import QUALITY_INTERVALS

from gste.arrangement.models import AccompanimentEvent, ArrangementIntent
from gste.core.fretboard import midi_to_string_fret
from gste.core.tuning import STANDARD_TUNING
from .model import ChordIntent, GuitarTexturePlan


def _nearest_pc(pc: int, *, low: int, high: int, center: int) -> int:
    values = [m for m in range(low, high + 1) if m % 12 == pc]
    return min(values, key=lambda m: abs(m-center)) if values else center


def _role_for_interval(interval: int, chord: ChordIntent) -> tuple[str, int, bool]:
    if interval == 0:
        return "bass", 96, False
    if interval in chord.color_intervals:
        return "guide_tone", 92, False
    if interval in {3, 4}:
        return "guide_tone", 88, False
    return "chord_tone", 72, True


def _position_cost_for_midi(midi: int, *, melody_hand_center: float, bass: bool,
                            transient_bass: bool = False) -> float:
    """Soft left-hand register cost used by v0.13.5.10.

    Open strings do not occupy the left-hand centre. Short/transient bass notes
    may remain in the natural low register even while the melody is high.
    """
    allowed = (4, 5, 6) if bass else (2, 3, 4, 5, 6)
    best = 99.0
    for string, fret in midi_to_string_fret(midi, max_fret=18, tuning=STANDARD_TUNING):
        if string not in allowed:
            continue
        if fret == 0:
            distance = 0.20 if bass else max(0.5, abs(melody_hand_center) * 0.18)
        else:
            distance = abs(fret - melody_hand_center)
            if bass and transient_bass:
                distance *= 0.35
        best = min(best, distance)
    return best


def _pitch_for_interval(chord: ChordIntent, interval: int, *, bass: bool = False,
                        melody_hand_center: float | None = None,
                        transient_bass: bool = False,
                        register_mode: str = "HYBRID") -> int:
    pc = (chord.root_pc + interval) % 12
    natural = _nearest_pc(pc, low=(40 if bass else 48), high=(59 if bass else 72),
                          center=(47 if bass else 60))
    if melody_hand_center is None:
        return natural

    # v0.13.5.10: melody hand centre is a preference, not a hard register gate.
    # Bass and upper harmony are resolved independently:
    #   ORIGINAL = natural guitar register
    #   NEAR     = closest legal position to melody centre
    #   HYBRID   = low/open/transient bass + melody-near upper structure
    if register_mode == "ORIGINAL":
        return natural

    lo, hi = (40, 67) if bass else (45, 79)
    choices = []
    for midi in range(lo, hi + 1):
        if midi % 12 != pc:
            continue
        pos_cost = _position_cost_for_midi(
            midi, melody_hand_center=melody_hand_center, bass=bass,
            transient_bass=transient_bass
        )
        register_penalty = 0.018 * abs(midi - (47 if bass else 64))
        octave_penalty = 0.012 * abs(midi - natural)
        choices.append((pos_cost + register_penalty + octave_penalty, midi))

    near = min(choices, default=(99.0, natural))[1]
    if register_mode == "NEAR":
        return near

    # HYBRID: upper tones follow melody centre. Bass stays natural when it is
    # open-string friendly, structural/locked, or transient; otherwise an
    # octave-equivalent near bass is allowed.
    if not bass:
        return near
    natural_positions = midi_to_string_fret(natural, max_fret=18, tuning=STANDARD_TUNING)
    natural_has_open = any(f == 0 and st in (4, 5, 6) for st, f in natural_positions)
    if natural_has_open or transient_bass or chord.bass_policy == "LOCK_ROOT_BASS":
        return natural
    natural_cost = _position_cost_for_midi(
        natural, melody_hand_center=melody_hand_center, bass=True,
        transient_bass=transient_bass
    )
    near_cost = _position_cost_for_midi(
        near, melody_hand_center=melody_hand_center, bass=True,
        transient_bass=transient_bass
    )
    return near if near_cost + 2.0 < natural_cost else natural

def _guide_intervals(chord: ChordIntent) -> list[int]:
    preferred = list(chord.color_intervals)
    preferred += [i for i in chord.required_intervals if i not in {0, 7} and i not in preferred]
    preferred += [i for i in chord.optional_intervals if i not in {0, 7} and i not in preferred]
    if not preferred:
        preferred = [7]
    return preferred


def _arpeggio_intervals(chord: ChordIntent) -> list[int]:
    """Return a guitar-oriented chord-tone cycle with real pitch-class motion.

    v0.13.5.13.3: an arpeggio is a voiced line, not a two-note alternation.
    Prefer root + characteristic/third + fifth; then colour tones. Duplicate
    pitch classes are removed. If the harmony genuinely contains only two
    usable pitch classes we keep that shell rather than inventing a foreign
    tone, but downstream Joint cost marks repeated two-note motion as less
    desirable.
    """
    raw: list[int] = [0]
    raw.extend(i for i in chord.color_intervals if i not in raw)
    raw.extend(i for i in chord.required_intervals if i not in raw)
    # Explicitly prefer a structural third before the fifth when available.
    thirds = [i for i in raw if i in {3, 4}]
    ordered: list[int] = [0]
    ordered.extend(i for i in thirds if i not in ordered)
    if 7 in chord.required_intervals or 7 in chord.optional_intervals:
        ordered.append(7)
    ordered.extend(i for i in raw if i not in ordered)
    ordered.extend(i for i in chord.optional_intervals if i not in ordered)
    # Keep at most four different harmonic functions in one local cycle.
    return ordered[:4] or [0]


def _arpeggio_cycle(intervals: list[int], count: int) -> list[int]:
    """Create directional motion instead of blind ABAB repetition."""
    if not intervals:
        return [0] * max(1, count)
    if len(intervals) == 1:
        return [intervals[0]] * max(1, count)
    # Three/four-tone lines use a shallow up/down contour. This avoids
    # monotonous repeated pairs while keeping the hand movement bounded.
    if len(intervals) >= 3:
        contour = intervals + intervals[-2:0:-1]
    else:
        contour = intervals
    return [contour[i % len(contour)] for i in range(max(1, count))]


def _right_hand_grammar_cycle(chord: ChordIntent, grammar: str, count: int) -> list[tuple[int, bool]]:
    """Return (chord interval, force_bass) for a guitar right-hand grammar.

    ``T121`` and ``3121`` describe right-hand voice roles, not fixed pitches or
    beats.  Several voicing variants deliberately map the same gesture to
    different chord functions, giving Joint different string/fret realizations
    while keeping the recognizable guitar picking language.
    """
    intervals = _arpeggio_intervals(chord)
    non_root = [i for i in intervals if i != 0]
    inner = non_root[0] if non_root else 0
    upper = non_root[1] if len(non_root) > 1 else inner
    colour = non_root[2] if len(non_root) > 2 else upper
    name = str(grammar or 'AUTO').upper()
    if name == 'T121_A':
        contour = [(0, True), (inner, False), (upper, False), (inner, False)]
    elif name == 'T121_B':
        contour = [(0, True), (upper, False), (12, False), (inner, False)]
    elif name == 'T121_C':
        contour = [(0, True), (inner, False), (colour, False), (12, False)]
    elif name == '3121_A':
        # Low-texture colour gesture: upper root -> inner -> upper tone -> inner.
        # Interval 12 intentionally means an upper root, not another thumb bass.
        contour = [(12, False), (inner, False), (upper, False), (inner, False)]
    else:
        return [(slot, slot == 0) for slot in _arpeggio_cycle(intervals, count)]
    return [contour[i % len(contour)] for i in range(max(1, count))]


def generate_guitar_pattern(intent: ArrangementIntent, chord: ChordIntent,
                            plan: GuitarTexturePlan, rhythm_pattern: tuple[float, ...],
                            *, melody_hand_center: float | None = None,
                            melody_hand_center_confidence: float = 1.0,
                            register_mode: str = "HYBRID",
                            right_hand_grammar: str = "AUTO") -> tuple[AccompanimentEvent, ...]:
    if plan.texture == "REST":
        return ()
    onsets = list(rhythm_pattern) or [0.0]
    abs_onsets = [intent.start + float(x) for x in onsets]
    # Duration is a notated rhythmic value, not window length / attack count.
    # Preserve attack positions; choose a readable note length for each attack.
    def readable_duration(onset: float, next_onset: float) -> float:
        available = max(0.0, min(next_onset, intent.start + intent.duration) - onset)
        # Binary durations and conventional eighth-note triplets only.
        # Do not create exotic tuplets to express arbitrary window divisions.
        values = (4.0, 3.0, 2.0, 1.5, 1.0, 0.75, 0.5, 1.0/3.0, 0.25, 1.0/6.0, 0.125, 0.0625)
        return next((v for v in values if v <= available + 1e-7), 0.0625)

    default_durations = [readable_duration(onset, abs_onsets[i + 1] if i + 1 < len(abs_onsets)
                          else intent.start + intent.duration) for i, onset in enumerate(abs_onsets)]
    duration_by_onset = {round(onset, 8): dur for onset, dur in zip(abs_onsets, default_durations)}
    step = default_durations[0] if default_durations else 0.25
    guide = _guide_intervals(chord)
    events: list[AccompanimentEvent] = []

    # Low-confidence hand centres must not aggressively move accompaniment.
    effective_center = melody_hand_center if melody_hand_center_confidence >= 0.58 else None
    bass_interval = ((chord.source_bass_pc - chord.root_pc) % 12) if chord.source_bass_pc is not None else 0
    if chord.bass_policy != "LOCK_ROOT_BASS" or chord.source_bass_pc == chord.root_pc:
        bass_interval = 0
    # In high positions, an inversion is allowed only when it materially reduces
    # the fret distance.  Structural/locked bass is never replaced.
    inversion_used = False
    if effective_center is not None and effective_center >= 8.0 and plan.allow_inversion and chord.bass_policy != "LOCK_ROOT_BASS" and guide:
        root_pitch = _pitch_for_interval(chord, bass_interval, bass=True, melody_hand_center=effective_center, register_mode=register_mode)
        def nearest_fret(midi: int) -> float:
            vals=[f for s,f in midi_to_string_fret(midi,max_fret=18,tuning=STANDARD_TUNING) if s in (3,4,5,6)]
            return min((abs(f-effective_center) for f in vals), default=99.0)
        root_distance=nearest_fret(root_pitch)
        best_interval=bass_interval; best_distance=root_distance
        for candidate_interval in guide[:2]:
            midi=_pitch_for_interval(chord,candidate_interval,bass=True,melody_hand_center=effective_center, register_mode=register_mode)
            dist=nearest_fret(midi)
            if dist+2.5 < best_distance:
                best_interval,best_distance=candidate_interval,dist
        if best_interval != bass_interval:
            bass_interval=best_interval
            inversion_used=True

    def add(onset: float, interval: int, idx: int, duration: float | None = None, *, force_bass: bool = False):
        actual_interval = bass_interval if force_bass else interval
        role, importance, optional = _role_for_interval(actual_interval, chord)
        bass = force_bass or actual_interval == 0
        marker = ":BASSLOCK" if chord.bass_policy == "LOCK_ROOT_BASS" else (":INV" if inversion_used and force_bass else "")
        events.append(AccompanimentEvent(
            event_id=f"{intent.window_id}:MAP:GTR{marker}:{plan.texture}:{right_hand_grammar}:{idx}", window_id=intent.window_id,
            onset=onset, duration=max(0.01, duration if duration is not None else duration_by_onset.get(round(onset, 8), 0.25)),
            role=role, pitch=_pitch_for_interval(
                chord, actual_interval, bass=bass, melody_hand_center=effective_center,
                transient_bass=(bass and (duration if duration is not None else duration_by_onset.get(round(onset, 8), 0.25)) <= max(0.45, intent.duration*0.34)),
                register_mode=register_mode
            ),
            importance=importance, optional=optional, reduction_level=1,
            source_chord=chord.chord_symbol,
        ))

    if right_hand_grammar == "SOURCE" and plan.texture in {"ARPEGGIO", "ROOT_GUIDE"}:
        source_roles = list(intent.functional_roles)
        sizes = list(intent.attack_sizes)
        role_intervals = {"ROOT":0, "THIRD":next((v for v in chord.required_intervals if v in {3,4}), guide[0]),
                          "FIFTH":7, "SEVENTH":next((v for v in chord.required_intervals if v in {10,11}), guide[0])}
        allowed = set(chord.required_intervals) | set(chord.optional_intervals) | {0}
        offset = 0
        cycle = _arpeggio_cycle(_arpeggio_intervals(chord), len(abs_onsets))
        for i, onset in enumerate(abs_onsets):
            size = int(sizes[i]) if i < len(sizes) else 1
            roles = source_roles[offset:offset+size]
            offset += size
            interval = next((role_intervals[x] for x in roles if x in role_intervals and role_intervals[x] in allowed), cycle[i])
            bass_line = str(intent.pattern_type) in {"BASS_LINE", "ROOT_PULSE"}
            bass_sequence = list(intent.bass_sequence)
            if bass_line and i < len(bass_sequence):
                interval = (int(bass_sequence[i])-chord.root_pc) % 12
            # Use actual inter-attack lengths, bounded by the intent window.
            end = abs_onsets[i+1] if i+1 < len(abs_onsets) else intent.start+intent.duration
            add(onset, interval, i+1, duration=readable_duration(onset, end), force_bass=(i == 0 and not bass_line))
            if bass_line:
                from dataclasses import replace
                events[-1] = replace(events[-1], role="bass", pitch=_pitch_for_interval(chord, interval, bass=True,
                    melody_hand_center=effective_center, register_mode=register_mode), importance=96, optional=False)
    elif plan.texture == "ROOT":
        for i, onset in enumerate(abs_onsets, 1): add(onset, 0, i, force_bass=True)
    elif plan.texture == "ROOT_GUIDE":
        seq = [0, guide[0]]
        for i, onset in enumerate(abs_onsets, 1):
            slot = seq[(i-1) % len(seq)]
            add(onset, slot, i, force_bass=(slot == 0))
    elif plan.texture in {"SPARSE_ARPEGGIO", "ARPEGGIO"}:
        # v0.13.5.13.3: arpeggio now has an explicit right-hand texture
        # grammar. T121 is the normal language; 3121 is exposed only by the
        # route policy in low-texture passages. Grammar controls voice order,
        # while Joint still chooses the physical strings/frets.
        selected = abs_onsets
        if plan.texture == "SPARSE_ARPEGGIO" and len(selected) > 2:
            selected = selected[::2]
        seq = _right_hand_grammar_cycle(chord, right_hand_grammar, len(selected))
        for i, (onset, (slot, force_bass)) in enumerate(zip(selected, seq), 1):
            add(onset, slot, i, force_bass=force_bass)
    elif plan.texture == "COMPACT_BLOCK":
        selected = abs_onsets if right_hand_grammar == "SOURCE" else abs_onsets[-1:]
        intervals = list(dict.fromkeys([0] + guide[:2]))
        for attack, onset in enumerate(selected):
            end = selected[attack+1] if attack+1 < len(selected) else intent.start+intent.duration
            source_sizes = list(intent.attack_sizes)
            count = min(3, int(source_sizes[attack])) if right_hand_grammar == "SOURCE" and attack < len(source_sizes) else len(intervals)
            for i, interval in enumerate(intervals[:max(1,count)]):
                add(onset, interval, attack*len(intervals)+i+1, duration=readable_duration(onset, end), force_bass=(interval == 0))
    return tuple(events)

# ---------------------------------------------------------------------------
# Melody-only compatibility realization
# ---------------------------------------------------------------------------
# The old arrangement.engine texture ladder used a second pitch/event generator.
# Phase 1 centralises that realization here so melody-only and source-derived
# accompaniment are both owned by arrangement.guitar.  The exact old event
# semantics are preserved to isolate architecture changes from musical changes.

def _legacy_bass_midi(root_pc: int) -> int:
    pitch = 40 + ((root_pc - 4) % 12)
    return pitch if pitch <= 52 else pitch - 12


def _legacy_tone_midis(chord) -> tuple[int, int, int]:
    root = _legacy_bass_midi(chord.root_pitch_class)
    required, optional = QUALITY_INTERVALS.get(chord.quality, (frozenset({0, 4}), frozenset({7})))
    guide_interval = next((i for i in sorted(required) if i != 0), 7)
    fifth_interval = 7 if 7 in required or 7 in optional else next((i for i in sorted(required, reverse=True) if i != 0), guide_interval)
    third_pc = (chord.root_pitch_class + guide_interval) % 12
    fifth_pc = (chord.root_pitch_class + fifth_interval) % 12
    third = 48 + third_pc
    fifth = 48 + fifth_pc
    return root, third, fifth


def _legacy_event(window, suffix: str, onset: float, duration: float, role: str,
                  pitch: int, importance: int, optional: bool, reduction: int,
                  chord_symbol: str) -> AccompanimentEvent:
    return AccompanimentEvent(
        f"{window.window_id}-{suffix}", window.window_id, onset, max(0.125, duration),
        role, pitch, importance, optional, reduction, chord_symbol,
    )


def generate_melody_pattern(window, chord, pattern: str, reduction: int) -> tuple[AccompanimentEvent, ...]:
    """Realize melody-only accompaniment through the shared guitar core.

    This function intentionally reproduces the pre-refactor event sequence.
    Later musicality phases can migrate these legacy texture names to the
    canonical ROOT/ROOT_GUIDE/SPARSE_ARPEGGIO/... vocabulary.
    """
    root, third, fifth = _legacy_tone_midis(chord)
    symbol = chord.chord_symbol
    duration = window.duration
    events: list[AccompanimentEvent] = [
        _legacy_event(window, "B", window.start, min(1.0, duration), "bass", root, 90, False, reduction, symbol)
    ]

    if pattern == "root":
        return tuple(events)
    if pattern == "root_guide":
        onset = window.start + min(max(0.5, duration / 2), max(0.0, duration - 0.25))
        events.append(_legacy_event(window, "G", onset, min(0.75, max(0.25, duration - (onset - window.start))), "guide", third, 72, True, reduction, symbol))
        return tuple(events)
    if pattern in {"bass_chord", "bass_inner"}:
        onset = window.start + min(1.0, duration / 2)
        events.append(_legacy_event(window, "3", onset, max(0.25, duration - (onset - window.start)), "third", third, 72, True, reduction, symbol))
        if pattern == "bass_chord" and duration >= 1.5:
            events.append(_legacy_event(window, "5", onset, max(0.25, duration - (onset - window.start)), "fifth", fifth, 45, True, reduction, symbol))
        return tuple(events)
    if pattern == "reduced_arpeggio":
        step = duration / 3
        tones = (("bass", root, 90), ("third", third, 68), ("fifth", fifth, 52))
        return tuple(
            _legacy_event(window, f"R{i+1}", window.start + i * step, step, role, pitch, importance, i > 0, reduction, symbol)
            for i, (role, pitch, importance) in enumerate(tones)
        )
    if pattern != "arpeggio":
        raise ValueError(f"Unsupported melody accompaniment texture: {pattern}")
    step = duration / 4
    tones = (("bass", root, 90), ("third", third, 64), ("fifth", fifth, 54), ("third", third, 60))
    return tuple(
        _legacy_event(window, f"A{i+1}", window.start + i * step, step, role, pitch, importance, i > 0, reduction, symbol)
        for i, (role, pitch, importance) in enumerate(tones)
    )
