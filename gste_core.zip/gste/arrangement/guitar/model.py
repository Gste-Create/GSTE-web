from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

BassPolicy = Literal["LOCK_ROOT_BASS", "PREFER_ROOT_BASS", "FREE_INVERSION"]


@dataclass(frozen=True)
class ChordIntent:
    root_pc: int
    quality: str
    chord_symbol: str
    required_intervals: tuple[int, ...]
    optional_intervals: tuple[int, ...]
    color_intervals: tuple[int, ...]
    bass_policy: BassPolicy = "PREFER_ROOT_BASS"
    source_bass_pc: int | None = None
    bass_motion: str = "STATIC_BASS"


@dataclass(frozen=True)
class GuitarTexturePlan:
    texture: str
    density_level: int
    preserve_source_rhythm: bool
    allow_octave_revoice: bool
    allow_inversion: bool
    max_simultaneous_notes: int
    reasons: tuple[str, ...] = ()
