from __future__ import annotations

from gste.control import get_value

from .model import ChordIntent, GuitarTexturePlan


def choose_texture_plan(*, chord: ChordIntent, source_pattern: str, melody_budget: str,
                        source_density: int, phrase_position: int,
                        previous_texture: str | None = None,
                        repeated_texture_count: int = 0,
                        phrase_primary_texture: str | None = None,
                        transition_score: float = 0.0,
                        phrase_boundary: bool = False,
                        phrase_contrast: float = 0.0) -> GuitarTexturePlan:
    """Choose a guitar-native texture instead of trimming individual piano notes.

    v0.13.5.1 policy:
      * root/shell textures are the safe default under dense melody;
      * arpeggio is the normal accompaniment language;
      * compact block chord is an accent/cadential texture, never the default;
      * texture changes are resisted inside a phrase unless musical evidence is strong.
    """
    # Expression transitions permit deliberate mode changes; otherwise phrase
    # mode has inertia. A local fourth-window index is only a weak cadence hint.
    accent = phrase_position == 3
    # v0.13.5.10: continuity is strong *inside* a phrase, but phrase boundaries
    # are deliberate replanning points. A boundary alone does not force a
    # denser texture; it merely releases the previous-phrase lock.
    strong_transition = transition_score >= float(get_value("texture.strong_transition_threshold", 0.62)) or (phrase_boundary and phrase_contrast >= float(get_value("texture.phrase_contrast_transition_threshold", 0.28)))
    if source_pattern == "REST":
        texture = "REST"
    elif melody_budget == "LOW":
        texture = "ROOT_GUIDE" if chord.color_intervals or chord.quality in {"major", "minor", "dominant7"} else "ROOT"
    elif melody_budget == "HIGH":
        if accent and source_pattern in {"BLOCK_CHORD", "BASS_CHORD_PULSE"}:
            texture = "COMPACT_BLOCK"
        elif source_pattern in {"ARPEGGIO", "BASS_LINE", "BASS_CHORD_PULSE"}:
            texture = "ARPEGGIO"
        else:
            texture = "SPARSE_ARPEGGIO"
    else:
        if accent and source_pattern == "BLOCK_CHORD":
            texture = "COMPACT_BLOCK"
        elif source_pattern in {"ARPEGGIO", "BASS_CHORD_PULSE"}:
            texture = "SPARSE_ARPEGGIO"
        else:
            texture = "ROOT_GUIDE"

    # Phrase-level primary texture is a soft musical plan, not a hard override.
    # It is applied only to the stable texture family and never forces a dense
    # texture over LOW melody budget.
    stable = {"ROOT", "ROOT_GUIDE", "SPARSE_ARPEGGIO", "ARPEGGIO"}
    if phrase_primary_texture in stable and texture in stable and melody_budget != "LOW" and not accent:
        texture = phrase_primary_texture

    # Phrase contrast can move one complexity step relative to the phrase plan.
    # This creates chorus/section lift without returning to window-by-window
    # texture jitter. Dense melody still wins over any lift.
    if phrase_boundary and phrase_contrast >= 0.45 and melody_budget != "LOW" and texture in stable:
        order = ["ROOT", "ROOT_GUIDE", "SPARSE_ARPEGGIO", "ARPEGGIO"]
        texture = order[min(len(order)-1, order.index(texture)+1)]

    # Arrangement-mode inertia: local fluctuations cannot switch neighbouring
    # textures unless Phrase Understanding found a meaningful transition.
    if not phrase_boundary and not accent and not strong_transition and previous_texture in stable and texture in stable:
        # Preserve the previous texture when the proposed change is only one
        # adjacent complexity step.
        order = ["ROOT", "ROOT_GUIDE", "SPARSE_ARPEGGIO", "ARPEGGIO"]
        if abs(order.index(previous_texture) - order.index(texture)) <= 1:
            texture = previous_texture

    max_notes = {
        "REST": 0, "ROOT": 1, "ROOT_GUIDE": 2,
        "SPARSE_ARPEGGIO": 1, "ARPEGGIO": 1, "COMPACT_BLOCK": 3,
    }[texture]
    return GuitarTexturePlan(
        texture=texture,
        density_level=source_density,
        preserve_source_rhythm=True,
        allow_octave_revoice=True,
        allow_inversion=chord.bass_policy != "LOCK_ROOT_BASS",
        max_simultaneous_notes=max_notes,
        reasons=(
            f"Guitar-native texture={texture} from source={source_pattern}, melody_budget={melody_budget}.",
            f"Bass policy={chord.bass_policy}; octave revoice precedes inversion.",
            f"Phrase primary={phrase_primary_texture or 'NONE'}, transition_score={transition_score:.2f}, contrast={phrase_contrast:.2f}; mode inertia={'released' if (strong_transition or phrase_boundary) else 'active'}.",
        ),
    )

# ---------------------------------------------------------------------------
# Melody-only shared policy (Phase 1 cleanup)
# ---------------------------------------------------------------------------
# These rules intentionally preserve the pre-refactor melody-only behaviour.
# Ownership moves here so melody-only and source-derived accompaniment no
# longer maintain separate guitar-arrangement decision cores.

AUTO_TEXTURE_ORDER = ["root", "root_guide", "bass_inner", "reduced_arpeggio", "arpeggio"]
_AUTO_TEXTURE_LEVEL = {
    "root": 1,
    "root_guide": 2,
    "bass_inner": 3,
    "bass_chord": 3,
    "reduced_arpeggio": 4,
    "arpeggio": 5,
}
_AUTO_LEVEL_TEXTURE = {
    1: "root",
    2: "root_guide",
    3: "bass_inner",
    4: "reduced_arpeggio",
    5: "arpeggio",
}


def melody_density(window) -> str:
    """Legacy-compatible five-level melody activity MD0..MD4."""
    notes = window.melody_notes
    count = len(notes)
    if count == 0:
        return "MD0"
    short_notes = sum(1 for note in notes if note.duration <= 0.5)
    very_short = sum(1 for note in notes if note.duration <= 0.25)
    if count <= 1:
        return "MD0"
    if count == 2 and short_notes <= 1:
        return "MD1"
    if count <= 3 and short_notes <= 2:
        return "MD2"
    if count >= 6 or very_short >= 4 or (count >= 5 and short_notes >= 4):
        return "MD4"
    return "MD3"


def choose_melody_texture(result, previous_chord: str | None, density: str,
                          previous_pattern: str | None) -> tuple[str, str]:
    """Preserve existing melody-only texture semantics inside guitar core."""
    chord_changed = previous_chord is None or previous_chord != result.selected.chord_symbol
    boundary = previous_chord is None or result.window.is_phrase_end or result.window.is_song_end

    if density == "MD0":
        desired = "bass_inner" if boundary else "arpeggio"
        reason = "Auto MD0: sparse/sustained melody; use a full flowing texture."
    elif density == "MD1":
        desired = "bass_inner" if chord_changed else "reduced_arpeggio"
        reason = "Auto MD1: light melody; keep a reduced but clearly harmonic texture."
    elif density == "MD2":
        desired = "bass_inner" if chord_changed or boundary else "reduced_arpeggio"
        reason = "Auto MD2: medium melody; use bass plus inner voice or reduced arpeggio."
    elif density == "MD3":
        desired = "root_guide"
        reason = "Auto MD3: busy melody; retain root plus guide tone before root-only fallback."
    else:
        desired = "root_guide" if boundary else "root"
        reason = (
            "Auto MD4: very busy melody at phrase boundary; state root plus guide tone."
            if boundary else
            "Auto MD4: very busy melody; minimal root anchor."
        )

    if (
        previous_pattern in _AUTO_TEXTURE_LEVEL
        and desired in _AUTO_TEXTURE_LEVEL
        and not chord_changed
        and not boundary
    ):
        previous_level = _AUTO_TEXTURE_LEVEL[previous_pattern]
        desired_level = _AUTO_TEXTURE_LEVEL[desired]
        if previous_level - desired_level > 1:
            desired_level = previous_level - 1
            desired = _AUTO_LEVEL_TEXTURE[desired_level]
            reason += " Texture continuity limited the downgrade to one level."
    return desired, reason

