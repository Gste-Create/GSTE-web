from __future__ import annotations

from gste.harmony.library import QUALITY_INTERVALS

from gste.arrangement.models import (
    AccompanimentEvent,
    AccompanimentWindow,
    ArrangementCandidate,
    ArrangementIntent,
    ChordProgressionResult,
)
from .pattern_generator import generate_melody_pattern
from dataclasses import replace as dc_replace
from gste.core.fretboard import midi_to_string_fret
from gste.core.tuning import STANDARD_TUNING
from gste.arrangement.guitar.adaptive_policy import ADAPTIVE_MOTION_POLICY


# Rich-to-safe fallback order retained from v0.13.5.1.  Ownership now belongs
# to the shared guitar arrangement core rather than arrangement.engine.
MELODY_FALLBACKS = {
    "arpeggio": ("arpeggio", "reduced_arpeggio", "bass_inner", "root_guide", "root"),
    "bass_chord": ("bass_chord", "bass_inner", "root_guide", "root"),
    "reduced_arpeggio": ("reduced_arpeggio", "bass_inner", "root_guide", "root"),
    "bass_inner": ("bass_inner", "root_guide", "root"),
    "root_guide": ("root_guide", "root"),
    "root": ("root",),
}
MELODY_REDUCTION = {
    "arpeggio": 0,
    "bass_chord": 1,
    "reduced_arpeggio": 1,
    "bass_inner": 2,
    "root_guide": 3,
    "root": 4,
}


def generate_melody_candidate_group(intent, progression):
    """Old import boundary, delegating to the sole canonical realization engine."""
    from .service import build_melody_arrangement_plan
    plan=build_melody_arrangement_plan(progression,intent.texture)
    for row,group in zip(plan.intents,plan.candidate_groups):
        if row.window_id==intent.window_id:
            return group
    raise ValueError('ACCOMPANIMENT_UNKNOWN_WINDOW:'+intent.window_id)

def melody_candidate_to_window(candidate: ArrangementCandidate, intent: ArrangementIntent) -> AccompanimentWindow:
    reasons = list(intent.reasons)
    texture_reason = {
        "root": "Texture ladder L1: root-only used as the minimal accompaniment layer.",
        "root_guide": "Texture ladder L2: root plus guide tone preserves harmonic identity with low density.",
        "bass_inner": "Texture ladder L3: bass plus inner voice.",
        "bass_chord": "Texture ladder L3: bass plus chord pulse.",
        "reduced_arpeggio": "Texture ladder L4: reduced three-note arpeggio.",
        "arpeggio": "Texture ladder L5: full four-note arpeggio.",
        "sparse_arpeggio": "Shared Guitar texture: sparse arpeggio preserves motion while protecting melody.",
    }[candidate.texture]
    reasons.append(texture_reason)
    return AccompanimentWindow(
        intent.window_id,
        candidate.texture,
        intent.density,
        candidate.reduction_level,
        candidate.events,
        tuple(reasons),
    )


# ---------------------------------------------------------------------------
# V0.13.5.11 AUTO_MELODY importance lineage + guaranteed-safe fallback
# ---------------------------------------------------------------------------
def _mark_auto_importance(events):
    """Identity-safe compatibility hook.

    v0.13.5.13.5 freezes event identity: importance/role already live on the
    AccompanimentEvent data line, so this function must never rewrite event_id.
    """
    return tuple(events)


def _legacy_safe_bass_midi(root_pc: int) -> int:
    # Exact low-root register rule from the v0.13.5.2 melody accompaniment core.
    pitch = 40 + ((root_pc - 4) % 12)
    return pitch if pitch <= 52 else pitch - 12


def _legacy_safe_events(intent, canonical, chord):
    """Guaranteed-safe v0.13.5.2-style melody accompaniment candidate.

    Dense melody keeps only the old strong-beat root bass. Otherwise add the
    old midpoint third/guide tone. This is a candidate, never a whole-path
    rollback, and is intentionally lower-fidelity than the modern candidates.
    """
    density=str(canonical.metadata.get("melody_density","MD2"))
    root=_legacy_safe_bass_midi(chord.root_pc)
    guide_interval = next((i for i in sorted(QUALITY_INTERVALS.get(chord.quality, (frozenset({0, 4}), frozenset({7})))[0]) if i != 0), 7)
    third_pc=(chord.root_pc + guide_interval) % 12
    third=48 + third_pc
    duration=float(intent.duration)
    reduction=4 if density in {"MD3","MD4"} else 3
    events=[
        AccompanimentEvent(
            event_id=f"{intent.window_id}:LEGACY_SAFE:B", window_id=intent.window_id,
            onset=float(intent.start), duration=max(0.125,min(1.0,duration)),
            role="bass", pitch=root, importance=96, optional=False,
            reduction_level=reduction, source_chord=chord.chord_symbol,
        )
    ]
    if density not in {"MD3","MD4"} and duration >= 0.75:
        onset=float(intent.start) + min(max(0.5,duration/2.0),max(0.0,duration-0.25))
        events.append(
            AccompanimentEvent(
                event_id=f"{intent.window_id}:LEGACY_SAFE:G", window_id=intent.window_id,
                onset=onset, duration=min(0.75,max(0.25,duration-(onset-float(intent.start)))),
                role="guide_tone", pitch=third, importance=82, optional=True,
                reduction_level=reduction, source_chord=chord.chord_symbol,
            )
        )
    return _mark_auto_importance(tuple(events))

# ---------------------------------------------------------------------------
# V0.13.5.11 unified Melody-only candidate realization
# ---------------------------------------------------------------------------
def _nearest_upper_fret_distance(pitch: int, hand_center: float) -> float:
    frets=[f for string,f in midi_to_string_fret(pitch,max_fret=18,tuning=STANDARD_TUNING) if string in (1,2,3,4)]
    return min((abs(f-hand_center) for f in frets), default=99.0)

def _conservative_melody_near_revoice(events, *, hand_center, hand_confidence):
    """Revoice only clearly distant upper tones; never delete events or move bass.

    The change is accepted only if the original pitch is >5 frets from the
    estimated melody centre and an octave-equivalent pitch can land within 3
    frets while improving distance by at least 2 frets. This keeps candidate
    cardinality identical to V0.13.5.11 and avoids speculative revoicing.
    """
    if hand_center is None or hand_confidence < 0.58:
        return tuple(events), 0, ("LOW_HAND_CENTER_CONFIDENCE",)
    out=[]; changed=0; reasons=[]
    for event in events:
        if event.role == "bass":
            out.append(event); continue
        original_distance=_nearest_upper_fret_distance(event.pitch, hand_center)
        if original_distance <= 5.0:
            out.append(event); reasons.append("ORIGINAL_WITHIN_5_FRETS"); continue
        pc=event.pitch%12; choices=[]
        for midi in range(48,80):
            if midi%12 != pc: continue
            dist=_nearest_upper_fret_distance(midi, hand_center)
            choices.append((dist,abs(midi-event.pitch),midi))
        if not choices:
            out.append(event); reasons.append("NO_OCTAVE_EQUIVALENT"); continue
        best_distance,_,best_pitch=min(choices)
        if best_distance <= 3.0 and original_distance-best_distance >= 2.0:
            out.append(dc_replace(event,pitch=best_pitch)); changed+=1
            reasons.append("CLEAR_DISTANCE_IMPROVEMENT_REVOICED")
        else:
            out.append(event); reasons.append("REVOICE_NOT_MATERIALLY_BETTER")
    return tuple(out), changed, tuple(sorted(set(reasons)))

def generate_unified_melody_candidate_group(intent, canonical, chord, primary_plan, prefilter=None, melody_hand_window=None, coordination=None):
    """Generate a bounded Guitar-native AUTO_MELODY candidate superset.

    V0.13.5.12 keeps the v0.13.5.11.1 family pre-filter and Joint ownership,
    but improves the *register realizations* proposed to Joint.  The budget is
    intentionally bounded: every retained texture keeps ORIGINAL; only the
    strongest feasibility-improving alternatives are added, with at most five
    modern candidates per window plus the on-demand LEGACY_SAFE fallback.
    """
    from dataclasses import replace
    from .pattern_generator import generate_guitar_pattern
    from .bounded_realization import assess_realization, realize_upper_harmony_in_hand_zone, realize_register_hierarchy

    stable=["ROOT","ROOT_GUIDE","SPARSE_ARPEGGIO","ARPEGGIO"]
    primary=primary_plan.texture if primary_plan.texture in stable else "ROOT_GUIDE"
    coordinated=list(getattr(coordination, "candidate_textures", ()) or ())
    allowed=list(getattr(prefilter, "survivors", ()) or coordinated or stable)
    if coordinated:
        allowed=[t for t in coordinated if t in allowed] or coordinated
    order=[primary]+[x for x in allowed if x!=primary] if primary in allowed else list(allowed)
    rank={"ARPEGGIO":5,"SPARSE_ARPEGGIO":4,"ROOT_GUIDE":3,"ROOT":1}
    density=str(canonical.metadata.get("melody_density","MD2"))
    attack_occupancy=float(canonical.metadata.get("melody_attack_occupancy",0.0) or 0.0)
    max_polyphony=int(canonical.metadata.get("melody_max_polyphony",1) or 1)
    pitch_span=float(canonical.metadata.get("melody_pitch_span",0.0) or 0.0)
    hand_center=getattr(melody_hand_window,"center_fret",None)
    hand_low=getattr(melody_hand_window,"low_fret",None)
    hand_high=getattr(melody_hand_window,"high_fret",None)
    hand_confidence=float(getattr(melody_hand_window,"confidence",0.0) or 0.0)
    hand_span=(float(hand_high or 0.0)-float(hand_low or 0.0)) if melody_hand_window else 0.0
    MAX_MODERN_CANDIDATES=5

    def conditioned_attacks(texture):
        attacks=tuple(canonical.rhythm.rhythm_pattern) or (0.0,)
        pressure=0
        pressure += 2 if density == "MD4" else (1 if density == "MD3" else 0)
        pressure += 1 if max_polyphony >= 2 else 0
        pressure += 1 if attack_occupancy >= 0.90 and len(attacks) >= 3 else 0
        pressure += 1 if hand_span >= 5.0 else 0
        activity=getattr(coordination,"activity_class","NORMAL") if coordination is not None else "NORMAL"
        fill=tuple(getattr(coordination,"fill_attacks",()) or ()) if coordination is not None else ()
        max_attacks=int(getattr(coordination,"max_motion_attacks",3) or 3) if coordination is not None else 3
        conditioned=ADAPTIVE_MOTION_POLICY.condition_attacks(
            texture=texture, attacks=attacks, density=density,
            attack_occupancy=attack_occupancy, activity_class=activity,
            fill_attacks=fill, max_motion_attacks=max_attacks,
        )
        if intent.preserve_source_rhythm:
            conditioned=attacks
        action="ADAPTIVE_DENSITY_POLICY" if conditioned != attacks else "EVENT_DENSITY_PRESERVED_V0135133"
        return conditioned, pressure, action

    # First build ORIGINAL for every retained texture.  This preserves musical
    # diversity and makes the pre-Joint feasibility gate advisory rather than a
    # hidden selector.
    originals=[]
    alternates=[]
    signatures=set()
    for texture in order:
        plan=replace(primary_plan, texture=texture, max_simultaneous_notes={"ROOT":1,"ROOT_GUIDE":2,"SPARSE_ARPEGGIO":1,"ARPEGGIO":1}[texture])
        realization_attacks, realization_pressure, realization_action = conditioned_attacks(texture)
        activity=getattr(coordination,"activity_class","NORMAL") if coordination is not None else "NORMAL"
        grammars=ADAPTIVE_MOTION_POLICY.right_hand_grammars(texture=texture, activity_class=activity, density=density)
        primary_grammar=grammars[0]
        raw_events=_mark_auto_importance(generate_guitar_pattern(
            intent,chord,plan,realization_attacks,
            melody_hand_center=None, melody_hand_center_confidence=0.0, register_mode="ORIGINAL",
            right_hand_grammar=primary_grammar,
        ))
        original_feas=assess_realization(
            raw_events, hand_center=hand_center, hand_low=hand_low, hand_high=hand_high,
            hand_confidence=hand_confidence,
        )
        base={
            "texture":texture, "events":raw_events, "register_mode":"ORIGINAL",
            "revoiced":0, "pitch_reasons":("V0135111_BASELINE_PRESERVED",),
            "feasibility":original_feas, "improvement":0.0,
            "attacks":realization_attacks, "pressure":realization_pressure, "action":realization_action,
            "right_hand_grammar":primary_grammar,
        }
        originals.append(base)
        signatures.add(tuple((round(e.onset,6),round(e.duration,6),e.pitch,e.role) for e in raw_events))

        # Route-specific right-hand grammar variants. They share harmony/timing
        # intent but expose different chord-function orderings, allowing Joint
        # to realize different strings/frets instead of converging on one safe
        # mechanical pattern.
        for grammar in grammars[1:]:
            grammar_events=_mark_auto_importance(generate_guitar_pattern(
                intent,chord,plan,realization_attacks,
                melody_hand_center=None, melody_hand_center_confidence=0.0, register_mode="ORIGINAL",
                right_hand_grammar=grammar,
            ))
            sig=tuple((round(e.onset,6),round(e.duration,6),e.pitch,e.role) for e in grammar_events)
            if sig in signatures:
                continue
            feas=assess_realization(grammar_events, hand_center=hand_center, hand_low=hand_low, hand_high=hand_high, hand_confidence=hand_confidence)
            alternates.append({
                **base, "events":grammar_events, "right_hand_grammar":grammar,
                "pitch_reasons":("V0135133_RIGHT_HAND_GRAMMAR_VARIANT",),
                "feasibility":feas, "improvement":0.10 if grammar.startswith("T121") else 0.06,
            })
            signatures.add(sig)

        # Upper harmony near; bass remains untouched.
        near_events, near_changed, near_reasons = _conservative_melody_near_revoice(
            raw_events, hand_center=hand_center, hand_confidence=hand_confidence
        )
        if near_changed > 0:
            sig=tuple((round(e.onset,6),round(e.duration,6),e.pitch,e.role) for e in near_events)
            if sig not in signatures:
                feas=assess_realization(near_events, hand_center=hand_center, hand_low=hand_low, hand_high=hand_high, hand_confidence=hand_confidence)
                alternates.append({
                    **base, "events":near_events, "register_mode":"MELODY_NEAR",
                    "revoiced":near_changed, "pitch_reasons":near_reasons,
                    "feasibility":feas, "improvement":round(feas.score-original_feas.score,6),
                })
                signatures.add(sig)

        # HAND_ZONE_SAFE: construct an upper-harmony realization from concrete
        # guitar positions inside the current Melody hand zone instead of
        # generating a chord first and only scoring its distance afterwards.
        zone_events, zone_changed, zone_reasons = realize_upper_harmony_in_hand_zone(
            raw_events, hand_center=hand_center, hand_low=hand_low, hand_high=hand_high,
            hand_confidence=hand_confidence,
        )
        use_hand_zone = coordination is None or getattr(coordination,"register_zone","MID") == "MID"
        if zone_changed > 0 and use_hand_zone:
            sig=tuple((round(e.onset,6),round(e.duration,6),e.pitch,e.role) for e in zone_events)
            if sig not in signatures:
                feas=assess_realization(zone_events, hand_center=hand_center, hand_low=hand_low, hand_high=hand_high, hand_confidence=hand_confidence)
                alternates.append({
                    **base, "events":zone_events, "register_mode":"HAND_ZONE_SAFE",
                    "revoiced":zone_changed, "pitch_reasons":zone_reasons,
                    "feasibility":feas, "improvement":round(feas.score-original_feas.score,6),
                })
                signatures.add(sig)



        # V0.13.5.12 REGISTER_HIERARCHY_SAFE: high melody keeps accompaniment
        # underneath; low melody may use a sparse upper overlay without turning
        # accompaniment into a competing top voice.
        if coordination is not None and getattr(coordination,"register_zone","MID") != "MID":
            hierarchy_events, hierarchy_changed, hierarchy_reasons = realize_register_hierarchy(
                raw_events,
                melody_midi=float(canonical.metadata.get("melody_register",60.0) or 60.0),
                register_zone=getattr(coordination,"register_zone","MID"),
                hand_center=hand_center, hand_confidence=hand_confidence,
            )
            if hierarchy_changed > 0:
                sig=tuple((round(e.onset,6),round(e.duration,6),e.pitch,e.role) for e in hierarchy_events)
                if sig not in signatures:
                    feas=assess_realization(hierarchy_events, hand_center=hand_center, hand_low=hand_low, hand_high=hand_high, hand_confidence=hand_confidence)
                    alternates.append({
                        **base, "events":hierarchy_events, "register_mode":"REGISTER_HIERARCHY_SAFE",
                        "revoiced":hierarchy_changed, "pitch_reasons":hierarchy_reasons,
                        "feasibility":feas, "improvement":round(feas.score-original_feas.score,6),
                    })
                    signatures.add(sig)

        # HYBRID_SAFE remains a MID-register option only.  In LOW/HIGH zones the
        # explicit hierarchy realization owns register separation.
        if hand_center is not None and hand_confidence >= 0.58 and (coordination is None or getattr(coordination,"register_zone","MID") == "MID"):
            hybrid_plan=replace(plan, allow_inversion=False)
            hybrid_events=_mark_auto_importance(generate_guitar_pattern(
                intent,chord,hybrid_plan,realization_attacks,
                melody_hand_center=hand_center, melody_hand_center_confidence=hand_confidence,
                register_mode="HYBRID", right_hand_grammar=primary_grammar,
            ))
            sig=tuple((round(e.onset,6),round(e.duration,6),e.pitch,e.role) for e in hybrid_events)
            if sig not in signatures:
                feas=assess_realization(hybrid_events, hand_center=hand_center, hand_low=hand_low, hand_high=hand_high, hand_confidence=hand_confidence)
                changed=sum(1 for a,b in zip(raw_events,hybrid_events) if a.pitch!=b.pitch)
                alternates.append({
                    **base, "events":hybrid_events, "register_mode":"HYBRID_SAFE",
                    "revoiced":changed, "pitch_reasons":("BOUNDED_HYBRID_BASS_UPPER_INDEPENDENT",),
                    "feasibility":feas, "improvement":round(feas.score-original_feas.score,6),
                })
                signatures.add(sig)

    # Add only clearly useful alternatives.  Primary texture gets a mild bonus,
    # but a high-risk secondary texture may win the remaining budget.  ORIGINAL
    # candidates are never removed by this gate.
    remaining=max(0, MAX_MODERN_CANDIDATES-len(originals))
    useful=[row for row in alternates if row["improvement"] >= 0.08 or row["feasibility"].label == "CLEARLY_GOOD"]
    useful.sort(key=lambda row: (
        -(row["improvement"] + (0.05 if row["texture"] == primary else 0.0)),
        0 if row["register_mode"] == "REGISTER_HIERARCHY_SAFE" else (1 if row["register_mode"] == "HAND_ZONE_SAFE" else (2 if row["register_mode"] == "HYBRID_SAFE" else 3)),
        order.index(row["texture"]),
    ))
    chosen=[*originals, *useful[:remaining]]

    out=[]
    for fallback,row in enumerate(chosen):
        texture=row["texture"]; register_mode=row["register_mode"]; events=row["events"]; feas=row["feasibility"]
        out.append(ArrangementCandidate(
            candidate_id=f"{intent.intent_id}:unified:{texture}:{register_mode}", intent_id=intent.intent_id,
            window_id=intent.window_id, texture=texture.lower(), reduction_level=max(0,5-rank[texture]),
            events=events, fidelity_rank=rank[texture], fallback_rank=fallback,
            reasons=intent.reasons+(f"V0.13.5.12 melody-adaptive coordinated candidate {texture}/{register_mode}.",),
            metadata={"source_mode":intent.source_mode,"source_candidate_type":"AUTO_INTENT_GUITAR",
                      "guitar_texture":texture,"register_policy":register_mode,"canonical_intent":True,
                      "runtime_voicing_selection_owner":"JOINT_ARRANGEMENT_DP","section_role":canonical.metadata.get("section_role"),
                      "prefilter_enabled":bool(prefilter),"prefilter_beam_size":getattr(prefilter,"beam_size",None),
                      "prefilter_survivors":list(getattr(prefilter,"survivors",()) or ()),
                      "prefilter_rejected":list(getattr(prefilter,"rejected",()) or ()),
                      "prefilter_scores":dict(getattr(prefilter,"scores",()) or ()),
                      "prefilter_reasons":list(getattr(prefilter,"reasons",()) or ()),
                      "melody_realization_conditioned":True,
                      "melody_realization_baseline_preserved":register_mode == "ORIGINAL",
                      "melody_hand_center":hand_center,"melody_hand_low_fret":hand_low,
                      "melody_hand_high_fret":hand_high,"melody_hand_center_confidence":hand_confidence,
                      "melody_hand_center_reason":getattr(melody_hand_window,"reason",None),
                      "melody_realization_pressure":row["pressure"],"melody_realization_action":row["action"],
                      "melody_realization_revoiced_upper_notes":row["revoiced"],
                      "melody_realization_omitted_optional_notes":0,
                      "melody_realization_pitch_reasons":list(row["pitch_reasons"]),
                      "melody_realization_attack_count":len(row["attacks"]),
                      "arranger_policy":"UNIFIED",
                      "right_hand_grammar":row.get("right_hand_grammar","AUTO"),
                      "melody_attack_occupancy":attack_occupancy,"melody_max_polyphony":max_polyphony,
                      "melody_pitch_span":pitch_span,"melody_hand_span":round(hand_span,3),
                      "bounded_realization_budget":MAX_MODERN_CANDIDATES,
                      "texture_coordination_version":"V0.13.5.12",
                      "coordinated_primary_texture":getattr(coordination,"primary_texture",None),
                      "coordinated_candidate_textures":list(getattr(coordination,"candidate_textures",()) or ()),
                      "melody_register_zone":getattr(coordination,"register_zone",None),
                      "melody_register_strategy":getattr(coordination,"register_strategy",None),
                      "melody_activity_class":getattr(coordination,"activity_class",None),
                      "melody_rest_ratio":getattr(coordination,"rest_ratio",None),
                      "melody_gap_fill_attacks":list(getattr(coordination,"fill_attacks",()) or ()),
                      "texture_coordination_reasons":list(getattr(coordination,"reasons",()) or ()),
                      "prejoint_feasibility_label":feas.label,"prejoint_feasibility_score":feas.score,
                      "prejoint_average_hand_distance":feas.average_hand_distance,
                      "prejoint_maximum_hand_distance":feas.maximum_hand_distance,
                      "prejoint_projected_span":feas.projected_span,
                      "prejoint_playable_note_ratio":feas.playable_note_ratio,
                      "prejoint_feasibility_reasons":list(feas.reasons),
                      "prejoint_feasibility_improvement_vs_original":row["improvement"]},
        ))

    safe_events=_legacy_safe_events(intent, canonical, chord)
    out.append(ArrangementCandidate(
        candidate_id=f"{intent.intent_id}:legacy-safe", intent_id=intent.intent_id,
        window_id=intent.window_id, texture="legacy_safe", reduction_level=4,
        events=safe_events, fidelity_rank=0, fallback_rank=len(out),
        reasons=intent.reasons+("V0.13.5.12 Guaranteed Safe candidate; Joint evaluates it only if modern candidates have no legal state.",),
        metadata={
            "source_mode":intent.source_mode, "source_candidate_type":"AUTO_LEGACY_SAFE",
            "guitar_texture":"LEGACY_SAFE", "register_policy":"LEGACY_SAFE",
            "canonical_intent":True, "guaranteed_safe_candidate":True,
            "runtime_voicing_selection_owner":"JOINT_ARRANGEMENT_DP",
            "importance_lineage":"ARRANGEMENT_TO_JOINT_TO_FINAL",
            "bounded_realization_budget":MAX_MODERN_CANDIDATES,
        },
    ))
    return tuple(out)

def melody_candidate_groups_to_timed_bundle(plan):
    """Return timed candidate variants for remapping to Joint harmony-window IDs."""
    timed=[]
    for canonical,group in zip(plan.canonical_intents,plan.candidate_groups):
        variants=[]
        for candidate in group:
            variant=f"AUTO_{candidate.metadata.get('guitar_texture',candidate.texture).upper()}_{candidate.metadata.get('register_policy','ORIGINAL')}"
            variants.append((variant,candidate.events))
        timed.append((canonical.harmony.start,canonical.harmony.duration,tuple(variants)))
    return tuple(timed)


def generate_melody_double_stop_candidates(intent, canonical, chord, base_group):
    """Bounded harmonization candidates; physical realization remains in Joint.

    A melody double stop is one chord tone at most an octave below the melody,
    rather than an unrelated low bass attack. Keep the other candidate attacks.
    """
    targets=canonical.metadata.get('editor_double_stops', ())
    if not targets: return tuple(base_group)
    classes={(chord.root_pc+i)%12 for i in chord.required_intervals+chord.optional_intervals+chord.color_intervals}
    choices=[]
    for eid,start,pitch in targets:
        tones=[p for p in range(max(40,pitch-12),pitch) if p%12 in classes and pitch-p in {3,4,5,7,8,9,12}]
        if not tones:return tuple(base_group)
        tones.sort(key=lambda p: ({3:0,4:0,8:1,9:1,5:2,7:3,12:4}[pitch-p],-p))
        choices.append((eid,start,pitch,tones))
    out=[]
    for base in tuple(base_group)[:5]:
        others=tuple(e for e in base.events if not any(abs(e.onset-t)<1e-6 for _,t,_ in targets))
        for variant in range(3):
            additions=[]
            for index,(eid,start,pitch,tones) in enumerate(choices):
                # The existing melody duration is supplied as request metadata.
                duration=canonical.metadata['editor_double_durations'][eid]
                additions.append(AccompanimentEvent(
                    event_id=f'{intent.window_id}:DOUBLE:{eid}:{variant}',window_id=intent.window_id,
                    onset=start,duration=min(duration,intent.start+intent.duration-start),
                    role='guide_tone',pitch=tones[variant%len(tones)],importance=90,optional=False,
                    reduction_level=base.reduction_level,source_chord=chord.chord_symbol))
            out.append(dc_replace(base,candidate_id=f'{base.candidate_id}:DOUBLE:{variant}',
                events=tuple(sorted(others+tuple(additions),key=lambda e:(e.onset,e.pitch))),
                metadata={**base.metadata,'user_double_stop':True},
                reasons=base.reasons+('USER_MELODY_DOUBLE_STOP_CANDIDATE',)))
    return tuple(out)
