from __future__ import annotations

from dataclasses import dataclass

from gste.control import get_section, get_value


@dataclass(frozen=True)
class AccompanimentDensityPolicy:
    """Source-neutral density/role-loss policy for rhythm-constrained music."""

    name: str = 'DENSITY_POLICY_V0135133'

    def texture_for_guitar(self, texture: str, *, melody_budget: str, source_density: int) -> str:
        t = str(texture).upper()
        # Dense source piano textures are deliberately compressed for guitar.
        if t == 'ARPEGGIO':
            if melody_budget == 'LOW' or source_density >= int(get_value("piano.dense_source_threshold", 4)):
                return 'SPARSE_ARPEGGIO'
        if t == 'COMPACT_BLOCK' and source_density >= int(get_value("piano.dense_source_threshold", 4)):
            return 'ROOT_GUIDE'
        return t

    def right_hand_grammars(self, *, texture: str, melody_budget: str, source_density: int) -> tuple[str, ...]:
        if texture not in {'ARPEGGIO', 'SPARSE_ARPEGGIO'}:
            return ('AUTO',)
        # Piano is a compression/re-voicing task. Keep fewer grammar variants
        # than melody-only and reserve 3121 for genuinely sparse windows.
        grammars = list(get_value("piano.normal_grammars", ["T121_A", "T121_B"]))
        if melody_budget == 'HIGH' and source_density <= int(get_value("piano.high_budget_sparse_density_max", 2)):
            grammars.extend(str(x) for x in get_value("piano.sparse_extra_grammars", ["3121_A"]) if str(x) not in grammars)
        return tuple(grammars)

    def thin_rhythm(
        self,
        rhythm: tuple[float, ...],
        *,
        melody_budget: str,
        source_density: int,
    ) -> tuple[float, ...]:
        """Do not mirror a piano attack on every beat under active melody."""
        seq = tuple(rhythm) or (0.0,)
        if len(seq) <= 2:
            return seq
        if melody_budget == 'LOW' or source_density >= int(get_value("piano.dense_source_threshold", 4)):
            limit = int(get_value("piano.compressed_max_attacks", 2))
            return tuple(seq[::2][:limit]) or (seq[0],)
        if melody_budget == 'MEDIUM':
            return tuple(seq[: int(get_value("piano.medium_budget_max_attacks", 2))])
        return seq[: int(get_value("piano.high_budget_max_attacks", 3))]

    @property
    def information_loss_weights(self) -> dict[str, float]:
        # Explicit requested priority:
        # important bass > characteristic tones > texture intention > optional inner voices
        defaults = {
            'source_bass': 10.0, 'root': 5.0, 'third': 6.0, 'seventh': 6.0,
            'guide_tone': 6.0, 'characteristic_tone': 6.5, 'fifth': 2.0,
            'extension': 2.0, 'optional_extension': 1.4,
            'root_doubling': 0.8, 'fill': 0.45,
        }
        defaults.update({k: float(v) for k, v in get_section("piano").get("information_loss", {}).items()})
        # get_section("piano") keeps nested information_loss in the same maintenance region.
        return defaults


DENSITY_POLICY = AccompanimentDensityPolicy()
