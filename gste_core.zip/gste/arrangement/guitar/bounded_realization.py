from __future__ import annotations

from dataclasses import dataclass
from collections import defaultdict

from gste.core.fretboard import midi_to_string_fret
from gste.core.tuning import STANDARD_TUNING


@dataclass(frozen=True)
class RealizationFeasibility:
    label: str
    score: float
    average_hand_distance: float
    maximum_hand_distance: float
    projected_span: float
    playable_note_ratio: float
    reasons: tuple[str, ...]


def _best_fret_for_pitch(pitch: int, hand_center: float, *, bass: bool) -> tuple[float, int | None]:
    allowed = (4, 5, 6) if bass else (1, 2, 3, 4, 5, 6)
    rows = [(abs(fret - hand_center) if fret > 0 else 0.35, fret)
            for string, fret in midi_to_string_fret(pitch, max_fret=18, tuning=STANDARD_TUNING)
            if string in allowed]
    return min(rows, default=(99.0, None), key=lambda row: (row[0], row[1] if row[1] is not None else 99))


def assess_realization(events, *, hand_center: float | None, hand_low: float | None,
                       hand_high: float | None, hand_confidence: float) -> RealizationFeasibility:
    """Cheap, advisory AUTO_MELODY feasibility estimate before Joint.

    This deliberately does not replicate Joint hard rules.  It only estimates
    whether a pitch/register realization is obviously far from the current
    melody hand region.  Joint remains the final playability authority.
    """
    if hand_center is None or hand_confidence < 0.58:
        return RealizationFeasibility(
            label="UNKNOWN", score=0.5, average_hand_distance=0.0,
            maximum_hand_distance=0.0, projected_span=0.0,
            playable_note_ratio=1.0, reasons=("LOW_HAND_CENTER_CONFIDENCE",),
        )
    distances: list[float] = []
    frets: list[int] = []
    playable = 0
    by_onset: dict[float, list[int]] = defaultdict(list)
    for event in events:
        dist, fret = _best_fret_for_pitch(event.pitch, float(hand_center), bass=(event.role == "bass"))
        if fret is None:
            continue
        playable += 1
        distances.append(float(dist))
        frets.append(int(fret))
        by_onset[round(float(event.onset), 6)].append(int(fret))
    total = max(1, len(events))
    playable_ratio = playable / total
    avg = sum(distances) / len(distances) if distances else 99.0
    max_dist = max(distances, default=99.0)
    low = float(hand_low if hand_low is not None else hand_center)
    high = float(hand_high if hand_high is not None else hand_center)
    projected_span = 0.0
    for onset_frets in by_onset.values():
        occupied = [f for f in onset_frets if f > 0]
        if low > 0:
            occupied.append(int(round(low)))
        if high > 0:
            occupied.append(int(round(high)))
        if occupied:
            projected_span = max(projected_span, float(max(occupied) - min(occupied)))
    # Score stays advisory and intentionally smooth.  A low score may suppress
    # an *alternate* realization, but ORIGINAL is always preserved for diversity.
    score = 1.0
    score -= min(0.45, avg * 0.055)
    score -= min(0.30, max(0.0, max_dist - 4.0) * 0.045)
    score -= min(0.20, max(0.0, projected_span - 5.0) * 0.04)
    score *= playable_ratio
    score = max(0.0, min(1.0, score))
    reasons = []
    if playable_ratio < 1.0:
        reasons.append("UNPLAYABLE_PITCH_PRESENT")
    if max_dist > 6.0:
        reasons.append("HIGH_MELODY_HAND_DISTANCE")
    if projected_span > 6.0:
        reasons.append("HIGH_PROJECTED_SPAN")
    if not reasons:
        reasons.append("NO_CLEAR_PREJOINT_REGISTER_RISK")
    label = "CLEARLY_GOOD" if score >= 0.72 else ("BORDERLINE" if score >= 0.43 else "CLEARLY_BAD")
    return RealizationFeasibility(
        label=label, score=round(score, 6), average_hand_distance=round(avg, 3),
        maximum_hand_distance=round(max_dist, 3), projected_span=round(projected_span, 3),
        playable_note_ratio=round(playable_ratio, 3), reasons=tuple(reasons),
    )



def realize_upper_harmony_in_hand_zone(events, *, hand_center: float | None, hand_low: float | None,
                                        hand_high: float | None, hand_confidence: float):
    """Build one bounded AUTO_MELODY realization *inside* the melody hand zone.

    Bass is deliberately preserved.  Upper harmony may move only by octaves and
    only when the alternative has a concrete guitar position closer to the
    current melody hand region.  This is a candidate proposal, not a hard rule;
    Joint still owns final fingering/playability.
    """
    from dataclasses import replace
    if hand_center is None or hand_confidence < 0.58:
        return tuple(events), 0, ("HAND_ZONE_LOW_CONFIDENCE",)
    low=float(hand_low if hand_low is not None else hand_center-2.0)
    high=float(hand_high if hand_high is not None else hand_center+2.0)
    zone_low=max(0.0, low-1.0); zone_high=min(18.0, high+1.0)
    out=[]; changed=0; reasons=[]
    for event in events:
        if event.role == "bass":
            out.append(event); reasons.append("STRUCTURAL_BASS_PRESERVED")
            continue
        candidates=[]
        for shift in (-24,-12,0,12,24):
            pitch=event.pitch+shift
            if not 40 <= pitch <= 88:
                continue
            for string,fret in midi_to_string_fret(pitch,max_fret=18,tuning=STANDARD_TUNING):
                if not 1 <= string <= 6:
                    continue
                in_zone = fret == 0 or zone_low <= fret <= zone_high
                zone_distance = 0.25 if fret == 0 else abs(float(fret)-float(hand_center))
                # Prefer a real position inside the current hand zone; then
                # minimize octave displacement and hand distance.
                candidates.append((0 if in_zone else 1, zone_distance, abs(shift), fret, pitch))
        if not candidates:
            out.append(event); reasons.append("NO_PLAYABLE_HAND_ZONE_EQUIVALENT")
            continue
        best=min(candidates)
        best_pitch=best[-1]
        # Never move an upper tone unless the proposed position is actually in
        # the zone and differs from the original pitch.
        if best[0] == 0 and best_pitch != event.pitch:
            out.append(replace(event,pitch=best_pitch)); changed+=1
            reasons.append("UPPER_HARMONY_OCTAVE_EQUIVALENT_IN_HAND_ZONE")
        else:
            out.append(event); reasons.append("ORIGINAL_ALREADY_HAND_ZONE_COMPATIBLE")
    return tuple(out), changed, tuple(sorted(set(reasons)))

def realize_register_hierarchy(events, *, melody_midi: float, register_zone: str,
                               hand_center: float | None, hand_confidence: float):
    """Create one melody-prominence-aware octave-equivalent realization.

    HIGH melody: keep upper accompaniment below the melody where practical.
    LOW/VERY_LOW melody: allow sparse upper harmony above melody, but choose the
    nearest octave-equivalent guitar pitch and leave structural bass untouched.
    MID melody: no extra realization; existing hand-zone logic is sufficient.
    """
    from dataclasses import replace
    if hand_center is None or hand_confidence < 0.58 or register_zone == "MID":
        return tuple(events), 0, ("REGISTER_HIERARCHY_NOT_REQUIRED",)
    out=[]; changed=0; reasons=[]
    for event in events:
        if event.role == "bass":
            out.append(event); reasons.append("STRUCTURAL_BASS_PRESERVED")
            continue
        candidates=[]
        for shift in (-24,-12,0,12,24):
            pitch=event.pitch+shift
            if not 40 <= pitch <= 88:
                continue
            positions=midi_to_string_fret(pitch,max_fret=18,tuning=STANDARD_TUNING)
            if not positions:
                continue
            best_fret=min((abs(f-hand_center) if f>0 else 0.35 for _,f in positions), default=99.0)
            if register_zone == "HIGH":
                hierarchy_penalty = 0.0 if pitch <= melody_midi-2.0 else 8.0 + (pitch-(melody_midi-2.0))*0.6
            else:
                # In low melody, one upper harmonic voice may sit above the
                # melody, but avoid pushing it more than ~one octave away.
                target = melody_midi + 5.0
                hierarchy_penalty = abs(pitch-target)*0.16
                if pitch < melody_midi-5.0:
                    hierarchy_penalty += 3.0
            candidates.append((hierarchy_penalty+best_fret*0.20, abs(shift), pitch))
        if not candidates:
            out.append(event); reasons.append("NO_REGISTER_HIERARCHY_EQUIVALENT")
            continue
        best_pitch=min(candidates)[-1]
        if best_pitch != event.pitch:
            out.append(replace(event,pitch=best_pitch)); changed+=1
            reasons.append("REGISTER_HIERARCHY_OCTAVE_EQUIVALENT")
        else:
            out.append(event); reasons.append("ORIGINAL_REGISTER_HIERARCHY_OK")
    return tuple(out), changed, tuple(sorted(set(reasons)))

