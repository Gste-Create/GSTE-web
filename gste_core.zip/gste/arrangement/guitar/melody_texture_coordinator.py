from __future__ import annotations

from dataclasses import dataclass

_TEXTURE_LEVEL = {"ROOT": 0, "ROOT_GUIDE": 1, "SPARSE_ARPEGGIO": 2, "ARPEGGIO": 3}
_LEVEL_TEXTURE = {v: k for k, v in _TEXTURE_LEVEL.items()}


@dataclass(frozen=True)
class MelodyTextureCoordination:
    """AUTO_MELODY texture budget shared by the modern and legacy-ladder paths.

    V0.13.5.12 deliberately separates two questions:
      1. musical understanding decides how much accompaniment is desirable;
      2. the legacy-compatible texture ladder supplies bounded richer/fallback
         alternatives, while Joint remains the final selector.
    """
    primary_texture: str
    candidate_textures: tuple[str, ...]
    register_zone: str
    register_strategy: str
    activity_class: str
    rest_ratio: float
    fill_attacks: tuple[float, ...]
    max_motion_attacks: int
    allow_upper_above_melody: bool
    reasons: tuple[str, ...]


def _zone(midi: float) -> str:
    if midi < 55.0:
        return "VERY_LOW"
    if midi < 60.0:
        return "LOW"
    if midi <= 69.0:
        return "MID"
    return "HIGH"


def _activity(density: str, occupancy: float, rest_ratio: float) -> str:
    if density in {"MD4"} or occupancy >= 0.90:
        return "VERY_BUSY"
    if density in {"MD3"} or occupancy >= 0.72:
        return "BUSY"
    if rest_ratio >= 0.34 or density in {"MD0", "MD1"}:
        return "OPEN"
    return "NORMAL"


def coordinate_melody_texture(canonical, proposed_texture: str) -> MelodyTextureCoordination:
    md = getattr(canonical, "metadata", {}) or {}
    melody_midi = float(md.get("melody_register", 60.0) or 60.0)
    density = str(md.get("melody_density", "MD2"))
    occupancy = float(md.get("melody_attack_occupancy", 0.0) or 0.0)
    rest_ratio = max(0.0, min(1.0, float(md.get("melody_rest_ratio", 0.0) or 0.0)))
    fill_attacks = tuple(float(x) for x in (md.get("melody_gap_fill_attacks", ()) or ()))
    zone = _zone(melody_midi)
    activity = _activity(density, occupancy, rest_ratio)
    reasons = [f"REGISTER_{zone}", f"ACTIVITY_{activity}", f"REST_RATIO_{rest_ratio:.2f}"]

    level = _TEXTURE_LEVEL.get(str(proposed_texture), 1)

    # Busy melody should leave harmonic anchors rather than behave like a piano.
    if activity == "VERY_BUSY":
        level = min(level, 1)
        reasons.append("BUSY_MELODY_CAP_ROOT_GUIDE")
    elif activity == "BUSY":
        level = min(level, 2)
        reasons.append("BUSY_MELODY_CAP_SPARSE")

    # Low melody is the narrowest guitar-register case.  Allow upper harmony
    # above it only as a sparse subordinate layer; never reward a full wall of
    # accompaniment merely to improve numerical retention.
    if zone == "VERY_LOW":
        level = min(level, 1 if rest_ratio < 0.34 else 2)
        register_strategy = "LOW_MELODY_SPARSE_OVERLAY"
        allow_upper_above = True
        reasons.append("VERY_LOW_MELODY_REDUCE_TEXTURE")
    elif zone == "LOW":
        level = min(level, 2)
        register_strategy = "LOW_MELODY_SPARSE_OVERLAY"
        allow_upper_above = True
        reasons.append("LOW_MELODY_LIMIT_DENSITY")
    elif zone == "HIGH":
        register_strategy = "HIGH_MELODY_ACCOMP_BELOW"
        allow_upper_above = False
        reasons.append("HIGH_MELODY_KEEP_ACCOMPANIMENT_BELOW")
    else:
        register_strategy = "MID_MELODY_BALANCED"
        allow_upper_above = False

    # Long notes / rests are the one place where richer motion is intentionally
    # encouraged.  This is a texture response, not a general density increase.
    gap_motion = bool(fill_attacks) and rest_ratio >= 0.18 and activity != "VERY_BUSY"
    if gap_motion:
        level = max(level, 2)
        reasons.append("MELODY_GAP_ENABLE_ARPEGGIO_RESPONSE")

    level = max(0, min(3, level))
    primary = _LEVEL_TEXTURE[level]

    # Coordinate the modern path with the old v0.13.5.2 ladder:
    # primary + one explicit lower fallback + at most one richer response.
    textures = [primary]
    if level > 0:
        textures.append(_LEVEL_TEXTURE[level - 1])
        reasons.append("LEGACY_LADDER_ONE_STEP_FALLBACK")
    if gap_motion and level < 3:
        textures.append(_LEVEL_TEXTURE[level + 1])
        reasons.append("GAP_RESPONSE_ONE_STEP_RICHER")
    elif activity == "OPEN" and zone in {"MID", "HIGH"} and level < 3:
        textures.append(_LEVEL_TEXTURE[level + 1])
        reasons.append("OPEN_MELODY_ONE_STEP_RICHER")

    # Preserve structural/motion diversity without reopening a large family beam.
    if all(t not in {"ROOT", "ROOT_GUIDE"} for t in textures):
        textures.append("ROOT_GUIDE")
        reasons.append("STRUCTURAL_FALLBACK_GUARD")
    if all(t not in {"SPARSE_ARPEGGIO", "ARPEGGIO"} for t in textures):
        # Keep one sparse-motion family as the modern equivalent of the old
        # ladder's richer candidate.  Busy/low melody still caps its attacks, so
        # this preserves choice without recreating piano-like density.
        textures.append("SPARSE_ARPEGGIO")
        reasons.append("LEGACY_LADDER_MOTION_DIVERSITY_GUARD")

    deduped = []
    for t in textures:
        if t not in deduped:
            deduped.append(t)
    # Hard bound: musical coordination supplies at most three modern texture
    # families; realization variants remain separately bounded downstream.
    deduped = deduped[:3]

    max_motion_attacks = 2 if activity in {"BUSY", "VERY_BUSY"} else (4 if gap_motion else 3)
    return MelodyTextureCoordination(
        primary_texture=primary,
        candidate_textures=tuple(deduped),
        register_zone=zone,
        register_strategy=register_strategy,
        activity_class=activity,
        rest_ratio=round(rest_ratio, 4),
        fill_attacks=fill_attacks,
        max_motion_attacks=max_motion_attacks,
        allow_upper_above_melody=allow_upper_above,
        reasons=tuple(reasons),
    )
