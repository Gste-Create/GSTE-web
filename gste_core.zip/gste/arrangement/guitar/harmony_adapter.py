from __future__ import annotations

from gste.harmony.library import QUALITY_INTERVALS
from .model import ChordIntent

# Intervals that define chord colour and should survive guitar reduction when possible.
_COLOR_INTERVALS = {
    "dominant7": (10,),
    "maj7": (11,),
    "minor7": (10,),
    "half_diminished7": (10,),
    "diminished7": (9,),
    "sus2": (2,),
    "sus4": (5,),
    "add9": (2,),
}


def _bass_policy(*, bass_motion: str, source_bass_pc: int | None, root_pc: int) -> str:
    # A moving/stepwise source bass is musical information, not merely a voicing.
    if bass_motion in {"STEPWISE_BASS", "DIRECTIONAL_BASS", "MOVING_BASS"}:
        return "LOCK_ROOT_BASS" if source_bass_pc == root_pc else "PREFER_ROOT_BASS"
    return "PREFER_ROOT_BASS"


def build_chord_intent(*, chord_symbol: str, root_pc: int, quality: str,
                       bass_motion: str, source_bass_pc: int | None = None,
                       bass_policy_override: str | None = None) -> ChordIntent:
    required, optional = QUALITY_INTERVALS.get(
        quality, (frozenset({0}), frozenset({7}))
    )
    # Root is always structurally available even when an older family omitted it
    # from its explicit required set.
    required_i = tuple(sorted(set(required) | {0}))
    color = tuple(sorted(i for i in _COLOR_INTERVALS.get(quality, ()) if i in set(required) | set(optional) | set(_COLOR_INTERVALS.get(quality, ()))))
    # A fifth is the first tone to omit for compact guitar voicings unless it is
    # structurally required by the quality.
    optional_i = tuple(sorted(set(optional) - set(color)))
    return ChordIntent(
        root_pc=root_pc,
        quality=quality,
        chord_symbol=chord_symbol,
        required_intervals=required_i,
        optional_intervals=optional_i,
        color_intervals=color,
        bass_policy=bass_policy_override or _bass_policy(bass_motion=bass_motion, source_bass_pc=source_bass_pc, root_pc=root_pc),
        source_bass_pc=source_bass_pc,
        bass_motion=bass_motion,
    )
