"""Guitar-native arrangement decision layer introduced in v0.13.5.1."""

from .model import BassPolicy, ChordIntent, GuitarTexturePlan
from .harmony_adapter import build_chord_intent
from .texture_policy import choose_texture_plan

__all__ = [
    "BassPolicy", "ChordIntent", "GuitarTexturePlan",
    "build_chord_intent", "choose_texture_plan",
    "MelodyHandWindow", "estimate_melody_hand_windows", "estimate_melody_hand_windows_from_progression",
]

from .service import GuitarArrangementDecisionEngine, DEFAULT_GUITAR_ARRANGEMENT_ENGINE

from .melody_position import MelodyHandWindow, estimate_melody_hand_windows, estimate_melody_hand_windows_from_progression

from .guitar_state import EarlyShapeCandidate, GuitarStateProfile, estimate_guitar_state, constrain_texture_to_guitar_state
