from __future__ import annotations

import re

_AUTO_IMP_RE = re.compile(r":AUTOIMP(?P<importance>\d{1,3}):AROLE(?P<role>[A-Z0-9_]+)")

ROLE_IMPORTANCE_DEFAULTS = {
    "bass": 96,
    "source_bass": 96,
    "root": 96,
    "root_doubling": 68,
    "guide": 88,
    "guide_tone": 88,
    "third": 86,
    "seventh": 88,
    "characteristic_tone": 88,
    "chord_tone": 68,
    "fifth": 58,
    "extension": 52,
    "fill": 40,
}


def normalize_role(role: str | None) -> str:
    text = (role or "fill").strip().lower()
    aliases = {
        "guide": "guide_tone",
        "third": "third",
        "bass": "bass",
        "chord": "chord_tone",
    }
    return aliases.get(text, text or "fill")


def encode_auto_importance(event_id: str, importance: int, role: str) -> str:
    """Persist AUTO_MELODY importance through MusicXML using source_event_id.

    NoteEvent has no metadata field. The event id is already preserved end to end,
    so a compact marker is the least invasive lineage carrier and does not alter
    Piano/source routes.
    """
    if ":AUTOIMP" in event_id:
        return event_id
    value = max(0, min(100, int(round(importance))))
    role_marker = re.sub(r"[^A-Z0-9_]+", "_", normalize_role(role).upper())
    return f"{event_id}:AUTOIMP{value:03d}:AROLE{role_marker}"


def parse_auto_importance(source_event_id: str | None) -> int | None:
    if not source_event_id:
        return None
    match = _AUTO_IMP_RE.search(str(source_event_id))
    return int(match.group("importance")) if match else None


def parse_auto_role(source_event_id: str | None) -> str | None:
    if not source_event_id:
        return None
    match = _AUTO_IMP_RE.search(str(source_event_id))
    return match.group("role").lower() if match else None


def effective_importance(source_event_id: str | None = None, role: str | None = None, *, importance: int | None = None) -> int:
    """Return musical importance without requiring semantics in Event ID.

    ``source_event_id`` is accepted only as a migration fallback for old files;
    runtime v0.13.5.15.5 callers should pass ``importance`` / ``role`` fields.
    """
    if importance is not None:
        return max(0, min(100, int(importance)))
    encoded = parse_auto_importance(source_event_id)
    if encoded is not None:
        return encoded
    return ROLE_IMPORTANCE_DEFAULTS.get(normalize_role(role), 50)


def note_importance(note) -> int | None:
    return getattr(note, "importance", None)


def note_role(note) -> str | None:
    return getattr(note, "arrangement_role", None)


def importance_loss_cost(importance: int) -> float:
    """Cost of discarding one AUTO_MELODY accompaniment event.

    The scale is deliberately modest: importance breaks ties among legal guitar
    reductions, but it never overrides physical hard rules.
    """
    value = max(0, min(100, int(importance)))
    if value >= 92:
        return 10.0
    if value >= 84:
        return 7.0
    if value >= 70:
        return 4.0
    if value >= 55:
        return 2.0
    return 0.8
