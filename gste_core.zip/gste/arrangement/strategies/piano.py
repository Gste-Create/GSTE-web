"""Historical import facade; policy has one common implementation."""
from gste.arrangement.guitar.density_policy import AccompanimentDensityPolicy as PianoArrangerPolicy, DENSITY_POLICY as PIANO_ARRANGER
