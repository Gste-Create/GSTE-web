"""Historical import facade; policy has one common implementation."""
from gste.arrangement.guitar.adaptive_policy import AdaptiveMotionPolicy as MelodyOnlyArrangerPolicy, ADAPTIVE_MOTION_POLICY as MELODY_ONLY_ARRANGER
