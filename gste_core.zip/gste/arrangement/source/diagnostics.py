from __future__ import annotations
from gste.version import VERSION

from collections import Counter
import json
from pathlib import Path

from gste.arrangement.models import SourceArrangementPlan, serializable
from gste.arrangement.routing import ArrangementRouteDecision
from gste.arrangement.diagnostics import write_harmony_bass_sanity_report


def write_route_diagnostics(decision: ArrangementRouteDecision, path: str | Path) -> Path:
    output = Path(path); output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps({
        "version": VERSION,
        "route": decision.route,
        "source_mode": decision.source_mode,
        "reason": decision.reason,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    return output


def _pattern_paths(output: Path) -> tuple[Path, Path]:
    name = output.name
    if "SOURCE_ARRANGEMENT_INTENTS" in name:
        json_name = name.replace("SOURCE_ARRANGEMENT_INTENTS", "SOURCE_PATTERN_ANALYSIS")
    elif "source_arrangement_intents" in name:
        json_name = name.replace("source_arrangement_intents", "source_pattern_analysis")
    else:
        json_name = output.stem + "_source_pattern_analysis.json"
    pattern_json = output.with_name(json_name)
    return pattern_json, pattern_json.with_suffix(".md")


def _write_pattern_review(plan: SourceArrangementPlan, output: Path) -> tuple[Path, Path] | None:
    if not plan.analyses:
        return None
    pattern_json, pattern_md = _pattern_paths(output)
    pattern_counts = Counter(item.pattern_type for item in plan.analyses)
    low_pattern = [item.window_id for item in plan.analyses if item.pattern_confidence < 0.65]
    low_harmony = [item.window_id for item in plan.analyses if item.harmony_confidence < 0.60]
    source_note_count = sum(len(item.notes) for item in plan.analyses)
    payload = {
        "version": VERSION,
        "purpose": "SOURCE_ANALYSIS_WITH_CANONICAL_GUITAR_DECISION_AND_LEGACY_MAPPING_AUDIT",
        "mapping_enabled": bool(plan.mappings),
        "window_count": len(plan.analyses),
        "source_note_count": source_note_count,
        "pattern_counts": dict(sorted(pattern_counts.items())),
        "low_pattern_confidence_windows": low_pattern,
        "low_harmony_confidence_windows": low_harmony,
        "review_targets": {
            "harmony_root_reasonable_target": ">=90% manually reviewed windows",
            "primary_texture_reasonable_target": ">=85% manually reviewed windows",
            "source_onset_duration_capture_target": "100%",
            "source_bass_sequence_capture_target": "100%",
        },
        "windows": [serializable(item) for item in plan.analyses],
    }
    pattern_json.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    lines = [
        f"# GSTE {VERSION} Source Harmony & Pattern Analysis", "",
        "**Purpose:** analyze source accompaniment and audit the v0.13.5.13.3 canonical / phrase / melody-centred guitar decision path.", "",
        f"- Windows: {len(plan.analyses)}",
        f"- Source notes recorded: {source_note_count}",
        f"- Low pattern-confidence windows (<0.65): {len(low_pattern)}",
        f"- Low harmony-confidence windows (<0.60): {len(low_harmony)}", "",
        "## Pattern distribution", "",
    ]
    for name, count in sorted(pattern_counts.items()):
        lines.append(f"- {name}: {count}")
    lines += ["", "## Window review", "",
              "| Window | Chord | Harmony conf. | Pattern | Pattern conf. | Roles | Rhythm | Bass | Attacks | Max voices |",
              "|---|---|---:|---|---:|---|---|---|---|---:|"]
    for item in plan.analyses:
        roles = "-".join(item.functional_role_sequence) if item.functional_role_sequence else "REST"
        rhythm = ", ".join(f"{x:g}" for x in item.rhythm_pattern) or "REST"
        bass = "-".join(str(x) for x in item.bass_sequence) if item.bass_sequence else "REST"
        attacks = ", ".join(str(x) for x in item.attack_sizes) or "0"
        lines.append(
            f"| {item.window_id} | {item.chord_symbol} | {item.harmony_confidence:.2f} | "
            f"{item.pattern_type} | {item.pattern_confidence:.2f} | {roles} | {rhythm} | {bass} | {attacks} | {item.voice_count} |"
        )
    lines += ["", "## Manual acceptance checklist", "",
              "- Confirm detected chord/root is musically reasonable for each sampled window.",
              "- Confirm BLOCK_CHORD / ARPEGGIO / BASS_LINE / BASS_CHORD_PULSE / ROOT_PULSE classification.",
              "- Confirm rhythm onsets/durations and bass sequence match the source score.",
              "- Low-confidence or MIXED windows should be reviewed before v0.13.4 mapping rules are enabled.", ""]
    pattern_md.write_text("\n".join(lines), encoding="utf-8")
    return pattern_json, pattern_md



def _selection_musicality(plan: SourceArrangementPlan) -> dict:
    selected = [candidate.metadata.get("source_candidate_type", "UNKNOWN") for candidate in plan.selected_candidates]
    counts = Counter(selected)
    total = max(1, len(selected))
    max_same = 0
    current = 0
    previous = None
    transitions = 0
    for item in selected:
        if item == previous:
            current += 1
        else:
            if previous is not None:
                transitions += 1
            previous = item
            current = 1
        max_same = max(max_same, current)
    return {
        "high_fidelity_ratio": round(counts.get("SOURCE_HIGH_FIDELITY_MAPPED", 0) / total, 4),
        "pattern_reduced_ratio": round(counts.get("SOURCE_PATTERN_REDUCED", 0) / total, 4),
        "source_exact_runtime_ratio": round(counts.get("SOURCE_EXACT", 0) / total, 4),
        "selection_transition_count": transitions,
        "max_consecutive_same_realization": max_same,
        "variety_warning": max_same >= 12,
    }

def _write_mapping_audit(plan: SourceArrangementPlan, output: Path) -> tuple[Path, Path] | None:
    if not plan.mappings:
        return None
    if "SOURCE_ARRANGEMENT_INTENTS" in output.name:
        mapping_name = output.name.replace("SOURCE_ARRANGEMENT_INTENTS", "SOURCE_ARRANGEMENT_MAPPING")
    elif "source_arrangement_intents" in output.name:
        mapping_name = output.name.replace("source_arrangement_intents", "source_arrangement_mapping")
    else:
        mapping_name = output.stem + "_source_arrangement_mapping.json"
    json_path = output.with_name(mapping_name)
    md_path = json_path.with_suffix(".md")
    payload = {
        "version": VERSION,
        "purpose": "SOURCE_TO_GUITAR_MAPPING_AUDIT",
        "mapping_enabled": bool(plan.mappings),
        "mapping_selection_enabled": False,
        "selected_policy": "CANONICAL_INTENT_PRIMARY__LEGACY_MAPPING_DIAGNOSTIC_ONLY",
        "high_register_revoicing_policy": "MAPPED_SOURCE_OCTAVE_OR_INVERSION_NEAR_MELODY_HAND_CENTER",
        "window_count": len(plan.mappings),
        "selection_counts": dict(Counter(candidate.metadata.get("source_candidate_type", "UNKNOWN") for candidate in plan.selected_candidates)),
        "musicality_diagnostics": _selection_musicality(plan),
        "mappings": [serializable(item) for item in plan.mappings],
    }
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = [
        f"# GSTE {VERSION} Source Arrangement Mapping Confidence Audit", "",
        "Legacy mapping is retained only for A/B diagnostics. These mappings cannot replace the canonical Guitar Decision in normal v0.13.5.13.3 execution.", "",
        "| Window | Source Pattern | Guitar Target | Chord | Pattern C. | Harmony C. | Role C. | Gate | Eligibility | Degradation Ladder |",
        "|---|---|---|---|---:|---:|---:|---|---|---|",
    ]
    for item in plan.mappings:
        ladder = " -> ".join(item.degradation_ladder)
        lines.append(f"| {item.window_id} | {item.source_pattern} | {item.target_pattern} | {item.chord_symbol} | {item.pattern_confidence:.2f} | {item.harmony_confidence:.2f} | {item.role_confidence:.2f} | {item.confidence_gate} | {item.mapping_eligibility} | {ladder} |")
    lines += ["", "## v0.13.5.13.3 Mapping Confidence Gate", "",
              "- Source Pattern must map to the intended Guitar Pattern family.",
              "- Rhythm and harmonic-role intent must remain preserved.",
              "- Exact piano register is intentionally not preserved as a mapping invariant.",
              "- No mapped candidate may bypass Joint Fingering hard constraints.",
              "- HIGH/MEDIUM/LOW are retained only as historical A/B diagnostics; they do not select the primary candidate in v0.13.5.13.3.",
              "- The active primary path is Canonical Intent + Phrase Understanding + Guitar Decision.",
              "- Raw SOURCE_EXACT is diagnostic-only and cannot enter the runtime Joint path.",
              "- Confidence does not directly set density. Low-confidence windows still rebuild Guitar candidates from abstract intent; Joint Fingering remains the physical authority.", ""]
    md_path.write_text("\n".join(lines), encoding="utf-8")
    return json_path, md_path


def write_source_arrangement_diagnostics(plan: SourceArrangementPlan, path: str | Path) -> tuple[Path, Path]:
    output = Path(path); output.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    analysis_by_window = {item.window_id: item for item in plan.analyses}
    mapping_by_window = {item.window_id: item for item in plan.mappings}
    for intent, group, selected in zip(plan.intents, plan.candidate_groups, plan.selected_candidates):
        row = {
            "intent": serializable(intent),
            "candidate_ladder": [serializable(candidate) for candidate in group],
            "selected_candidate_id": selected.candidate_id,
            "selected_fallback_rank": selected.fallback_rank,
            "selected_metadata": serializable(selected.metadata),
        }
        if intent.window_id in analysis_by_window:
            row["source_pattern_analysis"] = serializable(analysis_by_window[intent.window_id])
        if intent.window_id in mapping_by_window:
            row["source_mapping_decision"] = serializable(mapping_by_window[intent.window_id])
        rows.append(row)
    payload = {
        "version": VERSION,
        "source_mode": "SOURCE_ANALYZED",
        "intent_count": len(plan.intents),
        "selected_policy": "CANONICAL_INTENT_PRIMARY__LEGACY_MAPPING_DIAGNOSTIC_ONLY",
        "mapping_enabled": bool(plan.mappings),
        "mapping_selection_enabled": False,
        "windows": rows,
    }
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    md = output.with_suffix(".md")
    lines = [
        f"# GSTE {VERSION} Source Arrangement Diagnostics", "",
        "v0.13.5.13.3 uses Canonical Intent + Phrase Understanding as the Piano primary path; Legacy Piano Mapping is diagnostic-only.",
        "All runtime SOURCE_ANALYZED candidates are rebuilt from canonical harmony/bass/texture/rhythm intent. Raw SOURCE_EXACT is diagnostic-only and cannot enter Joint.", "",
        "| Window | Legacy Texture | Source Pattern | Density | Bass Motion | Source Attacks | Candidates | Selected | Confidence |",
        "|---|---|---|---|---|---:|---:|---|---:|",
    ]
    for intent, group, selected in zip(plan.intents, plan.candidate_groups, plan.selected_candidates):
        lines.append(
            f"| {intent.window_id} | {intent.texture} | {intent.pattern_type} | {intent.density} | {intent.bass_motion} | "
            f"{intent.metadata.get('source_note_attacks', 0)} | {len(group)} | {selected.metadata.get('source_candidate_type')} | {intent.source_confidence:.2f} |"
        )
    md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    _write_pattern_review(plan, output)
    _write_mapping_audit(plan, output)
    _write_v0136_layered_intents(plan, output)
    write_harmony_bass_sanity_report(
        plan, output.parent / "04_HARMONY_BASS_SANITY.json", output.parent / "04_HARMONY_BASS_SANITY.md"
    )
    return output, md


def _write_v0136_layered_intents(plan: SourceArrangementPlan, output: Path) -> tuple[Path, ...]:
    bundle=getattr(plan,"analysis_bundle",None)
    phrase=getattr(plan,"phrase_plan",None)
    if bundle is None:
        return ()
    base=output.parent
    files=[]
    if bundle.tonality_analysis is not None:
        from gste.tonality import write_tonality_analysis
        files.append(write_tonality_analysis(bundle.tonality_analysis,base/"02_PIANO_TONALITY_ANALYSIS.json"))
    datasets=[
        ("02_PIANO_BASS_INTENT.json", bundle.bass),
        ("02_PIANO_HARMONY_INTENT.json", bundle.harmony),
        ("02_PIANO_RHYTHM_INTENT.json", bundle.rhythm),
        ("02_PIANO_TEXTURE_INTENT.json", bundle.texture),
        ("03_CANONICAL_ARRANGEMENT_INTENT.json", bundle.canonical),
    ]
    for name,data in datasets:
        path=base/name
        path.write_text(json.dumps({"version":VERSION,"layer":"ANALYSIS" if name.startswith("02_") else "CANONICAL_INTENT","items":[serializable(x) for x in data]},ensure_ascii=False,indent=2),encoding="utf-8")
        files.append(path)
    if phrase is not None:
        path=base/"03_PHRASE_UNDERSTANDING.json"
        path.write_text(json.dumps({
            "version":VERSION,"layer":"PHRASE_UNDERSTANDING","minimum_context_measures":2,
            "contexts":[serializable(x) for x in phrase.contexts],
            "phrases":[serializable(x) for x in phrase.phrases],
            "expression_transitions":[serializable(x) for x in phrase.transitions],
            "resolved_harmonic_roots":list(phrase.harmonic_roots),
            "resolved_harmonic_qualities":list(getattr(phrase,"harmonic_qualities",())),
            "resolved_harmonic_symbols":list(getattr(phrase,"harmonic_symbols",())),
            "harmony_resolution_reasons":list(getattr(phrase,"harmony_resolution_reasons",())),
            "structural_bass_flags":list(phrase.structural_bass_flags)
        },ensure_ascii=False,indent=2),encoding="utf-8")
        files.append(path)
    return tuple(files)
