from __future__ import annotations

from collections import defaultdict

from gste.arrangement.models import ArrangementIntent, SourceNoteObservation, SourcePatternAnalysis
from gste.harmony.library import chord_family_name
from gste.harmony.piano_analysis import analyze_harmony_windows
from gste.harmony.windows import build_fixed_harmony_windows
from gste.input.project_models import PianoSplitProject


_REDUCTION = {
    "arpeggio": 0,
    "reduced_arpeggio": 1,
    "bass_chord": 1,
    "bass_inner": 2,
    "root_guide": 3,
    "root": 4,
}


def _attacks(notes, start: float, end: float):
    return [note for note in notes if start - 1e-9 <= note.start < end - 1e-9]


def _groups(notes):
    grouped: dict[float, list] = defaultdict(list)
    for note in notes:
        grouped[round(note.start, 6)].append(note)
    return {key: sorted(value, key=lambda note: note.pitch.midi) for key, value in grouped.items()}


def _source_texture(notes) -> str:
    """Legacy v0.13.4 texture retained so v0.13.4 does not change output."""
    if not notes:
        return "root"
    groups = _groups(notes)
    attacks = len(groups)
    max_simultaneous = max((len(group) for group in groups.values()), default=0)
    if max_simultaneous >= 3:
        return "bass_chord"
    if max_simultaneous == 2:
        return "bass_inner"
    if attacks >= 4:
        return "arpeggio"
    if attacks >= 3:
        return "reduced_arpeggio"
    if attacks >= 2:
        return "root_guide"
    return "root"


def _density(notes, duration: float) -> str:
    attacks = len({round(note.start, 6) for note in notes})
    rate = attacks / max(duration, 0.25)
    if attacks == 0:
        return "SD0"
    if rate <= 0.75:
        return "SD1"
    if rate <= 1.5:
        return "SD2"
    if rate <= 2.5:
        return "SD3"
    return "SD4"


def _bass_sequence(notes) -> tuple[int, ...]:
    groups = _groups(notes)
    return tuple(min(groups[key], key=lambda note: note.pitch.midi).pitch.midi for key in sorted(groups))


def _bass_motion_from_sequence(bass_line: tuple[int, ...]) -> str:
    if len(bass_line) <= 1 or len(set(bass_line)) <= 1:
        return "STATIC_BASS"
    intervals = [b - a for a, b in zip(bass_line, bass_line[1:])]
    if all(abs(value) <= 2 for value in intervals):
        return "STEPWISE_BASS"
    if all(value >= 0 for value in intervals) or all(value <= 0 for value in intervals):
        return "DIRECTIONAL_BASS"
    return "MOVING_BASS"


def _harmonic_role(pitch_class: int, root_pc: int | None, family) -> tuple[str, int | None, bool]:
    if root_pc is None:
        return "UNKNOWN", None, False
    interval = (pitch_class - root_pc) % 12
    if interval == 0:
        role = "ROOT"
    elif interval in (3, 4):
        role = "THIRD"
    elif interval in (6, 7, 8):
        role = "FIFTH"
    elif interval in (10, 11):
        role = "SEVENTH"
    elif interval in (2, 5, 9):
        role = "EXTENSION_OR_SUSPENSION"
    else:
        role = "OTHER"
    chord_tone = bool(family is not None and pitch_class in family.pitch_classes)
    if not chord_tone and role != "UNKNOWN":
        role = "NON_CHORD_TONE"
    return role, interval, chord_tone


def _pattern_classification(notes, root_pc: int | None, family, *, compound_meter: bool = False) -> tuple[str, float, tuple[str, ...]]:
    if not notes:
        return "REST", 1.0, ("No source accompaniment attacks begin in this window.",)
    groups = _groups(notes)
    ordered_onsets = sorted(groups)
    attack_sizes = [len(groups[onset]) for onset in ordered_onsets]
    multi = sum(size >= 2 for size in attack_sizes)
    chords = sum(size >= 3 for size in attack_sizes)
    single = sum(size == 1 for size in attack_sizes)
    max_sim = max(attack_sizes, default=0)
    bass = _bass_sequence(notes)

    roles: list[str] = []
    chord_tone_count = 0
    for onset in ordered_onsets:
        for note in groups[onset]:
            role, _, is_chord = _harmonic_role(note.pitch.midi % 12, root_pc, family)
            roles.append(role)
            chord_tone_count += int(is_chord)
    chord_ratio = chord_tone_count / max(len(notes), 1)

    # Timing is measured in quarter notes. Compound eighths are ternary
    # pulses, but are not notated tuplets; retain that distinction in the type.
    gaps = [b-a for a,b in zip(ordered_onsets, ordered_onsets[1:])]
    regular = len(gaps) >= 2 and max(gaps)-min(gaps) < 1e-5
    triplet = regular and any(abs(gaps[0]-v) < 1e-5 for v in (1/3, 2/3, 1/6, 1/12))
    compound = compound_meter and regular and abs(gaps[0]-.5) < 1e-5
    moving = len(set(n.pitch.midi % 12 for n in notes)) >= 3
    broken = max_sim <= 2 and single >= 2 and moving and chord_ratio >= .75
    if broken and (triplet or compound):
        return ("TRIPLET_ARPEGGIO" if triplet else "COMPOUND_ARPEGGIO"), .90, (
            "Regular ternary broken-chord attacks; preserve attack rhythm before thinning.",
        )
    line = [min(n.pitch.midi for n in groups[o]) for o in ordered_onsets]
    if max_sim == 1 and len(line) >= 8 and all(line[i] == line[i % 4] for i in range(len(line))) and line[0] < line[2] < line[1] and line[1] == line[3] and chord_ratio >= .75:
        return "ALBERTI_BASS", .92, ("Repeated low-high-middle-high chord-tone cycle.",)
    if multi and single:
        return "BASS_CHORD_PULSE", min(0.95, 0.72 + 0.04 * multi), (
            "Source alternates single/bass attacks with multi-note chord attacks.",
        )
    if chords and chords >= max(1, len(attack_sizes) - 1):
        return "BLOCK_CHORD", min(0.98, 0.78 + 0.05 * chords), (
            "Most source attacks contain three or more simultaneous notes.",
        )
    if max_sim == 1 and len(attack_sizes) >= 2:
        root_pulse = root_pc is not None and all((value % 12) == root_pc for value in bass)
        if root_pulse:
            return "ROOT_PULSE", min(0.97, 0.78 + 0.03 * len(bass)), (
                "Repeated single-note attacks remain on the detected chord root.",
            )
        stepwise = len(bass) >= 3 and all(abs(b - a) <= 2 for a, b in zip(bass, bass[1:]))
        if stepwise and chord_ratio < 0.85:
            return "BASS_LINE", 0.88, (
                "Single-note source line moves stepwise and includes non-chord/passing motion.",
            )
        if chord_ratio >= 0.75 and len(set(roles)) >= 2:
            return "ARPEGGIO", min(0.96, 0.72 + 0.04 * len(attack_sizes)), (
                "Single-note attacks outline multiple harmonic roles of the detected chord.",
            )
        return "BASS_LINE", 0.68 if stepwise else 0.58, (
            "Single-note accompaniment behaves more like a moving bass line than a clear chord arpeggio.",
        )
    if max_sim == 2:
        return "BASS_CHORD_PULSE", 0.70, (
            "Two-note source attacks are treated as a compact bass/chord pulse pattern.",
        )
    return "MIXED", 0.50, ("Source contains mixed attack shapes that do not fit one v0.13.4 primary pattern.",)


def analyze_piano_source_patterns(
    project: PianoSplitProject,
    *,
    quarters_per_window: float = 2.0,
    chord_top_k: int = 3,
) -> tuple[SourcePatternAnalysis, ...]:
    """Analyze source accompaniment without changing arrangement or fingering.

    This is the v0.13.4 review surface.  It intentionally records source rhythm,
    harmony roles, bass motion and pattern classification but does not remap the
    notes to guitar positions.
    """
    windows = build_fixed_harmony_windows(project, quarters_per_window=quarters_per_window)
    analyses = analyze_harmony_windows(windows, top_k=chord_top_k)
    results: list[SourcePatternAnalysis] = []
    for analysis in analyses:
        window = analysis.window
        notes = sorted(_attacks(window.accompaniment_notes, window.start, window.end), key=lambda n: (n.start, n.pitch.midi))
        groups = _groups(notes)
        best = analysis.candidates[0] if analysis.candidates else None
        family = best.family if best is not None else None
        if family is not None:
            root_pc = family.root_pc
            chord_symbol = chord_family_name(family)
            quality = family.quality
            harmony_confidence = max(0.25, min(1.0, 0.5 + best.total_score / 20.0))
        elif notes:
            root_pc = min(notes, key=lambda note: note.pitch.midi).pitch.midi % 12
            chord_symbol = f"PC{root_pc}"
            quality = "unknown"
            harmony_confidence = 0.35
        else:
            root_pc = 0
            chord_symbol = "N.C."
            quality = "none"
            harmony_confidence = 0.20

        metric_groups = tuple(g for g in project.melody.metric_groups
                              if g.start < window.end-1e-9 and g.end > window.start+1e-9)
        compound = bool(metric_groups and metric_groups[0].denominator == 8
                        and metric_groups[0].numerator >= 6 and metric_groups[0].numerator % 3 == 0)
        group_notes = [sorted(_attacks(window.accompaniment_notes, g.start, g.end),
                              key=lambda n:(n.start,n.pitch.midi)) for g in metric_groups]
        group_patterns = tuple(_pattern_classification(ns, root_pc if ns else None,
                                family, compound_meter=compound)[0] for ns in group_notes)
        group_counts = tuple(len(_groups(ns)) for ns in group_notes)
        repeated = (len(group_patterns) > 1 and len(set(group_patterns)) == 1
                    and len(set(group_counts)) == 1 and group_counts[0] > 0)
        pattern, pattern_confidence, pattern_reasons = _pattern_classification(notes, root_pc if notes else None, family, compound_meter=compound)
        if compound and group_patterns and all(p == "COMPOUND_ARPEGGIO" for p in group_patterns):
            pattern = "COMPOUND_ARPEGGIO"
            pattern_confidence = max(pattern_confidence, 0.85)
        if repeated:
            pattern_reasons += ("Repeated attack structure across complete source metric groups.",)
        ordered_onsets = sorted(groups)
        attack_index = {onset: index for index, onset in enumerate(ordered_onsets, start=1)}
        observations: list[SourceNoteObservation] = []
        role_sequence: list[str] = []
        for note_index, note in enumerate(notes, start=1):
            onset_key = round(note.start, 6)
            attack = groups[onset_key]
            role, interval, is_chord_tone = _harmonic_role(note.pitch.midi % 12, root_pc if notes else None, family)
            is_bass = bool(attack and note.pitch.midi == attack[0].pitch.midi)
            observations.append(SourceNoteObservation(
                event_id=note.source_event_id or f"{window.window_id}:SRC{note_index}",
                measure=note.measure,
                onset=note.start,
                relative_onset=round(note.start - window.start, 6),
                duration=note.duration,
                pitch=note.pitch.midi,
                pitch_class=note.pitch.midi % 12,
                attack_index=attack_index[onset_key],
                attack_size=len(attack),
                is_bass=is_bass,
                interval_from_root=interval,
                harmonic_role=role,
                is_chord_tone=is_chord_tone,
            ))
            role_sequence.append(role)

        attack_sizes = tuple(len(groups[onset]) for onset in ordered_onsets)
        bass_sequence = _bass_sequence(notes)
        pitch_values = [note.pitch.midi for note in notes]
        warnings: list[str] = []
        if best is None and notes:
            warnings.append("Harmony confidence is limited because no normal chord-family candidate survived analysis.")
        if pattern_confidence < 0.65 and notes:
            warnings.append("Pattern classification is low-confidence; review this window manually before mapping.")

        results.append(SourcePatternAnalysis(
            window_id=window.window_id,
            start=window.start,
            duration=window.duration,
            chord_symbol=chord_symbol,
            root_pitch_class=root_pc,
            chord_quality=quality,
            harmony_confidence=harmony_confidence,
            pattern_type=pattern,
            pattern_confidence=pattern_confidence,
            legacy_texture=_source_texture(notes),
            density=_density(notes, window.duration),
            bass_motion=_bass_motion_from_sequence(bass_sequence),
            bass_sequence=bass_sequence,
            functional_role_sequence=tuple(role_sequence),
            rhythm_pattern=tuple(round(onset - window.start, 6) for onset in ordered_onsets),
            attack_sizes=attack_sizes,
            max_simultaneous_notes=max(attack_sizes, default=0),
            voice_count=max(attack_sizes, default=0),
            pitch_min=min(pitch_values) if pitch_values else None,
            pitch_max=max(pitch_values) if pitch_values else None,
            notes=tuple(observations),
            metric_group_refs=tuple(g.group_id for g in metric_groups),
            metric_group_patterns=group_patterns,
            metric_group_attack_counts=group_counts,
            repeated_metric_pattern=repeated,
            harmony_note_evidence=analysis.evidence.note_evidence,
            reasons=pattern_reasons,
            warnings=tuple(warnings),
        ))
    return tuple(results)


def build_piano_source_intents(
    project: PianoSplitProject,
    *,
    quarters_per_window: float = 2.0,
    chord_top_k: int = 3,
    source_analyses: tuple[SourcePatternAnalysis, ...] | None = None,
) -> tuple[ArrangementIntent, ...]:
    """Translate piano source analysis into source-independent intents.

    v0.13.4 enriches diagnostics but deliberately retains the v0.13.4 legacy
    texture field for candidate selection, so this review release does not
    change the actual accompaniment output.
    """
    source_analyses = source_analyses or analyze_piano_source_patterns(
        project, quarters_per_window=quarters_per_window, chord_top_k=chord_top_k,
    )
    intents: list[ArrangementIntent] = []
    for source in source_analyses:
        reasons = [
            f"Source piano accompaniment observed {len(source.notes)} note attack(s) in the window.",
            f"v0.13.4 source pattern classified as {source.pattern_type} ({source.pattern_confidence:.2f}).",
            f"Source legacy texture {source.legacy_texture} is retained as an observation; v0.13.4 also creates an explicit guitar mapping decision.",
        ]
        if not source.notes:
            reasons.append("No source accompaniment attack begins in this window; preserve the source rest.")
        intents.append(ArrangementIntent(
            intent_id=f"SRC:{source.window_id}",
            source_mode="SOURCE_MAPPED",
            window_id=source.window_id,
            start=source.start,
            duration=source.duration,
            chord_symbol=source.chord_symbol,
            root_pitch_class=source.root_pitch_class,
            chord_quality=source.chord_quality,
            texture=source.legacy_texture,
            density=source.density,
            reduction_level=_REDUCTION[source.legacy_texture],
            bass_motion=source.bass_motion,
            melody_protection="HARD",
            preserve_source_rhythm=True,
            source_confidence=min(source.harmony_confidence, max(0.25, source.pattern_confidence)),
            reasons=tuple(reasons),
            attack_sizes=source.attack_sizes, functional_roles=source.functional_role_sequence,
            pattern_type=source.pattern_type, rhythm_pattern=source.rhythm_pattern, bass_sequence=source.bass_sequence,
            metadata={
                "analysis_source": "piano_existing_accompaniment",
                "metric_group_refs": list(source.metric_group_refs),
                "metric_group_patterns": list(source.metric_group_patterns),
                "metric_group_attack_counts": list(source.metric_group_attack_counts),
                "repeated_metric_pattern": source.repeated_metric_pattern,
                "source_note_attacks": len(source.notes),
                "source_attack_count": len(source.rhythm_pattern),
                "source_max_simultaneous_notes": source.max_simultaneous_notes,
                "source_pitch_min": source.pitch_min,
                "source_pitch_max": source.pitch_max,
                "source_pattern_stage": "ANALYSIS_V0132",
                "source_pattern_confidence": source.pattern_confidence,
                "source_harmony_confidence": source.harmony_confidence,
                "source_voice_count": source.voice_count,
                "mapping_enabled": True,
                "mapping_selection_policy": "AUDIT_ONLY_SOURCE_EXACT_BASELINE",
            },
        ))
    return tuple(intents)
