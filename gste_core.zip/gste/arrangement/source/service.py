"""Source analysis front door. Realization belongs solely to engine.service."""
from gste.arrangement.models import SourceArrangementPlan
from gste.arrangement.source_adapters.piano import analyze_piano_accompaniment
from gste.arrangement.data_contract import AccompanimentData
from gste.arrangement.engine.service import arrange
from .mapper import build_source_mapping_decisions


def analyze_and_map_piano_source(project, *, quarters_per_window=2.0, chord_top_k=3,
                                 legacy_mapping_mode='DIAGNOSTIC_ONLY', accompaniment_data=None):
    analyses=();bundle=None;mappings=()
    if accompaniment_data is None:
        analyses,bundle=analyze_piano_accompaniment(project,quarters_per_window=quarters_per_window,
            chord_top_k=chord_top_k,minimum_context_measures=2)
        accompaniment_data=AccompanimentData(bundle.canonical,preserve_rhythm=True,source_pitch_policy="SOURCE_AT_ATTACK")
        mappings=build_source_mapping_decisions(analyses) if legacy_mapping_mode != 'OFF' else ()
    realized=arrange(project.melody,accompaniment_data)
    return SourceArrangementPlan(intents=realized.intents,candidate_groups=realized.candidate_groups,
        selected_candidates=realized.selected_candidates,analyses=analyses,mappings=mappings,
        analysis_bundle=bundle,phrase_plan=bundle.phrase_plan if bundle else None,
        accompaniment_data=accompaniment_data)
