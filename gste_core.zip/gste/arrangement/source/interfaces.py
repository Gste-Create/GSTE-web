from __future__ import annotations

from typing import Protocol, Sequence

from gste.arrangement.models import ArrangementIntent


class SourceArrangementAnalyzer(Protocol):
    """Source-analysis boundary for piano/band/TAB accompaniment.

    Source-specific analyzers translate observations into ArrangementIntent.
    The shared arrangement engine and fingering layer must not inspect the
    original score representation in order to decide musical intent.
    """

    def analyze(self, source: object) -> Sequence[ArrangementIntent]: ...


class SourceMappingNotImplementedError(NotImplementedError):
    """Reserved for source formats not yet implemented by v0.13.3."""
