"""Import compatibility at ONE boundary; no parallel conversion algorithm."""
from gste.arrangement.accompaniment_contract import normalize_accompaniment_plan, contract_to_joint_bundle

def source_plan_to_candidate_bundle(plan, template):
    return contract_to_joint_bundle(normalize_accompaniment_plan(plan,source_kind="source_accompaniment"),template)

def source_plan_to_track(plan, template):
    return source_plan_to_candidate_bundle(plan,template)[0]
