"""Piano-source compatibility package.

Phase 1 deliberately avoids eager service imports. The previous eager import
created a cycle with the new Piano source adapter:
source_adapters.piano -> source.analyzer -> source.__init__ -> source.service
-> source_adapters.piano.

Core data/analyzer helpers remain directly available; the service module is
imported explicitly by runtime callers.
"""
from .adapter import source_plan_to_track, source_plan_to_candidate_bundle
from .analyzer import analyze_piano_source_patterns, build_piano_source_intents
from .diagnostics import write_route_diagnostics, write_source_arrangement_diagnostics
from .interfaces import SourceArrangementAnalyzer, SourceMappingNotImplementedError
from .mapper import map_source_analysis, build_source_mapping_decisions

__all__ = [
    "SourceArrangementAnalyzer", "SourceMappingNotImplementedError",
    "analyze_piano_source_patterns", "build_piano_source_intents",
    "map_source_analysis", "build_source_mapping_decisions",
    "source_plan_to_track", "source_plan_to_candidate_bundle", "write_route_diagnostics",
    "write_source_arrangement_diagnostics",
]
