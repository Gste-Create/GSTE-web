"""LEGACY Piano source-mapping compatibility layer.

Phase 1 keeps this module operational only for regression/fallback while the
new canonical Bass/Harmony/Rhythm/Texture + Phrase pipeline is validated.
Do not add new musical rules here. Planned retirement occurs after the new
Piano understanding path becomes primary and passes one full release of A/B
regression.
"""
from __future__ import annotations

from gste.arrangement.models import SourceMappingDecision, SourcePatternAnalysis

_PATTERN_MAP = {
    "ARPEGGIO": "GUITAR_ARPEGGIO",
    "BLOCK_CHORD": "COMPACT_BLOCK_CHORD",
    "BASS_LINE": "GUITAR_BASS_LINE",
    "BASS_CHORD_PULSE": "BASS_CHORD_PULSE",
    "ROOT_PULSE": "ROOT_PULSE",
    "REST": "REST",
    "MIXED": "CONSERVATIVE_MIXED",
}

_DEGRADATION = {
    "ARPEGGIO": ("SOURCE_HIGH_FIDELITY_MAPPED", "SOURCE_REDUCED_ARPEGGIO", "ROOT_PLUS_GUIDE", "ROOT_ONLY", "REST"),
    "BLOCK_CHORD": ("SOURCE_HIGH_FIDELITY_MAPPED", "COMPACT_CHORD", "SHELL_VOICING", "ROOT_PLUS_GUIDE", "ROOT_ONLY", "REST"),
    "BASS_LINE": ("SOURCE_HIGH_FIDELITY_MAPPED", "REDUCED_BASS_LINE", "ROOT_PULSE", "ROOT_ONLY", "REST"),
    "BASS_CHORD_PULSE": ("SOURCE_HIGH_FIDELITY_MAPPED", "BASS_PLUS_GUIDE", "ROOT_PLUS_GUIDE", "ROOT_ONLY", "REST"),
    "ROOT_PULSE": ("SOURCE_HIGH_FIDELITY_MAPPED", "ROOT_PULSE", "ROOT_ONLY", "REST"),
    "REST": ("REST",),
    "MIXED": ("SOURCE_HIGH_FIDELITY_MAPPED", "SOURCE_REDUCED_PATTERN", "ROOT_PLUS_GUIDE", "ROOT_ONLY", "REST"),
}

def _role_confidence(analysis: SourcePatternAnalysis) -> float:
    roles = tuple(analysis.functional_role_sequence)
    if not roles:
        return 1.0 if analysis.pattern_type == "REST" else 0.50
    uncertain = sum(1 for role in roles if role in {"NON_CHORD_TONE", "EXTENSION_OR_SUSPENSION"})
    ratio = uncertain / max(1, len(roles))
    return max(0.35, min(1.0, 1.0 - 0.55 * ratio))

def _confidence_gate(pattern: float, harmony: float, role: float, pattern_type: str) -> tuple[str, str]:
    if pattern_type == "REST":
        return "HIGH", "FULL_MAPPING_ELIGIBLE"
    if pattern < 0.65:
        return "LOW", "AUDIT_ONLY"
    if pattern >= 0.80 and harmony >= 0.80 and role >= 0.70:
        return "HIGH", "FULL_MAPPING_ELIGIBLE"
    return "MEDIUM", "SAFE_MAPPING_ONLY"

def map_source_analysis(analysis: SourcePatternAnalysis) -> SourceMappingDecision:
    target = _PATTERN_MAP.get(analysis.pattern_type, "CONSERVATIVE_MIXED")
    pattern_confidence = float(analysis.pattern_confidence)
    harmony_confidence = float(analysis.harmony_confidence)
    role_confidence = _role_confidence(analysis)
    gate, eligibility = _confidence_gate(pattern_confidence, harmony_confidence, role_confidence, analysis.pattern_type)
    mapping_confidence = min(pattern_confidence, harmony_confidence, role_confidence)
    warnings = list(analysis.warnings)
    if analysis.pattern_type == "MIXED":
        warnings.append("MIXED source pattern uses conservative mapping; review before enabling mapped selection.")
    if eligibility == "AUDIT_ONLY" and analysis.pattern_type != "REST":
        warnings.append("Low pattern confidence: mapping is audit-only in v0.13.4.1.")
    elif eligibility == "SAFE_MAPPING_ONLY":
        warnings.append("Mapping Confidence Gate permits rhythm/contour/role-preserving safe mapping only; uncertain chord reconstruction must not be forced.")
    return SourceMappingDecision(
        window_id=analysis.window_id, source_pattern=analysis.pattern_type, target_pattern=target,
        chord_symbol=analysis.chord_symbol, density=analysis.density, bass_motion=analysis.bass_motion,
        preserve_rhythm=True, preserve_harmonic_roles=True, preserve_exact_pitch=False,
        pattern_confidence=pattern_confidence, harmony_confidence=harmony_confidence, role_confidence=role_confidence,
        mapping_confidence=mapping_confidence, confidence_gate=gate, mapping_eligibility=eligibility,
        source_roles=analysis.functional_role_sequence, rhythm_pattern=analysis.rhythm_pattern,
        bass_sequence=analysis.bass_sequence, degradation_ladder=_DEGRADATION.get(analysis.pattern_type, _DEGRADATION["MIXED"]),
        reasons=(
            f"Source {analysis.pattern_type} maps to {target}.",
            f"Confidence gate={gate}; eligibility={eligibility}.",
            "Pattern, harmony, and harmonic-role confidence are evaluated separately.",
            "Source rhythm and harmonic roles are preserved as intent; exact piano register is not a mapping invariant.",
            "Guitar string/fret assignment remains the responsibility of Joint Fingering.",
        ), warnings=tuple(warnings),
    )

def build_source_mapping_decisions(analyses: tuple[SourcePatternAnalysis, ...]) -> tuple[SourceMappingDecision, ...]:
    return tuple(map_source_analysis(item) for item in analyses)
