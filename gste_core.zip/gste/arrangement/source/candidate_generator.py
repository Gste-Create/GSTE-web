"""LEGACY Piano-mapping candidate compatibility layer.

The shared guitar arrangement core is the target owner of accompaniment
creation. Existing SOURCE_* candidates remain temporarily for fallback and A/B
comparison; new source-understanding work must go through canonical intents.
"""
from __future__ import annotations

from collections import defaultdict

from gste.arrangement.models import AccompanimentEvent, ArrangementCandidate, ArrangementIntent, SourceMappingDecision
from gste.core.models import NoteEvent
from gste.harmony.windows import build_fixed_harmony_windows
from gste.input.project_models import PianoSplitProject
from gste.arrangement.guitar.model import ChordIntent, GuitarTexturePlan
from gste.arrangement.guitar.pattern_generator import generate_guitar_pattern
from gste.arrangement.guitar.density_policy import DENSITY_POLICY


def _source_role(note: NoteEvent, onset_group: list[NoteEvent]) -> str:
    ordered = sorted(onset_group, key=lambda item: item.pitch.midi)
    if ordered and note is ordered[0]:
        return "bass"
    return "source_chord_tone"


def _event_from_note(intent: ArrangementIntent, note: NoteEvent, onset_group: list[NoteEvent], index: int) -> AccompanimentEvent:
    role = _source_role(note, onset_group)
    source_importance = note.importance if note.importance is not None else (95 if role == "bass" else 75)
    # v0.1.4: Piano RH priority-pool events remain optional even if their pitch
    # happens to be the lowest event in a local attack.  Their importance is a
    # Joint loss cost, never a pre-Joint keep/drop command.
    priority_pool_event = str(note.arrangement_role or "").startswith("melody_priority_")
    return AccompanimentEvent(
        event_id=note.source_event_id or f"{intent.window_id}-SRC{index}",
        window_id=intent.window_id,
        onset=note.start,
        duration=note.duration,
        role=role,
        pitch=note.pitch.midi,
        importance=source_importance,
        optional=True if priority_pool_event else (False if role == "bass" else True),
        reduction_level=0,
        source_chord=intent.chord_symbol,
    )


def _attacks(project: PianoSplitProject, intent: ArrangementIntent) -> list[NoteEvent]:
    end = intent.start + intent.duration
    return [
        note for note in project.left_hand.notes
        if intent.start - 1e-9 <= note.start < end - 1e-9
    ]


def _nearest_same_pc(pitch: int, *, low: int, high: int, center: int) -> int:
    pc = pitch % 12
    values = [m for m in range(low, high + 1) if m % 12 == pc]
    if not values:
        return pitch
    return min(values, key=lambda m: (abs(m - center), abs(m - pitch)))


def _mapped_event(event: AccompanimentEvent) -> AccompanimentEvent:
    # v0.13.4 pitch-level guitar mapping only.  Bass remains in a bass register;
    # upper source tones are octave-folded into a central guitar register.
    if event.role == "bass":
        target = _nearest_same_pc(event.pitch, low=40, high=59, center=47)
    else:
        target = _nearest_same_pc(event.pitch, low=48, high=72, center=59)
    return AccompanimentEvent(
        event_id=f"{event.event_id}:MAP", window_id=event.window_id, onset=event.onset,
        duration=event.duration, role=event.role, pitch=target, importance=event.importance,
        optional=event.optional, reduction_level=event.reduction_level, source_chord=event.source_chord,
    )


def _guide_reduced(events: tuple[AccompanimentEvent, ...]) -> tuple[AccompanimentEvent, ...]:
    by_onset: dict[float, list[AccompanimentEvent]] = defaultdict(list)
    for event in events:
        by_onset[round(event.onset, 6)].append(event)
    out: list[AccompanimentEvent] = []
    for onset in sorted(by_onset):
        attack = sorted(by_onset[onset], key=lambda e: e.pitch)
        if not attack:
            continue
        out.append(attack[0])
        uppers = attack[1:]
        if uppers:
            # Keep one upper tone; prefer a non-root pitch class when available.
            root_pc = attack[0].pitch % 12
            guide = next((e for e in uppers if e.pitch % 12 != root_pc), uppers[-1])
            out.append(guide)
    return tuple(out)


def generate_source_candidate_group(
    intent: ArrangementIntent,
    project: PianoSplitProject,
    mapping: SourceMappingDecision | None = None,
    *,
    guitar_chord: ChordIntent | None = None,
    guitar_plan: GuitarTexturePlan | None = None,
    rhythm_pattern: tuple[float, ...] | None = None,
    melody_hand_center: float | None = None,
    melody_hand_center_confidence: float = 1.0,
    include_legacy_mapping_candidates: bool = True,
    arranger_policy: str = "PIANO",
    melody_budget: str = "MEDIUM",
    source_density: int = 2,
) -> tuple[ArrangementCandidate, ...]:
    """Rebuild Guitar candidates from abstract Piano accompaniment intent.

    group_V0.0.5: raw Piano events may be inspected here for source analysis /
    legacy diagnostics, but runtime candidates are generated from canonical
    harmony, bass policy, texture and rhythm intent.  Raw SOURCE_EXACT is not
    admitted to Joint.
    """
    notes = _attacks(project, intent) if include_legacy_mapping_candidates else []
    groups: dict[float, list[NoteEvent]] = defaultdict(list)
    for note in notes:
        groups[round(note.start, 6)].append(note)
    exact_events = tuple(
        _event_from_note(intent, note, groups[round(note.start, 6)], index)
        for index, note in enumerate(sorted(notes, key=lambda item: (item.start, item.pitch.midi)), start=1)
    )

    # Reduced source keeps the lowest note of each attack plus at most one upper
    # tone.  It is diagnostic/precomputed in v0.13.3 and is not selected yet.
    reduced_events: list[AccompanimentEvent] = []
    bass_events: list[AccompanimentEvent] = []
    for onset in sorted(groups):
        attack = sorted(groups[onset], key=lambda item: item.pitch.midi)
        if not attack:
            continue
        bass = _event_from_note(intent, attack[0], attack, len(reduced_events) + 1)
        bass_events.append(bass)
        reduced_events.append(bass)
        if len(attack) > 1:
            reduced_events.append(_event_from_note(intent, attack[-1], attack, len(reduced_events) + 1))

    mapped_exact = tuple(_mapped_event(event) for event in exact_events)
    mapped_reduced = _guide_reduced(mapped_exact)

    mapping_type = mapping.target_pattern if mapping is not None else "UNMAPPED"
    mapping_confidence = mapping.mapping_confidence if mapping is not None else intent.source_confidence

    guitar_candidate = None
    if guitar_chord is not None and guitar_plan is not None:
        rhythm = tuple(rhythm_pattern) if rhythm_pattern is not None else (mapping.rhythm_pattern if mapping is not None else tuple())
        # v0.13.5.10 candidate-superset rule:
        # Preserve one true v0.13.5.5-compatible natural-register realization,
        # then ADD v0.13.5.10 HYBRID / ORIGINAL / NEAR alternatives.
        grammars = DENSITY_POLICY.right_hand_grammars(
            texture=guitar_plan.texture, melody_budget=melody_budget, source_density=source_density
        )
        primary_grammar = grammars[0]
        baseline_events = generate_guitar_pattern(
            intent, guitar_chord, guitar_plan, rhythm,
            melody_hand_center=None, melody_hand_center_confidence=0.0,
            register_mode="ORIGINAL", right_hand_grammar=primary_grammar,
        )
        baseline_candidate = ArrangementCandidate(
            candidate_id=f"{intent.intent_id}:guitar_decision:baseline_v01355",
            intent_id=intent.intent_id, window_id=intent.window_id,
            texture=guitar_plan.texture,
            reduction_level=1 if guitar_plan.texture not in {"ROOT", "REST"} else 3,
            events=baseline_events, fidelity_rank=4, fallback_rank=1,
            reasons=intent.reasons + guitar_plan.reasons + (
                "v0.13.5.10 baseline-superset candidate preserving v0.13.5.5 natural-register guitar realization.",
            ),
            metadata={
                "source_mode": intent.source_mode,
                "source_candidate_type": "GUITAR_BASELINE_V01355",
                "guitar_texture": guitar_plan.texture,
                "guitar_bass_policy": guitar_chord.bass_policy,
                "allow_octave_revoice": guitar_plan.allow_octave_revoice,
                "allow_inversion": guitar_plan.allow_inversion,
                "required_intervals": list(guitar_chord.required_intervals),
                "optional_intervals": list(guitar_chord.optional_intervals),
                "color_intervals": list(guitar_chord.color_intervals),
                "selection_stage": "V01359_CANDIDATE_SUPERSET",
                "register_policy": "BASELINE_V01355",
                "baseline_candidate": True,
                "arranger_policy": arranger_policy,
                "right_hand_grammar": primary_grammar,
            },
        )

        # v0.13.5.10 register alternatives remain available as additions.
        register_candidates = []
        variant_specs = []
        for register_mode, rank, suffix in (
            ("HYBRID", 2, "hybrid"),
            ("ORIGINAL", 3, "original"),
            ("NEAR", 4, "near"),
        ):
            grammar_set = grammars if register_mode == "HYBRID" else (primary_grammar,)
            for grammar_index, grammar in enumerate(grammar_set):
                variant_specs.append((register_mode, rank + grammar_index * 0.1, suffix, grammar))
        for register_mode, rank, suffix, grammar in variant_specs:
            events = generate_guitar_pattern(
                intent, guitar_chord, guitar_plan, rhythm,
                melody_hand_center=melody_hand_center,
                melody_hand_center_confidence=melody_hand_center_confidence,
                register_mode=register_mode, right_hand_grammar=grammar,
            )
            register_candidates.append(ArrangementCandidate(
                candidate_id=f"{intent.intent_id}:guitar_decision:{suffix}:{grammar.lower()}",
                intent_id=intent.intent_id, window_id=intent.window_id,
                texture=guitar_plan.texture,
                reduction_level=1 if guitar_plan.texture not in {"ROOT", "REST"} else 3,
                events=events, fidelity_rank=4, fallback_rank=int(rank * 10),
                reasons=intent.reasons + guitar_plan.reasons + (
                    f"v0.13.5.13.3 Piano arranger realization: {register_mode}/{grammar}.",
                ),
                metadata={
                    "source_mode": intent.source_mode,
                    "source_candidate_type": "GUITAR_DECISION",
                    "guitar_texture": guitar_plan.texture,
                    "guitar_bass_policy": guitar_chord.bass_policy,
                    "allow_octave_revoice": guitar_plan.allow_octave_revoice,
                    "allow_inversion": guitar_plan.allow_inversion,
                    "required_intervals": list(guitar_chord.required_intervals),
                    "optional_intervals": list(guitar_chord.optional_intervals),
                    "color_intervals": list(guitar_chord.color_intervals),
                    "selection_stage": "V0135133_PIANO_DUAL_ARRANGER",
                    "melody_hand_center": melody_hand_center,
                    "melody_hand_center_confidence": melody_hand_center_confidence,
                    "register_policy": register_mode,
                    "arranger_policy": arranger_policy,
                    "right_hand_grammar": grammar,
                    "melody_priority_order": "IMPORTANT_BASS>CHARACTERISTIC_TONE>SOURCE_TEXTURE>OPTIONAL_INNER",
                },
            ))
        guitar_candidate = register_candidates[0]

        from dataclasses import replace
        source_pattern = str(intent.pattern_type)
        source_rhythm = tuple(intent.rhythm_pattern)
        if intent.preserve_source_rhythm and source_rhythm and source_pattern != "REST":
            broken = source_pattern in {"ARPEGGIO", "TRIPLET_ARPEGGIO", "COMPOUND_ARPEGGIO", "ALBERTI_BASS"}
            texture = "ARPEGGIO" if broken else ("COMPACT_BLOCK" if source_pattern in {"BLOCK_CHORD", "BASS_CHORD_PULSE"} else "ROOT_GUIDE")
            source_plan = replace(guitar_plan, texture=texture, allow_inversion=False)
            semantic_candidates = []
            for level, mode in enumerate(("ORIGINAL", "NEAR")):
                events = generate_guitar_pattern(intent, guitar_chord, source_plan, source_rhythm,
                    melody_hand_center=melody_hand_center, melody_hand_center_confidence=melody_hand_center_confidence,
                    register_mode=mode, right_hand_grammar="SOURCE")
                semantic_candidates.append(ArrangementCandidate(
                    candidate_id=f"{intent.intent_id}:source_semantic:{mode}", intent_id=intent.intent_id,
                    window_id=intent.window_id, texture=texture, reduction_level=0, events=events,
                    fidelity_rank=5, fallback_rank=level,
                    reasons=intent.reasons+("Source attack rhythm retained; octave realization precedes pulse removal.",),
                    metadata={"source_mode":intent.source_mode, "source_candidate_type":"GUITAR_SOURCE_SEMANTIC",
                              "register_policy":f"SOURCE_RHYTHM_{mode}", "guitar_texture":texture,
                              "pattern_type":source_pattern, "source_attack_count":len(source_rhythm),
                              "generated_attack_count":len({e.onset for e in events}), "rhythm_preserved":True},
                ))
            # One finer step: shorten only upper sustain, retaining all attacks
            # and bass anchors. Joint decides whether that release is needed.
            full = semantic_candidates[-1]
            released = tuple(replace(e, duration=max(.01,e.duration*.5), reduction_level=1) if e.role != "bass" else e for e in full.events)
            if released != full.events:
                semantic_candidates.append(replace(full, candidate_id=f"{intent.intent_id}:source_semantic:RELEASED",
                    reduction_level=1, fidelity_rank=4, fallback_rank=2, events=released,
                    reasons=full.reasons+("Upper sustain shortened before deleting any source pulse.",),
                    metadata={**full.metadata,"register_policy":"SOURCE_RHYTHM_RELEASED","degradation_action":"SHORTEN_UPPER_SUSTAIN"}))
            register_candidates = semantic_candidates + register_candidates


    # group_V0.0.5 source-abstraction boundary:
    # Raw Piano NoteEvents end their runtime life here.  SOURCE_EXACT used to
    # copy source pitch/onset/duration into Joint as a safety fallback, which
    # meant Piano notation timing could bypass the canonical accompaniment
    # intent.  Runtime candidates are now rebuilt exclusively from abstract
    # harmony/bass/texture/rhythm intent via generate_guitar_pattern().
    candidates = []
    if guitar_candidate is not None:
        candidates.extend([baseline_candidate, *register_candidates])
    if not candidates:
        raise ValueError(f"SOURCE_ABSTRACTION_NO_GUITAR_CANDIDATE:{intent.window_id}")

    if include_legacy_mapping_candidates:
        candidates.extend([
            ArrangementCandidate(
                candidate_id=f"{intent.intent_id}:source_high_fidelity_mapped", intent_id=intent.intent_id, window_id=intent.window_id,
                texture=mapping_type, reduction_level=0, events=mapped_exact, fidelity_rank=5, fallback_rank=10,
                reasons=intent.reasons + ("LEGACY diagnostic candidate: octave-folded source Piano mapping.",),
                metadata={"source_mode": "LEGACY_DIAGNOSTIC", "source_candidate_type": "SOURCE_HIGH_FIDELITY_MAPPED", "mapping_confidence": mapping_confidence, "audit_only": True},
            ),
            ArrangementCandidate(
                candidate_id=f"{intent.intent_id}:source_pattern_reduced", intent_id=intent.intent_id, window_id=intent.window_id,
                texture=mapping_type, reduction_level=2, events=mapped_reduced, fidelity_rank=3, fallback_rank=11,
                reasons=intent.reasons + ("LEGACY diagnostic candidate: mapped bass plus one guide tone.",),
                metadata={"source_mode": "LEGACY_DIAGNOSTIC", "source_candidate_type": "SOURCE_PATTERN_REDUCED", "mapping_confidence": mapping_confidence, "audit_only": True},
            ),
            ArrangementCandidate(
                candidate_id=f"{intent.intent_id}:source_reduced", intent_id=intent.intent_id, window_id=intent.window_id,
                texture="bass_inner" if len(reduced_events) > len(bass_events) else "root", reduction_level=2, events=tuple(reduced_events), fidelity_rank=3, fallback_rank=12,
                reasons=intent.reasons + ("LEGACY diagnostic source reduction.",),
                metadata={"source_mode": "LEGACY_DIAGNOSTIC", "source_candidate_type": "SOURCE_REDUCED", "audit_only": True},
            ),
            ArrangementCandidate(
                candidate_id=f"{intent.intent_id}:source_bass", intent_id=intent.intent_id, window_id=intent.window_id,
                texture="root", reduction_level=4, events=tuple(bass_events), fidelity_rank=1, fallback_rank=13,
                reasons=intent.reasons + ("LEGACY diagnostic bass-only reduction.",),
                metadata={"source_mode": "LEGACY_DIAGNOSTIC", "source_candidate_type": "SOURCE_BASS_ONLY", "audit_only": True},
            ),
        ])
    return tuple(candidates)
