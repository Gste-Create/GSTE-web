from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

@dataclass(frozen=True)
class SourceTone:
    event_id: str
    onset: float
    duration: float
    pitch: int
    measure: int
    role: str = "chord_tone"


@dataclass(frozen=True)
class SourcePitchRef:
    event_id: str
    onset: float
    pitch: int
    group_id: str
    octave_shift: int
    key_shift: int = 0


@dataclass(frozen=True)
class SourceEvidence:
    source_type: str
    source_id: str
    confidence: float = 1.0
    user_weight: float = 1.0
    metadata: dict[str, Any] = field(default_factory=dict)
    event_ids: tuple[str, ...] = ()

@dataclass(frozen=True)
class HarmonyIntent:
    window_id: str
    start: float
    duration: float
    root_pitch_class: int
    chord_symbol: str
    quality: str
    confidence: float
    required_pitch_classes: tuple[int, ...] = ()
    optional_pitch_classes: tuple[int, ...] = ()
    color_pitch_classes: tuple[int, ...] = ()
    bass_relation: str = "UNKNOWN"
    reasons: tuple[str, ...] = ()

@dataclass(frozen=True)
class BassIntent:
    window_id: str
    start: float
    duration: float
    primary_pitch: int | None
    pitch_class: int | None
    motion: str
    structural_role: str
    chord_role: str = "UNKNOWN"
    confidence: float = 0.0
    bass_sequence: tuple[int, ...] = ()
    reasons: tuple[str, ...] = ()

@dataclass(frozen=True)
class RhythmIntent:
    window_id: str
    start: float
    duration: float
    rhythm_pattern: tuple[float, ...]
    attack_sizes: tuple[int, ...]
    density: str
    syncopation: float = 0.0
    accent_positions: tuple[float, ...] = ()
    confidence: float = 1.0

@dataclass(frozen=True)
class TextureIntent:
    window_id: str
    start: float
    duration: float
    pattern_type: str
    density: str
    bass_separation: bool
    continuity_group: str = ""
    confidence: float = 1.0
    reasons: tuple[str, ...] = ()

@dataclass(frozen=True)
class PhraseIntent:
    phrase_id: str
    start: float
    duration: float
    window_ids: tuple[str, ...]
    energy_level: float
    transition_score: float
    transition_reasons: tuple[str, ...] = ()
    primary_texture: str = "SPARSE_ARPEGGIO"
    secondary_texture: str = "ROOT_GUIDE"
    accent_texture: str = "COMPACT_BLOCK"

@dataclass(frozen=True)
class SectionIntent:
    section_id: str
    start: float
    duration: float
    energy_level: float
    role: str = "MID_ENERGY"
    confidence: float = 0.6
    reasons: tuple[str, ...] = ()

@dataclass(frozen=True)
class CanonicalArrangementIntent:
    window_id: str
    harmony: HarmonyIntent
    bass: BassIntent
    rhythm: RhythmIntent
    texture: TextureIntent
    phrase: PhraseIntent | None
    evidence: tuple[SourceEvidence, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)
    section: SectionIntent | None = None

    observations: tuple = ()
    source_tones: tuple[SourceTone, ...] = ()

    functional_roles: tuple[str, ...] = ()
