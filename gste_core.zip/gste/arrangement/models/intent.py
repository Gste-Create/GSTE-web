from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal


SourceMode = Literal["CANONICAL", "AUTO_GENERATED", "SOURCE_MAPPED", "HYBRID"]


@dataclass(frozen=True)
class ArrangementIntent:
    """Source-independent musical intent for one harmonic window.

    v0.13.3 establishes this as the boundary between input analysis and the
    arrangement engine.  It intentionally describes *what* the accompaniment
    should do, not guitar strings/frets or fingering decisions.
    """

    intent_id: str
    source_mode: SourceMode
    window_id: str
    start: float
    duration: float
    chord_symbol: str
    root_pitch_class: int
    chord_quality: str
    texture: str
    density: str
    reduction_level: int
    bass_motion: str = "ROOT_ANCHOR"
    melody_protection: str = "HARD"
    preserve_source_rhythm: bool = False
    source_confidence: float = 1.0
    reasons: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)
    pattern_type: str = "UNKNOWN"
    rhythm_pattern: tuple[float, ...] = ()
    bass_sequence: tuple[int, ...] = ()
    provenance: tuple = ()

    attack_sizes: tuple[int, ...] = ()
    functional_roles: tuple[str, ...] = ()
