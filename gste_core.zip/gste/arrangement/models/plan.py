from __future__ import annotations

from dataclasses import dataclass

from .candidate import ArrangementCandidate
from .domain import AccompanimentWindow, ChordProgressionResult
from .intent import ArrangementIntent
from gste.arrangement.canonical import CanonicalArrangementIntent


@dataclass(frozen=True)
class ArrangementPlan:
    progression: ChordProgressionResult
    intents: tuple[ArrangementIntent, ...]
    candidate_groups: tuple[tuple[ArrangementCandidate, ...], ...]
    selected_candidates: tuple[ArrangementCandidate, ...]
    selected_windows: tuple[AccompanimentWindow, ...]
    canonical_intents: tuple[CanonicalArrangementIntent, ...] = ()

    accompaniment_data: object | None = None
