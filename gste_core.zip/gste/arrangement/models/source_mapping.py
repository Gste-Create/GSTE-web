from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class SourceMappingDecision:
    """v0.13.4 source accompaniment -> guitar arrangement mapping audit.

    This object deliberately contains musical mapping intent only.  It carries
    no string/fret/finger information, so the fingering layer remains the sole
    authority for physical playability.
    """

    window_id: str
    source_pattern: str
    target_pattern: str
    chord_symbol: str
    density: str
    bass_motion: str
    preserve_rhythm: bool
    preserve_harmonic_roles: bool
    preserve_exact_pitch: bool
    pattern_confidence: float
    harmony_confidence: float
    role_confidence: float
    mapping_confidence: float
    confidence_gate: str
    mapping_eligibility: str
    source_roles: tuple[str, ...]
    rhythm_pattern: tuple[float, ...]
    bass_sequence: tuple[int, ...]
    degradation_ladder: tuple[str, ...]
    reasons: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()
