from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .candidate import ArrangementCandidate
from .intent import ArrangementIntent
from .source_analysis import SourcePatternAnalysis
from .source_mapping import SourceMappingDecision


@dataclass(frozen=True)
class SourceArrangementPlan:
    """Source-mapped accompaniment analysis result before guitar fingering.

    v0.13.4 keeps source analysis and the fingering layer separated. Mapping
    decisions and mapped pitch-level candidates are now precomputed for audit;
    SOURCE_EXACT remains selected until melody-conditioned selection is enabled.
    """

    intents: tuple[ArrangementIntent, ...]
    candidate_groups: tuple[tuple[ArrangementCandidate, ...], ...]
    selected_candidates: tuple[ArrangementCandidate, ...]
    analyses: tuple[SourcePatternAnalysis, ...] = ()
    mappings: tuple[SourceMappingDecision, ...] = ()
    analysis_bundle: Any | None = None
    phrase_plan: Any | None = None

    accompaniment_data: object | None = None
