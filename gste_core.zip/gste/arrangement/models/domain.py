from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from gste.core.models import NoteEvent
from gste.structure.metric import MetricContext


# Compatibility import: the candidate type has one owner.
from gste.tonality import KeyCandidate, TonalityAnalysis


@dataclass(frozen=True)
class WeightedNote:
    midi: int
    pitch_class: int
    onset: float
    duration: float
    weight: float
    strong_beat: bool
    event_id: str | None = None
    metric_context: MetricContext | None = None


@dataclass(frozen=True)
class ChordWindow:
    window_id: str
    measure_start: int
    beat_start: float
    measure_end: int
    beat_end: float
    start: float
    duration: float
    melody_notes: tuple[WeightedNote, ...]
    weighted_pitch_classes: dict[int, float]
    is_phrase_end: bool = False
    is_song_end: bool = False


@dataclass(frozen=True)
class ChordCandidate:
    chord_symbol: str
    root_pitch_class: int
    quality: str
    scale_degree: int
    harmonic_function: str
    melody_fit_score: float
    strong_beat_score: float
    long_note_score: float
    key_score: float
    transition_cost: float = 0.0
    cadence_cost: float = 0.0
    complexity_cost: float = 0.0
    total_cost: float = 0.0
    reasons: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()


@dataclass(frozen=True)
class WindowResult:
    window: ChordWindow
    candidates: tuple[ChordCandidate, ...]
    selected: ChordCandidate
    confidence: float


@dataclass(frozen=True)
class ChordProgressionResult:
    selected_key: KeyCandidate
    key_candidates: tuple[KeyCandidate, ...]
    window_results: tuple[WindowResult, ...]
    selected_chords: tuple[str, ...]
    total_cost: float
    alternative_paths: tuple[tuple[str, ...], ...] = ()
    low_confidence_windows: tuple[str, ...] = ()
    tonality_analysis: TonalityAnalysis | None = None


@dataclass(frozen=True)
class AccompanimentEvent:
    event_id: str
    window_id: str
    onset: float
    duration: float
    role: str
    pitch: int
    importance: int
    optional: bool
    reduction_level: int
    source_chord: str
    intent_id: str | None = None
    candidate_id: str | None = None
    pattern_type: str | None = None
    provenance: tuple = ()
    preserve_rhythm: bool = False
    attack_loss: int = 0
    source_pitch_ref: object | None = None


@dataclass(frozen=True)
class AccompanimentWindow:
    window_id: str
    pattern: str
    density: str
    reduction_level: int
    events: tuple[AccompanimentEvent, ...]
    reasons: tuple[str, ...] = ()


@dataclass(frozen=True)
class ArrangementPackage:
    melody_events: tuple[NoteEvent, ...]
    accompaniment_events: tuple[AccompanimentEvent, ...]
    selected_chord_progression: ChordProgressionResult
    register_candidate: str
    transposition_semitones: int
    diagnostic_metadata: dict[str, Any] = field(default_factory=dict)


def serializable(value: Any) -> Any:
    if hasattr(value, "__dataclass_fields__"):
        return {k: serializable(v) for k, v in asdict(value).items()}
    if isinstance(value, dict):
        return {str(k): serializable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [serializable(v) for v in value]
    return value
