from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .domain import AccompanimentEvent


@dataclass(frozen=True)
class ArrangementCandidate:
    """One musically valid accompaniment realization before fingering.

    Candidates are ordered from higher-fidelity/richer realizations to safer
    reductions.  They contain pitches, timing and musical roles only; they do
    not contain guitar string/fret assignments.
    """

    candidate_id: str
    intent_id: str
    window_id: str
    texture: str
    reduction_level: int
    events: tuple[AccompanimentEvent, ...]
    fidelity_rank: int
    fallback_rank: int
    reasons: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)
