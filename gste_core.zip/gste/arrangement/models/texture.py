from __future__ import annotations

from enum import IntEnum


class TextureLevel(IntEnum):
    REST = 0
    ROOT_ONLY = 1
    ROOT_PLUS_GUIDE = 2
    BASS_PLUS_INNER = 3
    REDUCED_ARPEGGIO = 4
    FULL_ARPEGGIO = 5
