from __future__ import annotations

from dataclasses import dataclass
from gste.harmony.models import HarmonyNoteEvidence


@dataclass(frozen=True)
class SourceNoteObservation:
    """One observed accompaniment attack before any guitar mapping.

    v0.13.3 records source facts and harmonic function only.  It intentionally
    carries no guitar string/fret information and is therefore safe to inspect
    before the later source-mapping releases.
    """

    event_id: str
    measure: int | None
    onset: float
    relative_onset: float
    duration: float
    pitch: int
    pitch_class: int
    attack_index: int
    attack_size: int
    is_bass: bool
    interval_from_root: int | None
    harmonic_role: str
    is_chord_tone: bool


@dataclass(frozen=True)
class SourcePatternAnalysis:
    """Human-auditable description of the source accompaniment logic."""

    window_id: str
    start: float
    duration: float
    chord_symbol: str
    root_pitch_class: int
    chord_quality: str
    harmony_confidence: float
    pattern_type: str
    pattern_confidence: float
    legacy_texture: str
    density: str
    bass_motion: str
    bass_sequence: tuple[int, ...]
    functional_role_sequence: tuple[str, ...]
    rhythm_pattern: tuple[float, ...]
    attack_sizes: tuple[int, ...]
    max_simultaneous_notes: int
    voice_count: int
    pitch_min: int | None
    pitch_max: int | None
    notes: tuple[SourceNoteObservation, ...]
    reasons: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()

    # Source metric references survive normal dataclass serialization to debug.
    metric_group_refs: tuple[str, ...] = ()
    metric_group_patterns: tuple[str, ...] = ()
    metric_group_attack_counts: tuple[int, ...] = ()
    repeated_metric_pattern: bool = False
    harmony_note_evidence: tuple[HarmonyNoteEvidence, ...] = ()
