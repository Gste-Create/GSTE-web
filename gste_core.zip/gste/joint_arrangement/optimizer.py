from __future__ import annotations

from gste.control import get_value

from dataclasses import dataclass, replace
from collections import Counter

from gste.core.models import NoteEvent
from gste.core.event_identity import require_event_identity
from gste.arrangement.importance import parse_auto_importance, importance_loss_cost
from gste.core.tuning import STANDARD_TUNING, Tuning
from gste.harmony.piano_analysis import WindowHarmonyAnalysis
from gste.joint_arrangement.generator import realize_supplied_accompaniment_candidates, k_best_melody_paths
from gste.joint_arrangement.hand_shape import (
    evaluate_hand_shape, finger_assignment_candidates, finger_assignment_static_cost,
    active_hand_snapshots as _active_snapshot_notes, evaluate_timed_hand_shape,
)
from gste.joint_arrangement.models import AccompanimentCandidate, JointArrangementResult, JointWindowCandidate, WindowDiagnostic
from gste.joint_arrangement.joint_playability import evaluate_joint_playability, merge_duplicate_accompaniment
from gste.joint_arrangement.simultaneous_span import evaluate_simultaneous_span, validate_canonical_sounding_hand
from gste.fingering.canonical_validator import CanonicalHandNote, validate_canonical_snapshot
from gste.melody.backbone import LockedMelodyBackbone
from gste.arrangement.guitar.density_policy import DENSITY_POLICY

COMFORTABLE_JOINT_SPAN = int(get_value("joint.comfortable_joint_span", 4))
MAXIMUM_JOINT_SPAN = int(get_value("joint.maximum_joint_span", 6))
JOINT_SPAN_PENALTY_PER_FRET = float(get_value("joint.joint_span_penalty_per_fret", 8.0))
POSITION_MOVE_COST_PER_FRET = float(get_value("joint.position_move_cost_per_fret", 5.0))
LARGE_POSITION_MOVE_THRESHOLD = float(get_value("joint.large_position_move_threshold", 3.0))
LARGE_POSITION_MOVE_PENALTY = float(get_value("joint.large_position_move_penalty", 18.0))
RETAINED_NOTE_REWARD = float(get_value("joint.retained_note_reward", 1.5))
SAME_SHAPE_FAMILY_REWARD = float(get_value("joint.same_shape_family_reward", 3.0))
OUTER_GEOMETRY_TRANSITION_WEIGHT = float(get_value("joint.outer_geometry_transition_weight", 0.8))
# Bass identity is intentionally much larger than small local comfort deltas.
# A legal source bass must not lose merely because another chord tone saves 1–2 DP points.
BASS_IDENTITY_RANK_COST = float(get_value("joint.bass_identity_rank_cost", 24.0))
BASS_LINE_PITCH_CLASS_BREAK_COST = float(get_value("joint.bass_line_pitch_class_break_cost", 8.0))
BASS_LINE_UNNECESSARY_JUMP_COST = float(get_value("joint.bass_line_unnecessary_jump_cost", 1.5))
SOURCE_HARMONY_UNLOCK_PENALTY = float(get_value("joint.source_harmony_unlock_penalty", 250.0))
PRUNING_ORDER = tuple(get_value("joint.pruning_order", ["root_doubling", "fill", "fifth", "extension", "root", "characteristic_tone", "source_bass"]))
MELODY_ACCOMPANIMENT_DISTANCE_SOFT = float(get_value("joint.melody_accompaniment_distance_soft", 2.0))
MELODY_ACCOMPANIMENT_DISTANCE_HARD = float(get_value("joint.melody_accompaniment_distance_hard", 4.0))
MELODY_ACCOMPANIMENT_DISTANCE_COST = float(get_value("joint.melody_accompaniment_distance_cost", 10.0))
SHORT_EXCURSION_MIN_DISTANCE = float(get_value("joint.short_excursion_min_distance", 3.5))
SHORT_EXCURSION_RETURN_TOLERANCE = float(get_value("joint.short_excursion_return_tolerance", 2.0))
SHORT_EXCURSION_CLUSTER_TOLERANCE = float(get_value("joint.short_excursion_cluster_tolerance", 3.0))
SHORT_EXCURSION_FIXED_COST = float(get_value("joint.short_excursion_fixed_cost", 28.0))
SHORT_EXCURSION_DISTANCE_COST = float(get_value("joint.short_excursion_distance_cost", 8.0))

# v0.13.5.13.3 musicality-only weights. These are intentionally soft: no
# existing physical rule is relaxed or strengthened by these values.
MELODY_COLLISION_M2_M9_COST = float(get_value("joint.melody_collision_m2_m9_cost", 5.0))
MELODY_REGISTER_PROXIMITY_COST = float(get_value("joint.melody_register_proximity_cost", 2.2))
HIGH_MELODY_SUPPORT_REWARD = float(get_value("joint.high_melody_support_reward", 0.65))
TWO_NOTE_ARPEGGIO_REPETITION_COST = float(get_value("joint.two_note_arpeggio_repetition_cost", 6.0))
ERGONOMIC_SPAN3_SOFT_COST = float(get_value("joint.ergonomic_span3_soft_cost", 0.75))
ERGONOMIC_SPAN4_SOFT_COST = float(get_value("joint.ergonomic_span4_soft_cost", 2.0))
OPTIONAL_WIDE_SPAN3_COST = float(get_value("joint.optional_wide_span3_cost", 1.2))
OPTIONAL_WIDE_SPAN4_COST = float(get_value("joint.optional_wide_span4_cost", 3.5))


@dataclass(frozen=True)
class _ActiveRoleNote:
    role: str
    note: object




def _analysis_with_locked_melody_timing(analysis: WindowHarmonyAnalysis, timing: dict[str, object]) -> WindowHarmonyAnalysis:
    """Replace every window melody reference with the immutable backbone time.

    This is performed once, before candidate generation.  Every downstream
    Joint/Fingering function therefore sees exactly the parser/extractor locked
    attack/release values; no DP/transition helper needs to reconstruct timing.
    """
    locked_notes = []
    for note in analysis.window.melody_notes:
        event_id = str(note.source_event_id or "")
        locked = timing.get(event_id)
        if locked is None:
            raise ValueError(f"JOINT_LOCKED_TIMING_UNKNOWN_MELODY_EVENT:{event_id}")
        if int(note.pitch.midi) != int(locked.midi_pitch):
            raise ValueError(
                f"JOINT_LOCKED_TIMING_PITCH_MISMATCH:{event_id}:"
                f"{note.pitch.midi}!={locked.midi_pitch}"
            )
        locked_notes.append(replace(
            note, start=float(locked.attack), duration=float(locked.release-locked.attack),
        ))
    window = replace(analysis.window, melody_notes=locked_notes)
    return replace(analysis, window=window)

@dataclass(frozen=True)
class _DPCell:
    cost: float
    predecessor: int | None
    active_notes: tuple[_ActiveRoleNote, ...]
    recent_centers: tuple[float, ...]
    editor_loss: float = float('inf')


def _note_identity(role: str, note) -> tuple:
    event_id = require_event_identity(note.note, context=f"JOINT:{role}")
    return (
        role, event_id, note.note.pitch.midi,
        round(note.note.start, 6), round(note.note.duration, 6),
        note.string, note.fret,
    )


def _advance_active_notes(
    previous: tuple[_ActiveRoleNote, ...], current: JointWindowCandidate, tolerance: float = 1e-6,
) -> tuple[_ActiveRoleNote, ...]:
    """Carry every previously committed note that has not released yet.

    v0.13.5.15.7: the DP state is a committed physical schedule, not merely a
    snapshot of notes sounding at the next window onset.  A previous window
    may already own a note whose attack is equal to, or later than, the next
    window onset.  Dropping that note hides cross-window realization and
    future-attack conflicts from Joint while Final still sees them.
    """
    attacks = [float(note.note.start) for note in (*current.melody.notes, *current.accompaniment.notes)]
    onset = min(attacks, default=float(current.start))
    retained = [
        item for item in previous
        if item.note.note.start + item.note.note.duration > onset + tolerance
    ]
    additions = [
        *(_ActiveRoleNote("melody", note) for note in current.melody.notes),
        *(_ActiveRoleNote("accompaniment", note) for note in current.accompaniment.notes),
    ]
    deduplicated: dict[tuple, _ActiveRoleNote] = {}
    for item in (*retained, *additions):
        deduplicated[_note_identity(item.role, item.note)] = item
    return tuple(deduplicated.values())


def _evaluate_active_hand(active: tuple[_ActiveRoleNote, ...]):
    # One sustained structural melody event may be referenced by adjacent
    # windows, but it must keep one physical realization until its locked
    # release. A different string/fret is an illegal transition and is rejected
    # here, never repaired in Final.
    realized: dict[str, tuple[int, int]] = {}
    for item in active:
        if item.role != "melody":
            continue
        event_id = str(item.note.note.source_event_id or "")
        if not event_id:
            continue
        pos = (int(item.note.string), int(item.note.fret))
        previous = realized.get(event_id)
        if previous is not None and previous != pos:
            return False, "LOCKED_MELODY_REALIZATION_CONFLICT"
        realized[event_id] = pos
    melody = tuple(item.note for item in active if item.role == "melody")
    accompaniment = tuple(item.note for item in active if item.role == "accompaniment")
    evaluation = validate_canonical_sounding_hand(
        melody, accompaniment, maximum_fret_distance=int(MELODY_ACCOMPANIMENT_DISTANCE_HARD),
    )
    return evaluation.accepted, evaluation.reason or "CROSS_WINDOW_JOINT_PLAYABILITY"


def _active_signature(active: tuple[_ActiveRoleNote, ...]) -> tuple:
    return tuple(sorted(_note_identity(item.role, item.note) for item in active))


def _evaluate_active_candidate_boundaries(
    active: tuple[_ActiveRoleNote, ...], current: JointWindowCandidate, tolerance: float = 1e-6,
):
    """Fast DP physical gate over real candidate attacks.

    v0.13.5.15.7: DP carries a compressed committed-note schedule.  Do
    not rebuild and rescan a complete canonical timeline for every predecessor
    x candidate pair.  At each current attack, plus any already-committed future attack that
    actually overlaps a current note, filter the small schedule and apply the
    canonical snapshot validator directly.
    Final Review remains the exhaustive all-start/all-end timeline authority.
    """
    # Preserve the immutable realization rule before physical snapshot checks.
    realized: dict[str, tuple[int, int]] = {}
    for item in active:
        if item.role != "melody":
            continue
        event_id = str(item.note.note.source_event_id or "")
        if not event_id:
            continue
        pos = (int(item.note.string), int(item.note.fret))
        previous = realized.get(event_id)
        if previous is not None and previous != pos:
            return False, "LOCKED_MELODY_REALIZATION_CONFLICT"
        realized[event_id] = pos

    current_notes = (*current.melody.notes, *current.accompaniment.notes)
    current_attacks = {round(float(note.note.start), 6) for note in current_notes}
    current_onset = min(current_attacks, default=round(float(current.start), 6))
    # A previous window can already have committed a note that attacks after
    # this window begins. Check that future boundary now only when it actually
    # overlaps a note introduced by the current candidate. Unrelated future
    # boundaries stay in the committed schedule and are checked by a later
    # transition, avoiding the v15.7 prototype's repeated future rescans.
    current_keys = {
        *(_note_identity("melody", note) for note in current.melody.notes),
        *(_note_identity("accompaniment", note) for note in current.accompaniment.notes),
    }
    interacting_future_attacks = {
        round(float(item.note.note.start), 6)
        for item in active
        if _note_identity(item.role, item.note) not in current_keys
        and float(item.note.note.start) >= float(current_onset) - tolerance
        and any(
            float(note.note.start) <= float(item.note.note.start) + tolerance
            and float(note.note.start + note.note.duration) > float(item.note.note.start) + tolerance
            for note in current_notes
        )
    }
    attacks = sorted(current_attacks | interacting_future_attacks)
    if not attacks:
        attacks = [round(float(current.start), 6)]
    for onset in attacks:
        sounding = tuple(item for item in active
            if item.note.note.start <= onset + tolerance
            and item.note.note.start + item.note.note.duration > onset + tolerance)
        canon = tuple(CanonicalHandNote(
            role=item.role, string=int(item.note.string), fret=int(item.note.fret),
            start=float(item.note.note.start), end=float(item.note.note.start + item.note.note.duration),
            pitch=int(item.note.note.pitch.midi), measure=getattr(item.note.note, "measure", None),
            source_id=item.note.note.source_event_id,
        ) for item in sounding)
        issues = validate_canonical_snapshot(
            canon, onset, maximum_fret_distance=int(MELODY_ACCOMPANIMENT_DISTANCE_HARD),
        )
        if issues:
            return False, issues[0].violation_type
    return True, None


def _short_excursion_from_centers(
    recent_centers: tuple[float, ...], current_center: float,
) -> tuple[float, dict[str, float | str]]:
    for intermediate_count in (1, 2, 3):
        needed = intermediate_count + 1
        if len(recent_centers) < needed:
            continue
        anchor = recent_centers[-needed]
        intermediate = recent_centers[-intermediate_count:]
        if abs(current_center - anchor) > SHORT_EXCURSION_RETURN_TOLERANCE:
            continue
        if any(abs(position - anchor) <= SHORT_EXCURSION_MIN_DISTANCE for position in intermediate):
            continue
        if max(intermediate) - min(intermediate) > SHORT_EXCURSION_CLUSTER_TOLERANCE:
            continue
        departure = abs(intermediate[0] - anchor)
        returning = abs(current_center - intermediate[-1])
        cost = SHORT_EXCURSION_FIXED_COST + SHORT_EXCURSION_DISTANCE_COST * (departure + returning)
        return cost, {
            "short_excursion_detected": 1.0,
            "short_excursion_intermediate_windows": float(intermediate_count),
            "short_excursion_anchor_position": anchor,
            "short_excursion_remote_position": sum(intermediate) / len(intermediate),
            "short_excursion_return_position": current_center,
            "short_excursion_cost": cost,
        }
    return 0.0, {"short_excursion_detected": 0.0, "short_excursion_cost": 0.0}


def _median(values: list[int]) -> float:
    ordered = sorted(values)
    if not ordered:
        return 0.0
    midpoint = len(ordered) // 2
    return float(ordered[midpoint]) if len(ordered) % 2 else (ordered[midpoint - 1] + ordered[midpoint]) / 2.0



def _has_sequential_attacks(state: JointWindowCandidate, tolerance: float = 1e-6) -> bool:
    attacks = sorted({round(float(n.note.start), 6) for n in (*state.melody.notes, *state.accompaniment.notes)})
    return len(attacks) > 1


def _state_assignment_candidates(state: JointWindowCandidate):
    """Finger-assignment metadata must not multiply sequential path states.

    For a true single-attack chord we retain all legal assignment variants.
    For a multi-attack window, actual movement is already scored note-to-note in
    the melody path; one representative simultaneous assignment is sufficient
    as window-transition metadata and prevents a combinatorial state explosion.
    """
    rep_melody, rep_accompaniment, hand = _representative_hand_snapshot(state)
    assignments = finger_assignment_candidates(
        (*rep_melody, *rep_accompaniment), hand.base_fret, hand.anchor_shape,
    ) or ((),)
    return assignments[:1] if _has_sequential_attacks(state) else assignments


def _representative_hand_snapshot(state: JointWindowCandidate):
    """Choose one *actual simultaneous* snapshot for hand-assignment metadata.

    The representative snapshot is diagnostic/transition metadata only; every
    snapshot is still validated by the canonical timeline gate.
    """
    snapshots = _active_snapshot_notes(state.melody.notes, state.accompaniment.notes)
    if not snapshots:
        return (), (), evaluate_hand_shape((), ())
    ranked = []
    for onset, melody, accompaniment in snapshots:
        combined = (*melody, *accompaniment)
        hand = evaluate_hand_shape(melody, accompaniment)
        fretted = [n.fret for n in combined if n.fret > 0]
        span = 0 if not fretted else max(fretted) - min(fretted)
        ranked.append((len(fretted), span, -onset, melody, accompaniment, hand))
    _, _, _, melody, accompaniment, hand = max(ranked, key=lambda row: row[:3])
    return melody, accompaniment, hand


def _timed_hand_shape_is_legal(state: JointWindowCandidate):
    return evaluate_timed_hand_shape(state.melody.notes, state.accompaniment.notes)


def _fretted_values(state: JointWindowCandidate) -> list[int]:
    return [n.fret for n in (*state.melody.notes, *state.accompaniment.notes) if n.fret > 0]


def _joint_span(state: JointWindowCandidate) -> int:
    # v0.13.5.12.10.1: span is a simultaneous property, not the range visited
    # by sequential notes across an entire arrangement window.
    return int(evaluate_simultaneous_span((*state.melody.notes, *state.accompaniment.notes)).fret_span)


def _joint_position(state: JointWindowCandidate) -> float:
    frets = sorted(_fretted_values(state))
    if not frets:
        return 0.0
    middle = len(frets) // 2
    return float(frets[middle]) if len(frets) % 2 else (frets[middle - 1] + frets[middle]) / 2.0


def _hand_center(state: JointWindowCandidate) -> float:
    """Combined left-hand centre; open strings intentionally do not move it."""
    return _joint_position(state)


def _cross_window_span(
    previous: JointWindowCandidate, current: JointWindowCandidate,
):
    """Evaluate notes sustained from ``previous`` together with ``current``.

    v0.12.6 validated every window independently.  This transition-level gate
    supplies the previous notes that are still sounding at the next window so
    the same documented 4/3/2-fret rule also covers a window boundary.
    """
    onset = current.start
    sustained = tuple(
        note for note in (*previous.melody.notes, *previous.accompaniment.notes)
        if note.note.start < onset and note.note.start + note.note.duration > onset + 1e-6
    )
    if not sustained:
        return evaluate_simultaneous_span(())
    return evaluate_simultaneous_span(
        (*sustained, *current.melody.notes, *current.accompaniment.notes)
    )


def _cross_path_span(
    previous_states: tuple[JointWindowCandidate, ...], current: JointWindowCandidate,
):
    """Include every earlier note that still sounds, even across 2+ windows."""
    onset = current.start
    sustained = []
    seen: set[tuple] = set()
    for state in previous_states:
        for note in (*state.melody.notes, *state.accompaniment.notes):
            key = (
                note.note.source_event_id, note.note.pitch.midi,
                round(note.note.start, 6), round(note.note.duration, 6),
                note.string, note.fret,
            )
            if key in seen:
                continue
            if note.note.start < onset and note.note.start + note.note.duration > onset + 1e-6:
                sustained.append(note)
                seen.add(key)
    return evaluate_simultaneous_span(
        (*sustained, *current.melody.notes, *current.accompaniment.notes)
    )


def _cross_path_playability(
    previous_states: tuple[JointWindowCandidate, ...], current: JointWindowCandidate,
):
    """Validate cross-window sounding states at the candidate's real attacks.

    v0.13.5.15.6.9: ``JointWindowCandidate.start`` is an analysis-window
    boundary, not an authority for note time.  A candidate may contain a note
    whose canonical attack precedes that boundary.  Validate every distinct
    attack carried by the candidate against earlier notes that are physically
    sounding at that attack.
    """
    current_notes = (("melody", current.melody.notes), ("accompaniment", current.accompaniment.notes))
    attacks = sorted({round(float(note.note.start), 6) for _, notes in current_notes for note in notes})
    if not attacks:
        return validate_canonical_sounding_hand(
            current.melody.notes, current.accompaniment.notes,
            maximum_fret_distance=int(MELODY_ACCOMPANIMENT_DISTANCE_HARD),
        ).playability

    previous: list[tuple[str, object]] = []
    seen: set[tuple] = set()
    for state in previous_states:
        for role, notes in (("melody", state.melody.notes), ("accompaniment", state.accompaniment.notes)):
            for note in notes:
                key = (role, note.note.source_event_id, note.note.pitch.midi, round(note.note.start, 6),
                       round(note.note.duration, 6), note.string, note.fret)
                if key not in seen:
                    previous.append((role, note))
                    seen.add(key)

    for onset in attacks:
        sustained_melody = tuple(note for role, note in previous
            if role == "melody" and note.note.start < onset - 1e-6
            and note.note.start + note.note.duration > onset + 1e-6)
        sustained_accompaniment = tuple(note for role, note in previous
            if role == "accompaniment" and note.note.start < onset - 1e-6
            and note.note.start + note.note.duration > onset + 1e-6)
        active_melody = tuple(note for note in current.melody.notes
            if note.note.start <= onset + 1e-6 and note.note.start + note.note.duration > onset + 1e-6)
        active_accompaniment = tuple(note for note in current.accompaniment.notes
            if note.note.start <= onset + 1e-6 and note.note.start + note.note.duration > onset + 1e-6)
        result = validate_canonical_sounding_hand(
            active_melody, active_accompaniment, sustained_melody, sustained_accompaniment,
            maximum_fret_distance=int(MELODY_ACCOMPANIMENT_DISTANCE_HARD),
        ).playability
        if not result.accepted:
            return result
    return validate_canonical_sounding_hand(
        current.melody.notes, current.accompaniment.notes,
        maximum_fret_distance=int(MELODY_ACCOMPANIMENT_DISTANCE_HARD),
    ).playability


def _short_position_excursion(
    recent: tuple[JointWindowCandidate, ...], current: JointWindowCandidate,
) -> tuple[float, dict[str, float | str]]:
    """Price an A-B-A or A-B-B-A excursion lasting only one/two windows."""
    for intermediate_count in (1, 2, 3):
        needed = intermediate_count + 1
        if len(recent) < needed:
            continue
        anchor = recent[-needed]
        intermediate = (*recent[-intermediate_count:],)
        anchor_position = _hand_center(anchor)
        current_position = _hand_center(current)
        intermediate_positions = tuple(_hand_center(state) for state in intermediate)
        if abs(current_position - anchor_position) > SHORT_EXCURSION_RETURN_TOLERANCE:
            continue
        if any(abs(position - anchor_position) <= SHORT_EXCURSION_MIN_DISTANCE for position in intermediate_positions):
            continue
        if max(intermediate_positions) - min(intermediate_positions) > SHORT_EXCURSION_CLUSTER_TOLERANCE:
            continue
        departure = abs(intermediate_positions[0] - anchor_position)
        returning = abs(current_position - intermediate_positions[-1])
        cost = SHORT_EXCURSION_FIXED_COST + SHORT_EXCURSION_DISTANCE_COST * (departure + returning)
        return cost, {
            "short_excursion_detected": 1.0,
            "short_excursion_intermediate_windows": float(intermediate_count),
            "short_excursion_anchor_position": anchor_position,
            "short_excursion_remote_position": sum(intermediate_positions) / len(intermediate_positions),
            "short_excursion_return_position": current_position,
            "short_excursion_cost": cost,
        }
    return 0.0, {"short_excursion_detected": 0.0, "short_excursion_cost": 0.0}


def _overlap(a, b, tolerance: float = 1e-6) -> bool:
    a0=float(a.note.start); a1=a0+float(a.note.duration)
    b0=float(b.note.start); b1=b0+float(b.note.duration)
    return a0 < b1-tolerance and b0 < a1-tolerance


def _melody_register_collision_cost(state: JointWindowCandidate) -> tuple[float, dict[str, float]]:
    """Softly protect melody clarity without banning register overlap.

    Close m2/m9/M7-family pitch-class collisions and accompaniment that sits on
    top of the melody receive a cost. High melody instead rewards legal support
    several semitones below, addressing sparse accompaniment in the upper
    register. Timing comes from the already locked Joint notes.
    """
    penalty=0.0; high_support=0; close_pairs=0; dissonant_pairs=0
    melody=tuple(state.melody.notes); accompaniment=tuple(state.accompaniment.notes)
    for a in accompaniment:
        for m in melody:
            if not _overlap(a,m):
                continue
            delta=int(a.note.pitch.midi)-int(m.note.pitch.midi)
            distance=abs(delta); pc=min(distance%12, (12-distance%12)%12)
            if pc == 1:
                penalty += MELODY_COLLISION_M2_M9_COST
                dissonant_pairs += 1
            elif pc == 0 and distance <= 12:
                penalty += 0.8
            if distance <= 3:
                penalty += MELODY_REGISTER_PROXIMITY_COST
                close_pairs += 1
            elif distance <= 5:
                penalty += 0.8
            if delta >= 0:
                penalty += 1.6 + 0.18*min(12,delta)
            if int(m.note.pitch.midi) >= 70 and delta <= -7:
                high_support += 1
    reward = HIGH_MELODY_SUPPORT_REWARD * min(4, high_support)
    return penalty-reward, {
        'melody_register_collision_pairs': float(close_pairs),
        'melody_dissonant_collision_pairs': float(dissonant_pairs),
        'high_melody_support_pairs': float(high_support),
        'high_melody_support_reward': float(-reward),
    }


def _arpeggio_motion_cost(state: JointWindowCandidate) -> tuple[float, dict[str, float]]:
    """Penalize mechanical two-pitch broken-chord loops, never hard reject."""
    notes=sorted(state.accompaniment.notes, key=lambda n:(n.note.start,n.note.pitch.midi))
    harmonic=[n for n in notes if n.note.arrangement_role not in {'bass','root'}]
    if len(harmonic) < 4:
        harmonic=notes
    roles=set(state.accompaniment.tone_roles or ())
    harmonic_role = bool(roles & {'third','fifth','guide_tone','characteristic_tone','fill','chord_tone'})
    if len(harmonic) < 4 or (roles and not harmonic_role):
        return 0.0, {'arpeggio_pitch_class_diversity': float(len({n.note.pitch.midi%12 for n in harmonic}))}
    pcs=[n.note.pitch.midi%12 for n in harmonic]
    diversity=len(set(pcs))
    cost=0.0
    if diversity <= 2:
        cost += TWO_NOTE_ARPEGGIO_REPETITION_COST + 1.0*max(0,len(pcs)-4)
    if len(pcs) >= 4 and pcs[0] == pcs[2] and pcs[1] == pcs[3] and pcs[0] != pcs[1]:
        cost += 3.0
    if diversity >= 3 and all(a != b for a,b in zip(pcs,pcs[1:])):
        cost -= 1.0
    return cost, {'arpeggio_pitch_class_diversity': float(diversity), 'arpeggio_repetition_cost': float(cost)}


def _ergonomic_span_soft_cost(fret_span: int) -> float:
    """Light preference against legal wide shapes; hard limits are unchanged."""
    if fret_span >= 4:
        return ERGONOMIC_SPAN4_SOFT_COST
    if fret_span == 3:
        return ERGONOMIC_SPAN3_SOFT_COST
    return 0.0


def _optional_accompaniment_wide_shape_cost(state: JointWindowCandidate, fret_span: int) -> tuple[float, int]:
    """Prefer dropping/revoicing optional inner voices before accepting a wide legal shape.

    This never changes the hard span limit. It only distinguishes a wide shape
    required by important bass/guide tones from one created by disposable inner
    accompaniment.
    """
    if fret_span < 3:
        return 0.0, 0
    optional_roles = {'fill', 'root_doubling', 'fifth', 'extension', 'optional_extension'}
    count = sum(1 for role in (state.accompaniment.tone_roles or ()) if role in optional_roles)
    if count <= 0:
        return 0.0, 0
    unit = OPTIONAL_WIDE_SPAN4_COST if fret_span >= 4 else OPTIONAL_WIDE_SPAN3_COST
    return unit * min(2, count), count


def _local_cost(state: JointWindowCandidate) -> tuple[float, dict[str, float | str]]:
    span = _joint_span(state)
    canonical = validate_canonical_sounding_hand(
        state.melody.notes, state.accompaniment.notes,
        maximum_fret_distance=int(MELODY_ACCOMPANIMENT_DISTANCE_HARD),
    )
    simultaneous_span = canonical.span
    playability = canonical.playability
    if not canonical.accepted:
        return float("inf"), {
            "melody": state.melody.local_cost,
            "harmony_reward": -1.35 * state.harmony.total_score,
            "accompaniment": 0.85 * state.accompaniment.local_cost,
            "joint_fret_span": float(span),
            "simultaneous_fret_span": float(simultaneous_span.fret_span),
            "simultaneous_allowed_span": float(simultaneous_span.maximum_allowed_span),
            "simultaneous_highest_fret_string": float(simultaneous_span.highest_fret_string or -1),
            "simultaneous_span_position": simultaneous_span.position,
            "simultaneous_span_onset": float(simultaneous_span.onset or state.start),
            "joint_span_penalty": float("inf"),
            "rejection_reason": canonical.reason or "CANONICAL_SOUNDING_HAND",
            "playability_onset": float(playability.onset or state.start),
            "conflict_string": float(playability.string or -1),
            "melody_fret": float(playability.melody_fret if playability.melody_fret is not None else -1),
            "accompaniment_fret": float(playability.accompaniment_fret if playability.accompaniment_fret is not None else -1),
            "melody_accompaniment_fret_distance": float(playability.fret_distance),
        }
    # v0.13.5.12.10.1: evaluate ergonomic hand-shape rules per real sounding
    # snapshot. Sequential melody notes in the same search window are movement,
    # not a simultaneous chord. Canonical timeline rules above remain unchanged.
    hand_ok, hand, hand_onset, hand_reason, barre_span = _timed_hand_shape_is_legal(state)
    if not hand_ok:
        return float("inf"), {
            "melody": state.melody.local_cost,
            "harmony_reward": -1.35 * state.harmony.total_score,
            "accompaniment": 0.85 * state.accompaniment.local_cost,
            "joint_fret_span": float(span),
            "joint_span_penalty": float("inf"),
            "shape_family": hand.shape_family,
            "rejection_reason": hand_reason or "CANONICAL_SNAPSHOT_HAND",
            "playability_onset": float(hand_onset if hand_onset is not None else state.start),
            "barre_fret": float(hand.barre_fret if hand.barre_fret is not None else -1),
            "barre_span": float(barre_span),
        }
    melody_component = state.melody.local_cost
    harmony_component = -1.35 * state.harmony.total_score
    accompaniment_component = 0.85 * state.accompaniment.local_cost
    span_penalty = JOINT_SPAN_PENALTY_PER_FRET * max(span - COMFORTABLE_JOINT_SPAN, 0)
    melody_frets = [n.fret for n in state.melody.notes if n.fret > 0]
    accompaniment_frets = [n.fret for n in state.accompaniment.notes if n.fret > 0]
    melody_center = _median(melody_frets)
    accompaniment_center = _median(accompaniment_frets)
    center_distance = abs(melody_center - accompaniment_center) if accompaniment_frets else 0.0
    # One accompaniment finger can support a brief melody extension; dense
    # accompaniment cannot.  Open strings contribute neither centre nor span.
    density = len(accompaniment_frets)
    centre_penalty = MELODY_ACCOMPANIMENT_DISTANCE_COST * max(center_distance - MELODY_ACCOMPANIMENT_DISTANCE_SOFT, 0)
    if density >= 2 and center_distance > 3:
        centre_penalty += 12.0 * (center_distance - 3)
    if density >= 3 and span > 4:
        centre_penalty += 25.0
    # Do not hard-reject the median path centres: they describe motion across
    # the window, not a simultaneous hand. The canonical timeline gate above
    # already enforces the unchanged <=4 melody/accompaniment distance at every
    # real overlap. Keep centre distance as a soft movement/comfort cost only.
    bass_identity_cost = BASS_IDENTITY_RANK_COST * state.bass_identity_rank
    # v0.13.1: pruning is now explicitly more expensive than a legal
    # revoicing. The arrangement layer already generated a musical texture;
    # the fingering layer should preserve its event count/function whenever a
    # nearby equivalent voicing exists.
    pruning_cost = 1.8 * len(state.accompaniment.pruned_roles)
    revoice_types = {
        "B_TIMED_TEXTURE_REVOICING", "C_REVOICING", "D_FUNCTIONAL_REVOICING",
        "E_NEAR_POSITION_VOICING", "F_HIGH_REGISTER_OCTAVE_REVOICE",
        "G_HIGH_REGISTER_INVERSION",
    }
    accompaniment_ids = [str(n.note.source_event_id or "") for n in state.accompaniment.notes]
    accompaniment_variants = [str(getattr(n.note, "source_variant", "") or "") for n in state.accompaniment.notes]
    revoicable_texture = any(n.note.allow_revoice for n in state.accompaniment.notes)
    # Upstream loss is a source-neutral cost, so a pre-thinned candidate
    # cannot beat an equally feasible full pulse solely by being cheaper.
    attack_loss = max((n.note.attack_loss for n in state.accompaniment.notes), default=0)
    pruning_cost += 8.0 * attack_loss
    if revoicable_texture:
        pruning_cost = 6.5 * len(state.accompaniment.pruned_roles) + 8.0 * attack_loss

    # v0.13.5.11: the early simple melody accompaniment is a guaranteed
    # safety candidate, not a preferred texture. It may win when richer modern
    # candidates become illegal/very costly, but it should not flatten normal
    # successful passages merely because one root note is cheap to finger.
    legacy_safe_fallback_cost = 55.0 if any("LEGACY_SAFE" in variant for variant in accompaniment_variants) else 0.0

    # Arrangement importance is carried through source_event_id markers. Each
    # local pruning variant records the importance values that it discarded.
    # This cost is AUTO_MELODY-only by construction because Piano IDs have no
    # AUTOIMP marker. Hard playability still returns infinity before this cost.
    auto_importance_loss_cost = 0.0
    for modification in state.accompaniment.modifications:
        if str(modification).startswith("AUTOIMP_LOSS_"):
            try:
                auto_importance_loss_cost += importance_loss_cost(int(str(modification).rsplit("_",1)[-1]))
            except ValueError:
                pass

    # v0.1.8: a physically legal full Melody Shape must beat an otherwise
    # similar path that discards melody-like Piano source information.  The
    # penalty is importance-scaled and only applies after accompaniment-first
    # pruning has been exhausted.
    melody_priority_loss_cost = 0.0
    for modification in state.accompaniment.modifications:
        if str(modification).startswith("PIANOPRIORITY_LOSS_"):
            try:
                melody_priority_loss_cost += 6.0 * importance_loss_cost(int(str(modification).rsplit("_",1)[-1]))
            except ValueError:
                pass

    # v0.13.5.10 Musical Information Loss Cost.
    # Playability remains a hard prerequisite, but among legal reductions we
    # prefer removing disposable color/fill before structural musical content.
    role_loss_weight = dict(DENSITY_POLICY.information_loss_weights)
    # Keep Melody-only Auto Arrangement regression-stable: this new loss
    # model is intentionally scoped to source-mapped (Piano/ensemble-source)
    # accompaniment only. Auto-generated melody-only accompaniment retains its
    # existing v0.13.5.2-era Joint cost behavior.
    information_loss_cost = 0.0
    if revoicable_texture:
        information_loss_cost = sum(
            role_loss_weight.get(role, 2.0) for role in state.accompaniment.pruned_roles
        )
        # Source/structural bass omission receives an additional strong penalty,
        # while octave-equivalent bass remains substantially cheaper.
        if state.source_bass_pitch is not None:
            if state.output_bass_pitch is None:
                information_loss_cost += 12.0
            elif state.output_bass_pitch % 12 != state.source_bass_pitch % 12:
                information_loss_cost += 8.0
            elif state.output_bass_pitch != state.source_bass_pitch:
                information_loss_cost += 2.0
    if revoicable_texture and state.accompaniment.candidate_type in revoice_types and not state.accompaniment.pruned_roles:
        if state.accompaniment.candidate_type in {"F_HIGH_REGISTER_OCTAVE_REVOICE", "G_HIGH_REGISTER_INVERSION"}:
            revoicing_reward = -6.0
        elif state.accompaniment.candidate_type == "E_NEAR_POSITION_VOICING":
            revoicing_reward = -4.5
        else:
            revoicing_reward = -3.0
    else:
        revoicing_reward = 0.0
    texture_retention_reward = -0.8 * min(3, len(state.accompaniment.notes)) if revoicable_texture and state.accompaniment.notes else 0.0
    # v0.13.1: melody-only safety topology is a true last resort.  It is
    # always present so cross-window hard conflicts can be escaped, but it must
    # not beat a legal accompaniment-preserving/revoiced candidate merely on
    # local ergonomic cost.
    melody_only_fallback_cost = 120.0 if state.accompaniment.candidate_type == "K_MELODY_ONLY_HARD_CONFLICT" else 0.0
    guitar_variant_reward = -7.0 if state.accompaniment.candidate_type == "L_GUITAR_NATIVE_BASS_GUIDE" else (-3.5 if state.accompaniment.candidate_type == "L_GUITAR_NATIVE_BASS_ONLY" else 0.0)
    assignment = state.finger_assignment or hand.finger_mapping
    assignment_cost = finger_assignment_static_cost(assignment, hand.anchor_shape)
    hand_center = _hand_center(state)
    # v0.13.5.13.3: musicality terms are ranking-only. They never turn a legal
    # candidate illegal and never rescue a candidate rejected by canonical
    # hand rules above.
    collision_cost, collision_diag = _melody_register_collision_cost(state)
    arpeggio_motion_cost, arpeggio_diag = _arpeggio_motion_cost(state)
    ergonomic_span_cost = _ergonomic_span_soft_cost(int(simultaneous_span.fret_span))
    optional_wide_cost, optional_wide_count = _optional_accompaniment_wide_shape_cost(
        state, int(simultaneous_span.fret_span)
    )
    # V0.13.5.11: AUTO_MELODY importance is diagnostic lineage here, not a
    # normal Joint ranking term. It becomes decisive only when a selected
    # arrangement must be degraded during Fingering/Final realization.
    total = melody_component + harmony_component + accompaniment_component + span_penalty + centre_penalty + hand.total_static_cost + assignment_cost + bass_identity_cost + pruning_cost + information_loss_cost + melody_priority_loss_cost + revoicing_reward + texture_retention_reward + guitar_variant_reward + melody_only_fallback_cost + legacy_safe_fallback_cost + collision_cost + arpeggio_motion_cost + ergonomic_span_cost + optional_wide_cost
    return total, {
        "melody": melody_component,
        "harmony_reward": harmony_component,
        "accompaniment": accompaniment_component,
        "joint_fret_span": float(span),
        "joint_span_penalty": span_penalty,
        "shape_family": hand.shape_family,
        "recognized_common_shape": 1.0 if hand.recognized_common_shape else 0.0,
        "base_fret": float(hand.base_fret),
        "estimated_finger_count": float(hand.estimated_finger_count),
        "low_bass_risk": hand.low_bass_risk,
        "mini_barre_risk": hand.mini_barre_risk,
        "unknown_shape_risk": hand.unknown_shape_risk,
        "outer_string_distance": float(hand.outer_string_distance),
        "outer_string_stretch_cost": hand.outer_string_stretch_cost,
        "melody_reach": float(hand.melody_reach),
        "melody_reach_cost": hand.melody_reach_cost,
        "shape_family_adjustment": hand.family_adjustment,
        "common_shape_reward": min(hand.family_adjustment, 0.0),
        "static_hand_cost": hand.total_static_cost,
        "finger_assignment_static_cost": assignment_cost,
        "reverse_fret_drop": float(hand.reverse_fret_drop),
        "reverse_fret_drop_cost": hand.reverse_fret_drop_cost,
        "legal_shape_exception": 1.0 if hand.legal_shape_exception else 0.0,
        "anchor_shape": hand.anchor_shape,
        "barre_fret": float(hand.barre_fret) if hand.barre_fret is not None else -1.0,
        "finger_mapping": "; ".join(f"s{s}/f{f}=F{finger}" for s, f, finger in assignment) or "none",
        "hand_center": hand_center,
        "bass_identity_rank": float(state.bass_identity_rank),
        "bass_identity_cost": bass_identity_cost,
        "musical_information_loss_cost": information_loss_cost,
        "auto_importance_loss_cost": auto_importance_loss_cost,
        "melody_priority_loss_cost": melody_priority_loss_cost,
        "legacy_safe_fallback_cost": legacy_safe_fallback_cost,
        "bass_role": state.bass_role,
        "source_bass_pitch": float(state.source_bass_pitch) if state.source_bass_pitch is not None else -1.0,
        "output_bass_pitch": float(state.output_bass_pitch) if state.output_bass_pitch is not None else -1.0,
        "bass_substitution_reason": state.bass_substitution_reason,
        "source_harmony_locked": 1.0 if state.source_harmony_locked else 0.0,
        "pruned_roles": ", ".join(state.accompaniment.pruned_roles) or "none",
        "pruning_cost": pruning_cost,
        "revoicing_reward": revoicing_reward,
        "guitar_variant_reward": guitar_variant_reward,
        "texture_retention_reward": texture_retention_reward,
        "melody_only_fallback_cost": melody_only_fallback_cost,
        "melody_center": melody_center,
        "accompaniment_center": accompaniment_center,
        "melody_to_accompaniment_center_distance": center_distance,
        "melody_register_collision_cost": collision_cost,
        **collision_diag,
        "arpeggio_motion_cost": arpeggio_motion_cost,
        **arpeggio_diag,
        "ergonomic_wide_shape_soft_cost": ergonomic_span_cost,
        "optional_accompaniment_wide_shape_cost": optional_wide_cost,
        "optional_accompaniment_wide_shape_notes": float(optional_wide_count),
        "accompaniment_non_open_count": float(density),
        "accompaniment_candidate_type": state.accompaniment.candidate_type,
        "harmony_coverage": ", ".join(str(pc) for pc in state.accompaniment.harmony_coverage),
        "omitted_pitch_classes": ", ".join(str(pc) for pc in state.accompaniment.omitted_pitch_classes),
        "accompaniment_center_penalty": centre_penalty,
    }


def _local_pruning_variants(accompaniment: AccompanimentCandidate) -> list[AccompanimentCandidate]:
    """Guitar-native retention ladder before generic note-by-note pruning.

    v0.13.5.10 treats melody-only as the last resort. A generated guitar texture
    first falls through musically meaningful variants: full -> bass+guide ->
    structural/root bass -> generic one-note reductions. This preserves the
    arrangement *function* rather than merely deleting arbitrary Piano tones.
    """
    variants = [accompaniment]
    notes = list(accompaniment.notes)
    roles = list(accompaniment.tone_roles) or ["fill"] * len(notes)

    def append_variant(name: str, indices: list[int], candidate_type: str, reason: str) -> None:
        indices=sorted(set(i for i in indices if 0 <= i < len(notes)))
        if not indices or len(indices) >= len(notes):
            return
        kept=tuple(notes[i] for i in indices)
        kept_roles=tuple(roles[i] for i in indices)
        output_bass=min((n.note.pitch.midi for n in kept), default=None)
        if accompaniment.source_bass_pitch is None:
            identity_rank, identity_reason=6,"bass_omitted"
        elif output_bass == accompaniment.source_bass_pitch:
            identity_rank, identity_reason=0,"B0_exact_source_bass"
        elif output_bass is not None and output_bass % 12 == accompaniment.source_bass_pitch % 12:
            identity_rank, identity_reason=1,"B1_octave_equivalent_source_bass"
        elif output_bass is not None:
            identity_rank, identity_reason=5,"B5_functional_bass_variant"
        else:
            identity_rank, identity_reason=6,"B6_bass_omitted"
        removed_indices=[i for i in range(len(notes)) if i not in indices]
        removed_roles=tuple(roles[i] for i in removed_indices)
        removed_pcs={notes[i].note.pitch.midi % 12 for i in removed_indices}
        removed_importance_markers=tuple(
            f"AUTOIMP_LOSS_{value:03d}"
            for i in removed_indices
            for value in [notes[i].note.importance]
            if value is not None
        )
        variants.append(replace(
            accompaniment,
            name=f"{accompaniment.name}+{name}", notes=kept,
            output_bass_pitch=output_bass, bass_identity_rank=identity_rank,
            bass_substitution_reason=identity_reason,
            tone_roles=kept_roles, pruned_roles=(*accompaniment.pruned_roles,*removed_roles),
            pruning_reasons=(*accompaniment.pruning_reasons,reason),
            candidate_type=candidate_type,
            modifications=(*accompaniment.modifications,reason.upper(),*removed_importance_markers),
            omitted_pitch_classes=tuple(sorted(set(accompaniment.omitted_pitch_classes)|removed_pcs)),
            harmony_coverage=tuple(sorted({n.note.pitch.midi%12 for n in kept})),
        ))

    # Identify the most important bass and functional upper voice.
    bass_roles={"source_bass","bass","root","root_doubling"}
    guide_roles={"third","seventh","characteristic_tone","guide_tone"}
    bass_idx=next((i for i,r in enumerate(roles) if r=="source_bass"),None)
    if bass_idx is None:
        bass_idx=next((i for i,r in enumerate(roles) if r in bass_roles),None)
    if bass_idx is None and notes:
        bass_idx=min(range(len(notes)), key=lambda i: notes[i].note.pitch.midi)
    guide_idx=next((i for i,r in enumerate(roles) if r in guide_roles and i != bass_idx),None)
    if guide_idx is None:
        guide_idx=next((i for i,r in enumerate(roles) if i != bass_idx and r not in {"fill","root_doubling"}),None)

    source_ids=[str(n.note.source_event_id or "") for n in notes]
    source_variants=[str(getattr(n.note, "source_variant", "") or "") for n in notes]
    guitar_native=any(n.note.candidate_id is not None for n in notes)
    source_rhythm = any(n.note.preserve_rhythm for n in notes)
    if source_rhythm and len(notes) >= 2:
        # Thin vertical voicing first: keep every attack before deleting pulses.
        by_attack = {}
        for i,n in enumerate(notes):
            by_attack.setdefault(round(n.note.start, 6), []).append(i)
        indices = [max(group, key=lambda i: (roles[i] in guide_roles or roles[i] in bass_roles, notes[i].note.importance or 0)) for group in by_attack.values()]
        append_variant("rhythm-shell", indices, "L_SOURCE_RHYTHM_SHELL", "SOURCE_RHYTHM_VERTICAL_COMPRESSION")
    if guitar_native and len(notes) >= 2:
        if bass_idx is not None and guide_idx is not None:
            append_variant("guitar-bass-guide",[bass_idx,guide_idx],"L_GUITAR_NATIVE_BASS_GUIDE","GUITAR_VARIANT_BASS_GUIDE")
        if bass_idx is not None:
            append_variant("guitar-bass-only",[bass_idx],"L_GUITAR_NATIVE_BASS_ONLY","GUITAR_VARIANT_BASS_ONLY")

    # Generic incremental pruning remains available after musical variants.
    # AUTO_MELODY removes the least-important generated event first. Other
    # routes keep the historical role ladder byte-for-byte in behavior.
    active=list(range(len(notes)))
    auto_values=[note.note.importance for note in notes]
    # V0.13.5.11: importance must not steer normal Joint arbitration. Keep
    # the historical role ladder used by V0.13.5.10.2; AUTOIMP is still
    # attached to every removed event for downstream Final/Fingering audit.
    # v0.1.8 Melody-Shape-First reduction ladder.  Piano RH priority events
    # define the melody shape and are never removed while a lower-priority
    # bass/chord/texture event can yield instead.  This is not a hard keep:
    # after ordinary accompaniment has been exhausted, priority events may be
    # reduced in ascending importance order if physical feasibility requires it.
    priority_indices={i for i,n in enumerate(notes)
        if str(n.note.arrangement_role or "").startswith("melody_priority_")}
    pruning_groups=[(role,[idx for idx in range(len(notes)) if roles[idx] == role and idx not in priority_indices]) for role in PRUNING_ORDER]
    # Canonical Arrangement uses bass/guide_tone/chord_tone, while the old
    # Joint ladder used source_bass/characteristic_tone/fifth. Cover the actual
    # canonical roles too, otherwise incremental degradation silently vanishes.
    missing = [i for i,r in enumerate(roles) if r not in PRUNING_ORDER and i not in priority_indices]
    missing.sort(key=lambda i: (roles[i] in {"bass","source_bass"}, notes[i].note.importance or 50, i))
    pruning_groups.extend((roles[i],[i]) for i in missing)
    if priority_indices:
        pruning_groups.append(("melody_priority", sorted(priority_indices, key=lambda i: int(getattr(notes[i].note, "importance", 50) or 50))))
    for role, candidates in pruning_groups:
        for idx in candidates:
            if idx not in active:
                continue
            active.remove(idx)
            kept=tuple(notes[i] for i in active)
            kept_roles=tuple(roles[i] for i in active)
            if not kept:
                continue
            # Harmonic minimum-information gate: never keep a lone disposable
            # fifth/fill after bass/root/guide identity has disappeared.
            meaningful={"source_bass","bass","root","third","seventh","characteristic_tone","guide_tone"}
            if len(kept_roles)==1 and kept_roles[0] not in meaningful:
                continue
            removed=(*accompaniment.pruned_roles, *(roles[i] for i in range(len(notes)) if i not in active))
            output_bass=min(note.note.pitch.midi for note in kept)
            if accompaniment.source_bass_pitch is None:
                identity_rank, identity_reason = 6, "bass_omitted"
            elif output_bass == accompaniment.source_bass_pitch:
                identity_rank, identity_reason = 0, "B0_exact_source_bass"
            elif output_bass % 12 == accompaniment.source_bass_pitch % 12:
                identity_rank, identity_reason = 1, "B1_octave_equivalent_source_bass"
            else:
                identity_rank, identity_reason = 6, "B6_source_bass_removed_for_hard_conflict"
            variants.append(replace(
                accompaniment,
                name=f"{accompaniment.name}+prune-{roles[idx]}", notes=kept,
                omitted_required_tones=max(accompaniment.omitted_required_tones, len(set(roles) - set(kept_roles))),
                output_bass_pitch=output_bass, bass_identity_rank=identity_rank,
                bass_substitution_reason=identity_reason, tone_roles=kept_roles,
                pruned_roles=removed, pruning_reasons=(*accompaniment.pruning_reasons, "hand_shape_conflict"),
                candidate_type="F_REMOVE_DUPLICATE_OR_TONE",
                modifications=(
                    *accompaniment.modifications, f"OMITTED_{roles[idx].upper()}",
                    *(f"{'PIANOPRIORITY' if i in priority_indices else 'AUTOIMP'}_LOSS_{auto_values[i]:03d}" for i in range(len(notes)) if i not in active and auto_values[i] is not None),
                ),
                omitted_pitch_classes=tuple(sorted(set(accompaniment.omitted_pitch_classes) | {notes[i].note.pitch.midi % 12 for i in range(len(notes)) if i not in active})),
                harmony_coverage=tuple(sorted({n.note.pitch.midi % 12 for n in kept})),
            ))
    # Prefer musically labelled variants before generic reductions.
    priority={"L_SOURCE_RHYTHM_SHELL":0,"F_REMOVE_DUPLICATE_OR_TONE":1,"L_GUITAR_NATIVE_BASS_GUIDE":2,"L_GUITAR_NATIVE_BASS_ONLY":3}
    head=variants[:1]
    tail=sorted(variants[1:], key=lambda v:(len(notes)-len(v.notes), priority.get(v.candidate_type,4), v.local_cost))
    return [*head,*tail]


def _locked_harmonies(analysis: WindowHarmonyAnalysis) -> list:
    if not analysis.candidates:
        return []
    source_pcs = {note.pitch.midi % 12 for note in analysis.window.accompaniment_notes}
    first = analysis.candidates[0]
    confident = (
        len(source_pcs & first.family.required_pitch_classes) >= min(2, len(first.family.required_pitch_classes))
    )
    return [first] if confident else list(analysis.candidates)


def _shape_family(state: JointWindowCandidate) -> str:
    return str(state.cost_breakdown.get("shape_family", "UNKNOWN"))


def _transition(previous: JointWindowCandidate, current: JointWindowCandidate, *, validate_physical: bool = True) -> tuple[float, dict[str, float | str]]:
    cross_window_span = _cross_window_span(previous, current) if validate_physical else None
    if cross_window_span is not None and not cross_window_span.accepted:
        return float("inf"), {
            "rejection_reason": "CROSS_WINDOW_SUSTAINED_FRET_SPAN_LIMIT",
            "cross_window_fret_span": float(cross_window_span.fret_span),
            "cross_window_allowed_span": float(cross_window_span.maximum_allowed_span),
            "cross_window_highest_fret_string": float(cross_window_span.highest_fret_string or -1),
            "cross_window_span_position": cross_window_span.position,
            "cross_window_span_onset": float(cross_window_span.onset or current.start),
        }
    previous_position = _hand_center(previous)
    current_position = _hand_center(current)
    distance = abs(previous_position - current_position)
    position_move = POSITION_MOVE_COST_PER_FRET * distance
    large_move_penalty = (LARGE_POSITION_MOVE_PENALTY + 8.0 * (distance - LARGE_POSITION_MOVE_THRESHOLD)) if distance > LARGE_POSITION_MOVE_THRESHOLD else 0.0
    harmony_change = -0.35 if previous.harmony.family == current.harmony.family else 0.55
    previous_positions = {(n.string, n.fret) for n in (*previous.melody.notes, *previous.accompaniment.notes)}
    current_positions = {(n.string, n.fret) for n in (*current.melody.notes, *current.accompaniment.notes)}
    retained = previous_positions & current_positions
    retained_reward = -RETAINED_NOTE_REWARD * len(retained)
    prev_family, curr_family = _shape_family(previous), _shape_family(current)
    same_family_reward = -SAME_SHAPE_FAMILY_REWARD if prev_family == curr_family and prev_family not in {"UNKNOWN", "EMPTY"} else 0.0
    previous_outer = float(previous.cost_breakdown.get("outer_string_stretch_cost", 0.0))
    current_outer = float(current.cost_breakdown.get("outer_string_stretch_cost", 0.0))
    previous_reach = float(previous.cost_breakdown.get("melody_reach", 0.0))
    current_reach = float(current.cost_breakdown.get("melody_reach", 0.0))
    geometry_change_cost = OUTER_GEOMETRY_TRANSITION_WEIGHT * (abs(current_outer - previous_outer) + abs(current_reach - previous_reach))
    previous_assignment = previous.finger_assignment
    current_assignment = current.finger_assignment
    previous_fingers = str(previous.cost_breakdown.get("finger_mapping", "none"))
    current_fingers = str(current.cost_breakdown.get("finger_mapping", "none"))
    shared_fingers = set(previous_assignment) & set(current_assignment)
    finger_retained = bool(shared_fingers) or (previous_fingers != "none" and previous_fingers == current_fingers)
    finger_retention_reward = -2.5 * len(shared_fingers) if shared_fingers else (-1.0 if finger_retained else 0.0)
    guide_slides = sum(
        1 for s1, f1, finger1 in previous_assignment for s2, f2, finger2 in current_assignment
        if s1 == s2 and finger1 == finger2 and 0 < abs(f2 - f1) <= 2
    )
    guide_finger_reward = -1.1 * guide_slides
    previous_barre = float(previous.cost_breakdown.get("barre_fret", -1.0))
    current_barre = float(current.cost_breakdown.get("barre_fret", -1.0))
    barre_change_cost = 3.0 if previous_barre != current_barre and (previous_barre >= 0 or current_barre >= 0) else 0.0
    multi_action_cost = 0.0
    if distance > LARGE_POSITION_MOVE_THRESHOLD and len(retained) == 0 and previous_barre != current_barre:
        multi_action_cost = 10.0
    bass_line_cost = 0.0
    # v0.13.1 musicality: open strings stay fully legal, but repeated
    # root-only open-bass windows receive a small transition cost so an
    # equally playable fretted/guide-tone voicing can win.
    def _open_root_only(state: JointWindowCandidate) -> bool:
        notes = state.accompaniment.notes
        roles = tuple(state.accompaniment.tone_roles)
        if len(notes) != 1 or notes[0].fret != 0:
            return False
        return not roles or roles[0] in {"root", "source_bass", "root_doubling"}

    repeated_open_root_cost = 1.75 if _open_root_only(previous) and _open_root_only(current) else 0.0
    high_position_open_cost = 0.0
    if current_position >= 7.0 and _open_root_only(current):
        high_position_open_cost += 4.0 + 1.5 * (current_position - 7.0)
    if previous_position >= 7.0 and _open_root_only(previous):
        high_position_open_cost += 2.0 + 0.75 * (previous_position - 7.0)
    if previous.output_bass_pitch is not None and current.output_bass_pitch is not None:
        output_interval = abs(current.output_bass_pitch - previous.output_bass_pitch)
        # Penalise needless large output jumps while allowing source contour changes.
        bass_line_cost += BASS_LINE_UNNECESSARY_JUMP_COST * max(output_interval - 7, 0)
        if previous.source_bass_pitch is not None and current.source_bass_pitch is not None:
            source_same_pc = previous.source_bass_pitch % 12 == current.source_bass_pitch % 12
            output_same_pc = previous.output_bass_pitch % 12 == current.output_bass_pitch % 12
            if source_same_pc and not output_same_pc:
                bass_line_cost += BASS_LINE_PITCH_CLASS_BREAK_COST
    total = max(0.0, position_move + large_move_penalty + harmony_change + retained_reward + same_family_reward + geometry_change_cost + bass_line_cost + repeated_open_root_cost + high_position_open_cost + finger_retention_reward + guide_finger_reward + barre_change_cost + multi_action_cost)
    return total, {
        "previous_position": previous_position,
        "current_position": current_position,
        "previous_hand_center": previous_position,
        "current_hand_center": current_position,
        "hand_center_transition_cost": position_move + large_move_penalty,
        "position_distance": distance,
        "position_move_cost": position_move,
        "large_move_penalty": large_move_penalty,
        "harmony_change": harmony_change,
        "retained_note_count": float(len(retained)),
        "retained_note_reward": retained_reward,
        "previous_shape_family": prev_family,
        "current_shape_family": curr_family,
        "same_shape_family_reward": same_family_reward,
        "outer_geometry_change_cost": geometry_change_cost,
        "bass_line_transition_cost": bass_line_cost,
        "repeated_open_root_cost": repeated_open_root_cost,
        "high_position_open_cost": high_position_open_cost,
        "finger_retained": 1.0 if finger_retained else 0.0,
        "finger_retention_reward": finger_retention_reward,
        "shared_finger_count": float(len(shared_fingers)),
        "guide_finger_slide_count": float(guide_slides),
        "guide_finger_slide_reward": guide_finger_reward,
        "barre_created": 1.0 if previous_barre < 0 <= current_barre else 0.0,
        "barre_released": 1.0 if current_barre < 0 <= previous_barre else 0.0,
        "barre_change_cost": barre_change_cost,
        "multi_action_transition_cost": multi_action_cost,
    }


def evaluate_transition(previous: JointWindowCandidate, current: JointWindowCandidate) -> tuple[float, dict[str, float | str]]:
    """Public diagnostic wrapper around the DP transition evaluator."""
    return _transition(previous, current)


def _debug_counters(analyses, layers, diagnostics, *, reachable_windows=0, selected_windows=0):
    return {
        "windows_generated": sum(1 for a in analyses if a.window.melody_notes or a.window.accompaniment_notes),
        "candidates_generated": sum(int(d.raw_candidates) for d in diagnostics),
        "candidates_after_prejoint": sum(int(d.unique_after_local_cost) for d in diagnostics),
        "reachable_windows": int(reachable_windows),
        "selected_windows": int(selected_windows),
    }


def optimize_joint_arrangement(
    analyses: list[WindowHarmonyAnalysis], *, tuning: Tuning = STANDARD_TUNING,
    melody_paths_per_window: int = 6, accompaniment_per_chord: int = 4,
    joint_candidates_per_window: int = 24, max_candidates_per_note: int = 5,
    source_candidate_bundle=None, melody_backbone: LockedMelodyBackbone | None = None,
) -> JointArrangementResult:
    if melody_backbone is not None:
        timing = melody_backbone.by_id()
        analyses = [_analysis_with_locked_melody_timing(analysis, timing) for analysis in analyses]
    layers: list[list[JointWindowCandidate]] = []
    warnings: list[str] = []
    diagnostics: list[WindowDiagnostic] = []
    for analysis in analyses:
        if not analysis.window.melody_notes and not analysis.window.accompaniment_notes:
            # A score may contain a silent window between phrases. Silence
            # requires no fingering and is not an unplayable melody failure.
            diagnostics.append(WindowDiagnostic(
                window_id=analysis.window.window_id,
                measure=analysis.window.measure,
                beat=analysis.window.start - analysis.window.measure_start + 1 if hasattr(analysis.window, "measure_start") else 1.0,
                melody_notes=(), accompaniment_notes=(), raw_candidates=0,
                after_string_conflict=0, after_fret_span=0, after_stretch=0,
                after_sustain_conflict=0, after_dp_transition=0,
                first_zero_stage=None, failure_reason=None,
                simplification_level=4, removed_notes=(),
            ))
            warnings.append(f"{analysis.window.window_id}: silent window preserved without a fingering state.")
            continue
        # Keep fingering diversity for melody events that cross this window's
        # start/end boundary.  Adjacent windows reference the same locked
        # structural event, so Pre-Joint must not independently prune away all
        # common string/fret realizations before the global DP sees them.
        boundary_melody_ids = frozenset(
            str(note.source_event_id or "")
            for note in analysis.window.melody_notes
            if str(note.source_event_id or "")
            and (
                float(note.start) < float(analysis.window.start) - 1e-9
                or float(note.start + note.duration) > float(analysis.window.end) + 1e-9
            )
        )
        melody_paths = k_best_melody_paths(
            analysis.window.melody_notes, tuning=tuning,
            max_candidates_per_note=max_candidates_per_note, beam_width=melody_paths_per_window,
            preserve_event_ids=boundary_melody_ids,
        )
        # v0.13.5.12.7.1 Melody-immutable contract: if exact-MIDI melody
        # candidates do not exist, accompaniment must degrade; the melody is
        # never octave-folded here or in any local rescue path.
        octave_repairs: tuple[str, ...] = ()
        states: list[JointWindowCandidate] = []
        raw_count = 0
        rejected = 0
        span_rejected = 0
        diag_raw_topologies: set[tuple] = set()
        diag_after_span: set[tuple] = set()
        diag_after_playability: set[tuple] = set()
        diag_after_local: set[tuple] = set()
        diag_duplicate_merges = 0
        # V0.13.5.10 True Candidate Superset: source Guitar realizations remain
        # independent until this exact point. The source layer proposes; Joint
        # Arrangement arbitrates using the real melody fingering and DP context.
        source_variants = (source_candidate_bundle or {}).get(analysis.window.window_id)
        if source_candidate_bundle is not None and not source_variants:
            raise ValueError("ACCOMPANIMENT_WINDOW_MISSING_AT_JOINT:"+analysis.window.window_id)
        if not source_variants:
            source_variants = (("COMPAT_SELECTED", tuple(analysis.window.accompaniment_notes)),)

        # V0.13.5.11: LEGACY_SAFE is a true on-demand fallback. Modern
        # candidates get an exclusive first attempt and therefore retain the
        # V0.13.5.10.2 Joint arbitration surface. Only when no legal modern
        # state exists in this window do we evaluate the early simple pattern.
        legacy_safe_variants = tuple(
            item for item in source_variants if "LEGACY_SAFE" in str(item[0])
        )
        modern_source_variants = tuple(
            item for item in source_variants if "LEGACY_SAFE" not in str(item[0])
        ) or tuple(source_variants)

        def _populate_source_variants(variants):
            nonlocal raw_count, rejected, span_rejected, diag_duplicate_merges
            before_count = len(states)
            for melody in melody_paths:
                for harmony in _locked_harmonies(analysis):
                    for source_variant, variant_notes in variants:
                        variant_window = replace(analysis.window, accompaniment_notes=list(variant_notes))
                        variant_top_k = 1 if "LEGACY_SAFE" in str(source_variant) else accompaniment_per_chord
                        if str(source_variant) == "NO_ACCOMPANIMENT":
                            accompaniment_options = [AccompanimentCandidate(
                                name="NO_ACCOMPANIMENT", notes=tuple(), local_cost=0.0,
                                candidate_type="A_NONE", modifications=("ACCOMPANIMENT_MODE_NONE", "JOINT_GENERATION_DISABLED"),
                            )]
                        else:
                            # group_V0.0.4: Joint is an arbiter/fingering owner, not an
                            # accompaniment composer.  It may realize exact upstream
                            # pitches on the fretboard, but may not synthesize chord
                            # tones from the harmony family.
                            accompaniment_options = realize_supplied_accompaniment_candidates(
                                variant_window, melody, tuning=tuning, top_k=variant_top_k,
                            )
                        for accompaniment in accompaniment_options:
                            accompaniment = replace(
                                accompaniment,
                                name=f"{source_variant}|{accompaniment.name}",
                                modifications=(*accompaniment.modifications, f"SOURCE_VARIANT_{source_variant}"),
                            )
                            for reduced in _local_pruning_variants(accompaniment):
                                raw_count += 1
                                merged_notes, duplicate_notes = merge_duplicate_accompaniment(melody.notes, reduced.notes)
                                if duplicate_notes:
                                    duplicate_roles = tuple(
                                        reduced.tone_roles[index]
                                        for index, note in enumerate(reduced.notes)
                                        if note in duplicate_notes and index < len(reduced.tone_roles)
                                    )
                                    reduced = replace(
                                        reduced,
                                        notes=merged_notes,
                                        tone_roles=tuple(
                                            role for index, role in enumerate(reduced.tone_roles)
                                            if index >= len(reduced.notes) or reduced.notes[index] not in duplicate_notes
                                        ),
                                        pruned_roles=(*reduced.pruned_roles, *duplicate_roles),
                                        pruning_reasons=(*reduced.pruning_reasons, "duplicate_of_melody"),
                                        modifications=(*reduced.modifications, "SAME_STRING_SAME_FRET_MERGED"),
                                    )
                                if duplicate_notes:
                                    diag_duplicate_merges += len(duplicate_notes)
                                topology_signature = (
                                    tuple((n.string, n.fret) for n in melody.notes),
                                    harmony.family.root_pc, harmony.family.quality, str(source_variant),
                                    tuple((n.string, n.fret) for n in reduced.notes),
                                    reduced.candidate_type, tuple(reduced.tone_roles), tuple(reduced.pruned_roles),
                                )
                                diag_raw_topologies.add(topology_signature)
                                seed = JointWindowCandidate(
                                    window_id=analysis.window.window_id, measure=analysis.window.measure,
                                    start=analysis.window.start, duration=analysis.window.duration,
                                    melody=melody, harmony=harmony, accompaniment=reduced, local_cost=0.0,
                                )
                                span_check = evaluate_simultaneous_span((*seed.melody.notes, *seed.accompaniment.notes))
                                if not span_check.accepted:
                                    rejected += 1
                                    span_rejected += 1
                                    continue
                                diag_after_span.add(topology_signature)
                                playability_check = evaluate_joint_playability(
                                    seed.melody.notes, seed.accompaniment.notes,
                                    maximum_fret_distance=int(MELODY_ACCOMPANIMENT_DISTANCE_HARD),
                                )
                                if not playability_check.accepted:
                                    rejected += 1
                                    continue
                                diag_after_playability.add(topology_signature)
                                assignments = _state_assignment_candidates(seed)
                                for assignment in assignments:
                                    provisional = replace(seed, finger_assignment=assignment)
                                    total, breakdown = _local_cost(provisional)
                                    if total == float("inf"):
                                        rejected += 1
                                        continue
                                    diag_after_local.add(topology_signature)
                                    states.append(replace(provisional, local_cost=total, cost_breakdown=breakdown))
            return len(states) - before_count

        modern_state_count = _populate_source_variants(modern_source_variants)

        # v0.1.8 hierarchical Melody Shape arbitration.  Cost is only allowed
        # to compare accompaniment/transition choices *after* the best feasible
        # melody-shape retention tier is known.  If every RH-priority source
        # event can coexist in a legal state, incomplete melody states never
        # enter global DP.  If full retention is physically impossible, keep
        # the states with the greatest importance-weighted retained melody and
        # let Joint choose among that tier.
        priority_expected = {
            str(note.source_event_id or ""): int(getattr(note, "importance", 50) or 50)
            for _, variant_notes in modern_source_variants for note in variant_notes
            if str(note.arrangement_role or "").startswith("melody_priority_")
            and str(note.source_event_id or "")
        }
        full_priority_state_available = False
        from gste.editor.session import CURRENT as editor_current
        editor_session=editor_current.get()
        user_edited=bool(editor_session and any(c.window_id==analysis.window.window_id and c.metadata.get('editor_request_indices') for c in editor_session.rows))
        if states and priority_expected and not user_edited:
            def _priority_signature(state):
                kept = {str(n.note.source_event_id or "") for n in state.accompaniment.notes}
                retained = sum(importance_loss_cost(value) for eid, value in priority_expected.items() if eid in kept)
                count = sum(1 for eid in priority_expected if eid in kept)
                return (count, retained)
            signatures = [_priority_signature(state) for state in states]
            full_count = len(priority_expected)
            full_priority_state_available = any(count == full_count for count, _ in signatures)
            if full_priority_state_available:
                # Hard arbitration contract: once a physically legal state carries
                # every required Piano-priority event, lower-retention states must
                # never re-enter this layer through a later safety topology.
                states = [state for state, sig in zip(states, signatures) if sig[0] == full_count]
            else:
                best = max(signatures)
                states = [state for state, sig in zip(states, signatures) if sig == best]
            modern_state_count = len(states)

        if modern_state_count == 0 and legacy_safe_variants:
            safe_state_count = _populate_source_variants(legacy_safe_variants)
            if safe_state_count:
                warnings.append(
                    f"{analysis.window.window_id}: Guaranteed Safe Arrangement Candidate activated "
                    "only after all modern accompaniment candidates were physically unrealizable."
                )
        # Keep a deliberately expensive melody-only topology in every layer.
        # A cross-window conflict is path-dependent, so waiting until the whole
        # local layer is empty cannot provide DP with a local accompaniment
        # release at the one boundary that needs it.  The B6 bass rank and
        # local cost keep this behind every legal accompaniment-preserving path.
        if melody_paths and analysis.candidates and (not full_priority_state_available or boundary_melody_ids):
            safety_harmony = analysis.candidates[0]
            safety_removed = tuple(sorted({str(note.pitch.midi) for note in analysis.window.accompaniment_notes}))
            for melody in melody_paths:
                priority_loss = 15.0 * sum(importance_loss_cost(int(getattr(n, "importance", 50) or 50))
                                    for n in analysis.window.accompaniment_notes
                                    if str(n.arrangement_role or "").startswith("melody_priority_"))
                safety_accompaniment = AccompanimentCandidate(
                    "melody-only-cross-window-safety", (), 12.0 + priority_loss,
                    len(safety_harmony.family.required_pitch_classes),
                    candidate_type="K_MELODY_ONLY_HARD_CONFLICT",
                    modifications=("ACCOMPANIMENT_REMOVED_FOR_HARD_CONFLICT",),
                )
                seed = JointWindowCandidate(
                    window_id=analysis.window.window_id, measure=analysis.window.measure,
                    start=analysis.window.start, duration=analysis.window.duration,
                    melody=melody, harmony=safety_harmony,
                    accompaniment=safety_accompaniment, local_cost=0.0,
                    simplification_level=4, removed_notes=safety_removed,
                )
                assignments = _state_assignment_candidates(seed)
                for assignment in assignments:
                    provisional = replace(seed, finger_assignment=assignment)
                    total, breakdown = _local_cost(provisional)
                    if total != float("inf"):
                        states.append(replace(provisional, local_cost=total, cost_breakdown=breakdown))
        # v0.12.6.7 local melody rescue.  A narrow beam can contain only hand-
        # shape-invalid melody paths even though a legal same-pitch fingering
        # exists farther down the candidate list.  Before declaring the whole
        # arrangement failed, expand only this window's melody search and keep
        # it melody-only.  This is deliberately local: surrounding windows keep
        # their accompaniment and DP continuity.
        if not states and analysis.window.melody_notes and analysis.candidates:
            rescue_notes = list(analysis.window.melody_notes)
            rescue_octaves: tuple[str, ...] = ()
            rescue_paths = k_best_melody_paths(
                rescue_notes, tuning=tuning, max_candidates_per_note=max(12, max_candidates_per_note),
                beam_width=max(96, melody_paths_per_window * 12), max_fret=18,
            )
            rescue_harmony = analysis.candidates[0]
            rescue_removed = tuple(sorted({str(note.pitch.midi) for note in analysis.window.accompaniment_notes}))
            for melody in rescue_paths:
                rescue_acc = AccompanimentCandidate(
                    "local-melody-rescue", (), 18.0, len(rescue_harmony.family.required_pitch_classes),
                    candidate_type="M_LOCAL_MELODY_RESCUE",
                    modifications=("LOCAL_WINDOW_MELODY_ONLY_RESCUE",),
                )
                seed = JointWindowCandidate(
                    window_id=analysis.window.window_id, measure=analysis.window.measure,
                    start=analysis.window.start, duration=analysis.window.duration,
                    melody=melody, harmony=rescue_harmony, accompaniment=rescue_acc, local_cost=0.0,
                    simplification_level=4, removed_notes=(*rescue_removed, *rescue_octaves),
                )
                if not evaluate_simultaneous_span(seed.melody.notes).accepted:
                    continue
                assignments = _state_assignment_candidates(seed)
                for assignment in assignments:
                    provisional = replace(seed, finger_assignment=assignment)
                    total, breakdown = _local_cost(provisional)
                    if total != float("inf"):
                        states.append(replace(provisional, local_cost=total + 120.0, cost_breakdown={**breakdown, "local_rescue_penalty": 120.0}))
            if states:
                warnings.append(
                    f"{analysis.window.window_id}: local melody-only rescue recovered {len(states)} legal candidate(s); "
                    "other windows retain accompaniment."
                )

        # v0.1.9 lifecycle contract: fallback/safety states are created after
        # the v0.1.8 melody tier filter. Re-apply the immutable priority-ID
        # tier after *all* local states exist; otherwise a later melody-only
        # safety state can silently re-enter global DP and defeat a feasible
        # complete Melody Shape.
        if states and priority_expected and not boundary_melody_ids and not user_edited:
            def _final_priority_signature(state):
                kept = {str(n.note.source_event_id or "") for n in state.accompaniment.notes}
                retained = sum(importance_loss_cost(value) for eid, value in priority_expected.items() if eid in kept)
                count = sum(1 for eid in priority_expected if eid in kept)
                return (count, retained)
            final_signatures = [_final_priority_signature(state) for state in states]
            full_count = len(priority_expected)
            if any(count == full_count for count, _ in final_signatures):
                states = [state for state, sig in zip(states, final_signatures) if sig[0] == full_count]
            else:
                best = max(final_signatures)
                states = [state for state, sig in zip(states, final_signatures) if sig == best]

        from gste.editor.session import editor_intent_loss
        states.sort(key=lambda s: (editor_intent_loss(s), s.bass_identity_rank, s.local_cost, s.harmony.family.root_pc, s.harmony.family.quality))
        if rejected:
            warnings.append(
                f"{analysis.window.window_id}: rejected {rejected} physically conflicting or very high-risk candidates"
                f" ({span_rejected} simultaneous-span violations)."
            )
        level = 0
        removed: tuple[str, ...] = ()
        # The final safety net is intentionally melody-only.  It protects P0
        # melody continuity when a chord voicing cannot share the hand shape.
        if not states and melody_paths and analysis.candidates:
            level = 4
            removed = tuple(sorted({str(note.pitch.midi) for note in analysis.window.accompaniment_notes}))
            harmony = analysis.candidates[0]
            for melody in melody_paths:
                accompaniment = AccompanimentCandidate("melody-only", (), 12.0, len(harmony.family.required_pitch_classes))
                provisional = JointWindowCandidate(
                    window_id=analysis.window.window_id, measure=analysis.window.measure,
                    start=analysis.window.start, duration=analysis.window.duration,
                    melody=melody, harmony=harmony, accompaniment=accompaniment, local_cost=0.0,
                    simplification_level=level, removed_notes=removed,
                )
                total, breakdown = _local_cost(provisional)
                if total != float("inf"):
                    states.append(replace(provisional, local_cost=total, cost_breakdown=breakdown))
            warnings.append(f"{analysis.window.window_id}: simplified to Level 4 melody-only after full chord candidates were rejected.")
        first_zero = None if states else "Melody Candidate"
        reason = None if states else "No playable melody fingering in the configured fret range."
        diagnostics.append(WindowDiagnostic(
            window_id=analysis.window.window_id, measure=analysis.window.measure,
            beat=analysis.window.start - analysis.window.measure_start + 1 if hasattr(analysis.window, "measure_start") else 1.0,
            melody_notes=tuple(str(note.pitch.midi) for note in analysis.window.melody_notes),
            accompaniment_notes=tuple(str(note.pitch.midi) for note in analysis.window.accompaniment_notes),
            raw_candidates=raw_count, after_string_conflict=raw_count,
            after_fret_span=raw_count - span_rejected, after_stretch=len(states),
            after_sustain_conflict=len(states), after_dp_transition=len(states),
            first_zero_stage=first_zero, failure_reason=reason,
            simplification_level=level, removed_notes=(*removed, *octave_repairs),
            unique_raw_topologies=len(diag_raw_topologies),
            unique_after_fret_span=len(diag_after_span),
            unique_after_playability=len(diag_after_playability),
            unique_after_local_cost=len(diag_after_local),
            duplicate_merge_events=diag_duplicate_merges,
        ))
        if not states:
            warnings.append(f"No playable melody candidate for {analysis.window.window_id}.")
            return JointArrangementResult((), tuple(tuple(layer) for layer in layers), float("inf"), tuple(warnings), tuple(diagnostics), _debug_counters(analyses, layers, diagnostics))
        # Keep one topology leader before alternate assignments so the restored
        # 3–5 hand states cannot crowd out musically distinct candidates.
        def topology_key(state: JointWindowCandidate) -> tuple:
            return (
                tuple((n.string, n.fret) for n in state.melody.notes),
                state.harmony.family.root_pc, state.harmony.family.quality,
                tuple((n.string, n.fret) for n in state.accompaniment.notes),
                state.accompaniment.candidate_type, state.bass_identity_rank,
            )
        leaders: list[JointWindowCandidate] = []
        variants: list[JointWindowCandidate] = []
        seen: set[tuple] = set()
        for state in states:
            key = topology_key(state)
            if key in seen:
                variants.append(state)
            else:
                seen.add(key)
                leaders.append(state)
        safety_leaders = [
            state for state in leaders
            if state.accompaniment.candidate_type == "K_MELODY_ONLY_HARD_CONFLICT"
        ]
        regular_leaders = [
            state for state in leaders
            if state.accompaniment.candidate_type != "K_MELODY_ONLY_HARD_CONFLICT"
        ]
        leaders = [
            *regular_leaders[:joint_candidates_per_window],
            *safety_leaders[:max(4, melody_paths_per_window)],
        ]
        leader_keys = {topology_key(state) for state in leaders}
        variants = [state for state in variants if topology_key(state) in leader_keys]
        layers.append([*leaders, *variants[:joint_candidates_per_window * 2]])

    if not layers:
        return JointArrangementResult((), (), 0.0, (), (), _debug_counters(analyses, layers, diagnostics))
    # v0.13.5.15.7 committed-schedule DP: retain every already-selected note
    # that has not released yet (including future attacks), plus recent hand
    # centres and one predecessor index. No full-path scan.
    from gste.editor.session import editor_intent_loss
    first_row: list[_DPCell] = []
    for state in layers[0]:
        active = _advance_active_notes((), state)
        accepted, _ = _evaluate_active_hand(active)
        first_row.append(_DPCell(
            state.local_cost if accepted else float("inf"), None, active, (_hand_center(state),), editor_intent_loss(state) if accepted else float('inf'),
        ))
    dp: list[list[_DPCell]] = [first_row]
    path_observation = {
        "layer_count": len(layers),
        "layer_state_counts": [len(layer) for layer in layers],
        "reachable_state_counts": [sum(1 for cell in first_row if cell.cost < float("inf"))],
        "transition_rejection_counts": {},
        "first_unreachable_layer": None,
        "first_unreachable_window_id": None,
    }
    global_rejections: Counter[str] = Counter()
    # Many predecessor paths collapse to the same physical sounding state.
    # Cache that state/candidate validation instead of repeating canonical
    # snapshot work for every musically distinct predecessor cost.
    active_validation_cache: dict[tuple, tuple[bool, str | None]] = {}
    for index in range(1, len(layers)):
        row: list[_DPCell] = []
        layer_rejections: Counter[str] = Counter()
        reachable_previous = sum(1 for cell in dp[index - 1] if cell.cost < float("inf"))
        for current in layers[index]:
            best = _DPCell(float("inf"), None, (), ())
            current_center = _hand_center(current)
            for prev_index, previous in enumerate(layers[index - 1]):
                previous_cell = dp[index - 1][prev_index]
                if previous_cell.cost == float("inf"):
                    layer_rejections["PREVIOUS_STATE_UNREACHABLE"] += 1
                    continue
                # Physical legality is evaluated below from the compressed
                # active sounding state.  Re-running a full timeline inside
                # _transition doubled the hottest DP work without adding a rule.
                transition_cost, transition_detail = _transition(previous, current, validate_physical=False)
                if transition_cost == float("inf"):
                    reason = str(transition_detail.get("rejection_reason", "TRANSITION_REJECTED"))
                    layer_rejections[reason] += 1
                    continue
                active = _advance_active_notes(previous_cell.active_notes, current)
                active_key = (_active_signature(active), current.window_id)
                cached = active_validation_cache.get(active_key)
                if cached is None:
                    cached = _evaluate_active_candidate_boundaries(active, current)
                    active_validation_cache[active_key] = cached
                accepted, active_reason = cached
                if not accepted:
                    layer_rejections[str(active_reason or "ACTIVE_HAND_REJECTED")] += 1
                    continue
                excursion_cost, _ = _short_excursion_from_centers(
                    previous_cell.recent_centers, current_center,
                )
                cost = previous_cell.cost + current.local_cost + transition_cost + excursion_cost
                intent_loss = previous_cell.editor_loss + editor_intent_loss(current)
                if (intent_loss,cost) < (best.editor_loss,best.cost):
                    centers = (*previous_cell.recent_centers, current_center)[-4:]
                    best = _DPCell(cost, prev_index, active, centers, intent_loss)
            row.append(best)
        dp.append(row)
        reachable_now = sum(1 for cell in row if cell.cost < float("inf"))
        path_observation["reachable_state_counts"].append(reachable_now)
        global_rejections.update(layer_rejections)
        if reachable_previous > 0 and reachable_now == 0 and path_observation["first_unreachable_layer"] is None:
            path_observation["first_unreachable_layer"] = index
            path_observation["first_unreachable_window_id"] = layers[index][0].window_id if layers[index] else None
            path_observation["first_unreachable_rejection_counts"] = dict(layer_rejections)
            path_observation["previous_reachable_states"] = reachable_previous
            path_observation["current_candidate_states"] = len(layers[index])
    path_observation["transition_rejection_counts"] = dict(global_rejections)
    path_observation["edit_priority_policy"] = "PHYSICAL_HARD_LIMITS_THEN_USER_INTENT_THEN_SOFT_COST"

    reachable_windows = sum(1 for row in dp if any(cell.cost < float("inf") for cell in row))
    if not any(cell.cost < float("inf") for cell in dp[-1]):
        warnings.append("No complete DP path satisfies the compressed active-note hand-shape constraint.")
        return JointArrangementResult(
            (), tuple(tuple(layer) for layer in layers), float("inf"),
            tuple(warnings), tuple(diagnostics),
            _debug_counters(analyses, layers, diagnostics, reachable_windows=reachable_windows),
            path_observation,
        )
    last_index = min(range(len(layers[-1])), key=lambda i: (dp[-1][i].editor_loss,dp[-1][i].cost))
    total_cost = dp[-1][last_index].cost
    selected_indices = [last_index]
    for layer_index in range(len(layers) - 1, 0, -1):
        predecessor = dp[layer_index][selected_indices[-1]].predecessor
        if predecessor is None:
            raise RuntimeError("Broken v0.12.6.4 DP predecessor chain")
        selected_indices.append(predecessor)
    selected_indices.reverse()
    selected = [layers[layer_index][state_index] for layer_index, state_index in enumerate(selected_indices)]
    annotated = []
    recent_centers: tuple[float, ...] = ()
    active: tuple[_ActiveRoleNote, ...] = ()
    for index, state in enumerate(selected):
        active = _advance_active_notes(active, state)
        if index == 0:
            annotated.append(state)
        else:
            transition_cost, breakdown = _transition(selected[index - 1], state)
            accepted, reason = _evaluate_active_hand(active)
            if not accepted:
                breakdown = {"rejection_reason": reason, "playability_onset": float(state.start)}
            excursion_cost, excursion_breakdown = _short_excursion_from_centers(
                recent_centers, _hand_center(state),
            )
            annotated.append(replace(
                state, transition_cost=transition_cost + excursion_cost,
                transition_breakdown={**breakdown, **excursion_breakdown},
            ))
        recent_centers = (*recent_centers, _hand_center(state))[-4:]
    return JointArrangementResult(tuple(annotated), tuple(tuple(layer) for layer in layers), total_cost, tuple(warnings), tuple(diagnostics), _debug_counters(analyses, layers, diagnostics, reachable_windows=reachable_windows, selected_windows=len(annotated)), path_observation)
