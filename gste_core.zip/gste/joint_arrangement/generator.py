from __future__ import annotations
from dataclasses import replace

from gste.arrangement.importance import effective_importance, importance_loss_cost
from gste.core.models import FingeringCandidate, NoteEvent, Pitch
from gste.core.tuning import STANDARD_TUNING, Tuning
from gste.fingering.candidates import generate_candidates
from gste.fingering.cost import score_candidate, score_transition
from gste.harmony.models import ChordFamilyCandidate
from gste.harmony.windows import HarmonyWindow
from gste.joint_arrangement.models import AccompanimentCandidate, MelodyPathCandidate


def k_best_melody_paths(
    notes: list[NoteEvent], *, tuning: Tuning = STANDARD_TUNING, max_candidates_per_note: int = 5,
    beam_width: int = 8, max_fret: int = 17, preserve_event_ids: frozenset[str] = frozenset(),
) -> list[MelodyPathCandidate]:
    if not notes:
        return [MelodyPathCandidate(notes=(), local_cost=0.0)]
    ordered = sorted(notes, key=lambda n: (n.start, -n.pitch.midi))
    beam: list[tuple[float, tuple[FingeringCandidate, ...]]] = [(0.0, ())]
    for note in ordered:
        layer = generate_candidates(note, tuning=tuning, max_fret=max_fret, max_candidates=max_candidates_per_note)
        # v0.13.5.12.7 hard invariant: Joint may re-finger exact MIDI only.
        layer = [c for c in layer if int(c.note.pitch.midi) == int(note.pitch.midi)]
        if not layer:
            return []
        expanded: list[tuple[float, tuple[FingeringCandidate, ...]]] = []
        for cost, path in beam:
            for candidate in layer:
                transition = score_transition(path[-1], candidate) if path else 0.0
                expanded.append((cost + score_candidate(candidate) + transition, (*path, candidate)))
        expanded.sort(key=lambda item: (item[0], tuple((n.string, n.fret) for n in item[1])))

        # Cross-window Melody Shape continuity.  Keep at least the cheapest
        # path for every already-realized boundary-event fingering signature.
        # This must run after *every* note layer: otherwise a later note can
        # prune away the diversity that was preserved when the sustained note
        # itself was processed.
        if preserve_event_ids:
            diversified: list[tuple[float, tuple[FingeringCandidate, ...]]] = []
            seen_signatures: set[tuple[tuple[str, int, int], ...]] = set()
            for item in expanded:
                signature = tuple(sorted(
                    (str(c.note.source_event_id or ""), int(c.string), int(c.fret))
                    for c in item[1]
                    if str(c.note.source_event_id or "") in preserve_event_ids
                ))
                if signature in seen_signatures:
                    continue
                seen_signatures.add(signature)
                diversified.append(item)
            # Boundary diversity is a hard feasibility surface, not a scoring
            # preference.  It may exceed the ordinary local beam width, but is
            # naturally bounded by the per-note candidate limit.
            beam = diversified
            if len(beam) < beam_width:
                selected_keys = {
                    tuple((int(c.string), int(c.fret), str(c.note.source_event_id or "")) for c in item[1])
                    for item in beam
                }
                for item in expanded:
                    key = tuple((int(c.string), int(c.fret), str(c.note.source_event_id or "")) for c in item[1])
                    if key in selected_keys:
                        continue
                    beam.append(item)
                    selected_keys.add(key)
                    if len(beam) >= beam_width:
                        break
        else:
            beam = expanded[:beam_width]
    return [MelodyPathCandidate(notes=path, local_cost=cost) for cost, path in beam]




def realize_supplied_accompaniment_candidates(
    window: HarmonyWindow,
    melody: MelodyPathCandidate,
    *, tuning: Tuning = STANDARD_TUNING, max_fret: int = 17, top_k: int = 5,
) -> list[AccompanimentCandidate]:
    """Finger only the exact accompaniment notes supplied by upstream.

    group_V0.0.4 ownership rule: Joint may realize string/fret positions and
    later prune physically conflicting optional notes, but it must not infer
    new pitches from harmony.  Every pitch in every returned candidate is
    therefore traceable to ``window.accompaniment_notes``.
    """
    notes = sorted(window.accompaniment_notes, key=lambda n: (n.start, n.pitch.midi, n.duration))
    if not notes:
        return [AccompanimentCandidate(
            name="UPSTREAM_EMPTY", notes=tuple(), local_cost=0.0,
            candidate_type="A_UPSTREAM_EMPTY", modifications=("UPSTREAM_ONLY_NO_GENERATION",),
        )]
    layers = []
    for note in notes:
        exact = [c for c in generate_candidates(note, tuning=tuning, max_fret=max_fret, max_candidates=max(6, top_k * 2))
                 if int(c.note.pitch.midi) == int(note.pitch.midi)]
        if not exact:
            return []
        layers.append(exact)
    beam = [(0.0, tuple())]
    for layer in layers:
        expanded = []
        for cost, path in beam:
            for cand in layer:
                # Fingering choice only; pitch/onset/duration remain upstream-owned.
                transition = score_transition(path[-1], cand) if path else 0.0
                expanded.append((cost + score_candidate(cand) + transition, (*path, cand)))
        expanded.sort(key=lambda item: (item[0], tuple((n.string, n.fret) for n in item[1])))
        beam = expanded[:max(top_k * 4, 12)]
    out = []
    source_bass_pitch = min(n.pitch.midi for n in notes)
    for idx, (cost, path) in enumerate(beam[:top_k], start=1):
        out.append(AccompanimentCandidate(
            name=f"UPSTREAM_REALIZATION_{idx}", notes=path, local_cost=cost,
            source_bass_pitch=source_bass_pitch, output_bass_pitch=source_bass_pitch,
            bass_identity_rank=0, bass_role="UPSTREAM_BASS",
            bass_substitution_reason="upstream_exact_pitch", source_harmony_locked=True,
            tone_roles=tuple(str(getattr(n.note, "arrangement_role", None) or "upstream_tone") for n in path),
            candidate_type="A_UPSTREAM_ONLY", modifications=("UPSTREAM_ONLY_NO_GENERATION",),
            harmony_coverage=tuple(sorted({n.note.pitch.midi % 12 for n in path})),
        ))
    return out
