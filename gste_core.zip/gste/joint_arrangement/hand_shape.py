from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

from gste.core.models import FingeringCandidate


@dataclass(frozen=True)
class HandShapeEvaluation:
    shape_family: str
    recognized_common_shape: bool
    base_fret: int
    fret_span: int
    estimated_finger_count: int
    low_bass_risk: float
    mini_barre_risk: float
    unknown_shape_risk: float
    outer_string_stretch_cost: float
    melody_reach_cost: float
    melody_reach: int
    outer_string_distance: int
    family_adjustment: float
    total_static_cost: float
    reverse_fret_drop: int = 0
    reverse_fret_drop_cost: float = 0.0
    legal_shape_exception: bool = False
    anchor_shape: str = "custom"
    barre_fret: int | None = None
    finger_mapping: tuple[tuple[int, int, int], ...] = ()
    rejected: bool = False
    rejection_reason: str | None = None


def _assignment_is_legal(mapping: tuple[tuple[int, int, int], ...]) -> bool:
    """Reject only impossible finger reuse/crossing assignments.

    This is intentionally the v0.12.0 baseline.  Detailed ergonomic rules
    (reverse extension, partial barre comfort, etc.) remain in the existing
    hand-shape evaluator and are not recalibrated in v0.12.4.
    """
    by_finger: dict[int, list[tuple[int, int]]] = defaultdict(list)
    for string, fret, finger in mapping:
        by_finger[finger].append((string, fret))
    for positions in by_finger.values():
        if len({fret for _, fret in positions}) > 1:
            return False
        strings = sorted(string for string, _ in positions)
        if len(strings) > 1 and any(b - a > 1 for a, b in zip(strings, strings[1:])):
            return False
    ordered = sorted(mapping)
    for (s1, f1, finger1), (s2, f2, finger2) in zip(ordered, ordered[1:]):
        if s2 == s1 + 1 and f2 >= f1 and finger2 < finger1 and f1 != f2:
            return False
    return True


def finger_assignment_candidates(
    notes: tuple[FingeringCandidate, ...], base: int, anchor_shape: str,
) -> tuple[tuple[tuple[int, int, int], ...], ...]:
    """Return legal deterministic assignments for the *combined* hand shape."""
    fretted = tuple(sorted((n.string, n.fret) for n in notes if n.fret > 0))
    if not fretted:
        return ((),)
    by_fret: dict[int, list[int]] = defaultdict(list)
    for string, fret in fretted:
        by_fret[fret].append(string)
    variants: list[tuple[tuple[int, int, int], ...]] = []
    for index_at_base in (1, 2, 1, 3, 2):
        mapping: list[tuple[int, int, int]] = []
        for fret in sorted(by_fret):
            strings = sorted(by_fret[fret])
            finger = min(4, max(1, index_at_base + fret - base))
            if len(strings) >= 2 and index_at_base == 1:
                finger = 1
            mapping.extend((string, fret, finger) for string in strings)
        candidate = tuple(sorted(mapping))
        if _assignment_is_legal(candidate) and candidate not in variants:
            variants.append(candidate)
    default = _finger_mapping(notes, base)
    if _assignment_is_legal(default) and default not in variants:
        variants.insert(0, default)
    return tuple(variants[:5])


def finger_assignment_static_cost(mapping: tuple[tuple[int, int, int], ...], anchor_shape: str) -> float:
    """Small v0.12.0 preference for compact, recognised assignments."""
    if not mapping:
        return 0.0
    fingers = {finger for _, _, finger in mapping}
    by_finger: dict[int, list[int]] = defaultdict(list)
    for string, _, finger in mapping:
        by_finger[finger].append(string)
    barre_count = sum(1 for strings in by_finger.values() if len(strings) >= 2)
    return (
        0.18 * max(0, 3 - len(fingers))
        + 0.7 * barre_count
        - (0.65 if anchor_shape != "custom" else 0.0)
        + 0.22 * sum(1 for _, _, finger in mapping if finger == 4)
    )


# Movable CAGED / common shapes, stored from string 6 to string 1.
# Values are fret offsets from the shape's base fret; None means unused string.
_MOVABLE_PATTERNS: dict[str, tuple[int | None, ...]] = {
    "E_SHAPE_MAJOR": (0, 2, 2, 1, 0, 0),
    "E_SHAPE_MINOR": (0, 2, 2, 0, 0, 0),
    "A_SHAPE_MAJOR": (None, 0, 2, 2, 2, 0),
    "A_SHAPE_MINOR": (None, 0, 2, 2, 1, 0),
    "D_SHAPE_PARTIAL": (None, None, 0, 2, 3, 2),
    "C_SHAPE_PARTIAL": (None, 0, 2, 0, 1, 0),
    "G_SHAPE_FULL": (3, 2, 0, 0, 0, 3),
}

_OPEN_TEMPLATES: tuple[frozenset[tuple[int, int]], ...] = (
    frozenset({(5, 3), (4, 2), (3, 0), (2, 1), (1, 0)}),  # C
    frozenset({(4, 0), (3, 2), (2, 3), (1, 2)}),          # D
    frozenset({(6, 0), (5, 2), (4, 2), (3, 1), (2, 0), (1, 0)}),  # E
    frozenset({(6, 3), (5, 2), (4, 0), (3, 0), (2, 0), (1, 3)}),  # G
    frozenset({(5, 0), (4, 2), (3, 2), (2, 2), (1, 0)}),  # A
)


def _positions(notes: tuple[FingeringCandidate, ...]) -> dict[int, int]:
    return {note.string: note.fret for note in notes}


def _relative_pattern(notes: tuple[FingeringCandidate, ...]) -> tuple[tuple[int | None, ...], int]:
    positions = _positions(notes)
    fretted = [fret for fret in positions.values() if fret > 0]
    if not fretted:
        return tuple(positions.get(string) for string in range(6, 0, -1)), 0
    base = min(fretted)
    pattern: list[int | None] = []
    for string in range(6, 0, -1):
        fret = positions.get(string)
        pattern.append(None if fret is None else fret - base)
    return tuple(pattern), base


def _is_subset_pattern(actual: tuple[int | None, ...], template: tuple[int | None, ...]) -> bool:
    used = 0
    for value, expected in zip(actual, template):
        if value is None:
            continue
        used += 1
        if expected is None or value != expected:
            return False
    return used >= 2


def classify_shape(notes: tuple[FingeringCandidate, ...]) -> tuple[str, bool, int]:
    if not notes:
        return "EMPTY", True, 0
    positions = _positions(notes)
    used = frozenset(positions.items())
    for template in _OPEN_TEMPLATES:
        if used == template:
            return "OPEN", True, 0
        if used.issubset(template) and len(used) >= 2:
            return "OPEN_PARTIAL", True, min((f for f in positions.values() if f > 0), default=0)
    if any(fret == 0 for fret in positions.values()):
        return "OPEN", True, 0

    pattern, base = _relative_pattern(notes)
    for family, template in _MOVABLE_PATTERNS.items():
        if pattern == template:
            return family, True, base
        if _is_subset_pattern(pattern, template):
            if family == "G_SHAPE_FULL":
                return "G_SHAPE_SIMPLIFIED", True, base
            return family, True, base

    if len(notes) == 2:
        return "POWER_OR_SHELL", True, base
    if len(notes) <= 3 and all(note.string <= 4 for note in notes):
        return "TRIAD_OR_SHELL", True, base
    return "UNKNOWN", False, base


def _estimated_fingers(notes: tuple[FingeringCandidate, ...]) -> int:
    fretted = [(note.string, note.fret) for note in notes if note.fret > 0]
    if not fretted:
        return 0
    by_fret: dict[int, list[int]] = defaultdict(list)
    for string, fret in fretted:
        by_fret[fret].append(string)
    count = 0
    for strings in by_fret.values():
        ordered = sorted(strings)
        adjacent = any(b - a == 1 for a, b in zip(ordered, ordered[1:]))
        count += 1 if len(strings) >= 2 and adjacent else len(strings)
    return count


def _finger_mapping(notes: tuple[FingeringCandidate, ...], base: int) -> tuple[tuple[int, int, int], ...]:
    """Deterministic, auditable first-pass left-hand assignment.

    Tuple entries are (string, fret, finger), where 1=index through 4=pinky.
    Same-fret adjacent strings share index as a mini-barre candidate.
    """
    fretted = sorted((n.string, n.fret) for n in notes if n.fret > 0)
    if not fretted:
        return ()
    by_fret: dict[int, list[int]] = defaultdict(list)
    for string, fret in fretted:
        by_fret[fret].append(string)
    assigned: list[tuple[int, int, int]] = []
    for fret in sorted(by_fret):
        finger = min(4, max(1, fret - base + 1))
        if len(by_fret[fret]) >= 2:
            finger = 1
        assigned.extend((string, fret, finger) for string in by_fret[fret])
    return tuple(sorted(assigned))


def _reverse_drop(notes: tuple[FingeringCandidate, ...], recognized: bool, fingers: int) -> tuple[int, float, bool, bool]:
    """Check every simultaneous lower-string/higher-string fretted pair."""
    by_start: dict[float, list[FingeringCandidate]] = defaultdict(list)
    for note in notes:
        if note.fret > 0:
            by_start[round(note.note.start, 6)].append(note)
    maximum = 0
    for snapshot in by_start.values():
        for lower in snapshot:
            for higher in snapshot:
                if lower.string > higher.string:
                    maximum = max(maximum, lower.fret - higher.fret)
    legal_exception = recognized and maximum >= 3
    if maximum <= 1 or legal_exception:
        return maximum, 0.0, legal_exception, False
    if maximum == 2:
        return maximum, 1.5, False, False
    if maximum == 3:
        return maximum, 12.0, False, False
    # A four-fret reverse drop with three independently fretted fingers is the
    # documented hard rejection; recognised CAGED/open/shell topology is kept.
    rejected = fingers >= 3
    return maximum, 22.0 + 10.0 * (maximum - 4), False, rejected


def evaluate_hand_shape(
    melody_notes: tuple[FingeringCandidate, ...],
    accompaniment_notes: tuple[FingeringCandidate, ...],
) -> HandShapeEvaluation:
    all_notes = (*melody_notes, *accompaniment_notes)
    by_string_start: dict[tuple[int, float], set[int]] = defaultdict(set)
    for note in all_notes:
        by_string_start[(note.string, note.note.start)].add(note.fret)
    if any(len(frets) > 1 for frets in by_string_start.values()):
        return HandShapeEvaluation(
            "CONFLICT", False, 0, 0, 99, 0, 0, 0, 0, 0, 0, 0, float("inf"), True,
            "same_string_multiple_frets",
        )

    fretted = [note.fret for note in all_notes if note.fret > 0]
    fret_span = 0 if not fretted else max(fretted) - min(fretted)
    if fret_span > 6:
        return HandShapeEvaluation(
            "OUT_OF_REACH", False, min(fretted), fret_span, 99, 0, 0, 0, 0, 0, 0, 0, 0,
            float("inf"), True, "absolute_span_limit",
        )

    family, recognized, base = classify_shape(accompaniment_notes)
    if base == 0 and fretted:
        base = min(fretted)

    # Risk is cumulative rather than a single-feature rejection.
    low_bass = [n for n in accompaniment_notes if n.string in (5, 6) and n.fret > base and n.fret > 0]
    low_bass_risk = 0.0
    if len(low_bass) >= 2:
        low_bass_risk += 4.0
        if len({n.fret for n in low_bass}) == 1:
            low_bass_risk += 4.0
        offset = max(n.fret - base for n in low_bass)
        if offset >= 3:
            low_bass_risk += 4.0
        if offset >= 4:
            low_bass_risk += 3.0

    by_fret: dict[int, list[int]] = defaultdict(list)
    for note in all_notes:
        if note.fret > 0:
            by_fret[note.fret].append(note.string)
    mini_barre_risk = 0.0
    for fret, strings in by_fret.items():
        offset = fret - base
        ordered = sorted(strings)
        adjacent = any(b - a == 1 for a, b in zip(ordered, ordered[1:]))
        if offset >= 3 and len(strings) >= 2 and adjacent:
            mini_barre_risk += 4.0 if len(strings) == 2 else 8.0
            if offset >= 4:
                mini_barre_risk += 3.0

    unknown_risk = 0.0 if recognized else 2.0
    family_adjustments = {
        "OPEN": -4.0,
        "OPEN_PARTIAL": -1.25,
        "E_SHAPE_MAJOR": -3.0,
        "E_SHAPE_MINOR": -3.0,
        "A_SHAPE_MAJOR": -3.0,
        "A_SHAPE_MINOR": -3.0,
        "POWER_OR_SHELL": -1.5,
        "TRIAD_OR_SHELL": -1.0,
        "G_SHAPE_FULL": 8.0,
        "G_SHAPE_SIMPLIFIED": 2.0,
    }
    family_adjustment = family_adjustments.get(family, 0.0)

    # Protected common shapes greatly reduce generic topology penalties.
    if family.startswith("E_SHAPE"):
        low_bass_risk *= 0.0
        mini_barre_risk *= 0.25
    elif family.startswith("A_SHAPE"):
        low_bass_risk *= 0.25
        mini_barre_risk *= 0.15
    elif family in {"POWER_OR_SHELL", "TRIAD_OR_SHELL"}:
        low_bass_risk *= 0.5
        mini_barre_risk *= 0.5

    # v0.10: estimate whether melody and bass sit on opposite outer strings while also spanning frets.
    accompaniment_fretted = [n for n in accompaniment_notes if n.fret > 0]
    melody_fretted = [n for n in melody_notes if n.fret > 0]
    outer_string_distance = 0
    outer_string_stretch_cost = 0.0
    if accompaniment_fretted and melody_fretted:
        pairs = [(abs(m.string - a.string), abs(m.fret - a.fret)) for m in melody_fretted for a in accompaniment_fretted]
        outer_string_distance, outer_fret_distance = max(pairs, key=lambda item: item[0] * item[1])
        # Only charge the portion beyond an ordinary adjacent-string / two-fret reach.
        outer_string_stretch_cost = max(0.0, float(outer_fret_distance - 2)) * max(0.0, float(outer_string_distance - 1)) * 0.75
        if recognized:
            outer_string_stretch_cost *= 0.55

    melody_reach = max((n.fret - base for n in melody_fretted), default=0)
    melody_reach_cost = 0.0
    if melody_reach == 3:
        melody_reach_cost = 2.0
    elif melody_reach == 4:
        melody_reach_cost = 6.0
    elif melody_reach >= 5:
        melody_reach_cost = 12.0 + 3.0 * (melody_reach - 5)
    if recognized:
        melody_reach_cost *= 0.6

    melody_starts = sorted({note.note.start for note in melody_notes}) or [0.0]
    snapshots = [
        tuple((*accompaniment_notes, *(note for note in melody_notes if note.note.start == start)))
        for start in melody_starts
    ]
    fingers = max((_estimated_fingers(snapshot) for snapshot in snapshots), default=0)
    finger_risk = max(fingers - 4, 0) * 4.0
    reverse_drop, reverse_cost, legal_exception, reverse_rejected = _reverse_drop(all_notes, recognized, fingers)
    total = (low_bass_risk + mini_barre_risk + unknown_risk + outer_string_stretch_cost
             + melody_reach_cost + family_adjustment + finger_risk + reverse_cost)
    # Outer reach and melody reach are diagnostic soft costs; do not let either
    # single heuristic erase unusual but playable classical-guitar shapes.
    rejection_risk = low_bass_risk + mini_barre_risk + unknown_risk + finger_risk + max(family_adjustment, 0.0)
    rejected = reverse_rejected or (rejection_risk >= 20.0 and family == "UNKNOWN")
    reason = "IMPOSSIBLE_REVERSE_STRETCH" if reverse_rejected else ("unknown_shape_difficulty" if rejected else None)
    return HandShapeEvaluation(
        shape_family=family, recognized_common_shape=recognized, base_fret=base,
        fret_span=fret_span, estimated_finger_count=fingers, low_bass_risk=low_bass_risk,
        mini_barre_risk=mini_barre_risk, unknown_shape_risk=unknown_risk,
        outer_string_stretch_cost=outer_string_stretch_cost, melody_reach_cost=melody_reach_cost,
        melody_reach=melody_reach, outer_string_distance=outer_string_distance,
        family_adjustment=family_adjustment, total_static_cost=total,
        reverse_fret_drop=reverse_drop, reverse_fret_drop_cost=reverse_cost,
        legal_shape_exception=legal_exception,
        anchor_shape=family.replace("_", "-").replace("_PARTIAL", "") if recognized else "custom",
        barre_fret=base if any(len([n for n in all_notes if n.fret == fret and n.fret > 0]) >= 2 for fret in {n.fret for n in all_notes}) else None,
        finger_mapping=_finger_mapping(all_notes, base), rejected=rejected, rejection_reason=reason,
    )


def active_hand_snapshots(
    melody_notes, accompaniment_notes, *, tolerance: float = 1e-6,
):
    """Return real sounding hand snapshots inside one arrangement window.

    v0.13.5.12.10.1: an Arrangement Window is a search range, not a chord.
    Sequential melody attacks that merely share the same window must never be
    merged into one hand shape. Hard physical rules are evaluated only on the
    notes actually sounding together under the canonical [start, end) rule.
    """
    melody_notes = tuple(melody_notes)
    accompaniment_notes = tuple(accompaniment_notes)
    all_notes = (*melody_notes, *accompaniment_notes)
    attacks = sorted({round(float(n.note.start), 6) for n in all_notes})
    snapshots = []
    melody_ids = {id(n) for n in melody_notes}
    accompaniment_ids = {id(n) for n in accompaniment_notes}
    for onset in attacks:
        active = tuple(
            n for n in all_notes
            if float(n.note.start) <= onset + tolerance
            and float(n.note.start + n.note.duration) > onset + tolerance
        )
        if not active:
            continue
        snapshots.append((
            onset,
            tuple(n for n in active if id(n) in melody_ids),
            tuple(n for n in active if id(n) in accompaniment_ids),
        ))
    return tuple(snapshots)



def evaluate_timed_hand_shape(melody_notes, accompaniment_notes):
    """Validate hand-shape-only rules on each true simultaneous snapshot."""
    worst = None
    for onset, melody, accompaniment in active_hand_snapshots(melody_notes, accompaniment_notes):
        hand = evaluate_hand_shape(melody, accompaniment)
        combined = (*melody, *accompaniment)
        frets = [n.fret for n in combined if n.fret > 0]
        barre_span = (max(frets) - hand.barre_fret) if hand.barre_fret is not None and frets else 0
        if barre_span >= 4:
            return False, hand, onset, "BARRE_OUTWARD_SPAN_LIMIT", barre_span
        if hand.rejected:
            return False, hand, onset, hand.rejection_reason or "HAND_SHAPE_REJECTED", barre_span
        worst = hand if worst is None or hand.total_static_cost > worst.total_static_cost else worst
    if worst is None:
        worst = evaluate_hand_shape((), ())
    return True, worst, None, None, 0

