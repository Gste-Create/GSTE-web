"""v0.11.3 derived roles.  This reads raw events without changing the event model."""
from __future__ import annotations

from dataclasses import replace

from gste.input.project_models import TrackData


def remove_decorative_grace_notes(track: TrackData) -> TrackData:
    """Normalize zero-time notation before fingering candidates are generated.

    Grace notes remain preserved in ``events`` and in the source XML, but do
    not enter the sustained-note occupancy model.  A non-grace zero-duration
    note is also excluded from the derived track and produces an explicit
    warning instead of masquerading as an ordinary playable attack.
    """
    # v0.13.5.13.3: grace identity is structural-event identity, never
    # (pitch,onset). A real main note may legitimately share both pitch and onset
    # with a zero-time grace note; removing by musical signature deleted that
    # real note and later made Final/Serializer mapping impossible.
    grace_ids = {
        str(event.event_id) for event in track.events
        if event.is_grace and event.pitch_midi is not None and getattr(event, "event_id", None)
    }
    zero_duration = [
        note for note in track.notes
        if note.duration <= 0 and str(note.source_event_id or "") not in grace_ids
    ]
    notes = [
        note for note in track.notes
        if str(note.source_event_id or "") not in grace_ids and note.duration > 0
    ]
    warnings = list(track.warnings)
    if zero_duration:
        warnings.append(
            f"Excluded {len(zero_duration)} non-grace zero-duration note(s) before joint fingering; raw events remain available for review."
        )
    if not grace_ids:
        return replace(track, notes=notes, warnings=warnings)
    # v0.13.5.15.6.8: removing decorative notes must never rebuild time.
    # The Parser-owned physical measure grid is immutable derived metadata.
    # A grace note can change membership only; it cannot change measure start,
    # measure length, duration_quarters, or meter context.
    return replace(track, notes=notes, warnings=warnings)


def tie_role_counts(track: TrackData) -> dict[str, int]:
    """Tie stops are sustain-only and must never generate a new pluck candidate."""
    attacks = sum(1 for event in track.events if event.kind == "note" and not event.is_rest and "stop" not in event.tie_types)
    sustains = sum(1 for event in track.events if event.kind == "note" and not event.is_rest and "stop" in event.tie_types)
    return {"attack": attacks, "sustain": sustains, "grace": sum(1 for event in track.events if event.is_grace)}
