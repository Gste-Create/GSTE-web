from __future__ import annotations

from dataclasses import dataclass

from gste.core.models import FingeringCandidate


@dataclass(frozen=True)
class JointPlayabilityEvaluation:
    accepted: bool
    reason: str | None = None
    onset: float | None = None
    string: int | None = None
    melody_fret: int | None = None
    accompaniment_fret: int | None = None
    fret_distance: int = 0


def _active(note: FingeringCandidate, onset: float, tolerance: float) -> bool:
    return note.note.start <= onset + tolerance and note.note.start + note.note.duration > onset + tolerance


def merge_duplicate_accompaniment(
    melody: tuple[FingeringCandidate, ...],
    accompaniment: tuple[FingeringCandidate, ...],
    tolerance: float = 1e-6,
) -> tuple[tuple[FingeringCandidate, ...], tuple[FingeringCandidate, ...]]:
    """Remove accompaniment attacks already supplied by the melody.

    The melody event remains authoritative.  An accompaniment note is a
    duplicate only when pitch, string and fret agree and the sounding
    intervals overlap; same-pitch notes on different strings remain available
    as intentional doublings.
    """
    kept: list[FingeringCandidate] = []
    removed: list[FingeringCandidate] = []
    for note in accompaniment:
        duplicate = any(
            melody_note.note.pitch.midi == note.note.pitch.midi
            and melody_note.string == note.string
            and melody_note.fret == note.fret
            and melody_note.note.start < note.note.start + note.note.duration - tolerance
            and note.note.start < melody_note.note.start + melody_note.note.duration - tolerance
            for melody_note in melody
        )
        (removed if duplicate else kept).append(note)
    return tuple(kept), tuple(removed)


def evaluate_joint_playability(
    melody: tuple[FingeringCandidate, ...],
    accompaniment: tuple[FingeringCandidate, ...],
    *,
    maximum_fret_distance: int = 4,
    tolerance: float = 1e-6,
) -> JointPlayabilityEvaluation:
    """Validate string occupancy and melody/accompaniment hand distance.

    Guitar string 1 is highest and string 6 lowest. Open strings do not require
    a left-hand position, so they are excluded from the fret-distance gate.
    Every attack is checked against all notes still sounding at that instant.
    """
    all_notes = (*melody, *accompaniment)
    onsets = sorted({round(note.note.start, 6) for note in all_notes})
    melody_ids = {id(note) for note in melody}
    accompaniment_ids = {id(note) for note in accompaniment}
    for onset in onsets:
        active = tuple(note for note in all_notes if _active(note, onset, tolerance))
        for left_index, left in enumerate(active):
            for right in active[left_index + 1:]:
                if left.string != right.string or left.fret == right.fret:
                    continue
                return JointPlayabilityEvaluation(
                    False, "ACTIVE_STRING_OCCUPANCY", onset, left.string,
                    left.fret if id(left) in melody_ids else right.fret,
                    right.fret if id(right) in accompaniment_ids else left.fret,
                    abs(left.fret - right.fret),
                )
        active_melody = tuple(note for note in active if id(note) in melody_ids and note.fret > 0)
        active_accompaniment = tuple(note for note in active if id(note) in accompaniment_ids and note.fret > 0)
        for melody_note in active_melody:
            for accompaniment_note in active_accompaniment:
                distance = abs(melody_note.fret - accompaniment_note.fret)
                if distance > maximum_fret_distance:
                    return JointPlayabilityEvaluation(
                        False, "MELODY_ACCOMPANIMENT_FRET_DISTANCE", onset,
                        accompaniment_note.string, melody_note.fret,
                        accompaniment_note.fret, distance,
                    )
    return JointPlayabilityEvaluation(True)
