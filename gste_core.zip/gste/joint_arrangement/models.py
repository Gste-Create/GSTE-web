from __future__ import annotations

from dataclasses import dataclass, field

from gste.core.models import FingeringCandidate
from gste.harmony.models import ChordFamilyCandidate


@dataclass(frozen=True)
class AccompanimentCandidate:
    name: str
    notes: tuple[FingeringCandidate, ...]
    local_cost: float
    omitted_required_tones: int = 0
    source_bass_pitch: int | None = None
    output_bass_pitch: int | None = None
    bass_identity_rank: int = 6
    bass_role: str = "UNKNOWN_BASS"
    bass_substitution_reason: str = "no_source_bass"
    # v0.11.6: preserve the source-harmony decision separately from the guitar
    # reduction.  This makes it auditable when a difficult voicing is reduced.
    source_harmony_locked: bool = False
    tone_roles: tuple[str, ...] = ()
    pruned_roles: tuple[str, ...] = ()
    pruning_reasons: tuple[str, ...] = ()
    # v0.11.8: auditable accompaniment-only adaptation.  Melody candidates
    # remain immutable throughout the joint arranger.
    candidate_type: str = "A_ORIGINAL"
    modifications: tuple[str, ...] = ()
    omitted_pitch_classes: tuple[int, ...] = ()
    raised_octave_pitch_classes: tuple[int, ...] = ()
    harmony_coverage: tuple[int, ...] = ()

    @property
    def position(self) -> float:
        fretted = [n.fret for n in self.notes if n.fret > 0]
        return 0.0 if not fretted else sum(fretted) / len(fretted)

    @property
    def non_open_count(self) -> int:
        return sum(1 for n in self.notes if n.fret > 0)


@dataclass(frozen=True)
class MelodyPathCandidate:
    notes: tuple[FingeringCandidate, ...]
    local_cost: float

    @property
    def position(self) -> float:
        fretted = [n.fret for n in self.notes if n.fret > 0]
        return 0.0 if not fretted else sum(fretted) / len(fretted)


@dataclass(frozen=True)
class JointWindowCandidate:
    window_id: str
    measure: int
    start: float
    duration: float
    melody: MelodyPathCandidate
    harmony: ChordFamilyCandidate
    accompaniment: AccompanimentCandidate
    local_cost: float
    cost_breakdown: dict[str, float | str] = field(default_factory=dict)
    transition_cost: float = 0.0
    transition_breakdown: dict[str, float | str] = field(default_factory=dict)
    simplification_level: int = 0
    removed_notes: tuple[str, ...] = ()
    # v0.12.4: concrete combined melody/accompaniment left-hand state.
    # Entries are (string, fret, finger), finger 1=index … 4=pinky.
    finger_assignment: tuple[tuple[int, int, int], ...] = ()

    @property
    def source_bass_pitch(self) -> int | None:
        return self.accompaniment.source_bass_pitch

    @property
    def output_bass_pitch(self) -> int | None:
        return self.accompaniment.output_bass_pitch

    @property
    def bass_identity_rank(self) -> int:
        return self.accompaniment.bass_identity_rank

    @property
    def bass_role(self) -> str:
        return self.accompaniment.bass_role

    @property
    def bass_substitution_reason(self) -> str:
        return self.accompaniment.bass_substitution_reason

    @property
    def source_harmony_locked(self) -> bool:
        return self.accompaniment.source_harmony_locked


@dataclass(frozen=True)
class WindowDiagnostic:
    """Audit information for one joint-arrangement window (v0.11.3)."""
    window_id: str
    measure: int
    beat: float
    melody_notes: tuple[str, ...]
    accompaniment_notes: tuple[str, ...]
    raw_candidates: int
    after_string_conflict: int
    after_fret_span: int
    after_stretch: int
    after_sustain_conflict: int
    after_dp_transition: int
    first_zero_stage: str | None = None
    failure_reason: str | None = None
    simplification_level: int = 0
    removed_notes: tuple[str, ...] = ()
    # v0.13.5.12.3.1 diagnostic-only unique topology cohort. These counts are
    # monotonic and avoid assignment/branch multiplicity in legacy counters.
    unique_raw_topologies: int = 0
    unique_after_fret_span: int = 0
    unique_after_playability: int = 0
    unique_after_local_cost: int = 0
    duplicate_merge_events: int = 0


@dataclass(frozen=True)
class JointArrangementResult:
    selected: tuple[JointWindowCandidate, ...]
    candidate_layers: tuple[tuple[JointWindowCandidate, ...], ...]
    total_cost: float
    warnings: tuple[str, ...] = ()
    diagnostics: tuple[WindowDiagnostic, ...] = ()
    # v0.13.5.15.4 read-only pipeline counters. These never affect selection.
    debug_counters: dict[str, int] = field(default_factory=dict)
    # v0.13.5.15.5 observer-only global path-search evidence. Never used for selection.
    debug_observations: dict[str, object] = field(default_factory=dict)
