from __future__ import annotations

from dataclasses import dataclass

from gste.core.models import FingeringCandidate
from gste.joint_arrangement.joint_playability import JointPlayabilityEvaluation
from gste.fingering.canonical_validator import CanonicalHandNote, validate_canonical_timeline


@dataclass(frozen=True)
class SimultaneousSpanEvaluation:
    """Result of the v0.12.6 simultaneous left-hand span hard constraint."""

    accepted: bool
    fret_span: int
    maximum_allowed_span: int
    highest_fret_string: int | None
    onset: float | None
    position: str


def _active_at(note: FingeringCandidate, onset: float, tolerance: float) -> bool:
    start = note.note.start
    end = start + note.note.duration
    return start <= onset + tolerance and end > onset + tolerance


def _canonical_notes_from_candidates(notes: tuple[FingeringCandidate, ...], role: str = "unknown") -> tuple[CanonicalHandNote, ...]:
    return tuple(CanonicalHandNote(
        role=role, string=n.string, fret=n.fret, start=float(n.note.start),
        end=float(n.note.start + n.note.duration), pitch=n.note.pitch.midi,
        measure=getattr(n.note, "measure", None), source_id=n.note.source_event_id,
    ) for n in notes)


def evaluate_simultaneous_span(
    notes: tuple[FingeringCandidate, ...], tolerance: float = 1e-6,
) -> SimultaneousSpanEvaluation:
    """Compatibility wrapper over the canonical all-boundary timeline validator."""
    canon = _canonical_notes_from_candidates(notes)
    issues = validate_canonical_timeline(canon, maximum_fret_distance=10_000, tolerance=tolerance)
    span_issues = [i for i in issues if i.violation_type in {"SIMULTANEOUS_FRET_SPAN", "DIRECTIONAL_SIMULTANEOUS_FRET_SPAN"}]
    if span_issues:
        i = span_issues[0]
        return SimultaneousSpanEvaluation(False, int(i.span or 0), int(i.allowed_span or 4), i.highest_fret_string, i.time, i.position or "unknown")
    # Preserve useful diagnostic of the widest legal fretted snapshot.
    boundaries = sorted({round(float(n.note.start), 6) for n in notes} | {round(float(n.note.start+n.note.duration), 6) for n in notes})
    worst = SimultaneousSpanEvaluation(True, 0, 4, None, None, "empty_or_open")
    for onset in boundaries:
        active = [n for n in notes if n.note.start <= onset + tolerance and n.note.start+n.note.duration > onset+tolerance and n.fret > 0]
        if not active:
            continue
        low=min(n.fret for n in active); high=max(n.fret for n in active); span=high-low
        hs=min(n.string for n in active if n.fret==high); top=min(n.string for n in active); bottom=max(n.string for n in active)
        if hs==top: allowed,pos=4,"highest_string"
        elif hs==bottom: allowed,pos=2,"lowest_string"
        else: allowed,pos=3,"middle_string"
        cur=SimultaneousSpanEvaluation(True, span, allowed, hs, onset, pos)
        if span > worst.fret_span:
            worst=cur
    return worst


def validate_joint_sounding_hand_shape(
    melody_notes: tuple[FingeringCandidate, ...] = (),
    accompaniment_notes: tuple[FingeringCandidate, ...] = (),
    sustained_notes: tuple[FingeringCandidate, ...] = (),
    tolerance: float = 1e-6,
) -> SimultaneousSpanEvaluation:
    """Canonical v0.13.3.4 joint hand-span hard gate.

    Melody, accompaniment and explicitly supplied sustained notes are merged
    before validation.  Callers must never validate melody/accompaniment in
    isolation and then assume their union is playable.
    """
    return evaluate_simultaneous_span(
        tuple(melody_notes) + tuple(accompaniment_notes) + tuple(sustained_notes),
        tolerance=tolerance,
    )


@dataclass(frozen=True)
class CanonicalSoundingHandEvaluation:
    accepted: bool
    span: SimultaneousSpanEvaluation
    playability: JointPlayabilityEvaluation
    reason: str | None = None


def validate_canonical_sounding_hand(
    melody_notes: tuple[FingeringCandidate, ...] = (),
    accompaniment_notes: tuple[FingeringCandidate, ...] = (),
    sustained_melody_notes: tuple[FingeringCandidate, ...] = (),
    sustained_accompaniment_notes: tuple[FingeringCandidate, ...] = (),
    *,
    maximum_fret_distance: int = 4,
    tolerance: float = 1e-6,
) -> CanonicalSoundingHandEvaluation:
    """Candidate/DP adapter to the single canonical physical validator."""
    melody = tuple(melody_notes) + tuple(sustained_melody_notes)
    accompaniment = tuple(accompaniment_notes) + tuple(sustained_accompaniment_notes)
    canon = _canonical_notes_from_candidates(melody, "melody") + _canonical_notes_from_candidates(accompaniment, "accompaniment")
    issues = validate_canonical_timeline(canon, maximum_fret_distance=maximum_fret_distance, tolerance=tolerance)
    span = evaluate_simultaneous_span(melody + accompaniment, tolerance=tolerance)
    if issues:
        issue = issues[0]
        playability = JointPlayabilityEvaluation(
            False, issue.violation_type, issue.time, issue.string,
            issue.melody_fret, issue.accompaniment_fret, int(issue.distance or issue.span or 0),
        )
        reason = 'SIMULTANEOUS_FRET_SPAN_LIMIT' if issue.violation_type in {'SIMULTANEOUS_FRET_SPAN','DIRECTIONAL_SIMULTANEOUS_FRET_SPAN'} else issue.violation_type
        return CanonicalSoundingHandEvaluation(False, span, playability, reason)
    return CanonicalSoundingHandEvaluation(True, span, JointPlayabilityEvaluation(True), None)

