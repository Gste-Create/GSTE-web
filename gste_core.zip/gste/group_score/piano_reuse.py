from __future__ import annotations
from dataclasses import asdict, dataclass
from typing import Any
from gste.arrangement.source_adapters.piano import analyze_piano_accompaniment
from .models import GroupRoleContribution
from .profiles import role_weight

@dataclass(frozen=True)
class InstrumentAnalysisSpec:
    source_id: str
    instrument_family: str
    project: Any
    user_weight: float = 1.0


def analyze_instruments_with_piano_pipeline(specs, *, profiles=None, **analysis_kwargs):
    """v0.2.4 group-score analysis front end.

    Reuses ONE piano accompaniment analysis implementation for accompaniment-like
    tracks/projects. Instrument identity only changes role weights and provenance;
    it never forks the harmony/bass/texture/rhythm algorithms.
    """
    out=[]
    for spec in specs:
        _raw,bundle=analyze_piano_accompaniment(spec.project,**analysis_kwargs)
        for role,values in (("HARMONY",bundle.harmony),("BASS",bundle.bass),("TEXTURE",bundle.texture),("RHYTHM",bundle.rhythm)):
            w=max(0.0,float(spec.user_weight))*role_weight(spec.instrument_family,role,profiles=profiles)
            if w<=0 or not values: continue
            out.append(GroupRoleContribution(
                source_id=spec.source_id, role=role, payload=values, priority=w,
                origin=f"ORIGINAL_GROUP_SCORE:{spec.instrument_family.upper()}",
                metadata={"instrument_family":spec.instrument_family.upper(),"analysis_pipeline":"SHARED_ACCOMPANIMENT_ANALYZER",
                    "tonality_analysis":asdict(bundle.tonality_analysis),
                    "canonical_by_window":{c.window_id:c for c in bundle.canonical},
                    "observations_by_window":{c.window_id:c.observations for c in bundle.canonical},
                    "event_ids_by_window":{c.window_id:tuple(eid for e in c.evidence for eid in e.event_ids) for c in bundle.canonical}},
            ))
    return tuple(out)
