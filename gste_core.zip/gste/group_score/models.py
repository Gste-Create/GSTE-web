from dataclasses import dataclass, field
from typing import Any

@dataclass(frozen=True)
class GroupRoleContribution:
    source_id: str
    role: str
    payload: Any
    priority: float=1.0
    origin: str='ORIGINAL_GROUP_SCORE'
    alternatives: tuple[Any,...]=()
    metadata: dict[str,Any]=field(default_factory=dict)

@dataclass(frozen=True)
class UnifiedAccompanimentBundle:
    """Single pre-Pre-Joint musical-intent carrier; never contains fingering logic."""
    harmony: tuple[Any,...]=()
    bass: tuple[Any,...]=()
    texture: tuple[Any,...]=()
    rhythm: tuple[Any,...]=()
    priority: tuple[tuple[str,float],...]=()
    source_origin: tuple[tuple[str,str],...]=()
    alternatives: tuple[Any,...]=()
    metadata: dict[str,Any]=field(default_factory=dict)

    def pre_joint_intent_list(self):
        """One bounded semantic list for Pre-Joint; not four source-track copies."""
        return tuple((family,item) for family,items in (
            ("HARMONY",self.harmony),("BASS",self.bass),("TEXTURE",self.texture),("RHYTHM",self.rhythm)
        ) for item in items)
