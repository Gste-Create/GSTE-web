from __future__ import annotations
from dataclasses import replace
from gste.core.models import NoteEvent


def select_source_events_for_prejoint(*, bundle, tracks_by_source, melody_track):
    """v0.2.4 bridge: fused musical intent -> retained ORIGINAL source events.

    This layer does not generate fingering, chord voicings, or guitar shapes.
    It only maps the sources retained by three-stage Group Fusion back to their
    original NoteEvents. Missing musical roles are reported; generators may fill
    those roles before the common Piano-style accompaniment contract is built.
    """
    trace=tuple(bundle.metadata.get('three_stage_trace',()))
    kept_sources={r.get('source_id') for r in trace if r.get('stage')=='ARRANGEMENT_REDUCTION' and r.get('decision')=='KEEP'}
    kept_sources.discard(None)
    notes=[]
    seen=set()
    for sid in sorted(kept_sources):
        track=tracks_by_source.get(sid)
        if track is None: continue
        for n in track.notes:
            key=(str(n.source_event_id or ''),round(n.start,6),round(n.duration,6),n.pitch.midi,sid)
            if key in seen: continue
            seen.add(key)
            notes.append(replace(n, source_type='group_score_source', source_variant=sid))
    # Defensive fallback: if semantic analysis retained no source (e.g. all-rest
    # excerpt), preserve the strongest available source rather than invent notes.
    if not notes and tracks_by_source:
        sid=sorted(tracks_by_source)[0]
        notes=[replace(n, source_type='group_score_source', source_variant=sid) for n in tracks_by_source[sid].notes]
    notes.sort(key=lambda n:(n.start,n.pitch.midi,n.duration,str(n.source_event_id or '')))
    missing=[]
    if not bundle.harmony: missing.append('HARMONY')
    if not bundle.bass: missing.append('BASS')
    if not bundle.texture: missing.append('TEXTURE')
    if not bundle.rhythm: missing.append('RHYTHM')
    return replace(melody_track, track_id='group_fused_accompaniment', role='accompaniment', notes=notes, events=[]), tuple(sorted(kept_sources)), tuple(missing)
