from __future__ import annotations

# v0.2.4: role weights are configuration, not duplicated analyzers.
DEFAULT_INSTRUMENT_ROLE_WEIGHTS = {
    "PIANO": {"HARMONY":1.00,"BASS":0.90,"TEXTURE":1.00,"RHYTHM":1.00},
    "PIANO_ACCOMPANIMENT": {"HARMONY":1.00,"BASS":0.90,"TEXTURE":1.00,"RHYTHM":1.00},
    "RHYTHM_GUITAR": {"HARMONY":1.00,"BASS":0.30,"TEXTURE":0.90,"RHYTHM":1.00},
    "LEAD_GUITAR": {"HARMONY":1.00,"BASS":0.30,"TEXTURE":0.90,"RHYTHM":1.00},
    "GUITAR": {"HARMONY":1.00,"BASS":0.30,"TEXTURE":0.90,"RHYTHM":1.00},
    "BASS": {"HARMONY":0.35,"BASS":1.00,"TEXTURE":0.20,"RHYTHM":0.80},
    "BASS_GUITAR": {"HARMONY":0.35,"BASS":1.00,"TEXTURE":0.20,"RHYTHM":0.80},
}

def role_weight(instrument_family: str, role: str, *, profiles=None) -> float:
    table=profiles or DEFAULT_INSTRUMENT_ROLE_WEIGHTS
    fam=str(instrument_family or "PIANO_ACCOMPANIMENT").upper()
    return float(table.get(fam, table["PIANO_ACCOMPANIMENT"]).get(str(role).upper(), 0.0))
