from __future__ import annotations
from dataclasses import replace
from .models import GroupRoleContribution, UnifiedAccompanimentBundle

_FAMILIES={
 'HARMONY':{'HARMONY','CHORD','PIANO_HARMONY'}, 'BASS':{'BASS'},
 'TEXTURE':{'TEXTURE','RHYTHM_GUITAR_TEXTURE'}, 'RHYTHM':{'RHYTHM','RHYTHM_GUITAR'} }

def _family(role):
    r=role.upper()
    for fam,names in _FAMILIES.items():
        if r in names:return fam
    raise ValueError(f'Unsupported accompaniment role: {role}')

def _values(x): return tuple(x) if isinstance(x,(tuple,list)) else (x,)
def _confidence(x):
    try:return max(0.0,min(1.0,float(getattr(x,'confidence',1.0))))
    except Exception:return 1.0

def _window(x):
    s=getattr(x,'start',None); d=getattr(x,'duration',None)
    if isinstance(s,(int,float)) and isinstance(d,(int,float)): return (round(float(s),6),round(float(d),6))
    return (None,None)

def _semantic_key(fam,x):
    win=_window(x)
    # Confidence is evidence strength, not content. Preserve all musical
    # distinctions before deduplication; window IDs are aliases on a shared grid.
    fields = {
        'HARMONY': ('root_pitch_class','quality','chord_symbol','required_pitch_classes',
                    'optional_pitch_classes','color_pitch_classes','bass_relation'),
        'BASS': ('primary_pitch','pitch_class','motion','structural_role','chord_role','bass_sequence'),
        'TEXTURE': ('pattern_type','density','bass_separation','continuity_group'),
        'RHYTHM': ('rhythm_pattern','attack_sizes','density','syncopation','accent_positions'),
    }
    def frozen(value):
        if isinstance(value,(list,tuple)): return tuple(frozen(v) for v in value)
        if isinstance(value,dict): return tuple(sorted((k,frozen(v)) for k,v in value.items()))
        return value
    return win+tuple(frozen(getattr(x,k,None)) for k in fields[fam])


def merge_group_accompaniment(contributions, *, diagnostics_dir=None, analysis_floor=.12, family_limits=None):
    """v0.2.3 three-stage convergence before Pre-Joint.

    1 ANALYSIS_PRUNE: reject only extremely weak weighted evidence.
    2 GROUP_FUSION: merge semantically duplicate evidence, retaining provenance.
    3 ARRANGEMENT_REDUCTION: bound each semantic family before hand-shape search.
    No fingering/playability decision is made here.
    """
    family_limits=family_limits or {'HARMONY':3,'BASS':2,'TEXTURE':3,'RHYTHM':3}
    staged=[]; trace=[]; pri=[]; origins=[]; alts=[]
    for c in contributions:
        if not isinstance(c,GroupRoleContribution): raise TypeError('Expected GroupRoleContribution')
        fam=_family(c.role); pri.append((c.source_id,float(c.priority))); origins.append((c.source_id,c.origin)); alts.extend(c.alternatives)
        for x in _values(c.payload):
            score=max(0.0,float(c.priority))*_confidence(x)
            rec={'family':fam,'source_id':c.source_id,'origin':c.origin,'score':score,'semantic_key':repr(_semantic_key(fam,x))}
            if score < analysis_floor:
                trace.append({**rec,'stage':'ANALYSIS_PRUNE','decision':'REJECT','reason':'BELOW_WEIGHTED_EVIDENCE_FLOOR'}); continue
            staged.append((fam,x,score,c)); trace.append({**rec,'stage':'ANALYSIS_PRUNE','decision':'KEEP'})
    # Stage 2: duplicate semantic evidence collapses to one intent; strongest representation wins.
    fused={}
    for fam,x,score,c in staged:
        key=(fam,_semantic_key(fam,x)); old=fused.get(key)
        if old is None or score>old[1]:
            if old is not None: trace.append({'family':fam,'source_id':old[2].source_id,'score':old[1],'stage':'GROUP_FUSION','decision':'MERGED','reason':f'DUPLICATE_OF:{c.source_id}'})
            fused[key]=(x,score,c)
        else:
            trace.append({'family':fam,'source_id':c.source_id,'score':score,'stage':'GROUP_FUSION','decision':'MERGED','reason':f'DUPLICATE_OF:{old[2].source_id}'})
    # Stage 3: reduction is local to overlapping time windows/families, not a global winner-takes-all.
    selected={k:[] for k in _FAMILIES}; grouped={}
    for (fam,key),(x,score,c) in fused.items(): grouped.setdefault((fam,_window(x)),[]).append((x,score,c))
    for (fam,win),rows in grouped.items():
        rows.sort(key=lambda z:(-z[1],z[2].source_id,repr(_semantic_key(fam,z[0])))); limit=max(1,int(family_limits.get(fam,len(rows))))
        for i,(x,score,c) in enumerate(rows):
            keep=i<limit
            trace.append({'family':fam,'source_id':c.source_id,'score':score,'stage':'ARRANGEMENT_REDUCTION','decision':'KEEP' if keep else 'OMIT','reason':'WITHIN_FAMILY_LIMIT' if keep else 'LOWER_WEIGHTED_ALTERNATIVE'})
            if keep:selected[fam].append(x)
    bundle=UnifiedAccompanimentBundle(tuple(selected['HARMONY']),tuple(selected['BASS']),tuple(selected['TEXTURE']),tuple(selected['RHYTHM']),tuple(pri),tuple(origins),tuple(alts),{
        'analysis_floor':analysis_floor,'source_count':len(pri),'schema_version':'GSTE_GROUP_FUSION_V0.2.4','three_stage_trace':tuple(trace),
        'pre_joint_intent_count':sum(len(v) for v in selected.values()),'policy':'analysis_prune -> group_fusion -> arrangement_reduction -> pre_joint'
    })
    if diagnostics_dir is not None:
        from .diagnostics import write_group_score_diagnostics
        write_group_score_diagnostics(contributions,bundle,diagnostics_dir)
    return bundle
