"""Fusion ends as the SAME AccompanimentData used by a single source."""
from dataclasses import replace
from gste.arrangement.canonical import CanonicalArrangementIntent, SourceEvidence
from gste.arrangement.data_contract import AccompanimentData
from .merger import _semantic_key, _window, _family, _values, _confidence


def to_accompaniment_data(bundle, contributions):
    families={'HARMONY':bundle.harmony,'BASS':bundle.bass,'RHYTHM':bundle.rhythm,'TEXTURE':bundle.texture}
    windows=sorted({_window(x) for xs in families.values() for x in xs})
    out=[]
    for win in windows:
        chosen={}; owners={}; evidence=[]; alternatives={}; source_rows={}
        for family, values in families.items():
            rows=[]
            for x in values:
                if _window(x)!=win: continue
                matches=[(c,v) for c in contributions if _family(c.role)==family
                         for v in _values(c.payload)
                         if _semantic_key(family,v)==_semantic_key(family,x)
                         and c.priority*_confidence(v)>=bundle.metadata.get('analysis_floor',.12)]
                if not matches: raise ValueError('FUSION_PROVENANCE_MISSING:'+family)
                # Use each source item's confidence; never apply x's winning
                # confidence to all sources. Prefer the actual fused object.
                matches.sort(key=lambda pair:(-pair[0].priority*_confidence(pair[1]),
                                              pair[1] is not x,pair[0].source_id))
                winner=matches[0]
                rows.append((winner[0].priority*_confidence(winner[1]),winner[0].source_id,x,matches))
            if not rows: raise ValueError('FUSION_COMPONENT_MISSING:'+family+':'+str(win))
            rows.sort(key=lambda row:(-row[0],row[1],repr(_semantic_key(family,row[2]))))
            _,_,x,matches=rows[0]; owner,original=matches[0]
            chosen[family]=x;owners[family]=owner
            alternatives[family]=tuple(row[2] for row in rows[1:])
            source_rows[family]=owner.metadata.get('canonical_by_window',{}).get(original.window_id)
            for c,v in matches:
                ids=c.metadata.get('event_ids_by_window',{}).get(v.window_id,())
                evidence.append(SourceEvidence(c.origin,c.source_id,_confidence(v),c.priority,
                    {'component':family,'selected':c is owner and v is original,
                     'weighted_score':c.priority*_confidence(v),'matched_window':v.window_id},tuple(ids)))
        h=chosen['HARMONY'];wid=h.window_id
        parts={key:replace(value,window_id=wid) for key,value in chosen.items()}
        bass=parts['BASS'];harmony=parts['HARMONY']
        interval=None if bass.pitch_class is None else (bass.pitch_class-harmony.root_pitch_class)%12
        relation='UNKNOWN' if interval is None else ('NON_CHORD_OR_EXTENSION' if bass.pitch_class not in (harmony.root_pitch_class,*harmony.required_pitch_classes,*harmony.optional_pitch_classes,*harmony.color_pitch_classes) else ('ROOT' if interval==0 else ('THIRD' if interval in (3,4) else ('FIFTH' if interval in (6,7,8) else 'CHORD_TONE'))))
        parts['HARMONY']=replace(harmony,bass_relation=relation)
        parts['BASS']=replace(bass,chord_role=relation)
        # Retain every component's original metadata and record ownership.
        component_metadata={key:dict(c.metadata) for key,c in source_rows.items() if c is not None}
        metadata={}; conflicts={}
        for key,values in component_metadata.items():
            for name,value in values.items():
                if name in metadata and metadata[name]!=value:
                    conflicts.setdefault(name,{})[key]=value
                else: metadata.setdefault(name,value)
        # Policy owners: harmony interpretation, bass policy, rhythm grouping,
        # and texture phrase/section come from their selected component producer.
        policy_fields={'HARMONY':('harmony_root_smoothed','harmony_family_context_resolved','harmony_resolution_reason'),
                       'BASS':('bass_policy','bass_resolution','bass_context'),
                       'RHYTHM':('metric_group_refs','metric_group_patterns','metric_group_attack_counts','repeated_metric_pattern','metric_trace_status'),
                       'TEXTURE':('minimum_context_measures',)}
        for key,names in policy_fields.items():
            for name in names:
                if name in component_metadata.get(key,{}): metadata[name]=component_metadata[key][name]
        refs=[tuple(values['metric_group_refs']) for values in component_metadata.values() if values.get('metric_group_refs')]
        if refs and len(set(refs))!=1: raise ValueError('FUSION_METRIC_GROUP_CONFLICT:'+wid)
        metadata.update(fusion_alternatives=alternatives,component_sources={key:c.source_id for key,c in owners.items()},
                        component_metadata=component_metadata,metadata_conflicts=conflicts)
        texture_row=source_rows.get('TEXTURE');rhythm_row=source_rows.get('RHYTHM')
        # All observations support evidence validation. Identity deduplication
        # avoids multiplying the same source facts once per semantic family.
        observations={}
        for c in contributions:
            for ns in c.metadata.get('observations_by_window',{}).values():
                for n in ns:
                    if win[0]<=n.onset<win[0]+win[1]: observations.setdefault(n.event_id,n)
        out.append(CanonicalArrangementIntent(wid,parts['HARMONY'],parts['BASS'],parts['RHYTHM'],parts['TEXTURE'],
            texture_row.phrase if texture_row else None,tuple(evidence),metadata,
            texture_row.section if texture_row else None,observations=tuple(observations.values()),
            functional_roles=rhythm_row.functional_roles if rhythm_row else ()))
    return AccompanimentData(tuple(out),preserve_rhythm=True)
