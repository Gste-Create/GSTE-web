from __future__ import annotations
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any
import json, math

def _plain(x: Any):
    if is_dataclass(x):
        return {k:_plain(v) for k,v in asdict(x).items()}
    if isinstance(x, dict): return {str(k):_plain(v) for k,v in x.items()}
    if isinstance(x, (tuple,list)): return [_plain(v) for v in x]
    return x

def _window(payload: Any):
    """Best-effort time window used only for diagnostics, never arrangement."""
    vals = payload if isinstance(payload,(tuple,list)) else (payload,)
    starts=[]; ends=[]
    for v in vals:
        s=getattr(v,"start",None); d=getattr(v,"duration",None)
        if isinstance(s,(int,float)) and math.isfinite(float(s)):
            starts.append(float(s))
            if isinstance(d,(int,float)) and math.isfinite(float(d)):
                ends.append(float(s)+max(0.0,float(d)))
    return (min(starts), max(ends) if ends else min(starts)) if starts else (None,None)

def build_group_score_diagnostics(contributions, bundle):
    intents=[]; provenance=[]; conflicts=[]
    seen_sources=set()
    for idx,c in enumerate(contributions):
        start,end=_window(c.payload)
        if not c.source_id:
            conflicts.append({"severity":"HARD_ERROR","code":"MISSING_SOURCE_ID","contribution_index":idx})
        if (c.source_id,c.role) in seen_sources:
            conflicts.append({"severity":"STRUCTURAL_WARNING","code":"DUPLICATE_SOURCE_ID","source_id":c.source_id})
        seen_sources.add((c.source_id,c.role))
        rec={
            "source_id":c.source_id,"role":c.role,"origin":c.origin,
            "priority":float(c.priority),"time_start":start,"time_end":end,
            "payload":_plain(c.payload),"alternatives":_plain(c.alternatives),"metadata":_plain(getattr(c,"metadata",{})),
        }
        intents.append(rec)
        provenance.append({
            "contribution_index":idx,"source_id":c.source_id,"role":c.role,
            "origin":c.origin,"priority":float(c.priority),
            "target_family":_target_family(c.role),
            "time_start":start,"time_end":end,
        })
        if not math.isfinite(float(c.priority)) or float(c.priority) < 0:
            conflicts.append({"severity":"HARD_ERROR","code":"INVALID_PRIORITY","source_id":c.source_id,"value":c.priority})
        if start is not None and end is not None and end < start:
            conflicts.append({"severity":"HARD_ERROR","code":"INVALID_TIME_WINDOW","source_id":c.source_id,"start":start,"end":end})

    # Multiple sources feeding the same semantic family are not automatically wrong:
    # surface them for later musical arbitration while preserving all evidence.
    fam={}
    for p in provenance: fam.setdefault(p["target_family"],[]).append(p["source_id"])
    for family,sources in fam.items():
        uniq=sorted(set(sources))
        if family in {"HARMONY","BASS","TEXTURE","RHYTHM"} and len(uniq)>1:
            conflicts.append({
                "severity":"MUSICAL_WARNING","code":"MULTI_SOURCE_ROLE_COMPETITION",
                "family":family,"sources":uniq,
                "message":"Multiple group-score sources contribute to the same musical family; no automatic winner was chosen."
            })

    return {
        "schema_version":"GSTE_GROUP_MONITOR_V0.2.3",
        "route":"GROUP_SCORE",
        "intent_monitor":{"contribution_count":len(intents),"contributions":intents},
        "conflict_diagnostics":{
            "hard_error_count":sum(x["severity"]=="HARD_ERROR" for x in conflicts),
            "warning_count":sum(x["severity"]!="HARD_ERROR" for x in conflicts),
            "conflicts":conflicts,
            "policy":"Diagnostics observe and report; they never alter arrangement intent."
        },
        "provenance_trace":{"records":provenance},
        "decision_trace":{"records":_plain(bundle.metadata.get("three_stage_trace",()))},
        "monitor_scope":{"rule":"OBSERVE_ONLY","owns_musical_decisions":False,"owns_fingering_decisions":False},
        "merged_bundle":_plain(bundle),
    }

def _target_family(role:str):
    r=role.upper()
    if r in {"HARMONY","CHORD","PIANO_HARMONY"}: return "HARMONY"
    if r=="BASS": return "BASS"
    if r in {"TEXTURE","RHYTHM_GUITAR_TEXTURE"}: return "TEXTURE"
    if r in {"RHYTHM","RHYTHM_GUITAR"}: return "RHYTHM"
    return r

def write_group_score_diagnostics(contributions,bundle,output_dir):
    out=Path(output_dir); out.mkdir(parents=True,exist_ok=True)
    data=build_group_score_diagnostics(contributions,bundle)
    files={
        "intent_monitor":out/"02_GROUP_SCORE_INTENT_MONITOR.json",
        "conflicts":out/"03_GROUP_SCORE_CONFLICT_DIAGNOSTICS.json",
        "provenance":out/"04_GROUP_SCORE_PROVENANCE_TRACE.json",
        "decisions":out/"05_GROUP_SCORE_DECISION_TRACE.json",
    }
    files["intent_monitor"].write_text(json.dumps(data["intent_monitor"],ensure_ascii=False,indent=2),encoding="utf-8")
    files["conflicts"].write_text(json.dumps(data["conflict_diagnostics"],ensure_ascii=False,indent=2),encoding="utf-8")
    files["provenance"].write_text(json.dumps(data["provenance_trace"],ensure_ascii=False,indent=2),encoding="utf-8")
    files["decisions"].write_text(json.dumps(data["decision_trace"],ensure_ascii=False,indent=2),encoding="utf-8")
    return files
