from __future__ import annotations
from dataclasses import dataclass
from gste.arrangement.canonical import PhraseIntent

@dataclass(frozen=True)
class ContextWindow:
    context_id: str
    start: float
    duration: float
    local_window_ids: tuple[str,...]
    minimum_measures: int = 2

@dataclass(frozen=True)
class ExpressionTransition:
    window_id: str
    score: float
    reasons: tuple[str,...]

@dataclass(frozen=True)
class PhraseUnderstandingPlan:
    contexts: tuple[ContextWindow,...]
    phrases: tuple[PhraseIntent,...]
    transitions: tuple[ExpressionTransition,...]
    harmonic_roots: tuple[int,...]
    structural_bass_flags: tuple[bool,...]
    harmonic_qualities: tuple[str,...] = ()
    harmonic_symbols: tuple[str,...] = ()
    harmony_resolution_reasons: tuple[str,...] = ()
