from __future__ import annotations

import re
from statistics import median

from gste.arrangement.canonical import PhraseIntent
from gste.harmony.library import basic_chord_families, chord_family_name
from .context_window import build_context_windows
from .model import ExpressionTransition, PhraseUnderstandingPlan


def _melody_features(project, start, end):
    notes=[n for n in project.melody.notes if n.start < end and n.start+n.duration > start]
    attacks=[n for n in notes if start<=n.start<end]
    density=len(attacks)/max(.25,end-start)
    pitches=[n.pitch.midi for n in notes]
    return density,(sum(pitches)/len(pitches) if pitches else 0.0),(max(pitches)-min(pitches) if pitches else 0)


def _measure_number(window_id: str) -> int | None:
    match=re.search(r"M(\d+)",str(window_id))
    return int(match.group(1)) if match else None


def _typical_measure_length(project) -> float:
    lengths=list(getattr(project.left_hand,"measure_lengths",{}).values())
    return float(median(lengths)) if lengths else 4.0


def _structural_bass(analyses, contexts):
    flags=[]
    for a,c in zip(analyses,contexts):
        run=[x for x in analyses if x.window_id in c.local_window_ids and x.bass_sequence]
        pcs=[x.bass_sequence[0]%12 for x in run]
        root_matches=sum(1 for x in run if x.bass_sequence and x.bass_sequence[0]%12==x.root_pitch_class)
        flags.append(len(run)>=3 and len(set(pcs))>=2 and root_matches/max(1,len(run))>=.6)
    return tuple(flags)


def _upper_pcs(analysis) -> set[int]:
    return {int(n.pitch_class)%12 for n in getattr(analysis,"notes",()) if not bool(getattr(n,"is_bass",False))}


def _jaccard(a:set[int],b:set[int]) -> float:
    if not a and not b:return 1.0
    u=a|b
    return len(a&b)/len(u) if u else 0.0


def _is_sparse_harmony_evidence(a) -> bool:
    pcs={int(n.pitch_class)%12 for n in getattr(a,"notes",())}
    return (
        a.harmony_confidence < .56
        or len(pcs) <= 1
        or (getattr(a,"max_simultaneous_notes",0) <= 1 and a.harmony_confidence < .68)
    )


def _measure_pitch_classes(project, a) -> tuple[set[int],set[int]]:
    start=float(a.start); end=start+float(a.duration)
    melody={n.pitch.midi%12 for n in project.melody.notes if n.start < end-1e-9 and n.start+n.duration > start+1e-9}
    accompaniment={int(n.pitch_class)%12 for n in getattr(a,"notes",())}
    return melody,accompaniment


def _root_motion_bonus(a:int,b:int) -> float:
    d=(b-a)%12
    if d in (5,7): return .55
    if d in (2,10): return .20
    if d in (0,): return .45
    return 0.0


def _compose_bridge_family(project, analysis, previous, following):
    """Conservatively compose one coarse bridge chord for a long sparse gap.

    The candidate must be supported by at least one local pitch class.  Endpoint
    voice-leading and local melody/accompaniment coverage are scored, so this is
    a bounded contextual interpolation rather than free-form reharmonisation.
    """
    melody,acc=_measure_pitch_classes(project,analysis)
    observed=melody|acc
    if not observed:
        return None
    families=basic_chord_families()
    scored=[]
    for fam in families:
        required=set(fam.required_pitch_classes); allowed=set(fam.pitch_classes)
        if not (required & observed):
            continue
        melody_cov=len(melody&allowed)/max(1,len(melody))
        acc_cov=len(acc&allowed)/max(1,len(acc))
        missing=len(required-observed)
        endpoint=_root_motion_bonus(previous.root_pitch_class,fam.root_pc)+_root_motion_bonus(fam.root_pc,following.root_pitch_class)
        score=2.0*melody_cov+1.5*acc_cov+endpoint-.55*missing
        # Avoid unnecessarily exotic qualities in a low-evidence gap.
        if fam.quality in {"sus2","sus4","diminished"}: score-=.20
        scored.append((score,fam))
    if not scored:
        return None
    scored.sort(key=lambda x:(-x[0],x[1].root_pc,x[1].quality))
    best_score,best=scored[0]
    if best_score < 1.15:
        return None
    class Bridge: pass
    b=Bridge(); b.root_pitch_class=best.root_pc; b.chord_quality=best.quality; b.chord_symbol=chord_family_name(best)
    return b


def _resolved_harmony(project, analyses, contexts):
    """Resolve sparse harmony without rewriting confident source analysis.

    Rules for v0.13.5.10:
      1) Confident local harmony is immutable.
      2) A sparse window in the same measure first holds the preceding resolved chord.
      3) A multi-measure sparse run bounded by stable chords is filled from the
         endpoints; for sufficiently long gaps one locally-supported bridge
         family may be composed between them.
      4) Ordinary isolated ambiguity still uses neighbour/context smoothing.
    """
    resolved=[]; reasons=[]
    for i,(a,c) in enumerate(zip(analyses,contexts)):
        # High-confidence/local multi-tone evidence is frozen.
        if not _is_sparse_harmony_evidence(a) and a.harmony_confidence>=.68:
            resolved.append(a); reasons.append("LOCAL_HIGH_CONFIDENCE_LOCK"); continue
        # Same-measure sparse hold has first priority.
        current_measure=_measure_number(a.window_id)
        if i>0 and _measure_number(analyses[i-1].window_id)==current_measure and _is_sparse_harmony_evidence(a):
            resolved.append(resolved[i-1]); reasons.append("SAME_MEASURE_SPARSE_HARMONY_HOLD"); continue
        # Isolated neighbour-consistency repair.
        if 0<i<len(analyses)-1:
            prev,nxt=analyses[i-1],analyses[i+1]
            upper_sim=min(_jaccard(_upper_pcs(prev),_upper_pcs(a)),_jaccard(_upper_pcs(a),_upper_pcs(nxt)))
            if prev.root_pitch_class==nxt.root_pitch_class!=a.root_pitch_class and a.harmony_confidence<.72 and upper_sim>=.55:
                resolved.append(prev); reasons.append("ISOLATED_NEIGHBOUR_HARMONY_HOLD"); continue
        # Existing context vote, but carry the complete family rather than root only.
        local=[x for x in analyses if x.window_id in c.local_window_ids]
        scores={}
        exemplars={}
        for x in local:
            key=(x.root_pitch_class,x.chord_quality,x.chord_symbol)
            scores[key]=scores.get(key,0.0)+max(.1,x.harmony_confidence)
            exemplars[key]=x
        if scores:
            key=max(scores,key=scores.get)
            resolved.append(exemplars[key]); reasons.append("LOCAL_CONTEXT_HARMONY_VOTE")
        else:
            resolved.append(a); reasons.append("LOCAL_UNRESOLVED_KEEP")

    # Second pass: genuinely long sparse spans (>=2 measures) bounded by stable
    # harmony may be context-composed.  Same endpoint chord => hold throughout;
    # differing endpoints => previous/next split with at most one supported bridge.
    n=len(analyses); i=0
    while i<n:
        if not _is_sparse_harmony_evidence(analyses[i]):
            i+=1; continue
        j=i
        while j+1<n and _is_sparse_harmony_evidence(analyses[j+1]): j+=1
        measures={_measure_number(analyses[k].window_id) for k in range(i,j+1)}
        if len(measures)>=2 and i>0 and j+1<n and not _is_sparse_harmony_evidence(analyses[i-1]) and not _is_sparse_harmony_evidence(analyses[j+1]):
            prev=resolved[i-1]; nxt=resolved[j+1]
            if prev.root_pitch_class==nxt.root_pitch_class and prev.chord_quality==nxt.chord_quality:
                for k in range(i,j+1):
                    resolved[k]=prev; reasons[k]="MULTI_MEASURE_SPARSE_ENDPOINT_HOLD"
            else:
                mid=(i+j)//2
                for k in range(i,j+1):
                    resolved[k]=prev if k<=mid else nxt
                    reasons[k]="MULTI_MEASURE_SPARSE_ENDPOINT_INTERPOLATION"
                if j-i+1>=3:
                    bridge=_compose_bridge_family(project,analyses[mid],prev,nxt)
                    if bridge is not None:
                        resolved[mid]=bridge; reasons[mid]="MULTI_MEASURE_CONTEXT_COMPOSED_BRIDGE"
        i=j+1
    roots=tuple(x.root_pitch_class for x in resolved)
    qualities=tuple(x.chord_quality for x in resolved)
    symbols=tuple(x.chord_symbol for x in resolved)
    return roots,qualities,symbols,tuple(reasons)


def _smoothed_roots(analyses, contexts):
    # Compatibility helper retained for older tests/callers.
    class P: melody=type("M",(),{"notes":[]})()
    roots,_,_,_=_resolved_harmony(P(),analyses,contexts)
    return roots

def _transition_candidates(project, analyses, roots, features):
    """Build expression-transition evidence without equating chord changes to texture changes."""
    out=[]
    for i,a in enumerate(analyses):
        reasons=[]; local_score=0.0; structural_signals=0
        if i:
            d0,r0,_=features[i-1]; d1,r1,_=features[i]
            if abs(d1-d0)>=.8:
                local_score+=.28; reasons.append("MELODY_DENSITY_CHANGE"); structural_signals+=1
            if abs(r1-r0)>=5:
                local_score+=.22; reasons.append("MELODY_REGISTER_SHIFT"); structural_signals+=1
            if analyses[i].pattern_type!=analyses[i-1].pattern_type:
                local_score+=.18; reasons.append("SOURCE_TEXTURE_CHANGE"); structural_signals+=1
            if analyses[i].bass_motion!=analyses[i-1].bass_motion:
                local_score+=.07; reasons.append("BASS_MOTION_CHANGE")
            if roots[i]!=roots[i-1]:
                # Ordinary harmonic rhythm is evidence, not an arrangement-mode boundary.
                local_score+=.04; reasons.append("HARMONY_CHANGE")
            if a.pattern_type=="REST" or analyses[i-1].pattern_type=="REST":
                local_score+=.38; reasons.append("REST_BOUNDARY"); structural_signals+=2

        # A real texture-change permission requires multiple non-harmonic signals.
        if structural_signals>=2:
            score=min(1.0,local_score+.18)
        elif structural_signals==1:
            score=min(.64,local_score)
        else:
            score=min(.35,local_score)
        out.append(ExpressionTransition(a.window_id,score,tuple(reasons)))
    return tuple(out)


def build_phrase_understanding(project, analyses, *, minimum_measures:int=2, preferred_measures:int=4, maximum_measures:int=6):
    contexts=build_context_windows(analyses,project.left_hand.measure_lengths,minimum_measures=minimum_measures)
    roots,qualities,symbols,harmony_reasons=_resolved_harmony(project,analyses,contexts)
    bass_flags=_structural_bass(analyses,contexts)
    features=[_melody_features(project,a.start,a.start+a.duration) for a in analyses]
    transitions=_transition_candidates(project,analyses,roots,features)

    typical_measure=_typical_measure_length(project)
    minimum_duration=max(typical_measure*minimum_measures, typical_measure)
    preferred_duration=max(minimum_duration,typical_measure*preferred_measures)
    maximum_duration=max(preferred_duration,typical_measure*maximum_measures)

    phrases=[]; start_idx=0; pid=1
    i=1
    while i<=len(analyses):
        at_end=i==len(analyses)
        chunk=analyses[start_idx:i]
        if not chunk:
            i+=1; continue
        start=chunk[0].start
        end=chunk[-1].start+chunk[-1].duration
        span=end-start
        transition=transitions[i] if i<len(analyses) else None
        score=transition.score if transition is not None else 1.0
        reasons=set(transition.reasons if transition is not None else ())

        # Only an explicit rest boundary may shorten a phrase below the two-measure target.
        # Even a very high local feature score is otherwise held until enough musical
        # context has accumulated, preventing one-measure phrases from dense local changes.
        hard_boundary=("REST_BOUNDARY" in reasons and score>=.55)
        normal_boundary=score>=.65 and span>=minimum_duration
        preferred_boundary=span>=preferred_duration and score>=.45
        forced_boundary=span>=maximum_duration
        boundary=at_end or hard_boundary or normal_boundary or preferred_boundary or forced_boundary

        # Strong boundaries may shorten a phrase, but never below roughly one measure.
        if boundary and not at_end and span<minimum_duration and not (hard_boundary and span>=typical_measure*.9):
            boundary=False
        # Do not leave a final one-measure tail: merge it into the preceding phrase.
        if at_end and span<minimum_duration and phrases:
            previous=phrases.pop()
            merged_ids=previous.window_ids+tuple(x.window_id for x in chunk)
            merged_end=end
            phrases.append(PhraseIntent(
                previous.phrase_id,previous.start,merged_end-previous.start,merged_ids,
                previous.energy_level,previous.transition_score,previous.transition_reasons,
                previous.primary_texture,previous.secondary_texture,previous.accent_texture
            ))
            start_idx=i
            i+=1
            continue

        if boundary:
            ds=[features[j][0] for j in range(start_idx,i)]
            energy=min(1.0,(sum(ds)/max(1,len(ds)))/2.5)
            primary="ROOT_GUIDE" if energy>=.75 else ("SPARSE_ARPEGGIO" if energy>=.35 else "ARPEGGIO")
            entry_transition=transitions[start_idx].score if start_idx<len(transitions) else 0.0
            phrases.append(PhraseIntent(
                f"PHRASE_{pid:03d}",start,end-start,tuple(x.window_id for x in chunk),energy,
                entry_transition,transitions[start_idx].reasons if start_idx<len(transitions) else (),
                primary,"ROOT_GUIDE","COMPACT_BLOCK"
            ))
            pid+=1; start_idx=i
        i+=1

    return PhraseUnderstandingPlan(contexts,tuple(phrases),tuple(transitions),roots,bass_flags,qualities,symbols,harmony_reasons)
