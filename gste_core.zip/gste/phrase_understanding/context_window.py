from __future__ import annotations
from .model import ContextWindow

def build_context_windows(analyses, measure_lengths: dict[int,float], *, minimum_measures:int=2):
    if not analyses: return ()
    typical=sum(measure_lengths.values())/max(1,len(measure_lengths)) if measure_lengths else 4.0
    minimum_duration=max(2.0,typical*minimum_measures)
    out=[]
    for i,a in enumerate(analyses):
        center=a.start+a.duration/2
        start=max(0.0,center-minimum_duration/2)
        end=start+minimum_duration
        # Near the score end, slide the context left rather than shortening it.
        score_end=max((x.start+x.duration for x in analyses), default=end)
        if end>score_end and score_end>=minimum_duration:
            end=score_end
            start=end-minimum_duration
        ids=tuple(x.window_id for x in analyses if x.start < end-1e-9 and x.start+x.duration > start+1e-9)
        out.append(ContextWindow(f"CTX:{a.window_id}",start,end-start,ids,minimum_measures))
    return tuple(out)
