"""Interactive arrangement requests, applied before the shared guitar engine."""
