"""Offline audition from the same frozen sounding events used by export."""
from array import array
from pathlib import Path
import math
import wave
import sys
import subprocess


def write_wav(notes, path, *, start=0., end=None, bpm=120., sample_rate=22050):
    if not math.isfinite(bpm) or not 20<=bpm<=300:raise ValueError('Tempo must be 20–300 BPM.')
    notes=tuple(notes)
    if end is None:end=max((f.note.start+f.note.duration for f,role in notes),default=start)
    seconds=(end-start)*60/bpm
    if seconds<=0 or seconds>600:raise ValueError('Select an audition range of up to 10 minutes.')
    mix=[0.] * (int((seconds+.12)*sample_rate)+1)
    for f,role in notes:
        n=f.note;a=max(start,n.start);b=min(end,n.start+n.duration)
        if b<=a:continue
        first=int((a-start)*60/bpm*sample_rate);length=int((b-a)*60/bpm*sample_rate)
        freq=440*2**((n.pitch.midi-69)/12);gain=.23 if role=='melody' else .15
        # Deterministic decaying harmonic tone, no external synthesizer dependency.
        age=(a-n.start)*60/bpm
        for i in range(length):
            t=age+i/sample_rate
            attack=min(1.,t/.006);release=min(1.,(length-i)/(.025*sample_rate))
            tone=sum(math.sin(2*math.pi*freq*t*k)*math.exp(-t*(2.+k*.7))/k**1.5 for k in (1,2,3,4))
            mix[first+i]+=gain*attack*release*tone
    peak=max(1.,max(map(abs,mix),default=0.))
    pcm=array('h',(int(max(-1.,min(1.,v/peak))*30000) for v in mix))
    if sys.byteorder!='little':pcm.byteswap()
    with wave.open(str(path),'wb') as out:
        out.setnchannels(1);out.setsampwidth(2);out.setframerate(sample_rate);out.writeframes(pcm.tobytes())
    return Path(path)


class AuditionPlayer:
    def __init__(self):self.process=None
    def stop(self):
        if sys.platform=='win32':
            import winsound
            winsound.PlaySound(None,0)
        if self.process is not None:
            if self.process.poll() is None:self.process.terminate()
            self.process=None
    def play(self,path):
        self.stop()
        if sys.platform=='win32':
            import winsound
            winsound.PlaySound(str(path),winsound.SND_FILENAME|winsound.SND_ASYNC)
        else:
            import shutil
            executable=shutil.which('afplay' if sys.platform=='darwin' else 'ffplay')
            if not executable:raise RuntimeError('No audio player available; export WAV and open it in an audio player.')
            args=[executable,str(path)] if sys.platform=='darwin' else [executable,'-nodisp','-autoexit','-loglevel','quiet',str(path)]
            self.process=subprocess.Popen(args,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
