"""GSTE V0.4 beta: read-only, single-measure arrangement reference GUI.

This GUI never calls the arrangement optimizer, regeneration or score writer.
"""
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from .session import read_context
from .score import read_score
from .reference_index import index_measure, TUNING, NAMES


LANG = {
 'zh_TW': {
 'title':'編曲索引','open':'開啟編曲專案','chord':'查詢和弦：','search':'更新索引','hint':'唯讀編曲索引｜僅顯示選取小節；點選或拖曳框選藍色旋律音符，可按 Ctrl 多選。建議不會修改原譜。','bar':'小節','source_chord':'來源和弦','events':'旋律事件（選取音符後，下方顯示該音的雙音建議）','beat':'起拍（四分音符=1）','event_id':'旋律事件 ID','index_tab':'和弦指法＋伴奏編排索引','double_tab':'主旋律雙音建議','initial':'開啟 GSTE_EDITOR_CONTEXT.json（唯讀）','choose_bar':'請選擇小節','loaded':'已載入：{path}（唯讀）','missing':'MusicXML 中找不到此小節','summary':'小節 {bar}｜和弦 {chord}｜主旋律參考把位 {fret} 格｜藍色＝主旋律，灰色＝原伴奏','status':'小節 {bar}：附近未佔用弦的參考位置 {count} 個；未經 GSTE Joint／完整手型驗證','measure':'小節 {bar}（僅顯示本小節）','nearby':'{chord}｜主旋律附近／未佔用弦的和弦音（不列出全指板）','empty':'本小節無符合簡化篩選的建議；可考慮更換和弦或手動調整把位。','position':'{string}弦 {fret:>2}格  {name:<4}  MIDI {midi:<3}  {role}','omitted':'其餘 {count} 個位置省略','tab_heading':'伴奏編排示意 TAB（每一組為獨立參考，不代表可同時演奏）','onsets':'{name}｜示意起音：{onsets}','warning':'注意：未做完整手型、同時起音或時值驗證；請於 MuseScore 人工調整。','no_selection':'請在上方 TAB 點選或框選主旋律音符，或在旋律事件清單選取。\n\n會依選取音符的音高與當下弦位，列出附近未佔用弦的三度、六度、八度雙音參考。','melody':'旋律：{string}弦{fret}格  MIDI {pitch}  起拍 {beat:g}\n','double_position':'  {string}弦 {fret:>2}格  {name}{octave:<2}  MIDI {midi:<3}  {interval}\n','no_double':'  此把位無符合簡化條件的雙音建議\\n','footer':'以上為唯讀指板參考，不會加入音符或重新編曲；未經完整 GSTE 手型驗證。','minor_third':'小三度','major_third':'大三度','minor_sixth':'小六度','major_sixth':'大六度','octave':'八度','root_bass':'根音低音','block_chord':'柱式和弦','sparse_arpeggio':'稀疏分解和弦','arpeggio':'分解和弦','language':'語言'},
 'en': {
 'title':'Arrangement Reference','open':'Open project','chord':'Chord:','search':'Refresh index','hint':'Read-only arrangement reference | Only the selected measure is shown. Click or drag to select blue melody notes; hold Ctrl to select multiple notes. Suggestions do not change the score.','bar':'Measure','source_chord':'Source chord','events':'Melody events (select notes to see double-stop suggestions below)','beat':'Onset (quarter note = 1)','event_id':'Melody event ID','index_tab':'Chord Fingering + Accompaniment Index','double_tab':'Melody Double-Stop Suggestions','initial':'Open GSTE_EDITOR_CONTEXT.json (read-only)','choose_bar':'Select a measure','loaded':'Loaded: {path} (read-only)','missing':'Measure not found in MusicXML','summary':'Measure {bar} | Chord {chord} | Melody anchor fret {fret} | Blue = melody, gray = original accompaniment','status':'Measure {bar}: {count} nearby positions on available strings; not verified by GSTE Joint or full fingering rules','measure':'Measure {bar} (this measure only)','nearby':'{chord} | Chord tones near melody / on available strings (not the full fretboard)','empty':'No suggestions meet the simplified filter. Try another chord or adjust the position manually.','position':'String {string}  Fret {fret:>2}  {name:<4}  MIDI {midi:<3}  {role}','omitted':'{count} additional positions omitted','tab_heading':'Accompaniment TAB examples (each is independent; not intended to be played together)','onsets':'{name} | Example onsets: {onsets}','warning':'Note: Full fingering, simultaneous onset, and duration checks were not performed. Adjust manually in MuseScore.','no_selection':'Click or drag to select melody notes in the TAB above, or select them from the event list.\n\nNearby thirds, sixths and octaves on available strings will be suggested.','melody':'Melody: String {string} Fret {fret}  MIDI {pitch}  Onset {beat:g}\n','double_position':'  String {string}  Fret {fret:>2}  {name}{octave:<2}  MIDI {midi:<3}  {interval}\n','no_double':'  No double-stop suggestions meet the simplified criteria at this position\n','footer':'Read-only fretboard reference. No notes are added and no rearrangement is performed; full GSTE fingering checks have not been run.','minor_third':'Minor third','major_third':'Major third','minor_sixth':'Minor sixth','major_sixth':'Major sixth','octave':'Octave','root_bass':'Root bass','block_chord':'Block chord','sparse_arpeggio':'Sparse arpeggio','arpeggio':'Arpeggio','language':'Language'},
 'ja': {'title': '編曲リファレンス',
  'open': '編曲プロジェクトを開く',
  'chord': 'コード：',
  'search': '索引を更新',
  'hint': '閲覧専用の編曲リファレンス｜選択した小節のみ表示します。青いメロディー音符をクリックまたはドラッグして選択できます。Ctrl キーで複数選択できます。',
  'bar': '小節',
  'source_chord': '元のコード',
  'events': 'メロディーイベント（音符を選択すると複音の候補を表示）',
  'beat': '開始位置（四分音符＝1）',
  'event_id': 'イベント ID',
  'index_tab': 'コード運指・伴奏配置索引',
  'double_tab': 'メロディー複音候補',
  'initial': 'GSTE_EDITOR_CONTEXT.json を開いてください（閲覧専用）',
  'choose_bar': '小節を選択してください',
  'loaded': '読み込み完了：{path}（閲覧専用）',
  'missing': 'MusicXML に該当する小節がありません',
  'summary': '小節 {bar}｜コード {chord}｜メロディー基準フレット {fret}｜青：メロディー、灰：元の伴奏',
  'status': '小節 {bar}：使用可能な弦の近くの候補 {count} 件。GSTE Joint および運指全体の検証は未実施',
  'measure': '小節 {bar}（この小節のみ表示）',
  'nearby': '{chord}｜メロディー付近・使用可能な弦のコード構成音',
  'empty': '条件に合う候補がありません。コードまたはポジションを変更してください。',
  'position': '{string}弦 {fret:>2}フレット  {name:<4}  MIDI {midi:<3}  {role}',
  'omitted': 'ほか {count} 件を省略',
  'tab_heading': '伴奏 TAB の例（各例は独立しており、同時演奏を意味しません）',
  'onsets': '{name}｜開始位置の例：{onsets}',
  'warning': '注意：運指全体、同時発音、音価の検証は未実施です。MuseScore で手動調整してください。',
  'no_selection': '上の TAB でメロディー音符をクリック・ドラッグして選択するか、イベント一覧から選択してください。\n\n使用可能な弦の近くにある3度、6度、8度の複音候補を表示します。',
  'melody': 'メロディー：{string}弦 {fret}フレット  MIDI {pitch}  開始 {beat:g}\n',
  'double_position': '  {string}弦 {fret:>2}フレット  {name}{octave:<2}  MIDI {midi:<3}  {interval}\n',
  'no_double': '  このポジションに条件を満たす複音候補はありません\n',
  'footer': '閲覧専用の指板リファレンスです。音符の追加や再編曲は行わず、GSTE の運指全体の検証も未実施です。',
  'minor_third': '短3度',
  'major_third': '長3度',
  'minor_sixth': '短6度',
  'major_sixth': '長6度',
  'octave': 'オクターブ',
  'root_bass': 'ルートベース',
  'block_chord': 'ブロックコード',
  'sparse_arpeggio': '疎なアルペジオ',
  'arpeggio': 'アルペジオ',
  'language': '言語'}
}

class ArrangementEditor(tk.Toplevel):
    def __init__(self, master, context_path=None, language=None, on_language_change=None):
        super().__init__(master)
        self.language = language if language is not None else tk.StringVar(value='繁體中文')
        self.on_language_change = on_language_change
        self.title('GSTE V0.4 beta — Arrangement Reference')
        self.geometry('1160x840')
        self.minsize(870, 650)
        self.context = None
        self.score = {}
        self.measure = None
        self.hitboxes = []
        self.rect = None
        self.drag_start = None
        self.ctrl = False
        self.chord = tk.StringVar(value='C')
        self.status = tk.StringVar(value=self.tr('initial'))
        self.summary = tk.StringVar(value=self.tr('choose_bar'))

        bar = ttk.Frame(self, padding=8)
        bar.pack(fill='x')
        self.open_button = ttk.Button(bar, command=self.open_project); self.open_button.pack(side='left')
        self.chord_label = ttk.Label(bar); self.chord_label.pack(side='left')
        entry = ttk.Entry(bar, textvariable=self.chord, width=13)
        entry.pack(side='left')
        entry.bind('<Return>', lambda _: self.refresh())
        self.search_button = ttk.Button(bar, command=self.refresh); self.search_button.pack(side='left', padx=5)
        self.language_label = ttk.Label(bar); self.language_label.pack(side='left', padx=(18, 4))
        self.language_combo = ttk.Combobox(bar, textvariable=self.language, values=('繁體中文', 'English', '日本語'), state='readonly', width=12)
        self.language_combo.pack(side='left')
        self.language_combo.bind('<<ComboboxSelected>>', self._language_selected)
        self.hint_label = ttk.Label(self, foreground='#805900'); self.hint_label.pack(anchor='w', padx=12)

        pane = ttk.Panedwindow(self, orient='horizontal')
        pane.pack(fill='both', expand=True, padx=9, pady=7)
        left, right = ttk.Frame(pane), ttk.Frame(pane)
        pane.add(left, weight=1)
        pane.add(right, weight=4)
        self.bars = ttk.Treeview(left, columns=('bar', 'chord'), show='headings', selectmode='browse')
        for key, label, width in [('bar', '', 85), ('chord', '', 135)]:
            self.bars.heading(key, text=label)
            self.bars.column(key, width=width)
        self.bars.pack(fill='both', expand=True)
        self.bars.bind('<<TreeviewSelect>>', self.select_measure)

        ttk.Label(right, textvariable=self.summary, wraplength=840).pack(anchor='w', pady=(0, 4))
        self.canvas = tk.Canvas(right, height=175, bg='white')
        self.canvas.pack(fill='x')
        self.canvas.bind('<Configure>', lambda _: self.draw_tab())
        self.canvas.bind('<ButtonPress-1>', self.canvas_down)
        self.canvas.bind('<B1-Motion>', self.canvas_drag)
        self.canvas.bind('<ButtonRelease-1>', self.canvas_up)
        self.events_label = ttk.Label(right); self.events_label.pack(anchor='w', pady=(7, 0))
        self.events = ttk.Treeview(right, columns=('beat', 'pitch', 'id'), show='headings', selectmode='extended', height=5)
        for key, label, width in [('beat', '', 190), ('pitch', 'MIDI', 75), ('id', '', 290)]:
            self.events.heading(key, text=label)
            self.events.column(key, width=width)
        self.events.pack(fill='x')
        self.events.bind('<<TreeviewSelect>>', self.selection_changed)

        self.tabs = tabs = ttk.Notebook(right)
        tabs.pack(fill='both', expand=True, pady=(8, 0))
        combo = ttk.Frame(tabs)
        double = ttk.Frame(tabs)
        tabs.add(combo, text='')
        tabs.add(double, text='')
        self.index_canvas = tk.Canvas(combo, bg='white', height=250)
        self.index_scroll = ttk.Scrollbar(combo, orient='vertical', command=self.index_canvas.yview)
        self.index_canvas.configure(yscrollcommand=self.index_scroll.set)
        self.index_canvas.pack(side='left', fill='both', expand=True)
        self.index_scroll.pack(side='right', fill='y')
        self.index_canvas.bind('<Configure>', lambda _: self.draw_index())
        self.double_text = tk.Text(double, wrap='word', font=('Consolas', 11), height=11)
        self.double_text.pack(fill='both', expand=True)
        self.double_text.configure(state='disabled')
        ttk.Label(self, textvariable=self.status, wraplength=1080).pack(fill='x', padx=12, pady=8)
        self.language.trace_add('write', lambda *_: self.refresh_language())
        self.refresh_language()
        if context_path:
            self.load_project(context_path)

    def tr(self, key, **kwargs):
        code = {'繁體中文':'zh_TW', 'English':'en', '日本語':'ja'}.get(self.language.get(), 'zh_TW')
        return LANG[code][key].format(**kwargs)

    def _role(self, position):
        if self.language.get() == '繁體中文':
            return position['role']
        if self.language.get() == '日本語':
            roles_ja = {0:'ルート', 2:'長2度', 3:'短3度', 4:'長3度', 5:'完全4度', 6:'減5度', 7:'完全5度', 8:'増5度', 10:'短7度', 11:'長7度'}
            return roles_ja.get(position['interval'], str(position['interval']))
        roles = {0:'Root', 2:'Second', 3:'Minor third', 4:'Major third', 5:'Fourth',
                 6:'Diminished fifth', 7:'Fifth', 8:'Augmented fifth',
                 10:'Minor seventh', 11:'Major seventh'}
        return roles.get(position['interval'], str(position['interval']))

    def _language_selected(self, _=None):
        if self.on_language_change:
            self.on_language_change(self.language.get())

    def refresh_language(self):
        self.title('GSTE V0.4 beta — ' + self.tr('title'))
        self.open_button.config(text=self.tr('open'))
        self.chord_label.config(text=self.tr('chord'))
        self.search_button.config(text=self.tr('search'))
        self.language_label.config(text=self.tr('language'))
        self.hint_label.config(text=self.tr('hint'))
        for col, key in [('bar','bar'), ('chord','source_chord')]:
            self.bars.heading(col, text=self.tr(key))
        for col, key in [('beat','beat'), ('id','event_id')]:
            self.events.heading(col, text=self.tr(key))
        self.events_label.config(text=self.tr('events'))
        self.tabs.tab(0, text=self.tr('index_tab'))
        self.tabs.tab(1, text=self.tr('double_tab'))
        if self.measure in self.score and hasattr(self, 'index_data'):
            self.refresh()
        else:
            self.status.set(self.tr('initial'))
            self.summary.set(self.tr('choose_bar'))

    def open_project(self):
        path = filedialog.askopenfilename(parent=self, title='GSTE_EDITOR_CONTEXT.json', filetypes=[('JSON', '*.json')])
        if path:
            self.load_project(path)

    def load_project(self, path):
        try:
            context = read_context(path)
            score = read_score(Path(path).parent / 'GSTE_TAB.musicxml')
        except Exception as exc:
            messagebox.showerror('Open project', str(exc), parent=self)
            return
        self.context = context
        self.score = {m['measure']: m for m in score}
        self.bars.delete(*self.bars.get_children())
        for m in context['measures']:
            chords = list(dict.fromkeys(w['harmony']['chord_symbol'] for w in context['windows']
                                        if m['start'] <= w['harmony']['start'] < m['start'] + m['duration']))
            self.bars.insert('', 'end', iid=str(m['measure']), values=(m['label'], ' / '.join(chords) or 'C'))
        self.status.set(self.tr('loaded', path=path))
        if self.bars.get_children():
            self.bars.selection_set(self.bars.get_children()[0])
            self.select_measure()

    def select_measure(self, _=None):
        selected = self.bars.selection()
        if not selected:
            return
        self.measure = int(selected[0])
        source = self.bars.item(selected[0], 'values')[1].split(' / ')[0]
        self.chord.set(source if source not in ('NONE', 'UNKNOWN') else 'C')
        self.events.delete(*self.events.get_children())
        m = self.score.get(self.measure)
        if m is None:
            self.status.set(self.tr('missing'))
            return
        # The score is the source of truth for the visible TAB and selectable melody.
        seen = set()
        for n in m['notes']:
            if n['role'] != 'melody':
                continue
            eid = n.get('event_id') or n['note_id']
            if eid in seen:
                continue
            seen.add(eid)
            self.events.insert('', 'end', iid=str(len(self.events.get_children())),
                               values=(f"{n['offset'] + 1:g}", n['pitch'], eid))
        self.refresh()

    def selected_notes(self):
        if self.measure not in self.score:
            return []
        ids = {self.events.item(i, 'values')[2] for i in self.events.selection()}
        return [n for n in self.score[self.measure]['notes'] if n['role'] == 'melody'
                and (n.get('event_id') or n['note_id']) in ids]

    def selection_changed(self, _=None):
        self.draw_tab()
        self.draw_double()

    def refresh(self):
        if self.measure not in self.score:
            return
        try:
            self.index_data = index_measure(self.score[self.measure], self.chord.get().strip())
        except Exception as exc:
            self.status.set(str(exc))
            return
        data = self.index_data
        self.summary.set(self.tr('summary', bar=self.score[self.measure]['label'], chord=data['chord'], fret=data['anchor_fret']))
        self.draw_tab()
        self.draw_index()
        self.draw_double()
        self.status.set(self.tr('status', bar=self.measure, count=len(data['nearby'])))

    def draw_tab(self):
        self.canvas.delete('all')
        self.hitboxes = []
        if self.measure not in self.score:
            return
        m = self.score[self.measure]
        width = max(self.canvas.winfo_width(), 650)
        left, right = 45, width - 25
        selected = {(n.get('event_id') or n['note_id']) for n in self.selected_notes()}
        for string in range(1, 7):
            y = 24 + string * 21
            self.canvas.create_text(19, y, text=str(string))
            self.canvas.create_line(left, y, right, y, fill='#aaaaaa')
        self.canvas.create_text(left, 12, text=self.tr('measure', bar=m['label']), anchor='w')
        for n in m['notes']:
            if not n.get('string') or n.get('fret') is None:
                continue
            x = left + 20 + (right - left - 40) * n['offset'] / max(m['duration'], .01)
            y = 24 + n['string'] * 21
            eid = n.get('event_id') or n['note_id']
            melody = n['role'] == 'melody'
            color = '#2463ad' if melody else '#777777'
            self.canvas.create_rectangle(x - 11, y - 9, x + 11, y + 9,
                                         fill='#ffe59a' if melody and eid in selected else 'white', outline='')
            self.canvas.create_text(x, y, text=str(n['fret']), fill=color, font=('Segoe UI', 11, 'bold'))
            end = min(right - 4, x + (right - left - 40) * n['duration'] / max(m['duration'], .01))
            self.canvas.create_line(x + 11, y + 7, end, y + 7, fill=color)
            if melody:
                self.hitboxes.append((x - 13, y - 11, x + 13, y + 11, eid))

    def canvas_down(self, event):
        self.drag_start = (event.x, event.y)
        self.ctrl = bool(event.state & 4)
        if not self.ctrl:
            self.events.selection_remove(self.events.selection())
        self._select_hits(event.x, event.y, event.x, event.y)

    def _select_hits(self, x1, y1, x2, y2):
        for a, b, c, d, eid in self.hitboxes:
            if a <= x2 and c >= x1 and b <= y2 and d >= y1:
                for row in self.events.get_children():
                    if self.events.item(row, 'values')[2] == eid:
                        self.events.selection_add(row)

    def canvas_drag(self, event):
        if self.drag_start is None:
            return
        if self.rect:
            self.canvas.delete(self.rect)
        self.rect = self.canvas.create_rectangle(*self.drag_start, event.x, event.y,
                                                  outline='#2463ad', dash=(4, 2))

    def canvas_up(self, event):
        if self.drag_start is None:
            return
        x, y = self.drag_start
        self._select_hits(*sorted((x, event.x)), *sorted((y, event.y)))
        if self.rect:
            self.canvas.delete(self.rect)
        self.rect = None
        self.drag_start = None
        self.selection_changed()

    def draw_index(self):
        if not hasattr(self, 'index_data'):
            return
        c = self.index_canvas
        c.delete('all')
        data = self.index_data
        width = max(c.winfo_width(), 640)
        y = 12
        c.create_text(14, y, anchor='nw', text=self.tr('nearby', chord=data['chord']),
                      font=('Segoe UI', 11, 'bold'), fill='#26374a')
        y += 27
        if not data['nearby']:
            c.create_text(14, y, anchor='nw', text=self.tr('empty'))
            y += 30
        else:
            for p in data['nearby'][:48]:
                c.create_text(20, y, anchor='nw', font=('Consolas', 10),
                              text=self.tr('position', **dict(p, role=self._role(p))))
                y += 20
            if len(data['nearby']) > 48:
                c.create_text(20, y, anchor='nw', text=self.tr('omitted', count=len(data['nearby']) - 48))
                y += 24
        y += 12
        c.create_text(14, y, anchor='nw', text=self.tr('tab_heading'),
                      font=('Segoe UI', 11, 'bold'), fill='#26374a')
        y += 30
        candidates = data['nearby']
        bass = sorted(candidates, key=lambda p: (-p['string'], p['fret']))
        treble = sorted(candidates, key=lambda p: (p['string'], p['fret']))
        for name, onsets in data['patterns'].items():
            if name == 'ROOT_BASS':
                picks = bass[:1]
            elif name == 'BLOCK_CHORD':
                picks = treble[:4]
            elif name == 'SPARSE_ARPEGGIO':
                picks = (bass[:1] + treble[:1])[:len(onsets)]
            else:
                pool = bass[:1] + treble[:3]
                picks = [pool[i % len(pool)] for i in range(len(onsets))] if pool else []
            if not picks:
                continue
            c.create_text(15, y, anchor='nw', text=self.tr('onsets', name=self.tr({'ROOT_BASS':'root_bass','BLOCK_CHORD':'block_chord','SPARSE_ARPEGGIO':'sparse_arpeggio','ARPEGGIO':'arpeggio'}.get(name, 'arpeggio')), onsets=', '.join(f'{x:g}' for x in onsets)),
                          font=('Segoe UI', 10, 'bold'))
            y += 26
            x0, x1 = 55, max(width - 40, 410)
            for s in range(1, 7):
                yy = y + (s - 1) * 19
                c.create_text(22, yy, text=str(s))
                c.create_line(x0, yy, x1, yy, fill='#b6b6b6')
            for i, p in enumerate(picks):
                onset = 0 if name == 'BLOCK_CHORD' else onsets[min(i, len(onsets)-1)]
                xx = x0 + 22 + (x1 - x0 - 44) * onset / max(data['duration'], .01)
                yy = y + (p['string'] - 1) * 19
                c.create_rectangle(xx - 12, yy - 9, xx + 12, yy + 9, fill='white', outline='')
                c.create_text(xx, yy, text=str(p['fret']), fill='#2b568b', font=('Segoe UI', 10, 'bold'))
            y += 6 * 19 + 18
        c.create_text(14, y, anchor='nw', text=self.tr('warning'),
                      fill='#805900')
        y += 35
        c.configure(scrollregion=(0, 0, width, y))

    def draw_double(self):
        t = self.double_text
        t.configure(state='normal')
        t.delete('1.0', 'end')
        if self.measure not in self.score:
            t.configure(state='disabled')
            return
        notes = self.selected_notes()
        if not notes:
            t.insert('end', self.tr('no_selection'))
        else:
            data = self.index_data
            melody = data['melody']
            for n in notes:
                t.insert('end', self.tr('melody', string=n['string'], fret=n['fret'], pitch=n['pitch'], beat=n['offset']+1))
                proposals = []
                for string, opened in enumerate(TUNING, 1):
                    if string == n['string']:
                        continue
                    # Exclude strings occupied by OTHER sounding melody notes at this onset.
                    if any(other is not n and other['string'] == string
                           and other['offset'] <= n['offset'] < other['offset'] + other['duration']
                           for other in melody):
                        continue
                    for fret in range(0, 25):
                        if fret != 0 and abs(fret - max(n['fret'], data['anchor_fret'])) > 4:
                            continue
                        midi = opened + fret
                        diff = abs(midi - n['pitch'])
                        if diff not in (3, 4, 8, 9, 12):
                            continue
                        label = self.tr({3:'minor_third', 4:'major_third', 8:'minor_sixth', 9:'major_sixth', 12:'octave'}[diff])
                        proposals.append((abs(fret - n['fret']), string, fret, midi, label))
                for _, string, fret, midi, label in sorted(proposals)[:20]:
                    t.insert('end', self.tr('double_position', string=string, fret=fret, name=NAMES[midi % 12], octave=midi // 12 - 1, midi=midi, interval=label))
                if not proposals:
                    t.insert('end', self.tr('no_double'))
                t.insert('end', '\n')
            t.insert('end', self.tr('footer'))
        t.configure(state='disabled')
