"""Read-only arrangement reference; no mutation or arrangement search."""
import re
TUNING=(64,59,55,50,45,40)  # strings 1..6, standard tuning
NAMES=('C','C#','D','D#','E','F','F#','G','G#','A','A#','B')
INTERVALS={'':(0,4,7),'m':(0,3,7),'7':(0,4,7,10),'maj7':(0,4,7,11),'m7':(0,3,7,10),'sus2':(0,2,7),'sus4':(0,5,7),'dim':(0,3,6),'aug':(0,4,8)}
ROLE={0:'根音',2:'二度',3:'小三度',4:'大三度',5:'四度',6:'減五度',7:'五度',8:'增五度',10:'小七度',11:'大七度'}
def chord_pitches(symbol):
    match=re.fullmatch(r'\s*([A-Ga-g])([#b♯♭]?)(maj7|m7|sus2|sus4|dim|aug|m|7)?(?:/([A-Ga-g][#b]?))?\s*',symbol)
    if not match: raise ValueError('不支援的和弦名稱：'+symbol+'（支援 C, Cm, C7, Cmaj7, Cm7, Csus2, Csus4 等）')
    letter,acc,quality,bass=match.groups()
    base={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[letter.upper()]+({'#':1,'♯':1,'b':-1,'♭':-1}.get(acc,0))
    intervals=INTERVALS[quality or '']
    return base%12,tuple(((base+i)%12,i) for i in intervals)
def index_measure(measure,chord,max_fret=24,span=4):
    root,tones=chord_pitches(chord)
    melody=[n for n in measure['notes'] if n['role']=='melody' and n.get('string') and n.get('fret') is not None]
    occupied={n['string'] for n in melody}
    positions=[]
    for string,open_pitch in enumerate(TUNING,1):
        for fret in range(max_fret+1):
            midi=open_pitch+fret
            for pc,interval in tones:
                if midi%12==pc:
                    positions.append({'string':string,'fret':fret,'midi':midi,'name':NAMES[midi%12]+str(midi//12-1),'role':ROLE.get(interval,str(interval)),'interval':interval,'theoretical':True})
                    break
    anchors=[n['fret'] for n in melody if n['fret']>0]
    anchor=round(sum(anchors)/len(anchors)) if anchors else 1
    # Conservative guide only: measure-level overlap may over-restrict, and actual
    # onset/duration and hand-shape feasibility need full GSTE validation.
    nearby=[dict(p,guide_eligible=(p['string'] not in occupied and (p['fret']==0 or abs(p['fret']-anchor)<=span))) for p in positions]
    guide=[p for p in nearby if p['guide_eligible']]
    # Each item is a position suggestion, NOT a verified GSTE Joint candidate.
    beats=measure['duration']
    patterns={'ROOT_BASS':[0.0], 'BLOCK_CHORD':[0.0], 'SPARSE_ARPEGGIO':[0.0,beats/2], 'ARPEGGIO':[i*beats/4 for i in range(4)]}
    return {'chord':chord,'anchor_fret':anchor,'melody':melody,'theoretical':nearby,'nearby':guide,'patterns':patterns,'duration':beats,'occupied_strings':sorted(occupied)}
