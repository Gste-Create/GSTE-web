"""Read the actual exported TAB for selection and final artifact checks."""
import xml.etree.ElementTree as ET
import json
from pathlib import Path


def read_score(path):
    identities=load_identities(path)
    root=ET.parse(path).getroot()
    # Accept the writer's namespace-free MusicXML and ordinary namespaced files.
    for e in root.iter(): e.tag=e.tag.rsplit('}',1)[-1]
    from gste.exporter.canonical_tab_reader import canonical_tab_part, is_canonical_tab_note
    from gste.exporter.joint_tab_xml_exporter import _note_role
    part=canonical_tab_part(root)
    rows=[];divisions=1.;absolute=0.;meter=4.
    steps={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
    for index,m in enumerate(part.findall('measure'),1):
        if m.findtext('attributes/divisions'): divisions=float(m.findtext('attributes/divisions'))
        if m.findtext('attributes/time/beats'):
            meter=float(m.findtext('attributes/time/beats'))*4/float(m.findtext('attributes/time/beat-type'))
        cursor=0.;last=0.;maximum=0.;notes=[]
        for element_index,e in enumerate(m):
            duration=float(e.findtext('duration','0'))/divisions
            if e.tag=='backup': cursor-=duration
            elif e.tag=='forward': cursor+=duration;maximum=max(maximum,cursor)
            elif e.tag=='note':
                start=last if e.find('chord') is not None else cursor
                if e.find('chord') is None:
                    last=start
                    if e.find('grace') is None: cursor+=duration
                maximum=max(maximum,cursor,start+duration)
                p=e.find('pitch');tech=e.find('notations/technical')
                if p is not None and is_canonical_tab_note(e,part,root):
                    pitch=12*(int(p.findtext('octave'))+1)+steps[p.findtext('step')]+int(p.findtext('alter','0'))
                    notes.append({'note_id':f"{part.get('id')}:M{index}:E{element_index}",'role':identities.get(f"{part.get('id')}:M{index}:E{element_index}",{}).get('role',_note_role(e)),'notation':notation_fields(e),'start':absolute+start,'offset':start,'duration':duration,'pitch':pitch,'voice':e.findtext('voice','1'),
                        'string':int(tech.findtext('string','0')) if tech is not None else 0,
                        'fret':int(tech.findtext('fret','0')) if tech is not None else 0,
                        'event_id':identities.get(f"{part.get('id')}:M{index}:E{element_index}",{}).get('event_id',e.findtext("notations/other-notation[@type='gste-event-id']")),
                        'tie_start':any(t.get('type')=='start' for t in e.findall('tie')),
                        'tie_stop':any(t.get('type')=='stop' for t in e.findall('tie'))})
        length=maximum if m.get('implicit')=='yes' else max(meter,maximum)
        rows.append({'measure':index,'label':m.get('number',str(index)),'start':absolute,'duration':length,'notes':notes})
        absolute+=length
    # The serializer may preserve distinct source IDs for notation fragments of
    # one cross-bar tie. Normalize only a uniquely matching, contiguous tie
    # continuation at the editor read boundary. Never infer by voice alone.
    reconcile_tie_fragments(rows)
    return rows


def reconcile_tie_fragments(rows):
    """Reconcile source-fragment IDs without weakening tie validation.

    Require exactly one active predecessor with matching pitch, string, fret,
    role and continuous timing. Ambiguous and orphaned ties remain errors in
    sounding_notes(); this is not a generic pitch-based fallback.
    """
    active = {}
    notes = [n for m in rows for n in m['notes']]
    notes.sort(key=lambda n: (n['start'], not n['tie_stop']))
    for n in notes:
        if n['tie_stop']:
            matches = [prior for prior in active.values()
                       if all(prior[k] == n[k] for k in ('pitch','string','fret','role'))
                       and abs(prior['start'] + prior['duration'] - n['start']) < 1e-5]
            if len(matches) == 1:
                n['source_fragment_event_id'] = n['event_id']
                n['event_id'] = matches[0]['event_id']
            elif len(matches) > 1:
                raise ValueError('Ambiguous tie continuation at '+str(n['start']))
        if n['tie_stop']:
            for key, prior in list(active.items()):
                if prior['event_id'] == n['event_id']:
                    del active[key]
        if n['tie_start']:
            active[n['event_id']] = n


def notation_fields(element):
    """Lossless notation fragment plus convenient renderer fields; voice is layout only."""
    return {'xml':ET.tostring(element,encoding='unicode'),
        'type':element.findtext('type'),'dots':len(element.findall('dot')),
        'staff':element.findtext('staff','1'),'chord':element.find('chord') is not None,
        'grace':element.find('grace') is not None,'rest':element.find('rest') is not None,
        'pitch':{k:element.findtext('pitch/'+k) for k in ('step','alter','octave')},
        'time_modification':{k:element.findtext('time-modification/'+k) for k in ('actual-notes','normal-notes','normal-type')}}


def notation_document(path):
    """All parts, rests and attributes, with unambiguous XML element addresses.

    note_id is revision scoped; event_id is the canonical sounding/source identity.
    A tied event can map to multiple notation IDs.
    """
    identities=load_identities(path)
    root=ET.parse(path).getroot()
    for e in root.iter():e.tag=e.tag.rsplit('}',1)[-1]
    from gste.exporter.joint_tab_xml_exporter import _note_role
    from gste.exporter.canonical_tab_reader import canonical_tab_part,is_canonical_tab_note
    tab=canonical_tab_part(root);parts=[]
    for part in root.findall('part'):
        measures=[]
        for mi,m in enumerate(part.findall('measure'),1):
            notes=[]
            for ei,e in enumerate(m):
                if e.tag!='note':continue
                nid=f"{part.get('id')}:M{mi}:E{ei}"
                notes.append({'note_id':nid,'event_id':identities.get(nid,{}).get('event_id',e.findtext("notations/other-notation[@type='gste-event-id']")),
                    'role':identities.get(nid,{}).get('role','rest' if e.find('rest') is not None else _note_role(e)),
                    'canonical_tab':part is tab and is_canonical_tab_note(e,part,root),
                    'element_index':ei,'voice':e.findtext('voice','1'),**notation_fields(e)})
            measures.append({'measure':mi,'label':m.get('number'), 'xml':ET.tostring(m,encoding='unicode'),'notes':notes})
        parts.append({'part_id':part.get('id'),'measures':measures})
    return {'schema_version':'GSTE_NOTATION_V1','id_scope':'SCORE_REVISION',
        'musicxml':ET.tostring(root,encoding='unicode'),'parts':parts}


def load_identities(path):
    path=Path(path)
    exact=path.with_suffix('.notation.json')
    if exact.exists():return json.loads(exact.read_text(encoding='utf-8'))
    context=path.parent/'GSTE_EDITOR_CONTEXT.json'
    if context.exists():
        c=json.loads(context.read_text(encoding='utf-8'))
        if c.get('notation'):
            return {n['note_id']:n for p in c['notation']['parts'] for m in p['measures'] for n in m['notes']}
    sidecar=path.parent/'GSTE_NOTATION_MAP.json'
    if sidecar.exists():return json.loads(sidecar.read_text(encoding='utf-8'))
    # Legacy projects require reconversion to obtain a semantic mapping.
    # Retain the old reader behaviour only at this compatibility boundary.
    root=ET.parse(path).getroot();result={}
    for p in root.findall('part'):
        for mi,m in enumerate(p.findall('measure'),1):
            for ei,n in enumerate(m):
                if n.tag=='note':result[f"{p.get('id')}:M{mi}:E{ei}"]={'role':'melody' if n.findtext('voice','1')=='1' else 'accompaniment'}
    return result
