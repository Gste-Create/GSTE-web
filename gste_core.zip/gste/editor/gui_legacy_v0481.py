"""Thin desktop controller for local preview and shared full regeneration."""
from pathlib import Path
import json
import shutil
import threading
from queue import Queue, Empty
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from datetime import datetime

from .session import read_context, make_request, write_json, regenerate, KINDS, PATTERNS
from .score import read_score
from .local import preview, export_preview, sounding_notes, as_fingering
from .playback import AuditionPlayer, write_wav
import tempfile

LABELS={'SET_HARMONY':'修改和弦 / Harmony','SET_PATTERN':'修改伴奏方式 / Pattern',
        'ADD_ACCOMPANIMENT':'指定拍點加入伴奏 / Add accompaniment','ADD_MELODY_DOUBLE_STOP':'主旋律加入雙音 / Double stop', 'DELETE_ACCOMPANIMENT':'刪除單顆伴奏音 / Delete note'}


class ArrangementEditor(tk.Toplevel):
    def __init__(self, master, context_path=None):
        super().__init__(master)
        self.title('GSTE V0.4.8.1 — 半自動編曲 / Arrangement Editor');self.geometry('1130x850');self.minsize(950,720)
        self.context_path=None;self.context=None;self.requests=[];self.busy=False;self.rect=None;self.worker_results=Queue()
        self.audition_generation=0;self.preview_result=None;self.preview_results=Queue();self.preview_generation=0;self.preview_job=None;self.preview_running=False;self.preview_pending=None
        self.player=AuditionPlayer();self.audio_dir=tempfile.TemporaryDirectory(prefix='gste_audition_');self.view=tk.StringVar(value='原轉換');self.tempo=tk.StringVar(value='120')
        self.kind=tk.StringVar(value=LABELS[KINDS[0]]);self.chord=tk.StringVar(value='C');self.pattern=tk.StringVar(value='ARPEGGIO')
        self.density=tk.StringVar(value='medium');self.priority=tk.StringVar(value='soft');self.status=tk.StringVar(value='開啟 V0.4 轉換結果中的 GSTE_EDITOR_CONTEXT.json')
        self.start_beat=tk.StringVar(value='');self.end_beat=tk.StringVar(value='')
        bar=ttk.Frame(self,padding=10);bar.pack(fill='x')
        ttk.Button(bar,text='開啟編曲專案 / Open project',command=self.open_project).pack(side='left')
        ttk.Button(bar,text='開啟原轉換完整樂譜 / Open original',command=self.open_score).pack(side='left',padx=8)
        ttk.Button(bar,text='原樣匯出 MusicXML / Export unchanged',command=self.export_unchanged).pack(side='left',padx=8)
        ttk.Label(self,text='點選小節；點藍色旋律音符或拖曳框選，可用 Ctrl 保留多選。此頁顯示實際 TAB 摘要；完整五線譜請開啟 MusicXML。',wraplength=1050).pack(anchor='w',padx=12)
        ttk.Label(self,text='加入或移除要求後自動更新局部 TAB；局部預覽固定旋律弦格。重新生成則會重跑全曲。',foreground='#935500').pack(anchor='w',padx=12)
        audition=ttk.Frame(self);audition.pack(fill='x',padx=12)
        switch=ttk.Combobox(audition,textvariable=self.view,values=('原轉換','局部修改','再次轉換'),state='readonly',width=12);switch.pack(side='left');switch.bind('<<ComboboxSelected>>',lambda e:self.switch_view())
        ttk.Label(audition,text=' BPM ').pack(side='left');ttk.Entry(audition,textvariable=self.tempo,width=5).pack(side='left')
        for label,command in [('播放此小節',self.play_measure),('停止',self.stop_audio),('直接匯出局部結果',self.export_local)]:ttk.Button(audition,text=label,command=command).pack(side='left',padx=4)
        pane=ttk.Panedwindow(self,orient='horizontal');pane.pack(fill='both',expand=True,padx=10,pady=8)
        left=ttk.Frame(pane);right=ttk.Frame(pane);pane.add(left,weight=1);pane.add(right,weight=4)
        self.measures=ttk.Treeview(left,columns=('label','harmony'),show='headings',height=14,selectmode='browse')
        self.measures.heading('label',text='小節 / Bar');self.measures.heading('harmony',text='來源和弦 / Harmony');self.measures.column('label',width=65);self.measures.column('harmony',width=145)
        self.measures.pack(fill='both',expand=True);self.measures.bind('<<TreeviewSelect>>',self.select_measure)
        ttk.Label(right,text='藍色＝旋律，灰色＝伴奏；TAB 數字按實際起音位置排列（非完整節奏排版）。').pack(anchor='w')
        self.info_var=tk.StringVar()
        ttk.Label(right,textvariable=self.info_var,wraplength=720).pack(anchor='w',pady=4)
        self.canvas=tk.Canvas(right,height=185,background='white');self.canvas.pack(fill='x')
        self.canvas.bind('<Configure>',lambda e:self.draw_tab())
        self.canvas.bind('<Button-1>',self.canvas_down);self.canvas.bind('<B1-Motion>',self.canvas_drag);self.canvas.bind('<ButtonRelease-1>',self.canvas_up)
        self.events=ttk.Treeview(right,columns=('beat','pitch','id'),show='headings',selectmode='extended',height=6)
        for k,label,width in [('beat','拍點（四分音符=1）',130),('pitch','音高 MIDI',80),('id','旋律事件 ID',310)]:self.events.heading(k,text=label);self.events.column(k,width=width)
        self.events.pack(fill='both',expand=True);self.events.bind('<<TreeviewSelect>>',lambda e:self.draw_tab())
        ttk.Label(right,text='伴奏音符（選取後可刪除單音；跨小節延音以整個事件刪除）').pack(anchor='w')
        self.acc_events=ttk.Treeview(right,columns=('beat','pitch','note_id'),show='headings',selectmode='extended',height=4)
        for k,label,width in [('beat','拍點',80),('pitch','MIDI',65),('note_id','記譜音符 ID',320)]:
            self.acc_events.heading(k,text=label);self.acc_events.column(k,width=width)
        self.acc_events.pack(fill='x')
        controls=ttk.LabelFrame(self,text='修改要求 / Edit request',padding=8);controls.pack(fill='x',padx=10)
        ttk.Combobox(controls,textvariable=self.kind,values=list(LABELS.values()),state='readonly',width=38).grid(row=0,column=0,padx=5)
        ttk.Label(controls,text='和弦').grid(row=0,column=1);ttk.Entry(controls,textvariable=self.chord,width=9).grid(row=0,column=2)
        ttk.Label(controls,text='伴奏').grid(row=0,column=3);ttk.Combobox(controls,textvariable=self.pattern,values=PATTERNS,state='readonly',width=18).grid(row=0,column=4)
        ttk.Label(controls,text='新增密度').grid(row=0,column=5);ttk.Combobox(controls,textvariable=self.density,values=('low','medium','high'),state='readonly',width=8).grid(row=0,column=6)
        ttk.Label(controls,text='新增範圍：起拍 / 終拍（留白＝整小節）').grid(row=1,column=0,pady=6)
        ttk.Entry(controls,textvariable=self.start_beat,width=9).grid(row=1,column=1);ttk.Entry(controls,textvariable=self.end_beat,width=9).grid(row=1,column=2)
        ttk.Combobox(controls,textvariable=self.priority,values=('soft','hard'),state='readonly',width=10).grid(row=1,column=3)
        ttk.Label(controls,text='soft＝盡量；hard＝未滿足則拒絕結果').grid(row=1,column=4,columnspan=2)
        ttk.Button(controls,text='加入要求 / Add',command=self.add_request).grid(row=1,column=6)
        self.field_widgets=[(v,[w for w in controls.winfo_children() if getattr(w,'cget',None) and w.winfo_class() in ('TEntry','TCombobox') and str(w.cget('textvariable'))==str(v)]) for v in (self.chord,self.pattern,self.density,self.start_beat,self.end_beat)]
        self.kind.trace_add('write',lambda *_:self.update_fields());self.update_fields()
        self.queue=ttk.Treeview(self,columns=('summary',),show='headings',height=5,selectmode='extended');self.queue.heading('summary',text='本次修改清單（同區域衝突依加入順序覆寫）');self.queue.pack(fill='x',padx=10,pady=6)
        actions=ttk.Frame(self,padding=10);actions.pack(fill='x')
        self.buttons=[]
        for label,command in [('移除選取 / Remove',self.remove_request),('儲存要求 / Save JSON',self.save_requests),('載入要求 / Load JSON',self.load_requests),('重新生成 / Regenerate',self.run)]:
            button=ttk.Button(actions,text=label,command=command);button.pack(side='left',padx=4);self.buttons.append(button)
        ttk.Label(self,textvariable=self.status,wraplength=1060).pack(fill='x',padx=12,pady=(0,10))
        self.protocol('WM_DELETE_WINDOW',self.close_editor)
        self.after(60,self.poll_preview)
        if context_path:self.load_project(context_path)

    def open_project(self):
        if self.busy:return
        path=filedialog.askopenfilename(parent=self,title='GSTE_EDITOR_CONTEXT.json',filetypes=[('GSTE editor context','*.json')])
        if path:self.load_project(path)

    def load_project(self,path):
        try:
            context=read_context(path);score=read_score(Path(path).parent/'GSTE_TAB.musicxml')
        except Exception as exc:messagebox.showerror('Open project',str(exc),parent=self);return
        self.context_path=Path(path).resolve();self.context=context;self.score={m['measure']:m for m in score};self.original_score=self.score;self.regenerated_score=None;self.preview_result=None;self.preview_generation+=1;self.requests=[];self.view.set('原轉換')
        self.measures.delete(*self.measures.get_children());self.queue.delete(*self.queue.get_children())
        for m in context['measures']:
            chords=list(dict.fromkeys(w['harmony']['chord_symbol'] for w in context['windows'] if m['start']<=w['harmony']['start']<m['start']+m['duration']))
            self.measures.insert('', 'end',iid=str(m['measure']),values=(m['label'],' / '.join(chords) or 'NONE'))
        self.status.set(f"{self.context_path.parent.name} — 已保存修改 {len(context['edit_history'])} 筆 / inherited edits")
        if self.measures.get_children():self.measures.selection_set(self.measures.get_children()[0])

    def open_score(self):
        if self.context_path:
            from gste.desktop_app import _open_folder
            _open_folder(self.context_path.parent/'GSTE_TAB.musicxml')

    def export_unchanged(self):
        """Export the opened source TAB byte-for-byte, without editor search or serialization.

        This intentionally ignores pending edit requests and the current preview.
        """
        if self.busy or not self.context_path:
            return
        source = self.context_path.parent / 'GSTE_TAB.musicxml'
        try:
            # Revalidate the original score hash before copying.
            read_context(self.context_path)
            destination = filedialog.asksaveasfilename(
                parent=self, title='原樣匯出 TAB MusicXML（不套用修改要求）',
                defaultextension='.musicxml', initialfile='GSTE_TAB_Unchanged.musicxml',
                filetypes=[('MusicXML', '*.musicxml'), ('XML', '*.xml')])
            if not destination:
                return
            target = Path(destination).resolve()
            if target == source.resolve():
                raise ValueError('不可覆寫原始 GSTE_TAB.musicxml，請選擇其他位置。')
            shutil.copyfile(source, target)
        except Exception as exc:
            self.status.set(f'原樣匯出失敗：{exc}')
            messagebox.showerror('Export unchanged', str(exc), parent=self)
            return
        self.status.set(f'原樣匯出完成（未重新編曲、未套用修改）：{target}')
        messagebox.showinfo('Export unchanged', self.status.get(), parent=self)

    def select_measure(self,_event=None):
        selection=self.measures.selection()
        if not selection:return
        self.measure=int(selection[0]);self.events.delete(*self.events.get_children())
        self.acc_events.delete(*self.acc_events.get_children())
        for n in self.score[self.measure]['notes']:
            if n['role']!='melody' and n.get('note_id'):
                self.acc_events.insert('', 'end',iid=n['note_id'],values=(f"{n['offset']+1:g}",n['pitch'],n['note_id']))
        m=next(m for m in self.context['measures'] if m['measure']==self.measure)
        for n in self.context['melody_events']:
            if n['measure']==self.measure:self.events.insert('', 'end',iid=n['event_id'],values=(f"{n['start']-m['start']+1:g}",n['pitch']+self.context['transposition_semitones'],n['event_id']))
        windows=[w for w in self.context['windows'] if m['start']<=w['harmony']['start']<m['start']+m['duration']]
        details = [f"{w['window_id']}: {w['texture']['pattern_type']} → {', '.join(self.context.get('selected_candidate_families',{}).get(w['window_id'],[])) or 'NONE'}" for w in windows]
        self.info_var.set('規劃伴奏 → 實際候選 / Planned → Selected: ' + (' | '.join(details) or 'NONE'))
        self.start_beat.set('');self.end_beat.set('');self.draw_tab()

    def draw_tab(self):
        """Four-bar context: previous, selected, and two following bars.

        Selection remains tied to canonical melody event IDs; the other bars
        are visual context only and do not change the edit target.
        """
        self.canvas.delete('all');self.hitboxes=[]
        if not self.context or not hasattr(self,'measure'):return
        ordered=sorted(self.score)
        if self.measure not in self.score:return
        position=ordered.index(self.measure)
        visible=ordered[max(0,position-1):position+3]
        width=max(self.canvas.winfo_width(),600)
        left,right=36,width-20
        bar_width=(right-left)/max(1,len(visible))
        selected=set(self.events.selection())
        for string in range(1,7):
            y=35+string*19
            self.canvas.create_text(15,y,text=str(string))
            self.canvas.create_line(left,y,right,y,fill='#aaaaaa')
        for index,measure_id in enumerate(visible):
            m=self.score[measure_id]
            x0=left+index*bar_width
            if index:
                self.canvas.create_line(x0,28,x0,150,fill='#555555',width=2)
            self.canvas.create_text(x0+6,15,anchor='w',text=f"小節 {m['label']}" + (' ★' if measure_id==self.measure else ''))
            for n in m['notes']:
                if not n['string']:continue
                event=next((e for e in self.context['melody_events'] if
                    (e['event_id']==n.get('event_id') or
                     (not self.context.get('notation') and abs(e['start']-n['start'])<1e-5 and
                      e['pitch']+self.context['transposition_semitones']==n['pitch'])) and
                    n['role']=='melody'),None)
                x=x0+12+(bar_width-24)*n['offset']/max(m['duration'],.01)
                y=35+n['string']*19
                color='#2463ad' if n['role']=='melody' else '#666666'
                highlighted=measure_id==self.measure and event and event['event_id'] in selected
                self.canvas.create_rectangle(x-9,y-8,x+9,y+8,fill='#ffe59a' if highlighted else 'white',outline='')
                self.canvas.create_text(x,y,text=str(n['fret']),fill=color,font=('Segoe UI',10,'bold'))
                end=min(x0+bar_width-5,x+(bar_width-24)*n['duration']/max(m['duration'],.01))
                self.canvas.create_line(x+9,y+6,end,y+6,fill=color)
                if measure_id==self.measure and event:
                    self.hitboxes.append((x-11,y-10,x+11,y+10,event['event_id']))

    def canvas_down(self,e):
        self.drag_start=(e.x,e.y);self.ctrl=bool(e.state&4)
        if not self.ctrl:self.events.selection_remove(self.events.selection())
        for x1,y1,x2,y2,eid in self.hitboxes:
            if x1<=e.x<=x2 and y1<=e.y<=y2:self.events.selection_add(eid)

    def canvas_drag(self,e):
        if self.rect:self.canvas.delete(self.rect)
        self.rect=self.canvas.create_rectangle(*self.drag_start,e.x,e.y,outline='#2463ad',dash=(4,2))

    def canvas_up(self,e):
        if self.rect:
            a,b=self.drag_start;x1,x2=sorted((a,e.x));y1,y2=sorted((b,e.y))
            for a,b,c,d,eid in self.hitboxes:
                if a<=x2 and c>=x1 and b<=y2 and d>=y1:self.events.selection_add(eid)
            self.canvas.delete(self.rect);self.rect=None

    def add_request(self):
        if self.busy or not self.context:return
        try:
            kind=next(k for k,v in LABELS.items() if v==self.kind.get());r={'type':kind,'priority':self.priority.get()}
            if kind=='ADD_MELODY_DOUBLE_STOP':r['event_ids']=list(self.events.selection())
            elif kind=='DELETE_ACCOMPANIMENT':
                r['measure']=self.measure
                r['note_ids']=list(self.acc_events.selection())
            else:
                r['measure']=self.measure
                if kind=='SET_HARMONY':r['chord']=self.chord.get().strip()
                elif kind=='SET_PATTERN':r['pattern_type']=self.pattern.get()
                else:
                    r['density']=self.density.get();r['chord']=self.chord.get().strip();r['pattern_type']=self.pattern.get()
                    m=next(m for m in self.context['measures'] if m['measure']==self.measure)
                    for field,var in [('start',self.start_beat),('end',self.end_beat)]:
                        if var.get().strip():r[field]=m['start']+float(var.get())-1
            make_request(self.context,self.requests+[r]);self.requests.append(r);self.refresh_queue()
        except Exception as exc:messagebox.showerror('Edit request',str(exc),parent=self)

    def refresh_queue(self):
        self.queue.delete(*self.queue.get_children())
        self.schedule_preview()
        for i,r in enumerate(self.requests):
            target = f"小節 {r['measure']}" if 'measure' in r else f"旋律音符 {len(r['event_ids'])} 顆"
            value = ' / '.join(str(r[k]) for k in ('chord','pattern_type','density','start','end','note_ids') if k in r)
            self.queue.insert('', 'end',iid=str(i),values=(f"{i+1}. {LABELS[r['type']]} — {target} — {value} — {r.get('priority','soft')}",))

    def remove_request(self):
        if self.busy:return
        remove={int(i) for i in self.queue.selection()};self.requests=[r for i,r in enumerate(self.requests) if i not in remove];self.refresh_queue()

    def save_requests(self):
        if self.busy or not self.context:return
        path=filedialog.asksaveasfilename(parent=self,defaultextension='.json',initialfile='GSTE_EDIT_REQUEST.json')
        if path:write_json(path,make_request(self.context,self.requests))

    def load_requests(self):
        if self.busy or not self.context:return
        path=filedialog.askopenfilename(parent=self,filetypes=[('JSON','*.json')])
        if path:
            try:
                from .session import validate_requests
                packet=json.loads(Path(path).read_text(encoding='utf-8'));validate_requests(self.context,packet)
                self.requests=packet['requests'];self.refresh_queue()
            except Exception as exc:messagebox.showerror('Load requests',str(exc),parent=self)

    def run(self):
        if self.busy or not self.context or not self.requests:return
        base=filedialog.askdirectory(parent=self,title='選擇新結果的上層資料夾 / Choose output parent')
        if not base:return
        out=Path(base)/('GSTE_Edit_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
        out.mkdir();packet=out/'submitted_requests.json';write_json(packet,make_request(self.context,self.requests))
        self.busy=True;self.status.set('重新轉譜中 / Regenerating…')
        for b in self.buttons:b.state(['disabled'])
        context_path=self.context_path
        def worker():
            try:result=regenerate(context_path,packet,out)
            except Exception as exc:self.worker_results.put((None,out,str(exc)))
            else:self.worker_results.put((result,out,None))
        threading.Thread(target=worker,daemon=True).start()
        self.after(80,self.poll_worker)

    def poll_worker(self):
        try: payload = self.worker_results.get_nowait()
        except Empty:
            if self.busy: self.after(80,self.poll_worker)
            return
        self.done(*payload)

    def done(self,result,out,error):
        self.busy=False
        for b in self.buttons:b.state(['!disabled'])
        if error:
            self.status.set(f'重新生成未接受：{error} — {out}')
            messagebox.showerror('Regenerate',f'{error}\n\n{out}',parent=self);return
        data=json.loads((out/'GSTE_EDIT_RESULT.json').read_text(encoding='utf-8'))
        failed=sum(r['status'] not in ('APPLIED_WITH_REVIEW','SUPERSEDED') for r in data['requests'])
        self.regenerated_score={m['measure']:m for m in read_score(out/'GSTE_TAB.musicxml')}
        self.view.set('再次轉換');self.switch_view()
        self.status.set(f'完成；降階或未滿足 {failed} 筆。請檢查 GSTE_EDIT_RESULT.md 與完整樂譜。{out}')
        messagebox.showinfo('Regenerate',self.status.get(),parent=self)


    def stop_audio(self):
        self.audition_generation+=1;self.player.stop()

    def close_editor(self):
        if self.busy:return
        self.player.stop();self.audio_dir.cleanup();self.destroy()

    def switch_view(self):
        if not self.context:return
        self.audition_generation+=1
        mode=self.view.get()
        if mode=='局部修改' and self.preview_result:self.score=self.preview_result.score()
        elif mode=='再次轉換' and self.regenerated_score:self.score=self.regenerated_score
        else:self.score=self.original_score
        self.player.stop();self.draw_tab()

    def schedule_preview(self):
        self.preview_generation+=1;self.preview_result=None
        if self.preview_job:self.after_cancel(self.preview_job)
        self.preview_job=self.after(180,self.start_preview)
        if self.view.get()=='局部修改':self.score=self.original_score;self.draw_tab()

    def start_preview(self):
        self.preview_job=None
        if not self.context:return
        task=(self.preview_generation,self.context_path,make_request(self.context,self.requests))
        if self.preview_running:
            self.preview_pending=task;return
        self.launch_preview(task)

    def launch_preview(self,task):
        generation,path,packet=task;self.preview_running=True;self.status.set('局部可行解搜尋中…')
        def worker():
            try:result=preview(path,packet);error=None
            except Exception as exc:result=None;error=str(exc)
            self.preview_results.put(('preview',generation,result,error))
        threading.Thread(target=worker,daemon=True).start()

    def poll_preview(self):
        if not self.winfo_exists():return
        try:kind,generation,result,error=self.preview_results.get_nowait()
        except Empty:pass
        else:
            if kind=='preview':self.preview_running=False
            if generation==self.preview_generation:
                if error:self.status.set(error)
                elif kind=='audio':
                    try:
                        path,audition_generation=result
                        if audition_generation==self.audition_generation:self.player.play(path)
                    except Exception as exc:self.status.set(str(exc))
                elif kind=='export':self.status.set(f'局部結果已匯出：{result}')
                else:
                    self.preview_result=result;self.view.set('局部修改');self.switch_view()
                    missing=[o for o in result.outcomes if o['status']!='APPLIED']
                    detail='；'.join(o['window_id']+': '+o['status'] for o in missing)
                    self.status.set(f'局部搜尋 {result.elapsed_ms:.0f} ms — '+(('可直接匯出；'+detail) if result.accepted else '未完全可行；'+detail))
            if kind=='preview' and self.preview_pending:
                pending=self.preview_pending;self.preview_pending=None
                if pending[0]==self.preview_generation:self.launch_preview(pending)
        self.after(60,self.poll_preview)

    def play_measure(self):
        if not self.context or not hasattr(self,'measure'):return
        if self.view.get()=='局部修改' and (not self.preview_result or not self.preview_result.accepted):
            self.status.set('請等候可行的局部預覽後再播放。');return
        try:
            bpm=float(self.tempo.get());score=list(self.score.values());m=self.score[self.measure]
            notes=tuple((as_fingering(n),'melody' if n['role']=='melody' else 'accompaniment') for n in sounding_notes(score))
        except Exception as exc:self.status.set(str(exc));return
        self.audition_generation+=1;audition_generation=self.audition_generation
        generation=self.preview_generation;path=Path(self.audio_dir.name)/f'audition_{generation}_{audition_generation}.wav'
        self.player.stop()
        def worker():
            try:result=write_wav(notes,path,start=m['start'],end=m['start']+m['duration'],bpm=bpm);error=None
            except Exception as exc:result=None;error=str(exc)
            self.preview_results.put(('audio',generation,(result,audition_generation),error))
        threading.Thread(target=worker,daemon=True).start()

    def export_local(self):
        if not self.preview_result or not self.preview_result.accepted:
            self.status.set('局部結果未完全可行，請先處理未滿足的要求。');return
        base=filedialog.askdirectory(parent=self,title='局部結果輸出資料夾')
        if not base:return
        try:bpm=float(self.tempo.get())
        except ValueError:self.status.set('BPM 必須是數字。');return
        out=Path(base)/('GSTE_Local_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
        generation=self.preview_generation;preview_result=self.preview_result
        self.status.set('匯出局部 MusicXML 與試聽 WAV…')
        def worker():
            try:result=export_preview(preview_result,out,bpm=bpm);error=None
            except Exception as exc:result=None;error=str(exc)
            self.preview_results.put(('export',generation,result,error))
        threading.Thread(target=worker,daemon=True).start()

    def update_fields(self):
        kind=next(k for k,v in LABELS.items() if v==self.kind.get())
        active=[(self.chord,kind in ('SET_HARMONY','ADD_ACCOMPANIMENT')),(self.pattern,kind in ('SET_PATTERN','ADD_ACCOMPANIMENT')),(self.density,kind=='ADD_ACCOMPANIMENT'),(self.start_beat,kind=='ADD_ACCOMPANIMENT'),(self.end_beat,kind=='ADD_ACCOMPANIMENT')] 
        for widget in next(widgets for v,widgets in self.field_widgets if v is self.pattern):
            widget.configure(values=PATTERNS[:-1] if kind=='ADD_ACCOMPANIMENT' else PATTERNS)
        if kind=='ADD_ACCOMPANIMENT' and self.pattern.get()=='REST':self.pattern.set('ARPEGGIO')
        for variable,widgets in self.field_widgets:
            for widget in widgets:
                widget.configure(state=('readonly' if widget.winfo_class()=='TCombobox' else 'normal') if next(enabled for v,enabled in active if v is variable) else 'disabled')
