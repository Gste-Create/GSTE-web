"""Bounded local feasibility over shared arrangement candidates; melody is frozen."""
from dataclasses import dataclass, replace, fields
from pathlib import Path
from types import SimpleNamespace
import time
import math

from gste.core.models import NoteEvent, Pitch, FingeringCandidate
from gste.core.fretboard import midi_to_string_fret
from gste.core.tuning import resolve_tuning
from gste.arrangement.canonical import model as canonical
from gste.arrangement.data_contract import AccompanimentData
from gste.arrangement.models.source_analysis import SourceNoteObservation
from gste.arrangement.engine.service import arrange
from gste.fingering.canonical_validator import CanonicalHandNote, validate_canonical_timeline, timeline_boundaries
from gste.joint_arrangement.hand_shape import evaluate_timed_hand_shape
from .session import CURRENT, EditorSession, read_context, validate_requests, parse_chord
from .score import read_score


def decode_window(row):
    """Decode the existing canonical JSON contract at the editor boundary only."""
    def decode(cls, value):
        return cls(**{f.name:tuple(value[f.name]) if str(f.type).startswith("tuple") else value[f.name] for f in fields(cls) if f.name in value})
    values=dict(row)
    for key, cls in [('harmony',canonical.HarmonyIntent),('bass',canonical.BassIntent),
                     ('rhythm',canonical.RhythmIntent),('texture',canonical.TextureIntent),
                     ('phrase',canonical.PhraseIntent),('section',canonical.SectionIntent)]:
        values[key]=decode(cls,row[key]) if row.get(key) else None
    for key, cls in [('evidence',canonical.SourceEvidence),('source_tones',canonical.SourceTone),('observations',SourceNoteObservation)]:
        values[key]=tuple(decode(cls,v) for v in row.get(key,()))
    return canonical.CanonicalArrangementIntent(**values)


def sounding_notes(score):
    """Read one sounding interval per event; voice never identifies a tie.

    Tied notation must carry an event ID. Never guess a continuation by pitch
    or voice when identity is missing. Untied legacy notes remain readable.
    """
    result=[]; active={}
    segments=[(m['measure'],n) for m in score for n in m['notes']]
    segments.sort(key=lambda item:(item[1]['start'],not item[1].get('tie_stop',False)))
    for measure,n in segments:
        event_id=n.get('event_id')
        stop=n.get('tie_stop',False); start=n.get('tie_start',False)
        if (start or stop) and (not math.isfinite(n['start']) or not math.isfinite(n['duration']) or n['duration']<=0):
            raise ValueError(f'Invalid tie timing for event {event_id}.')
        if (start or stop) and not event_id:
            raise ValueError('Missing event ID for tied note; reconvert the source to create an identity-aware editor project.')
        if stop:
            previous=active.get(event_id)
            if previous is None:
                raise ValueError(f'Disconnected tie for event {event_id}: no active tie start.')
            for field in ('pitch','string','fret','role'):
                if previous.get(field)!=n.get(field):
                    raise ValueError(f'Tie {field} mismatch for event {event_id}.')
            if abs(previous['start']+previous['duration']-n['start'])>1e-5:
                raise ValueError(f'Disconnected tie for event {event_id}: non-contiguous timing.')
            previous['duration']+=n['duration']
            previous['notation_note_ids'].append(n.get('note_id'))
            previous['notation_voices'].append(n.get('voice'))
            previous['tie_segment_count']+=1
        else:
            if event_id and event_id in active:
                raise ValueError(f'Overlapping attack for active tied event {event_id}.')
            previous={**n,'measure':measure,'tie_start':False,'tie_stop':False,
                'notation_note_ids':[n.get('note_id')],'notation_voices':[n.get('voice')],
                'tie_segment_count':1}
            result.append(previous)
        if start:active[event_id]=previous
        elif event_id:active.pop(event_id,None)
    if active:
        raise ValueError('Unclosed tie in exported score: '+', '.join(map(str,active)))
    return result


def as_fingering(n):
    note=NoteEvent(Pitch(n['pitch']),n['start'],n['duration'],n['measure'],source_event_id=n.get('event_id'))
    return FingeringCandidate(note,n['string'],n['fret'],0)


def hand_note(f,role):
    n=f.note
    return CanonicalHandNote(role,f.string,f.fret,n.start,n.start+n.duration,n.pitch.midi,n.measure)


def feasible(melody, accompaniment, interval=None):
    pairs=[(f,'melody') for f in melody]+[(f,'accompaniment') for f in accompaniment]
    if interval is not None:
        a,b=interval;pairs=[(f,r) for f,r in pairs if f.note.start<b-1e-7 and f.note.start+f.note.duration>a+1e-7]
    notes=tuple(hand_note(f,r) for f,r in pairs)
    if interval is not None:
        notes=tuple(replace(n,start=max(n.start,a),end=min(n.end,b)) for n in notes)
        pairs=[(replace(f,note=replace(f.note,start=max(f.note.start,a),duration=min(f.note.start+f.note.duration,b)-max(f.note.start,a))),r) for f,r in pairs]
    from gste.control import get_value
    if validate_canonical_timeline(notes,maximum_fret_distance=int(get_value('joint.melody_accompaniment_distance_hard',4))):return False
    return evaluate_timed_hand_shape(tuple(f for f,r in pairs if r=='melody'),tuple(f for f,r in pairs if r!='melody'))[0]


@dataclass(frozen=True)
class LocalPreview:
    context_path: Path
    packet: dict
    notes: tuple
    changed_measures: tuple
    outcomes: tuple
    harmonies: tuple
    elapsed_ms: float
    accepted: bool

    def score(self):
        rows=read_score(self.context_path.parent/'GSTE_TAB.musicxml')
        for m in rows:
            m['notes']=[]
            for f,role in self.notes:
                start=max(f.note.start,m['start']);end=min(f.note.start+f.note.duration,m['start']+m['duration'])
                if end<=start+1e-7:continue
                m['notes'].append({'start':start,'offset':start-m['start'],'duration':end-start,
                    'pitch':f.note.pitch.midi,'string':f.string,'fret':f.fret,'voice':'1' if role=='melody' else '2',
                    'role':role,'event_id':f.note.source_event_id,'tie_stop':start>f.note.start+1e-7,'tie_start':end<f.note.start+f.note.duration-1e-7})
        return {m['measure']:m for m in rows}


def preview(context_path, packet, *, search_budget=12000):
    began=time.perf_counter();context_path=Path(context_path).resolve();context=read_context(context_path)
    validate_requests(context,packet)
    source=read_score(context_path.parent/'GSTE_TAB.musicxml');notes=sounding_notes(source)
    melody=[]
    for n in notes:
        if n['role']=='melody':
            e=next((e for e in context['melody_events'] if (e['event_id']==n.get('event_id') or (not context.get('notation') and abs(e['start']-n['start'])<1e-5 and e['pitch']+context['transposition_semitones']==n['pitch']))),None)
            n['event_id']=e['event_id'] if e else n.get('event_id')
            melody.append(as_fingering(n))
    virtual_windows=not context['windows']
    if virtual_windows and packet['requests']:
        # NONE has no accompaniment intent. Reuse the AUTO analysis producer to
        # supply its canonical window grid; initialize every window as silence.
        from gste.input_formats.router import parse_source_track
        from gste.arrangement.auto.harmony import optimize_progression
        from gste.arrangement.auto.canonical_intent import build_melody_canonical_intents
        from gste.arrangement.models import serializable
        original_track=parse_source_track(context_path.parent/context['conversion']['melody'],track_id='local',role='melody')
        timeline=replace(original_track,notes=[f.note for f in melody])
        progression=optimize_progression(timeline.notes,timeline.source_file,timeline)
        canonical_rows=build_melody_canonical_intents(progression,timeline=timeline)
        context={**context,'windows':serializable(tuple(replace(c,texture=replace(c.texture,pattern_type='REST'),
            rhythm=replace(c.rhythm,rhythm_pattern=(),attack_sizes=())) for c in canonical_rows))}
    events={e['event_id']:e for e in context['melody_events']}
    touched={r['measure'] for r in packet['requests'] if 'measure' in r}
    touched.update(events[i]['measure'] for r in packet['requests'] if r['type']=='ADD_MELODY_DOUBLE_STOP' for i in r['event_ids'])
    def affects(r,c):
        if r['type'] == 'DELETE_ACCOMPANIMENT': return False
        a=c.harmony.start;b=a+c.harmony.duration
        if r['type']=='ADD_MELODY_DOUBLE_STOP':return any(a<=events[i]['start']<b-1e-7 for i in r['event_ids'])
        m=next(m for m in context['measures'] if m['measure']==r['measure'])
        return max(a,r.get('start',m['start']))<min(b,r.get('end',m['start']+m['duration']))-1e-7
    selected_rows=[decode_window(raw) for raw in context['windows'] if any(affects(r,decode_window(raw)) for r in packet['requests'])]
    replace_rows=[c for c in selected_rows if any(r['type'] in ('SET_HARMONY','SET_PATTERN') and affects(r,c) for r in packet['requests'])]
    for r in packet['requests']:
        if r['type'] in ('SET_HARMONY','SET_PATTERN') and ('start' in r or 'end' in r):
            m=next(m for m in context['measures'] if m['measure']==r['measure'])
            boundaries={round(c.harmony.start,6) for c in selected_rows}|{round(c.harmony.start+c.harmony.duration,6) for c in selected_rows}
            if any(round(r.get(k,default),6) not in boundaries for k,default in [('start',m['start']),('end',m['start']+m['duration'])]):
                raise ValueError('Harmony/pattern ranges must align with canonical window boundaries. Fill-rest ranges may use any beat.')
    deleted_ids={nid for r in packet['requests'] if r['type']=='DELETE_ACCOMPANIMENT' for nid in r['note_ids']}
    deleted_events={n.get('event_id') for n in notes if n['role']!='melody' and deleted_ids.intersection(n.get('notation_note_ids',()))}
    unchanged=[as_fingering(n) for n in notes if n['role']!='melody' and n.get('event_id') not in deleted_events and not deleted_ids.intersection(n.get('notation_note_ids',())) and not any(c.harmony.start-1e-7<=n['start']<c.harmony.start+c.harmony.duration-1e-7 for c in replace_rows)]
    tuning=resolve_tuning(context['conversion'].get('tuning_name','standard'),context['conversion'].get('custom_tuning'))
    # Work entirely in output pitch space, so local editing never reruns register/key search.
    shift=0 if virtual_windows else context['transposition_semitones'];rows=[]
    for c in selected_rows:
        h=c.harmony
        from gste.harmony.library import chord_family_name
        from gste.harmony.models import ChordFamily
        from gste.harmony.library import QUALITY_INTERVALS
        required,optional=QUALITY_INTERVALS[h.quality]
        h=replace(h,root_pitch_class=(h.root_pitch_class+shift)%12,
            chord_symbol=chord_family_name(ChordFamily((h.root_pitch_class+shift)%12,h.quality,required,optional)),
            required_pitch_classes=tuple((p+shift)%12 for p in h.required_pitch_classes),optional_pitch_classes=tuple((p+shift)%12 for p in h.optional_pitch_classes))
        # Source restrictions were already realized in the baseline. New local intent is user-owned.
        rows.append(replace(c,harmony=h,bass=replace(c.bass,pitch_class=(c.bass.pitch_class+shift)%12 if c.bass.pitch_class is not None else None,
            primary_pitch=c.bass.primary_pitch+shift if c.bass.primary_pitch is not None else None),source_tones=(),functional_roles=(),
            metadata={k:v for k,v in c.metadata.items() if not k.startswith('editor_')}))
    # Reconstruct the source metric grid through the SAME parser as formal
    # conversion. Never infer meter from rendered TAB or default to 4/4.
    from gste.input_formats.router import parse_source_track
    source_path=context_path.parent/context['conversion']['melody']
    source_track=parse_source_track(source_path,track_id='editor_metric',role='melody')
    track=SimpleNamespace(notes=tuple(f.note for f in melody),measure_starts={m['measure']:m['start'] for m in context['measures']},
        measure_lengths={m['measure']:m['duration'] for m in context['measures']},metric_groups=source_track.metric_groups)
    expected={(m['measure'],round(m['start'],6),round(m['duration'],6)) for m in context['measures']}
    actual={(m,round(s,6),round(source_track.measure_lengths[m],6)) for m,s in source_track.measure_starts.items()}
    if expected != actual:
        raise ValueError('Editor source meter timeline differs from current score; reconvert source.')
    session=EditorSession(SimpleNamespace(editor_context=None,edit_requests=None,kind='local',accompaniment_mode='AUTO_GENERATED'))
    session.base={**context,'transposition_semitones':0,'key_semitones':0,
        'melody_events':[{**e,'pitch':e['pitch']+shift} for e in context['melody_events']]}
    session.requests=packet['requests']
    token=CURRENT.set(session)
    try:plan=arrange(track,AccompanimentData(tuple(rows),True))
    finally:CURRENT.reset(token)
    chosen=list(unchanged);outcomes=[];harmonies=[]
    for row,group in zip(plan.accompaniment_data.windows,plan.candidate_groups):
        harmonies.append((row.harmony.start,row.harmony.root_pitch_class,row.harmony.quality))
        m=next(m for m in context['measures'] if m['start']<=row.harmony.start<m['start']+m['duration']-1e-7)
        baseline=[f.fret for f,r in [(f,'melody') for f in melody]+[(as_fingering(n),'accompaniment') for n in notes if n['measure']==m['measure'] and n['role']!='melody'] if f.fret>0 and f.note.start<row.harmony.start+row.harmony.duration and f.note.start+f.note.duration>row.harmony.start]
        center=sum(baseline)/len(baseline) if baseline else 3.
        replace_window=any(c.window_id==row.window_id for c in replace_rows)
        steps=[0];winner=None
        def search(event_list,index,acc):
            if steps[0]>=search_budget:return None
            steps[0]+=1
            if index==len(event_list):return tuple(acc)
            e=event_list[index]
            n=NoteEvent(Pitch(e.pitch),e.onset,e.duration,m['measure'],source_event_id=e.event_id,
                intent_id=e.intent_id,candidate_id=e.candidate_id,pattern_type=e.pattern_type,provenance=e.provenance)
            positions=sorted(midi_to_string_fret(e.pitch,max_fret=context['conversion'].get('max_fret',17),tuning=tuning),key=lambda sf:(abs(sf[1]-center) if sf[1] else 1.,sf))
            for string,fret in positions:
                f=FingeringCandidate(n,string,fret,0)
                if feasible(melody,chosen+acc+[f],(n.start,n.start+n.duration)):
                    found=search(event_list,index+1,acc+[f])
                    if found is not None:return found
            return None
        target_attacks={round(row.harmony.start+t,6) for t in row.rhythm.rhythm_pattern}
        group=sorted(group,key=lambda candidate:(len(target_attacks-{round(e.onset,6) for e in candidate.events}),candidate.texture!=row.texture.pattern_type,len(candidate.events)))
        for candidate in group:
            event_list=candidate.events
            if not replace_window:
                fills=row.metadata.get('editor_add_attacks',())
                doubles={t for eid,t,p in row.metadata.get('editor_double_stops',())}
                event_list=tuple(e for e in event_list if any(abs(e.onset-t)<1e-6 for t in (*fills,*doubles)))
            if any(r.get('chord') and affects(r,row) for r in packet['requests']):
                allowed=set(row.harmony.required_pitch_classes)|set(row.harmony.optional_pitch_classes)
                if any(e.pitch%12 not in allowed for e in event_list):continue
            double_targets=row.metadata.get('editor_double_stops',())
            if any(not any(abs(e.onset-t)<1e-6 and 0<pitch-e.pitch<=12 for e in event_list) for eid,t,pitch in double_targets):
                continue
            winner=search(sorted(event_list,key=lambda e:(e.onset,-e.importance,e.pitch)),0,[])
            if winner is not None:break
        if winner is None:
            outcomes.append({'window_id':row.window_id,'status':'UNSATISFIED','reason':'SEARCH_BUDGET' if steps[0]>=search_budget else 'NO_LOCAL_FEASIBLE_CANDIDATE','searched_nodes':steps[0]})
        else:
            chosen.extend(winner)
            expected={round(row.harmony.start+t,6) for t in row.rhythm.rhythm_pattern}
            if not replace_window:
                expected={round(t,6) for t in (*row.metadata.get('editor_add_attacks',()),*(t for eid,t,p in row.metadata.get('editor_double_stops',())))}
            actual={round(f.note.start,6) for f in winner}
            outcomes.append({'window_id':row.window_id,'status':('UNSATISFIED' if (not expected and not replace_window) or (expected and not actual) else ('APPLIED' if expected<=actual and candidate.texture==row.texture.pattern_type else 'DEGRADED')),'searched_nodes':steps[0],
                'candidate_id':candidate.candidate_id,'missing_attacks':sorted(expected-actual)})
    def validation_spans(c):
        spans=[]
        for r in packet['requests']:
            if not affects(r,c):continue
            if r['type']=='ADD_MELODY_DOUBLE_STOP':
                spans.extend((events[i]['start'],events[i]['start']+events[i]['duration']) for i in r['event_ids'] if c.harmony.start<=events[i]['start']<c.harmony.start+c.harmony.duration-1e-7)
            else:
                spans.append((max(c.harmony.start,r.get('start',c.harmony.start)),min(c.harmony.start+c.harmony.duration,r.get('end',c.harmony.start+c.harmony.duration))))
        return spans
    for index,c in enumerate(plan.accompaniment_data.windows):
        if not all(feasible(melody,chosen,span) for span in validation_spans(c)):
            outcomes[index]={**outcomes[index],'status':'UNSATISFIED','reason':'LOCAL_SOUNDING_HAND_CONFLICT'}
    hard_windows={c.window_id for c in selected_rows if any(r.get('priority','soft')=='hard' and affects(r,c) for r in packet['requests'])}
    accepted=all(o['status']!='UNSATISFIED' and (o['status']=='APPLIED' or o['window_id'] not in hard_windows) for o in outcomes)
    return LocalPreview(context_path,packet,tuple([(f,'melody') for f in melody]+[(f,'accompaniment') for f in chosen]),
        tuple(sorted(touched)),tuple(outcomes),tuple(harmonies),(time.perf_counter()-began)*1000,accepted)


def export_preview(result, output_dir, *, bpm=120.):
    """Export the accepted frozen score, audition and reproducible original-revision request."""
    import shutil
    import tempfile
    from .session import write_json, digest
    from .playback import write_wav
    from gste.exporter.joint_tab_xml_exporter import frozen_local_to_musicxml
    if not result.accepted:raise ValueError('Preview is not fully feasible; resolve the reported windows before direct export.')
    out=Path(output_dir).resolve()
    if out.exists():raise ValueError('Choose a new output directory.')
    out.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(dir=out.parent) as temp:
        stage=Path(temp)
        score=stage/'GSTE_LOCAL_TAB.musicxml'
        score.write_text(frozen_local_to_musicxml(result.context_path.parent/'GSTE_TAB.musicxml',result.notes,result.harmonies),encoding='utf-8')
        from gste.exporter.public_musicxml_sanitizer import sanitize_public_musicxml
        sanitize_public_musicxml(score)
        # Validate the actual final bytes, including tied sounding durations and preserved melody.
        actual=sounding_notes(read_score(score))
        expected=sorted((round(f.note.start,5),round(f.note.duration,5),f.note.pitch.midi,f.string,f.fret,r) for f,r in result.notes)
        observed=sorted((round(n['start'],5),round(n['duration'],5),n['pitch'],n['string'],n['fret'],'melody' if n['role']=='melody' else 'accompaniment') for n in actual)
        if expected!=observed:raise ValueError('Local export interval integrity failed.')
        from .score import notation_document
        write_json(stage/'GSTE_LOCAL_NOTATION.json',{'notation':notation_document(score),'score_notes':read_score(score)})
        write_wav(result.notes,stage/'GSTE_LOCAL_AUDITION.wav',bpm=bpm)
        write_json(stage/'GSTE_EDIT_REQUEST.json',result.packet)
        # Portable baseline project for full regeneration and three-way comparison.
        original=stage/'original';original.mkdir()
        shutil.copy2(result.context_path,original/'GSTE_EDITOR_CONTEXT.json')
        shutil.copy2(result.context_path.parent/'GSTE_TAB.musicxml',original/'GSTE_TAB.musicxml')
        context=read_context(result.context_path)
        for rel in context['input_sha256']:
            src=(result.context_path.parent/rel).resolve()
            if not src.is_relative_to(result.context_path.parent) or digest(src)!=context['input_sha256'][rel]:raise ValueError('Original source input missing or changed.')
            target=original/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,target)
        write_json(stage/'GSTE_LOCAL_RESULT.json',{'stage':'LOCAL_FEASIBILITY','source_revision':result.packet['source_revision'],
            'accepted':result.accepted,'changed_measures':result.changed_measures,'windows':result.outcomes,'elapsed_ms':result.elapsed_ms,
            'score_sha256':digest(score),'artifact_trace':{'writer':'joint_tab_xml_exporter.frozen_local_to_musicxml','postprocessors':[]},
            'regenerate_context':'original/GSTE_EDITOR_CONTEXT.json','requests':'GSTE_EDIT_REQUEST.json'})
        from gste.diagnostics import PipelineDiagnosticsRecorder
        recorder=PipelineDiagnosticsRecorder(stage/'debug')
        recorder.record('execution_scope','LOCAL_FEASIBILITY_NO_GLOBAL_SEARCH')
        recorder.record('editor_requests',result.packet)
        recorder.record('local_feasibility',{'windows':result.outcomes,'accepted':result.accepted,'elapsed_ms':result.elapsed_ms})
        recorder.record_transition('LOCAL_FEASIBILITY',input_summary={'revision':result.packet['source_revision'],'requests':len(result.packet['requests'])},output_summary={'notes':len(result.notes),'changed_measures':result.changed_measures})
        recorder.checkpoint('LOCAL_FINAL_ARTIFACT',details={'writer':'joint_tab_xml_exporter.frozen_local_to_musicxml','interval_integrity':'PASS','score_sha256':digest(score)})
        recorder.complete()
        out.mkdir()
        for file in stage.iterdir():shutil.move(str(file),out/file.name)
    return out
