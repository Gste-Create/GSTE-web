from __future__ import annotations

from contextvars import ContextVar
from dataclasses import asdict, replace
from hashlib import sha256
from pathlib import Path
import json
import re
import shutil
import math

from gste.arrangement.canonical.model import SourceEvidence
from gste.arrangement.data_contract import AccompanimentData
from gste.arrangement.models import serializable
from gste.harmony.library import QUALITY_INTERVALS
from gste.arrangement.auto.rhythm import rhythm_attacks

CURRENT = ContextVar('gste_editor_session', default=None)
SCHEMA = 'GSTE_EDITOR_V1'
PATTERNS = ('ROOT', 'ROOT_GUIDE', 'SPARSE_ARPEGGIO', 'ARPEGGIO', 'COMPACT_BLOCK', 'REST')
KINDS = ('SET_HARMONY', 'SET_PATTERN', 'ADD_ACCOMPANIMENT', 'ADD_MELODY_DOUBLE_STOP', 'DELETE_ACCOMPANIMENT')
SUFFIX = {'': 'major', 'm': 'minor', '7': 'dominant7', 'maj7': 'maj7', 'm7': 'minor7',
          'sus2': 'sus2', 'sus4': 'sus4', 'dim': 'diminished', 'dim7': 'diminished7', 'm7b5': 'half_diminished7'}


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')


def parse_chord(symbol):
    match = re.fullmatch(r'([A-G])([#b]?)(maj7|m7b5|m7|m|7|sus2|sus4|dim7|dim)?', symbol.strip())
    if not match:
        raise ValueError('Unsupported chord. Examples: C, Am, G7, Fmaj7, Asus2, Bm7b5.')
    root = ({'C': 0, 'D': 2, 'E': 4, 'F': 5, 'G': 7, 'A': 9, 'B': 11}[match[1]] + {'': 0, '#': 1, 'b': -1}[match[2]]) % 12
    return root, SUFFIX[match[3] or '']


def read_context(path):
    path = Path(path).resolve()
    context = json.loads(path.read_text(encoding='utf-8'))
    if context.get('schema_version') != SCHEMA:
        raise ValueError('This is not a V0.4 GSTE editor project.')
    score = path.parent / 'GSTE_TAB.musicxml'
    if not score.is_file() or digest(score) != context['score_sha256']:
        raise ValueError('Score changed since conversion. Reconvert the source to create a matching editor project.')
    return context


def make_request(context, requests):
    packet = {'schema_version': SCHEMA, 'source_revision': context['revision'], 'requests': requests}
    validate_requests(context, packet)
    return packet


def validate_requests(context, packet):
    if packet.get('schema_version') != SCHEMA or packet.get('source_revision') != context['revision']:
        raise ValueError('Edit requests belong to a different score revision.')
    requests = packet.get('requests')
    if not isinstance(requests, list) or len(requests) > 2000:
        raise ValueError('requests must be a list with at most 2000 entries.')
    measures = {m['measure'] for m in context['measures']}
    ids = {n['event_id']: n for n in context['melody_events']}
    for r in requests:
        if not isinstance(r, dict) or r.get('type') not in KINDS or r.get('priority', 'soft') not in ('soft', 'hard'):
            raise ValueError('Invalid edit type or priority.')
        if r['type'] == 'DELETE_ACCOMPANIMENT':
            selected = r.get('note_ids')
            notation = {n['note_id']: n for m in context.get('score_notes', []) for n in m['notes'] if n.get('note_id')}
            if not isinstance(selected, list) or not selected or any(nid not in notation or notation[nid]['role'] == 'melody' for nid in selected):
                raise ValueError('Select valid accompaniment notation note IDs.')
        if r['type'] == 'ADD_MELODY_DOUBLE_STOP':
            if 'note_ids' in r:
                mapping={n['note_id']:n for p in context.get('notation',{}).get('parts',[]) for m in p['measures'] for n in m['notes']}
                mapping.update({n['note_id']:n for m in context.get('score_notes',[]) for n in m['notes']})
                selected=r['note_ids']
                if not isinstance(selected,list) or not selected or any(nid not in mapping or mapping[nid]['role']!='melody' or mapping[nid].get('event_id') not in ids for nid in selected):
                    raise ValueError('Select valid canonical melody note IDs from this score revision.')
                resolved=list(dict.fromkeys(mapping[nid]['event_id'] for nid in selected))
                if 'event_ids' in r and set(r['event_ids'])!=set(resolved):raise ValueError('note_ids and event_ids disagree.')
                r['event_ids']=resolved
            event_ids = r.get('event_ids')
            if not isinstance(event_ids, list) or not event_ids or any(i not in ids for i in event_ids):
                raise ValueError('Select valid melody event IDs from this editor project.')
        else:
            if type(r.get('measure')) is not int or r['measure'] not in measures:
                raise ValueError('Invalid physical measure index.')
            if 'start' in r or 'end' in r:
                m = next(m for m in context['measures'] if m['measure'] == r['measure'])
                a, b = r.get('start', m['start']), r.get('end', m['start']+m['duration'])
                if not all(type(v) in (float, int) and math.isfinite(v) for v in (a,b)) or not m['start'] <= a < b <= m['start']+m['duration']+1e-7:
                    raise ValueError('Edit range must lie inside the selected measure.')
            if r['type'] == 'SET_HARMONY': parse_chord(r.get('chord', ''))
            if r['type'] == 'SET_PATTERN' and r.get('pattern_type') not in PATTERNS:
                raise ValueError('Unsupported accompaniment pattern.')
            if r['type'] == 'ADD_ACCOMPANIMENT':
                if r.get('chord'):parse_chord(r['chord'])
                if 'pattern_type' in r and r['pattern_type'] not in PATTERNS[:-1]:raise ValueError('Adding accompaniment requires a sounding pattern.')
            if r['type'] == 'ADD_ACCOMPANIMENT' and r.get('density', 'medium') not in ('low', 'medium', 'high'):
                raise ValueError('Unsupported fill density.')




def requested_add_attacks(window, request, metric_groups):
    a=window.harmony.start;b=a+window.harmony.duration
    begin,end=max(a,request.get('start',a)),min(b,request.get('end',b))
    if begin>=end-1e-7:return ()
    offsets=rhythm_attacks(a,b-a,metric_groups,
        pattern_type=request.get('pattern_type','SPARSE_ARPEGGIO'),
        density=request.get('density','medium'))
    return tuple(round(a+t,7) for t in offsets if begin-1e-7<=a+t<end-1e-7)

def override_harmony(harmony, bass, symbol, shift):
    root, quality = parse_chord(symbol)
    root = (root-shift) % 12
    from gste.harmony.library import chord_family_name
    from gste.harmony.models import ChordFamily
    required, optional = QUALITY_INTERVALS[quality]
    return (replace(harmony, root_pitch_class=root, chord_symbol=chord_family_name(ChordFamily(root,quality,required,optional)), quality=quality,
        required_pitch_classes=tuple((root+i)%12 for i in required), optional_pitch_classes=tuple((root+i)%12 for i in optional), color_pitch_classes=(), reasons=('USER_HARMONY',)),
        replace(bass,pitch_class=root,primary_pitch=48+root,bass_sequence=(),motion='STATIC_BASS'))

class EditorSession:
    """A conversion-local request adapter, never a second arranger/monitor.

    The ContextVar carries the explicit ConversionRequest through legacy route
    adapters. It is reset in finally, so parallel conversions cannot share edits.
    """
    def __init__(self, request):
        self.request = request
        self.rows = ()
        self.melody = None
        self.shift = 0
        self.base = None
        self.requests = []
        if request.editor_context is not None:
            self.base = read_context(request.editor_context)
            packet = json.loads(Path(request.edit_requests).read_text(encoding='utf-8')) if request.edit_requests else make_request(self.base, [])
            validate_requests(self.base, packet)
            self.requests = self.base.get('edit_history', []) + packet['requests']
        elif request.edit_requests:
            raise ValueError('edit_requests requires editor_context.')

    def apply(self, melody, data):
        self.melody = melody
        self.rows = data.windows
        metric_groups = getattr(melody, "metric_groups", None)
        if metric_groups is None:
            raise ValueError("Editor rhythm requires original source metric groups")
        boundaries={round(v,6) for c in data.windows for v in (c.harmony.start,c.harmony.start+c.harmony.duration)}
        for r in self.requests:
            if r['type'] in ('SET_HARMONY','SET_PATTERN') and any(k in r and round(r[k],6) not in boundaries for k in ('start','end')):
                raise ValueError('Harmony/pattern ranges must align with canonical window boundaries; the requested fragment cannot be silently enlarged.')
        notes = {n.source_event_id: n for n in melody.notes if n.source_event_id}
        if self.base:
            for n in self.base['melody_events']:
                if n['event_id'] not in notes:
                    raise ValueError('Source event identity changed; create a new project.')
        edited = []
        for c in data.windows:
            a, b = c.harmony.start, c.harmony.start+c.harmony.duration
            measure = next((m for m, s in melody.measure_starts.items() if s <= a < s+melody.measure_lengths[m]-1e-7), None)
            metadata = dict(c.metadata)
            harmony, bass, rhythm, texture = c.harmony, c.bass, c.rhythm, c.texture
            touched = []
            # NONE projects need canonical windows only to edit selected regions.
            if self.request.kind == 'melody' and self.request.accompaniment_mode == 'NONE':
                texture = replace(texture, pattern_type='REST')
                rhythm = replace(rhythm, rhythm_pattern=(), attack_sizes=())
            for index, r in enumerate(self.requests):
                if r['type'] == 'DELETE_ACCOMPANIMENT':
                    continue  # Output-only edit, never changes canonical arrangement.
                if r['type'] == 'ADD_MELODY_DOUBLE_STOP':
                    selected = [notes[i] for i in r['event_ids'] if i in notes and a <= notes[i].start < b-1e-7]
                    if not selected: continue
                    attacks = tuple(sorted({round(n.start-a, 7) for n in selected}))
                    attacks = tuple(sorted(set(rhythm.rhythm_pattern) | set(attacks)))
                    metadata['editor_double_durations'] = {**metadata.get('editor_double_durations',{}), **{n.source_event_id:n.duration for n in selected}}
                    double_targets = {eid:(eid,t,pitch) for eid,t,pitch in metadata.get('editor_double_stops',())}
                    octave_shift = 0
                    if self.base:
                        from gste.register_key_optimization import register_key_candidates
                        key_shift = self.base.get('key_semitones', next(c.key_semitones for c in register_key_candidates() if c.total_shift==self.base['transposition_semitones']))
                        octave_shift = self.base['transposition_semitones'] - key_shift
                    double_targets.update({n.source_event_id:(n.source_event_id,n.start,n.pitch.midi+octave_shift) for n in selected})
                    metadata['editor_double_stops'] = tuple(double_targets.values())
                    if texture.pattern_type=='REST':
                        metadata['requested_texture'] = 'ROOT_GUIDE'
                        texture = replace(texture, pattern_type='ROOT_GUIDE')
                    rhythm = replace(rhythm, rhythm_pattern=attacks, attack_sizes=(1,)*len(attacks), density='SD1')
                else:
                    if r['measure'] != measure or r.get('end', b) <= a or r.get('start', a) >= b: continue
                    if r['type'] == 'SET_HARMONY':
                        harmony,bass=override_harmony(harmony,bass,r['chord'],self.base['transposition_semitones'] if self.base else 0)
                        if texture.pattern_type == 'REST':
                            texture = replace(texture, pattern_type='ROOT_GUIDE')
                            metadata['requested_texture'] = 'ROOT_GUIDE'
                            rhythm = replace(rhythm, rhythm_pattern=(0.,), attack_sizes=(1,), density='SD1')
                    elif r['type'] == 'SET_PATTERN':
                        for key in ('editor_attacks','editor_add_attacks','editor_double_stops','editor_attack_releases'): metadata.pop(key,None)
                        metadata['requested_texture'] = r['pattern_type']
                        texture = replace(texture, pattern_type=r['pattern_type'])
                        attacks = rhythm_attacks(a,b-a,metric_groups,pattern_type=r['pattern_type'],density='medium')
                        rhythm = replace(rhythm, rhythm_pattern=attacks, attack_sizes=(1,)*len(attacks), density='SD2')
                    elif r['type'] == 'ADD_ACCOMPANIMENT':
                        begin, end = max(a, r.get('start', a)), min(b,r.get('end',b))
                        if r.get('chord'):harmony,bass=override_harmony(harmony,bass,r['chord'],self.base['transposition_semitones'] if self.base else 0)
                        # User attacks are musical intent; sounding-hand feasibility decides acceptance.
                        attacks = tuple(t-a for t in requested_add_attacks(c,r,metric_groups))
                        new_times=tuple(a+t for t in attacks)
                        metadata['editor_add_attacks'] = tuple(sorted(set(metadata.get('editor_add_attacks',()))|set(new_times)))
                        metadata['editor_attack_releases']={**metadata.get('editor_attack_releases',{}),**{round(t,7):next((u for u in new_times if u>t+1e-7),end) for t in new_times}}
                        attacks = tuple(sorted(set(rhythm.rhythm_pattern) | set(attacks)))
                        metadata['editor_attacks'] = tuple(a+t for t in attacks)
                        rhythm = replace(rhythm, rhythm_pattern=attacks, attack_sizes=(1,)*len(attacks), density='SD2')
                        texture = replace(texture, pattern_type=r.get('pattern_type','SPARSE_ARPEGGIO') if attacks else 'REST')
                        metadata['requested_texture'] = texture.pattern_type
                touched.append(index)
            if touched:
                metadata.update(editor_request_indices=touched, editor_free_pitch=True)
                c = replace(c, harmony=harmony,bass=bass,rhythm=rhythm,texture=texture,
                    source_tones=(), functional_roles=(), metadata=metadata,
                    evidence=c.evidence+(SourceEvidence('USER_EDIT','EDITOR:'+','.join(map(str,touched))),))
            else:
                c = replace(c, rhythm=rhythm,texture=texture)
            edited.append(c)
        self.rows = tuple(edited)
        return replace(data,windows=self.rows)

    def observe_candidates(self, plan):
        self.candidate_textures = {c.candidate_id:c.texture.upper() for group in plan.candidate_groups for c in group}

    def observe_result(self, result, shift, key_shift=0):
        self.shift = shift
        self.key_shift = key_shift
        self.selected_families = {w.window_id:sorted({getattr(self, 'candidate_textures', {}).get(f.note.candidate_id, 'UNKNOWN') for f in w.accompaniment.notes}) for w in result.selected}
        self.final_notes = [(f.note, role) for w in result.selected for role, fs in [('melody',w.melody.notes),('accompaniment',w.accompaniment.notes)] for f in fs]

    def finish(self, result):
        out = self.request.output_dir
        from gste.input_formats.router import parse_source_track
        track = self.melody or parse_source_track(self.request.melody,track_id='piano_right',role='melody')
        from gste.editor.score import read_score
        score_rows = read_score(result.tab_musicxml)
        final_melody = [n for m in score_rows for n in m['notes'] if n['role']=='melody' and not n['tie_stop']]
        events = [{'event_id':n.source_event_id,'measure':n.measure,'start':n.start,'duration':n.duration,'pitch':n.pitch.midi} for n in track.notes if n.source_event_id and any(f['event_id']==n.source_event_id for f in final_melody)]
        measures = [{'measure':m,'label':track.measure_display_labels.get(m,str(m)), 'start':s,'duration':track.measure_lengths[m]} for m,s in track.measure_starts.items()]
        inputs = out/'editor_inputs'; inputs.mkdir(exist_ok=True)
        conversion = asdict(self.request)
        conversion.pop('editor_context'); conversion.pop('edit_requests'); conversion.pop('output_dir')
        for name in ('melody','left_hand'):
            src = conversion[name]
            if src:
                target=inputs/(name+Path(src).suffix)
                shutil.copy2(src,target)
                conversion[name]=str(target.relative_to(out))
        conversion['ensemble_tracks'] = []
        for i, item in enumerate(self.request.ensemble_tracks):
            target=inputs/(f'ensemble_{i}'+Path(item.path).suffix); shutil.copy2(item.path,target)
            row=asdict(item);row['path']=str(target.relative_to(out));conversion['ensemble_tracks'].append(row)
        hashes={v:digest(out/v) for v in [conversion['melody'],conversion['left_hand']]+[t['path'] for t in conversion['ensemble_tracks']] if v}
        score_hash=digest(result.tab_musicxml)
        revision=sha256((score_hash+json.dumps(hashes,sort_keys=True)+json.dumps(self.requests,sort_keys=True)).encode()).hexdigest()
        from gste.editor.score import notation_document
        for event in events:
            event['note_ids']=[n['note_id'] for m in score_rows for n in m['notes'] if n['event_id']==event['event_id'] and n['role']=='melody']
        notation=notation_document(result.tab_musicxml)
        event_index={}
        for part in notation['parts']:
            for measure in part['measures']:
                for note in measure['notes']:
                    if note['event_id']:event_index.setdefault(note['event_id'],[]).append(note['note_id'])
        context={'notation':notation,'event_to_note_ids':event_index,'score_notes':score_rows,
            'edit_priority_policy':'PHYSICAL_HARD_LIMITS_THEN_USER_INTENT_THEN_SOFT_COST',
            'schema_version':SCHEMA,'revision':revision,'score_sha256':score_hash,'conversion':conversion,'input_sha256':hashes,
            'measures':measures,'melody_events':events,'windows':serializable(self.rows),'selected_candidate_families':getattr(self,'selected_families',{}),'transposition_semitones':self.shift,'key_semitones':getattr(self,'key_shift',0),'edit_history':self.requests,
            'scope_policy':'RECOMPUTE_FULL_SCORE_WITH_LOCAL_INTENT_OVERRIDES',
            'privacy':'Contains musical content and source scores. Not a privacy-safe debug report.'}
        write_json(out/'GSTE_EDITOR_CONTEXT.json',context)
        write_json(out/'GSTE_EDIT_REQUEST.json',make_request(context,[]))
        self.write_results(out, context)
        return result

    def write_results(self, out, context):
        from gste.editor.score import read_score
        final=read_score(out/'GSTE_TAB.musicxml')
        notes=[n for m in final for n in m['notes']]
        rows=[]
        for i,r in enumerate(self.requests):
            if is_superseded(self.requests,i):
                rows.append({'request_index':i,'request':r,'status':'SUPERSEDED','detail':'Replaced by a later request for the same target.','window_ids':[]})
                continue
            windows=[c for c in self.rows if i in c.metadata.get('editor_request_indices',[])]
            selected=[]
            for c in windows:
                selected += [n for n in notes if c.harmony.start-1e-6 <= n['start'] < c.harmony.start+c.harmony.duration-1e-6 and n['role'] != 'melody']
            assessment={}
            ok=bool(selected); detail='Final score contains accompaniment in the requested region.'
            if r['type']=='SET_HARMONY':
                root, quality=parse_chord(r['chord']);required,optional=QUALITY_INTERVALS[quality];allowed={(root+j)%12 for j in required|optional}
                ok=bool(selected) and all(n['pitch']%12 in allowed for n in selected)
                detail='Harmony intent applied; final accompaniment pitch classes checked (guitar reduction may omit chord tones).'
            elif r['type']=='SET_PATTERN':
                if r['pattern_type']=='REST': ok=not selected
                else:
                    ok=bool(selected) and all(c.metadata.get('requested_texture')==r['pattern_type'] for c in windows)
                    actual_families = {f for c in windows for f in getattr(self,'selected_families',{}).get(c.window_id,())}
                    expected = {round(c.harmony.start+t,6) for c in windows for t in c.rhythm.rhythm_pattern}
                    actual = {round(n['start'],6) for n in selected if not n['tie_stop']}
                    reduced = bool(selected) and (not actual_families or actual_families != {r['pattern_type']} or not expected <= actual)
                detail='Requested candidate family applied. Joint may reduce rhythm/voicing; visual musical review is required.'
            elif r['type']=='ADD_ACCOMPANIMENT':
                expected=[t for c in windows for t in requested_add_attacks(c,r,self.melody.metric_groups)]
                attacks=[n for n in selected if not n['tie_stop'] and any(abs(n['start']-t)<1e-5 for t in expected)]
                ok=bool(attacks)
                reduced=bool(expected) and not all(any(abs(n['start']-t)<1e-5 for n in attacks) for t in expected)
                if r.get('chord'):
                    root,quality=parse_chord(r['chord']);required,optional=QUALITY_INTERVALS[quality]
                    ok=ok and all(n['pitch']%12 in {(root+j)%12 for j in required|optional} for n in attacks)
                if r.get('pattern_type'):
                    families={f for c in windows for f in getattr(self,'selected_families',{}).get(c.window_id,())}
                    reduced=reduced or families!={r['pattern_type']}
                assessment={'requested_attacks':expected,'missing_attacks':[t for t in expected if not any(abs(n['start']-t)<1e-5 for n in attacks)]}
                detail='Checked final accompaniment attacks at user-requested times.'
            elif r['type']=='ADD_MELODY_DOUBLE_STOP':
                ids={n['event_id']:n for n in context['melody_events']}
                ok=all(e in ids and any(abs(n['start']-ids[e]['start'])<1e-5 and 0 < ids[e]['pitch']+self.shift-n['pitch'] <= 12 for n in notes if n['role']!='melody' and not n['tie_stop']) for e in r['event_ids'])
                detail='Checked a chord tone within one octave below each selected melody onset.'
            status = 'APPLIED_WITH_REVIEW' if ok else 'UNSATISFIED'
            if ok and ((r['type']=='SET_PATTERN' and r['pattern_type']!='REST') or r['type']=='ADD_ACCOMPANIMENT') and reduced: status = 'DEGRADED'
            rows.append({**assessment,'request_index':i,'request':r,'status':status,'detail':detail,'window_ids':[c.window_id for c in windows], 'selected_candidate_families':{c.window_id:getattr(self,'selected_families',{}).get(c.window_id,[]) for c in windows}})
        write_json(out/'GSTE_EDIT_RESULT.json',{'schema_version':SCHEMA,'requests':rows,'scope_policy':context['scope_policy'],'edit_priority_policy':context['edit_priority_policy']})
        (out/'GSTE_EDIT_RESULT.md').write_text('# 半自動編曲修改結果 / Edit results\n\n整首重新搜尋，指定區域覆寫編曲意圖；重新生成維持原結果的整曲移調，未指定區域的指法仍可能變動。\n\n'+ '\n'.join(f"- {i+1}. {x['request']['type']}: {x['status']} — {x['detail']}" for i,x in enumerate(rows)),encoding='utf-8')
        failures=[x for x in rows if x['status'] not in ('APPLIED_WITH_REVIEW','SUPERSEDED') and x['request'].get('priority')=='hard']
        if failures:
            # Reject a hard request honestly; preserve the candidate as a review artifact.
            (out/'GSTE_TAB.musicxml').rename(out/'GSTE_REJECTED_PREVIEW.musicxml')
            rejection = '# GSTE V0.4 Conversion Report\n\nStatus: REJECTED — hard edit request unsatisfied.\n\nSee GSTE_EDIT_RESULT.md. GSTE_REJECTED_PREVIEW.musicxml is for review only.\n'
            (out/'CONVERSION_REPORT.md').write_text(rejection, encoding='utf-8')
            (out/'ERROR_REPORT.md').write_text(rejection, encoding='utf-8')
            raise ValueError('Hard edit request not satisfied. See GSTE_EDIT_RESULT.md; the preview is not an accepted conversion.')


def apply_editor_requests(melody, data):
    session=CURRENT.get()
    return session.apply(melody,data) if session else data


def regenerate(context_path, packet_path, output_dir):
    from gste.conversion_service import ConversionRequest,run_conversion
    from gste.pipeline.ensemble_priority import EnsemblePriorityTrack
    context_path=Path(context_path).resolve();context=read_context(context_path);parent=context_path.parent
    packet=json.loads(Path(packet_path).read_text(encoding='utf-8'));validate_requests(context,packet)
    target_dir=Path(output_dir).resolve()
    if target_dir==parent or any((parent/rel).resolve().is_relative_to(target_dir) for rel in context['input_sha256']):
        raise ValueError('Choose a new output directory; original conversion and source inputs must be preserved.')
    if (target_dir/'GSTE_TAB.musicxml').exists() or (target_dir/'GSTE_EDITOR_CONTEXT.json').exists():
        raise ValueError('Choose a new output directory; an existing conversion must not be overwritten.')
    options=dict(context['conversion'])
    for rel, expected in context['input_sha256'].items():
        path=(parent/rel).resolve()
        if not path.is_relative_to(parent) or not path.is_file() or digest(path)!=expected:
            raise ValueError('Editor source input missing or changed: '+rel)
    for key in ('melody','left_hand'):
        if options[key]: options[key]=parent/options[key]
    options['ensemble_tracks']=tuple(EnsemblePriorityTrack(**{**t,'path':parent/t['path']}) for t in options['ensemble_tracks'])
    return run_conversion(ConversionRequest(**options,output_dir=Path(output_dir),editor_context=context_path,edit_requests=Path(packet_path)))


def constrain_joint_harmony(analyses, key_shift):
    """The Joint harmony input must retain user harmony, not re-infer it."""
    from gste.harmony.models import ChordFamily, ChordFamilyCandidate
    session=CURRENT.get()
    if not session or not session.requests:return analyses
    session.search_key_shift=key_shift
    rows={c.window_id:c for c in session.rows}
    result=[]
    for analysis in analyses:
        c=rows.get(analysis.window.window_id)
        harmony_requests=[session.requests[i] for i in c.metadata.get('editor_request_indices',[]) if session.requests[i]['type']=='SET_HARMONY' or (session.requests[i]['type']=='ADD_ACCOMPANIMENT' and session.requests[i].get('chord'))] if c else []
        if harmony_requests:
            root,quality=parse_chord(harmony_requests[-1]['chord'])
            root = (root - (session.base['transposition_semitones'] if session.base else 0)) % 12
            required,optional=QUALITY_INTERVALS[quality]
            family=ChordFamily((root+key_shift)%12,quality,required,optional)
            analysis=replace(analysis,candidates=[ChordFamilyCandidate(family,1.,0.,0.,0.)])
        result.append(analysis)
    return tuple(result)


def constrain_edit_candidates(c, group):
    """Apply user timing constraints to candidates before physical search."""
    if not c.metadata.get('editor_attacks'):return group
    allowed=c.metadata['editor_attacks']
    constrained=[]
    for candidate in group:
        events=[]
        for e in candidate.events:
            if not any(abs(e.onset-t)<1e-6 for t in allowed):continue
            if any(abs(e.onset-t)<1e-6 for t in c.metadata.get('editor_add_attacks', ())):
                releases=c.metadata.get('editor_attack_releases',{})
                next_attack=releases.get(round(e.onset,7),releases.get(str(round(e.onset,7)),c.harmony.start+c.harmony.duration))
                e=replace(e,duration=min(e.duration,next_attack-e.onset))
            events.append(e)
        constrained.append(replace(candidate,events=tuple(events)))
    return tuple(constrained)


def is_superseded(requests, index):
    r=requests[index]
    for later in requests[index+1:]:
        if r['type'] != later['type']: continue
        if r['type']=='ADD_MELODY_DOUBLE_STOP':
            if set(r['event_ids']) <= set(later['event_ids']): return True
        elif all(r.get(k)==later.get(k) for k in ('measure','start','end')):
            return True
    return False


def constrain_editor_transforms(candidates):
    session=CURRENT.get()
    if session and session.base:
        return tuple(c for c in candidates if c.total_shift == session.base['transposition_semitones'])
    return candidates


def editor_intent_loss(state):
    """Discrete intent loss, compared lexicographically before any soft cost.

    Physical feasibility remains the optimizer's responsibility. The bounded
    candidate pool can still degrade intent; final-artifact reports expose it.
    """
    session=CURRENT.get()
    if not session or not session.requests:return 0
    c=next((c for c in session.rows if c.window_id==state.window_id),None)
    if c is None or not c.metadata.get('editor_request_indices'):return 0
    notes=[f.note for f in state.accompaniment.notes]
    loss=0
    for i in c.metadata['editor_request_indices']:
        if is_superseded(session.requests,i):continue
        r=session.requests[i];kind=r['type']
        selected=[n for n in notes if r.get('start',c.harmony.start)-1e-6<=n.start<r.get('end',c.harmony.start+c.harmony.duration)-1e-6]
        if kind=='SET_HARMONY' or (kind=='ADD_ACCOMPANIMENT' and r.get('chord')):
            root,quality=parse_chord(r['chord']);required,optional=QUALITY_INTERVALS[quality]
            allowed={(root+j)%12 for j in required|optional}
            # Joint pitches have key shift, while the request is in output space.
            delta=(session.base['transposition_semitones'] if session.base else 0)-getattr(session,'search_key_shift',0)
            loss+=int(not selected)+sum((n.pitch.midi+delta)%12 not in allowed for n in selected)
        if kind=='SET_PATTERN':
            if r['pattern_type']=='REST':loss+=len(selected);continue
            expected=[c.harmony.start+t for t in c.rhythm.rhythm_pattern]
            families={getattr(session,'candidate_textures',{}).get(n.candidate_id,str(getattr(n,'texture_family','') or getattr(n,'pattern_type','')).upper()) for n in selected}
            loss+=int(r['pattern_type'] not in families)
        elif kind=='ADD_ACCOMPANIMENT':expected=requested_add_attacks(c,r,session.melody.metric_groups)
        elif kind=='ADD_MELODY_DOUBLE_STOP':
            loss+=sum(not any(abs(n.start-t)<1e-6 and 0<pitch+getattr(session,'search_key_shift',0)-n.pitch.midi<=12 for n in notes) for eid,t,pitch in c.metadata.get('editor_double_stops',()) if eid in r['event_ids'])
            continue
        else:continue
        loss+=sum(not any(abs(n.start-t)<1e-6 for n in selected) for t in expected)
    return loss
