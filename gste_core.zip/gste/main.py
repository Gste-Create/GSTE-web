"""Top-level GSTE workflow orchestration.

This module deliberately contains no musical rules, cost calculations, or
export formatting.  It only connects the existing musical modules in their
original execution order.
"""
from __future__ import annotations

from gste.control import get_value

from dataclasses import dataclass, replace
from pathlib import Path
import json
import time

from gste.version import VERSION
from gste.diagnostics import PipelineDiagnosticsRecorder, failure_safe_pipeline
from gste.diagnostics.event_conservation import build_event_conservation, result_note_snapshots
from gste.diagnostics.canonical_timeline import CanonicalTimeline, compare_existing_windows
from gste.diagnostics.canonical_time import snapshot_notes, compare_to_reference
from gste.alignment.validator import validate_strict_alignment
from gste.arrangement.routing import resolve_arrangement_route, expected_route_for_source
from gste.arrangement.importance import parse_auto_importance
from gste.arrangement.source.service import analyze_and_map_piano_source
from gste.arrangement.source import source_plan_to_track, write_route_diagnostics, write_source_arrangement_diagnostics
from gste.arrangement.models import serializable
from gste.arrangement.accompaniment_contract import normalize_accompaniment_plan, contract_to_joint_bundle, contract_summary
from gste.core.tuning import STANDARD_TUNING, Tuning
from gste.core.models import NoteEvent, Pitch
from gste.melody.backbone import (
    lock_melody_backbone, validate_result_against_backbone,
    validate_track_against_backbone, backbone_to_dict, build_prelock_event_identity_audit,
)
from gste.exporter.joint_arrangement_report import (
    write_arrangement_dashboard, write_diagnostic_alternatives, write_joint_candidates_json, write_mixed_harmony_diagnostics,
)
from gste.exporter.melody_identity_lifecycle import build_priority_identity_lifecycle, write_priority_identity_lifecycle
from gste.exporter.joint_tab_xml_exporter import write_joint_tab_musicxml
from gste.exporter.human_review_report import (
    write_harmony_bass_review, write_melody_verification, write_review_json, write_review_summary,
)
from gste.exporter.event_review_report import (
    build_event_integrity, write_boundary_candidates_json, write_event_boundary_review,
    write_event_dump_json, write_event_integrity_report,
)
from gste.exporter.arrangement_diagnostics import write_arrangement_diagnostics
from gste.exporter.range_review import write_range_review_musicxml
from gste.exporter.public_musicxml_sanitizer import sanitize_public_musicxml
from gste.exporter.retention_lifecycle import snapshot_result, build_lifecycle_report, write_lifecycle_report
from gste.exporter.observer_purity import arrangement_signature, file_sha256, assert_observer_purity
from gste.exporter.piano_audition import write_piano_audition_without_ties
from gste.exporter.fingering_review_report import write_fingering_review_report
from gste.exporter.register_key_report import write_register_key_report, write_no_valid_register_key_report
from gste.exporter.melody_range_debug import write_melody_range_debug
from gste.exporter.melody_role_report import write_melody_role_report
from gste.exporter.timeline_rhythm_diagnostics import build_timeline_rhythm_diagnostics, write_timeline_rhythm_diagnostics
from gste.exporter.dissonance_diagnostics import build_dissonance_diagnostics, write_dissonance_diagnostics
from gste.exporter.review_triage import build_review_triage, write_review_triage
from gste.exporter.engineer_debug_summary import write_engineer_debug_summary
from gste.exporter.integrity_gate import write_integrity_gate
from gste.input.project_models import PianoSplitProject
from gste.joint_arrangement.event_roles import remove_decorative_grace_notes, tie_role_counts
from gste.joint_arrangement.models import AccompanimentCandidate
from gste.melody_extraction import extract_melody_path, MelodyPathResult
from gste.melody_extraction.piano_guitar_fallback import extract_guitar_feasible_piano_melody
from gste.input_formats.router import parse_source_track
from gste.structure import build_event_boundary_candidates
from gste.register_key_optimization import optimize_register_and_key, run_fingering_for_selected_transform, NoValidGlobalTransformError, is_complex_source_piano
from gste.fingering_review import ReviewConfig, validate_final_fingering_hard_rules
from gste.fingering_review.fingering_smoothing import smooth_final_fingering


@dataclass(frozen=True)
class JointArrangementOutputs:
    review_summary_md: Path
    melody_verification_md: Path
    harmony_bass_review_md: Path
    review_json: Path
    tab_musicxml: Path
    fingering_review_md: Path
    fingering_review_json: Path
    candidates_json: Path
    dashboard_md: Path
    diagnostics_md: Path
    boundary_review_md: Path
    event_integrity_md: Path
    boundary_candidates_json: Path
    event_dump_json: Path
    arrangement_diagnostics_json: Path
    register_key_report_md: Path
    register_key_report_json: Path
    melody_role_report_md: Path | None = None
    melody_role_report_json: Path | None = None
    input_route_json: Path | None = None
    source_arrangement_json: Path | None = None
    source_arrangement_md: Path | None = None

    @property
    def summary_md(self) -> Path:
        return self.review_summary_md


def _build_unified_melody_priority_pool(right, role_result, primary_track):
    """Preserve non-primary source events for unified Melody Joint arbitration.

    group_V0.0 contract: every melody source uses the same non-destructive admission rule.
    Role analysis assigns importance; it never owns deletion. The structural primary
    melody remains hard-locked, while every other pitched source event is carried as
    optional melody-priority material. Joint owns reduction after Melody Shape is set.
    """
    if role_result is None:
        return ()
    primary_ids = {str(n.source_event_id or "") for n in primary_track.notes}
    by_id = {str(c.note.source_event_id or ""): c for c in role_result.candidates}
    role_importance = {
        "PRIMARY_MELODY": 96,
        "PROBABLE_MELODY": 88,
        "AMBIGUOUS_UPPER_VOICE": 76,
        "ACCOMPANIMENT_OR_DECORATION": 58,
    }
    out = []
    for note in right.notes:
        event_id = str(note.source_event_id or "")
        if not event_id or event_id in primary_ids:
            continue
        candidate = by_id.get(event_id)
        role_name = str(getattr(getattr(candidate, "role", None), "value", "AMBIGUOUS_UPPER_VOICE"))
        base = role_importance.get(role_name, 70)
        confidence = float(getattr(candidate, "confidence", 0.0) or 0.0)
        # Confidence only refines ordering inside a role; it can never turn the
        # event into a keep/drop decision.
        importance = max(1, min(99, int(round(base + min(3.0, confidence * 3.0)))))
        out.append(replace(
            note, importance=importance,
            arrangement_role=f"melody_priority_{role_name.lower()}",
            source_type="source_melody_priority",
        ))
    return tuple(out)


@failure_safe_pipeline
def arrange_source_score(
    melody_path: str | Path, accompaniment_path: str | Path, *, output_dir: str | Path = "outputs/joint_arrangement",
    quarters_per_window: float = 2.0, chord_top_k: int = 3,
    melody_paths_per_window: int = int(get_value("search.melody_paths_per_window", 6)),
    accompaniment_per_chord: int = int(get_value("search.accompaniment_per_chord", 4)),
    joint_candidates_per_window: int = int(get_value("search.joint_candidates_per_window", 24)),
    max_candidates_per_note: int = int(get_value("search.max_candidates_per_note", 5)), tuning: Tuning = STANDARD_TUNING, melody_extraction_mode: str = "role_analysis",
    accompaniment_source: str = "independent_score",
    final_review_strict: bool = False,
    external_accompaniment_contract=None,
    accompaniment_data=None,
    parsed_source_project=None, original_source_tracks=None,
    sanitize_public_output: bool = True,
) -> JointArrangementOutputs:
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    _runtime_started = time.perf_counter()
    _export_started = None
    recorder = PipelineDiagnosticsRecorder.current()
    if recorder is None:  # defensive path for direct internal calls
        recorder = PipelineDiagnosticsRecorder(out)

    def _checkpoint(stage: str, *, status: str = "OK", details: dict[str, object] | None = None) -> None:
        # Compatibility shim: all primary monitoring is owned by the recorder.
        recorder.checkpoint(stage, status=("PASS" if status == "OK" else status), details=details)

    def _write_blocking_invariant(*, invariant:str, message:str, last_valid_stage:str, violations=None, details=None) -> Path:
        rows=list(violations or [])
        first=rows[0] if rows else {}
        payload={
            "version":VERSION,"status":"BLOCKED","invariant":invariant,"message":message,
            "last_valid_stage":last_valid_stage,"measure":first.get("measure"),"onset":first.get("onset"),
            "strings_frets":[{"role":n.get("role"),"string":n.get("string"),"fret":n.get("fret")} for n in first.get("active_notes",[])],
            "melody_accompaniment_roles":[n.get("role") for n in first.get("active_notes",[])],
            "violations":rows,"details":details or {},
        }
        recorder.record("blocking_invariant", payload)
        recorder.flush()
        path=out/"BLOCKING_INVARIANT.json"
        path.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")
        return path

    def _validate_locked_melody_or_block(backbone, candidate_result, stage: str) -> None:
        try:
            validate_result_against_backbone(backbone, candidate_result, stage=stage)
        except Exception as exc:
            _write_blocking_invariant(
                invariant="MELODY_BACKBONE_HARD_LOCK", message=str(exc),
                last_valid_stage=stage, details={"stage": stage},
            )
            raise
    source_melody = parsed_source_project.melody if parsed_source_project is not None else parse_source_track(melody_path, track_id="piano_right", role="right_hand_source")
    if accompaniment_source == "none":
        # group_V0.0.4: construct a timeline-aligned empty accompaniment track
        # directly from the Melody Source. The normal parser correctly rejects
        # note-less scores, so NONE must not masquerade as an empty MusicXML input.
        source_accompaniment = replace(source_melody, track_id="no_accompaniment", role="accompaniment_none", notes=[], events=[], warnings=[*source_melody.warnings, "ACCOMPANIMENT_MODE_NONE"])
    else:
        source_accompaniment = parsed_source_project.left_hand if parsed_source_project is not None else parse_source_track(accompaniment_path, track_id="piano_left", role="accompaniment")
    from gste.alignment.common_timeline import common_timeline
    if original_source_tracks is None:
        original_source_tracks = (source_melody,) if accompaniment_source in {"none","synthetic_from_melody_grid"} else (source_melody,source_accompaniment)
    normalized, alignment_report = common_timeline(original_source_tracks)
    recorder.record("common_timeline_alignment", alignment_report)
    if normalized is None:
        recorder.checkpoint("COMMON_TIMELINE", status="FAIL", details=alignment_report)
        raise ValueError("COMMON_TIMELINE_CONFLICT: see PIPELINE_DIAGNOSTICS.json")
    if accompaniment_source == "independent_score":
        source_melody,source_accompaniment=normalized
    recorder.checkpoint("COMMON_TIMELINE", details=alignment_report)
    from gste import tonality
    source_tonality = tonality.analyze_tonality(source_melody.notes,source_melody)
    tonality.write_tonality_analysis(source_tonality,out/"01_TONALITY_ANALYSIS.json")
    recorder.record("tonality_analysis",serializable(source_tonality))
    _checkpoint("SOURCE_PARSER", details={"melody_notes": len(source_melody.notes), "accompaniment_notes": len(source_accompaniment.notes)})
    expected_route = expected_route_for_source(accompaniment_source)
    route_decision = resolve_arrangement_route(accompaniment_source=accompaniment_source)
    if route_decision.route != expected_route:
        recorder.record("source_provenance_contract", {
            "status": "FAIL", "entrypoint": "arrange_source_score",
            "accompaniment_source": accompaniment_source,
            "expected_route": expected_route, "actual_route": route_decision.route,
            "error": "SOURCE_ROUTE_CONTRACT_MISMATCH",
        })
        recorder.flush()
        raise ValueError(f"SOURCE_ROUTE_CONTRACT_MISMATCH:source={accompaniment_source}:expected={expected_route}:actual={route_decision.route}")
    recorder.record("source_provenance_contract", {
        "status": "PASS", "entrypoint": "arrange_source_score",
        "accompaniment_source": accompaniment_source,
        "expected_route": expected_route, "actual_route": route_decision.route,
    })
    route_path = write_route_diagnostics(route_decision, out / "00_INPUT_ROUTE.json")
    recorder.record("input_route", getattr(route_decision, "route", str(route_decision)))
    _checkpoint("INPUT_ROUTE")
    source_arrangement_json = source_arrangement_md = None
    # SOURCE_PIANO exports only the primary melody events selected by the
    # extraction layer; secondary melody-source material is not silently forced
    # back into the guitar melody at serialization time.
    export_melody_event_ids: set[str] | None = None
    raw_alignment = validate_strict_alignment(PianoSplitProject(melody=source_melody, left_hand=source_accompaniment))
    if accompaniment_source in {"synthetic_from_melody_grid", "none"} and not raw_alignment.is_aligned:
        raise ValueError("Generated accompaniment does not match its melody source grid.")
    # group_V0.0.1 UNIFIED MELODY CONTRACT:
    # Once a track is declared a Melody Source, its source route may not choose a
    # different melody algorithm.  The proven Piano-RH role-analysis chain is the
    # single reader->identity->analysis entry for AUTO_MELODY, SOURCE_PIANO and
    # future non-prefingered melody adapters.  Keep the argument only for API
    # compatibility; legacy values are recorded but deliberately do not branch.
    if melody_extraction_mode != "role_analysis":
        recorder.record("deprecated_melody_extraction_mode_ignored", {
            "requested": melody_extraction_mode,
            "effective": "role_analysis",
            "policy": "ALL_MELODY_SOURCES_USE_UNIFIED_PIANO_RH_ANALYSIS_CHAIN",
        })
    role_result: MelodyPathResult = extract_melody_path(source_melody)
    extraction = role_result.extraction
    _checkpoint("UNIFIED_MELODY_ROLE_ANALYSIS", details={
        "source_route": route_decision.route,
        "source_notes": len(source_melody.notes),
        "selected_primary_notes": len(extraction.melody_track.notes),
        "policy": "UNIFIED_PIANO_RH_MELODY_ANALYSIS",
    })
    recorder.record_transition(
        "SOURCE_TO_MELODY_ROLE",
        input_summary={"source_note_count": len(source_melody.notes)},
        output_summary={"primary_melody_note_count": len(extraction.melody_track.notes)},
        differences={"classification_only": True, "source_time_mutation": "NOT_PERMITTED"},
        status="PASS",
    )
    melody_track = remove_decorative_grace_notes(extraction.melody_track)
    left_track = remove_decorative_grace_notes(source_accompaniment)
    if accompaniment_source in {"synthetic_from_melody_grid", "none"}:
        # Both tracks were proven to share the same source grid above.  Grace
        # normalization belongs to melody preprocessing and can otherwise
        # rewrite only the melody's derived measure metadata.  Carry that
        # canonical grid onto the generated track without altering its notes.
        left_track = replace(
            left_track,
            measure_starts=dict(melody_track.measure_starts),
            measure_lengths=dict(melody_track.measure_lengths),
            time_signatures=list(melody_track.time_signatures),
            duration_quarters=melody_track.duration_quarters,
        )
    # group_V0.0 Unified Melody Core: route-independent melody admission.
    # Primary melody is hard-locked. Other possible melody/polyphonic source notes
    # remain alive as priority material until Melody Shape / Joint arbitration.
    priority_pool = ()
    priority_pool = _build_unified_melody_priority_pool(source_melody, role_result, melody_track)
    if role_result is not None:
        if priority_pool:
            merged = sorted((*left_track.notes, *priority_pool), key=lambda n: (n.start, n.pitch.midi, n.duration, str(n.source_event_id or "")))
            left_track = replace(left_track, notes=merged)
            recorder.record("unified_melody_priority_pool", {
                "policy": "UNIFIED_MELODY_ROLE_PRIORITY_ONLY_MELODY_SHAPE_FIRST_JOINT_OWNS_REDUCTION",
                "source_route": route_decision.route,
                "primary_locked_count": len(melody_track.notes),
                "priority_pool_count": len(priority_pool),
                "importance_min": min(n.importance for n in priority_pool if n.importance is not None),
                "importance_max": max(n.importance for n in priority_pool if n.importance is not None),
            })
    project = PianoSplitProject(melody=melody_track, left_hand=left_track)

    def _write_range_review_if_needed(review_track):
        # Diagnostic only: failure to write a review excerpt must never hide the
        # original conversion failure.  No pitch, timing, or arrangement state is changed.
        try:
            return write_range_review_musicxml(
                melody_path, review_track, out / "RANGE_REVIEW.musicxml",
                tuning=tuning, maximum_fret=18, context_measures=2,
            )
        except Exception as review_exc:
            (out / "debug").mkdir(parents=True, exist_ok=True)
            (out / "debug" / "RANGE_REVIEW_WRITE_ERROR.txt").write_text(str(review_exc), encoding="utf-8")
            return None
    # v0.13.5.13.3: establish the one authoritative structural melody timeline
    # immediately after melody identity/extraction is complete.  Downstream code
    # may change only string/fret realization (and the explicit global pitch shift);
    # it must never recompute attack/release from windows or serialized XML.
    (out / "debug").mkdir(parents=True, exist_ok=True)
    _identity_audit = build_prelock_event_identity_audit(project.melody)
    recorder.record("prelock_event_identity_audit", _identity_audit)
    _checkpoint("EVENT_IDENTITY_AUDIT", details={
        "status": _identity_audit.get("status"),
        "duplicate_id_count": _identity_audit.get("duplicate_id_count", 0),
        "missing_id_count": _identity_audit.get("missing_id_count", 0),
    })
    melody_backbone = lock_melody_backbone(
        project.melody,
        stage="UNIFIED_MELODY_EXTRACTION",
    )
    recorder.record("locked_melody_backbone", backbone_to_dict(melody_backbone))
    write_melody_range_debug(melody_backbone, tuning, out / "debug" / "MELODY_RANGE_DEBUG.json", maximum_fret=18)
    _checkpoint("MELODY_BACKBONE_LOCK", details={"locked_events": len(melody_backbone.events) if hasattr(melody_backbone, "events") else None})

    # v0.13.5.15.6.7: the locked Melody Backbone is the single authority for
    # which source melody events may survive into MusicXML serialization.
    # This must apply to AUTO_MELODY as well as SOURCE_PIANO: role_analysis can
    # intentionally omit secondary/simultaneous source notes, and the exporter
    # must not re-introduce those omitted source identities from the XML template.
    export_melody_event_ids = set(melody_backbone.event_ids)

    accompaniment_contract = None
    source_candidate_bundle = None
    if accompaniment_source == "none":
        # group_V0.0.4: NONE is a first-class accompaniment contract. Every
        # harmony window receives one explicit empty candidate so Joint cannot
        # fall back to compatibility chord generation.
        from gste.harmony.windows import build_fixed_harmony_windows
        _none_windows = build_fixed_harmony_windows(project, quarters_per_window=quarters_per_window)
        source_candidate_bundle = {w.window_id: (("NO_ACCOMPANIMENT", tuple()),) for w in _none_windows}
        from gste.arrangement.data_contract import AccompanimentData
        recorder.record("accompaniment_data", serializable(AccompanimentData((),False)))
        recorder.record("accompaniment_mode", {"mode":"NONE", "intent_count":0, "candidate_count":0})
        _checkpoint("ACCOMPANIMENT_INTENT_CONTRACT", details={"status":"PASS", "source_kind":"none", "intent_count":0, "policy":"EMPTY_IS_VALID"})
        _checkpoint("ACCOMPANIMENT_CANDIDATE_CONTRACT", details={"status":"PASS", "source_kind":"none", "candidate_count":0, "joint_empty_windows":len(source_candidate_bundle), "policy":"NO_GENERATION"})
    if external_accompaniment_contract is not None:
        accompaniment_contract = external_accompaniment_contract
        left_track, source_candidate_bundle = contract_to_joint_bundle(accompaniment_contract, left_track)
        recorder.record("unified_accompaniment_contract", contract_summary(accompaniment_contract))
        recorder.record("accompaniment_data", serializable(accompaniment_contract.accompaniment_data))
        _checkpoint("ACCOMPANIMENT_INTENT_CONTRACT", details=contract_summary(accompaniment_contract))
        _checkpoint("ACCOMPANIMENT_CANDIDATE_CONTRACT", details={"status":"PASS", "window_count":len(source_candidate_bundle)})
    alignment = validate_strict_alignment(project)
    recorder.record("strict_alignment", {"is_aligned": alignment.is_aligned, "issues": serializable(alignment.issues)})
    if not alignment.is_aligned:
        recorder.checkpoint("STRICT_ALIGNMENT", status="FAILED", details={"is_aligned": False})
        raise ValueError("Melody and accompaniment failed strict alignment; run analyze-piano first.")
    _checkpoint("STRICT_ALIGNMENT", details={"is_aligned": True})

    # v0.13.3 input-route separation: an independent piano accompaniment is
    # first translated to ArrangementIntent/ArrangementCandidate and only then
    # adapted to the legacy TrackData fingering boundary.  The selected source
    # candidate is pitch/rhythm faithful, so this release should preserve the
    # v0.13.3 musical result while making the data path explicit.
    if route_decision.route in {"SOURCE_PIANO", "SOURCE_ENSEMBLE"} and external_accompaniment_contract is None:
        source_plan = analyze_and_map_piano_source(
            project, quarters_per_window=quarters_per_window, chord_top_k=chord_top_k, accompaniment_data=accompaniment_data,
        )
        source_arrangement_json, source_arrangement_md = write_source_arrangement_diagnostics(
            source_plan, out / "02_SOURCE_ARRANGEMENT_INTENTS.json",
        )
        source_kind = "source_accompaniment"
        accompaniment_contract = normalize_accompaniment_plan(source_plan, source_kind=source_kind)
        recorder.record("unified_accompaniment_contract", contract_summary(accompaniment_contract))
        recorder.record("accompaniment_data", serializable(accompaniment_contract.accompaniment_data))
        _checkpoint("ACCOMPANIMENT_INTENT_CONTRACT", details=contract_summary(accompaniment_contract))
        left_track, source_candidate_bundle = contract_to_joint_bundle(accompaniment_contract, left_track)
        _checkpoint("ACCOMPANIMENT_CANDIDATE_CONTRACT", details={"status":"PASS", "source_kind":source_kind, "source_route":route_decision.route, "window_count":len(source_candidate_bundle), "candidate_bundle_present":bool(source_candidate_bundle)})
    # v0.1.6: attach exact RH-priority events to every Piano source variant.
    # Joint can then compare legal realizations using one common priority-loss
    # cost instead of letting a variant erase RH material before arbitration.
    if priority_pool and source_candidate_bundle and accompaniment_contract is not None:
        augmented = {}
        intent_by_id = {i.window_id: i for i in accompaniment_contract.intents}
        for window_id, variants in source_candidate_bundle.items():
            intent = intent_by_id[window_id]
            end = intent.start + intent.duration
            rh = tuple(n for n in priority_pool if intent.start - 1e-9 <= n.start < end - 1e-9)
            merged_variants = []
            for variant_name, base_notes in variants:
                if rh:
                    merged = tuple(sorted((*base_notes, *rh), key=lambda n: (n.start, n.pitch.midi, str(n.source_event_id or ""))))
                    merged_variants.append((f"{variant_name}+RH_PRIORITY", merged))
                else:
                    merged_variants.append((variant_name, base_notes))
            if rh:
                merged_variants.append(("RH_PRIORITY_EXACT", tuple(replace(n, source_variant="RH_PRIORITY_EXACT", texture_family="RH_PRIORITY_EXACT") for n in rh)))
            augmented[window_id] = tuple(merged_variants)
        source_candidate_bundle = augmented
    # Keep priority events visible in the canonical Joint analysis window as
    # optional source material; source-plan adaptation must not erase them.
    if priority_pool and accompaniment_contract is not None:
        existing = {str(n.source_event_id or "") for n in left_track.notes}
        merged = sorted((*left_track.notes, *(n for n in priority_pool if str(n.source_event_id or "") not in existing)),
                        key=lambda n: (n.start, n.pitch.midi, str(n.source_event_id or "")))
        left_track = replace(left_track, notes=merged)
    project = PianoSplitProject(melody=melody_track, left_hand=left_track)
    adapted_alignment = validate_strict_alignment(project)
    if not adapted_alignment.is_aligned:
        raise ValueError("SOURCE_ROUTE_ADAPTER_ALIGNMENT_FAILED")

    _checkpoint("ACCOMPANIMENT_SOURCE_ADAPTER", details={
        "source_route": route_decision.route,
        "accompaniment_source": accompaniment_source,
        "candidate_bundle_present": bool(source_candidate_bundle),
        "accompaniment_notes": len(left_track.notes),
    })

    from gste.editor.session import CURRENT as _editor_session
    if _editor_session.get() is not None and _editor_session.get().requests:
        recorder.record("editor_requests", {"requests": _editor_session.get().requests,
            "effective_windows": serializable(_editor_session.get().rows),
            "responsible_stage": "ACCOMPANIMENT_DATA_BEFORE_ARRANGEMENT"})
        _checkpoint("EDITOR_REQUEST_APPLIED", details={"request_count": len(_editor_session.get().requests)})

    complex_piano = is_complex_source_piano(project, quarters_per_window=quarters_per_window, input_route=route_decision.route)
    _checkpoint("INPUT_AND_SOURCE_ANALYSIS", details={
        "input_route": route_decision.route,
        "complex_piano": complex_piano,
        "melody_notes": len(project.melody.notes),
        "accompaniment_notes": len(project.left_hand.notes),
    })

    try:
        selected_transform, transform_evaluations = optimize_register_and_key(
            project, tuning=tuning, quarters_per_window=quarters_per_window, chord_top_k=chord_top_k,
            melody_paths_per_window=melody_paths_per_window, accompaniment_per_chord=accompaniment_per_chord,
            joint_candidates_per_window=joint_candidates_per_window, max_candidates_per_note=max_candidates_per_note, input_route=route_decision.route,
            source_candidate_bundle=source_candidate_bundle,
        )
    except NoValidGlobalTransformError as exc:
        # group_V0.0.1 unified melody recovery.  This recovery belongs to the
        # Melody Core, not to SOURCE_PIANO: every Melody Source gets the same
        # continuity-heavy, auditable fallback when the normal global transform
        # has no legal solution.
        if role_result is not None:
            fallback_melody_raw, fallback_actions, fallback_role = extract_guitar_feasible_piano_melody(source_melody)
            fallback_melody = remove_decorative_grace_notes(fallback_melody_raw)
            fallback_project = PianoSplitProject(melody=fallback_melody, left_hand=left_track)
            fallback_alignment = validate_strict_alignment(fallback_project)
            if fallback_alignment.is_aligned:
                try:
                    selected_transform, transform_evaluations = optimize_register_and_key(
                        fallback_project, tuning=tuning, quarters_per_window=quarters_per_window, chord_top_k=chord_top_k,
                        melody_paths_per_window=melody_paths_per_window, accompaniment_per_chord=accompaniment_per_chord,
                        joint_candidates_per_window=joint_candidates_per_window, max_candidates_per_note=max_candidates_per_note,
                        input_route=route_decision.route, source_candidate_bundle=source_candidate_bundle,
                    )
                    role_result = fallback_role
                    melody_track = fallback_melody
                    project = fallback_project
                    _identity_audit = build_prelock_event_identity_audit(project.melody)
                    recorder.record("prelock_event_identity_audit_fallback", _identity_audit)
                    melody_backbone = lock_melody_backbone(
                        project.melody, stage="UNIFIED_MELODY_EXTRACTION_FALLBACK"
                    )
                    recorder.record("locked_melody_backbone_fallback", backbone_to_dict(melody_backbone))
                    export_melody_event_ids = set(melody_backbone.event_ids)
                    (out / "07_UNIFIED_MELODY_EXTRACTION_FALLBACK.json").write_text(json.dumps({
                        "version": VERSION,
                        "trigger": "NO_VALID_GLOBAL_TRANSFORM",
                        "policy": fallback_role.extraction.policy,
                        "source_note_count": fallback_role.extraction.source_note_count,
                        "kept_note_count": fallback_role.extraction.kept_note_count,
                        "omitted_note_count": fallback_role.extraction.omitted_note_count,
                        "selected_event_ids": [n.source_event_id for n in fallback_melody.notes],
                        "actions": list(fallback_actions),
                        "rule": "Select only existing source notes / classify secondary material; never alter source pitch or relax fretboard limits.",
                    }, ensure_ascii=False, indent=2), encoding="utf-8")
                    _checkpoint("UNIFIED_MELODY_EXTRACTION_FALLBACK", details={
                        "policy": fallback_role.extraction.policy,
                        "kept_notes": len(fallback_melody.notes),
                    })
                except NoValidGlobalTransformError as fallback_exc:
                    _write_range_review_if_needed(project.melody)
                    write_no_valid_register_key_report(fallback_exc.evaluations, out / "07_GLOBAL_TRANSFORM_SEARCH.md")
                    write_melody_range_debug(fallback_project.melody, tuning, out / "debug" / "MELODY_RANGE_DEBUG.json", maximum_fret=18, evaluations=fallback_exc.evaluations)
                    _checkpoint("GLOBAL_TRANSFORM_AND_JOINT_SEARCH", status="NO_VALID_GLOBAL_TRANSFORM", details={
                        "candidate_count": len(fallback_exc.evaluations), "fallback_attempted": True,
                    })
                    raise ValueError("NO_VALID_GLOBAL_TRANSFORM; see 07_GLOBAL_TRANSFORM_SEARCH.json for rejection reasons") from fallback_exc
            else:
                write_no_valid_register_key_report(exc.evaluations, out / "07_GLOBAL_TRANSFORM_SEARCH.md")
                write_melody_range_debug(melody_backbone, tuning, out / "debug" / "MELODY_RANGE_DEBUG.json", maximum_fret=18, evaluations=exc.evaluations)
                raise ValueError("UNIFIED_MELODY_EXTRACTION_FALLBACK_ALIGNMENT_FAILED") from exc
        else:
            _write_range_review_if_needed(project.melody)
            write_no_valid_register_key_report(exc.evaluations, out / "07_GLOBAL_TRANSFORM_SEARCH.md")
            write_melody_range_debug(melody_backbone, tuning, out / "debug" / "MELODY_RANGE_DEBUG.json", maximum_fret=18, evaluations=exc.evaluations)
            _checkpoint("GLOBAL_TRANSFORM_AND_JOINT_SEARCH", status="NO_VALID_GLOBAL_TRANSFORM", details={
                "candidate_count": len(exc.evaluations),
            })
            raise ValueError("NO_VALID_GLOBAL_TRANSFORM; see 07_GLOBAL_TRANSFORM_SEARCH.json for rejection reasons") from exc
    write_melody_range_debug(melody_backbone, tuning, out / "debug" / "MELODY_RANGE_DEBUG.json", maximum_fret=18, evaluations=transform_evaluations)
    _checkpoint("GLOBAL_TRANSFORM_SELECTION", details={
        "selected_transform": selected_transform.candidate.label,
        "evaluated_candidates": len(transform_evaluations),
    })
    transformed_melody_backbone = melody_backbone.shifted(
        selected_transform.candidate.total_shift, lock_stage="GLOBAL_TRANSFORM_LOCKED"
    )
    validate_track_against_backbone(
        transformed_melody_backbone, selected_transform.project.melody, stage="GLOBAL_TRANSFORM"
    )
    recorder.record("transformed_melody_backbone", backbone_to_dict(transformed_melody_backbone))
    # v0.13.5.12.10.1: only now ask the Fingering/Joint layer to realize the
    # selected global transform.  A transform is never invalidated merely
    # because the transform-ranking beam could not find a path.
    # group_V0.0.1: Melody fingering search may not branch on source route.
    # Accompaniment candidates can differ by source adapter, but the Melody Shape
    # search budget and Joint realization contract are shared.
    _mp, _acc, _jc, _nc = (
        min(melody_paths_per_window, 5),
        min(accompaniment_per_chord, 3),
        min(joint_candidates_per_window, 16),
        min(max_candidates_per_note, 4),
    )
    _checkpoint("UNIFIED_MELODY_PREJOINT_SEARCH_CONFIG", details={
        "melody_paths_per_window": _mp, "accompaniment_per_chord": _acc,
        "joint_candidates_per_window": _jc, "max_candidates_per_note": _nc,
        "source_route": route_decision.route,
    })
    selected_transform = run_fingering_for_selected_transform(
        selected_transform, tuning=tuning,
        melody_paths_per_window=_mp, accompaniment_per_chord=_acc,
        joint_candidates_per_window=_jc, max_candidates_per_note=_nc,
        source_candidate_bundle=source_candidate_bundle,
        melody_backbone=transformed_melody_backbone,
    )
    _checkpoint("FINGERING_PATH_SEARCH", details={
        "selected_windows": len(selected_transform.result.selected),
    })
    analyses = list(selected_transform.analyses)
    result = selected_transform.result
    _checkpoint("JOINT_SELECTED", details={
        "selected_windows": len(result.selected),
        "source_route": route_decision.route,
    })
    recorder.record_transition(
        "PREJOINT_TO_JOINT",
        input_summary={"candidate_windows": len(getattr(result, "candidate_layers", ()) or ())},
        output_summary={"selected_windows": len(result.selected)},
        differences={"selection_only": True, "new_pitch_generation": "FORBIDDEN"},
        status="PASS" if result.selected else "FAIL",
    )
    # v0.13.5.15.4.1: diagnostics are a flight recorder, not a success report.
    # Flush them BEFORE any hard validation can abort the pipeline, so failed
    # scores retain the evidence needed to locate the first zero/failing stage.
    tie_roles = {key: tie_role_counts(source_melody)[key] + tie_role_counts(source_accompaniment)[key] for key in ("attack", "sustain", "grace")}
    arrangement_diag = __import__("gste.exporter.arrangement_diagnostics", fromlist=["build_arrangement_diagnostics"]).build_arrangement_diagnostics(result, tie_roles=tie_roles)
    recorder.record("arrangement_diagnostics", arrangement_diag)
    recorder.record_metrics(**getattr(result, "debug_counters", {}))
    recorder.record("joint_path_search", getattr(result, "debug_observations", {}), section="global_observations")

    # v0.13.5.15.6: consolidated always-on conservation monitor.
    # Deep per-event window/lifecycle probes remain available for sandbox use,
    # but are no longer duplicated in every production conversion report.
    _event_conservation = build_event_conservation(transformed_melody_backbone, analyses, result)
    recorder.record_and_flush("event_conservation", _event_conservation, section="trackers")
    # v0.13.5.15.4.1 Phase 1: establish a shared canonical timeline /
    # window-projection reference clock. Observer-only: existing production
    # windows continue to drive every musical decision in this release.
    _canonical_timeline = CanonicalTimeline.from_track(source_melody)
    recorder.record_and_flush(
        "canonical_window_projection",
        compare_existing_windows(_canonical_timeline, analyses),
        section="trackers",
    )
    _selected_melody_notes, _selected_accompaniment_notes = result_note_snapshots(result)
    _canonical_reference = {
        event.structural_event_id: {
            "attack": round(float(event.attack), 9),
            "release": round(float(event.release), 9),
            "duration": round(float(event.duration), 9),
            "midi": int(event.midi_pitch),
            "measure": event.measure,
        }
        for event in transformed_melody_backbone.events
    }
    _canonical_selected = snapshot_notes(_selected_melody_notes)
    recorder.record_and_flush(
        "canonical_time_integrity",
        {
            "contract": "CanonicalTime = immutable physical [attack, release) + duration; measure/beat/window/grid are analysis coordinates only and must never rewrite source-note time.",
            "joint_selected_vs_locked_melody": compare_to_reference(_canonical_reference, _canonical_selected),
            "analysis_window_policy": "VARIABLE_READ_ONLY_VIEW",
            "source_time_rewrite": "FORBIDDEN",
        },
        section="trackers",
    )
    recorder.flush()
    diagnostic_path = recorder.path
    # v0.13.5.12.6.3: after Global/phrase register planning, structural melody
    # absolute pitch + onset + duration become immutable hard invariants.
    _validate_locked_melody_or_block(transformed_melody_backbone, result, "JOINT_SELECTED")
    _retention_snapshots = [snapshot_result(result, "JOINT_SELECTED")]
    _export_recovery_events: list[dict[str, object]] = []
    register_report, register_json = write_register_key_report(selected_transform, transform_evaluations, out / "07_GLOBAL_TRANSFORM_SEARCH.md")
    if not result.selected:
        raise ValueError(f"No playable melody candidate; full diagnostics written to {diagnostic_path}.")

    # v0.1.5 observer-only ownership trace.  Role analysis admits priority
    # events; Joint alone decides which survive.  Exporter must serialize that
    # decision and may not make a second musical keep/drop decision.
    if priority_pool:
        admitted_priority_ids = {str(n.source_event_id or "") for n in priority_pool if n.source_event_id}
        selected_priority_ids = {
            str(c.note.source_event_id or "")
            for state in result.selected
            for c in state.accompaniment.notes
            if c.note.source_event_id and str(c.note.source_event_id or "") in admitted_priority_ids
        }
        recorder.record_and_flush("unified_melody_joint_ownership", {
            "contract": "ROLE_ADMITS_PRIORITY; JOINT_SELECTS; EXPORT_SERIALIZES_JOINT_OWNERSHIP",
            "admitted_count": len(admitted_priority_ids),
            "joint_selected_count": len(selected_priority_ids),
            "joint_rejected_count": len(admitted_priority_ids - selected_priority_ids),
            "joint_selected_source_event_ids": sorted(selected_priority_ids),
            "joint_rejected_source_event_ids": sorted(admitted_priority_ids - selected_priority_ids),
            "exporter_second_keep_drop_decision": "FORBIDDEN",
        }, section="trackers")
    # Always emit G2 evidence, including the valid zero-priority case.  Absence of
    # optional secondary melody material is PASS evidence, not a missing monitor.
    _priority_lifecycle = build_priority_identity_lifecycle(priority_pool, result)
    write_priority_identity_lifecycle(_priority_lifecycle, out / "debug" / "25_MELODY_IDENTITY_LIFECYCLE.json")
    _checkpoint("UNIFIED_MELODY_IDENTITY_LIFECYCLE", details={
        "expected_priority": _priority_lifecycle["expected_count"],
        "retained_priority": _priority_lifecycle["retained_count"],
        "dropped_by_joint": _priority_lifecycle["dropped_by_joint_count"],
        "unexplained_loss": _priority_lifecycle["unexplained_loss_count"],
    })
    if _priority_lifecycle["unexplained_loss_count"]:
        raise ValueError("MELODY_IDENTITY_LIFECYCLE_UNEXPLAINED_LOSS")

    boundaries = build_event_boundary_candidates(source_melody, source_accompaniment)
    integrity = build_event_integrity(source_melody, source_accompaniment)
    if original_source_tracks is not None:
        from gste.exporter.event_review_report import build_source_registry_integrity
        integrity = build_source_registry_integrity(original_source_tracks)
    melody_roles = ({(item.note.pitch.midi, round(item.note.start, 6)): item.role.value for item in role_result.candidates}
                    if role_result is not None else None)
    context = {"right_source_events": source_melody.events, "boundaries": boundaries, "integrity": integrity, "melody_roles": melody_roles}
    # Optional debug artifact only.  Monitoring/export previews may never block
    # the musical pipeline.
    try:
        write_joint_tab_musicxml(
            result, out / "04_PRE_FINAL_REVIEW_TAB.musicxml",
            f"{VERSION} Pre-Final-Review Joint TAB", tuning,
            source_path=melody_path, canonical_timeline=project.melody,
            total_semitone_shift=selected_transform.candidate.total_shift,
            validate_integrity=False, auto_recovery=False,
            selected_melody_source_event_ids=export_melody_event_ids,
            melody_backbone=transformed_melody_backbone,
        )
    except Exception as exc:
        (out / "debug" / "04_PRE_FINAL_EXPORT_WARNING.json").write_text(
            json.dumps({"version": VERSION, "status": "WARNING", "message": str(exc)}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    summary = write_review_summary(result, analyses, out / "00_REVIEW_SUMMARY.md", **context)
    melody = write_melody_verification(result, analyses, out / "01_MELODY_VERIFICATION.md", **context)
    harmony_bass = write_harmony_bass_review(result, analyses, out / "02_HARMONY_BASS_REVIEW.md", **context)
    review_json = write_review_json(result, analyses, out / "03_REVIEW_DATA.json", **context)
    _checkpoint("PRE_FINAL_EXPORT_AND_REPORTS")
    # Post-Joint fingering refinement has one narrow authority: it may relocate
    # an existing note to an equivalent string/fret realization to smooth an
    # isolated position excursion or local hand-shape outlier.  It may not
    # change event identity, pitch, time, duration, role, note count, or
    # arrangement content.  Joint/Fingering therefore remains authoritative.
    final_validator_config = ReviewConfig(strict=final_review_strict)
    smoothing_result = smooth_final_fingering(
        result, tuning=tuning, maximum_fret=18,
        maximum_repairs=final_validator_config.maximum_passes,
        validator_config=final_validator_config,
        melody_backbone=transformed_melody_backbone,
    )
    smoothed_result = smoothing_result.score
    _validate_locked_melody_or_block(transformed_melody_backbone, smoothed_result, "FINGERING_SMOOTHING")
    _retention_snapshots.append(snapshot_result(smoothed_result, "FINGERING_SMOOTHING"))

    # Final Review is intentionally validation-only.  It is the immutable hard
    # gate after smoothing and must never repair, smooth, revoice, or delete.
    final_review = validate_final_fingering_hard_rules(
        smoothed_result, config=final_validator_config,
        melody_backbone=transformed_melody_backbone,
    )
    reviewed_result = final_review.score
    _validate_locked_melody_or_block(transformed_melody_backbone, reviewed_result, "FINAL_REVIEW")

    _retention_snapshots.append(snapshot_result(reviewed_result, "FINAL_REVIEW"))
    final_review_md, final_review_json = write_fingering_review_report(
        final_review, out / "04_FINAL_FINGERING_REVIEW.md",
    )
    _checkpoint("FINAL_FINGERING_REVIEW", details={
        "physical_remaining": len(getattr(final_review, "remaining_issues", ()) or ()),
    })

    # Streamlined final path: Joint owns arrangement/primary fingering, the
    # dedicated smoothing stage may only change equivalent string/fret
    # realization, and Final Review is the authoritative validation-only gate.
    # Export must not re-arrange, re-finger or delete musical content.
    export_result = reviewed_result
    from gste.editor.session import CURRENT as _editor_current
    if _editor_current.get() is not None:
        _editor_current.get().observe_result(export_result, selected_transform.candidate.total_shift, selected_transform.candidate.key_semitones)
    if accompaniment_contract is not None:
        from gste.arrangement.accompaniment_contract import audit_selected_lineage
        source_pitch_audit = audit_selected_lineage(accompaniment_contract, reviewed_result)
        recorder.record("accompaniment_semantic_provenance", source_pitch_audit)
        (out / "debug" / "28_SOURCE_PITCH_AUDIT.json").write_text(
            json.dumps(serializable(source_pitch_audit),ensure_ascii=False,indent=2),encoding="utf-8")
    def _write_privacy_event_trace_from_export_report():
        try:
            from gste.diagnostics.privacy_event_trace import write_event_lifecycle_trace
            report_path = out / "debug" / "23_EXPORT_INTEGRITY.json"
            report_data = json.loads(report_path.read_text(encoding="utf-8")) if report_path.exists() else {}
            write_event_lifecycle_trace(output_dir=out, source_notes=source_melody.notes, role_candidates=role_result.candidates, priority_pool=priority_pool, result=export_result, export_integrity=report_data)
        except Exception as trace_exc:
            recorder.record("privacy_event_trace_error", {"type": type(trace_exc).__name__, "message": str(trace_exc)})
    # Export is a separate observed stage. A serializer failure must never be
    # reported as FINAL_FINGERING_REVIEW merely because that was the previous
    # successful checkpoint.
    _checkpoint("FINAL_EXPORT", details={"phase": "SERIALIZATION_STARTED"}, status="RUNNING")
    try:
        tab = write_joint_tab_musicxml(
            export_result, out / "05_TAB.musicxml",
        f"{VERSION} Guitar Score", tuning,
        source_path=melody_path, canonical_timeline=project.melody,
        total_semitone_shift=selected_transform.candidate.total_shift,
        validate_integrity=False, auto_recovery=False,
        selected_melody_source_event_ids=export_melody_event_ids,
        melody_backbone=transformed_melody_backbone,
        serializer_manifest_path=out / "debug" / "21_SERIALIZER_MELODY_MANIFEST.json",
            structural_sanity_report_path=out / "debug" / "22_MUSICXML_STRUCTURAL_SANITY.json",
            export_integrity_report_path=out / "debug" / "23_EXPORT_INTEGRITY.json",
        )
    except BaseException as export_exc:
        recorder.record_transition(
            "JOINT_TO_EXPORTED_MUSICXML",
            input_summary={"selected_windows": len(export_result.selected)},
            output_summary={"musicxml_written": False},
            differences={"export_error_type": type(export_exc).__name__, "export_error": str(export_exc)},
            status="FAIL",
        )
        _write_privacy_event_trace_from_export_report()
        recorder.flush()
        raise

    _write_privacy_event_trace_from_export_report()
    _retention_snapshots.append(snapshot_result(export_result, "CANONICAL_FINAL_VALIDATED"))
    lifecycle_data = build_lifecycle_report(_retention_snapshots, recovery_events=())
    write_lifecycle_report(lifecycle_data, out / "debug" / "18_retention_lifecycle.json", out / "debug" / "18_retention_lifecycle.md")
    _checkpoint("FINAL_EXPORT", details={
        "physical_remaining": len(getattr(final_review, "remaining_issues", ()) or ()),
    })
    try:
        _export_monitor = json.loads((out / "debug" / "23_EXPORT_INTEGRITY.json").read_text(encoding="utf-8"))
    except Exception:
        _export_monitor = {}
    _export_mutations = int(_export_monitor.get("mutation_count", 0) or 0)
    _export_missing = int(_export_monitor.get("missing_event_count", 0) or 0)
    _export_ghost = int(_export_monitor.get("ghost_event_count", 0) or 0)
    recorder.record_transition(
        "JOINT_TO_EXPORTED_MUSICXML",
        input_summary={"selected_windows": len(export_result.selected)},
        output_summary={"reparsed_event_count": _export_monitor.get("reparsed_event_count")},
        differences={"mutation_count": _export_mutations, "missing_event_count": _export_missing, "ghost_event_count": _export_ghost},
        status="PASS" if not (_export_mutations or _export_missing or _export_ghost) else "FAIL",
    )
    write_piano_audition_without_ties(out / "05_TAB.musicxml", out / "05_TAB_AUDITION_NO_TIES.musicxml")

    # Diagnostic-only monitoring. v0.13.5.15.3 adds an explicit purity guard:
    # observers may write reports, but may not change the validated arrangement
    # or the already-exported MusicXML.
    _observer_arrangement_signature = arrangement_signature(export_result)
    _observer_export_hash = file_sha256(tab)
    try:
        # v0.13.5.12.4 diagnostic-only absolute-time audit.  This deliberately
        # runs after the validated export so it can distinguish source irregularity,
        # in-memory melody mutation/window ownership, and serialized representation.
        timeline_diag, rhythm_diag = build_timeline_rhythm_diagnostics(
            source_melody=project.melody,
            source_accompaniment=project.left_hand,
            transformed_melody=selected_transform.project.melody,
            joint_result=result,
            final_result=reviewed_result,
            export_result=export_result,
            exported_musicxml=tab,
            total_semitone_shift=selected_transform.candidate.total_shift,
            input_route=route_decision.route,
            accompaniment_mode=("NONE" if accompaniment_source=="none" else ("AUTO_GENERATED" if accompaniment_source=="synthetic_from_melody_grid" else "SOURCE_ANALYZED")),
            melody_backbone=transformed_melody_backbone,
            serializer_manifest_path=out / "debug" / "21_SERIALIZER_MELODY_MANIFEST.json",
        )
        write_timeline_rhythm_diagnostics(
            timeline_diag, rhythm_diag, debug_dir=out / "debug", output_dir=out,
        )

        # v0.13.5.12.4 diagnostic-only harmonic collision review.  This runs on
        # the validated final MusicXML and never feeds back into arrangement/Joint.
        dissonance_diag = build_dissonance_diagnostics(
            source_melody=project.melody,
            source_accompaniment=project.left_hand,
            joint_result=export_result,
            exported_musicxml=tab,
            input_route=route_decision.route,
            total_semitone_shift=selected_transform.candidate.total_shift,
            export_recovery_events=_export_recovery_events,
            melody_backbone=transformed_melody_backbone,
        )
        write_dissonance_diagnostics(
            dissonance_diag, debug_dir=out / "debug", output_dir=out,
        )
        review_packet = build_review_triage(
            timeline=timeline_diag, rhythm=rhythm_diag, dissonance=dissonance_diag,
            input_route=route_decision.route,
        )
        write_review_triage(
            review_packet, debug_dir=out / "debug", output_dir=out,
        )
        assert_observer_purity(
            result=export_result, result_signature_before=_observer_arrangement_signature,
            exported_path=tab, exported_hash_before=_observer_export_hash,
        )
        _checkpoint("TIMELINE_RHYTHM_DISSONANCE_DIAGNOSTICS", details={
            "first_melody_mismatch_stage": timeline_diag.get("first_mismatch_stage"),
            "rhythm_primary_diagnosis": rhythm_diag.get("primary_diagnosis"),
            "dissonance_issue_count": dissonance_diag.get("issue_count", 0),
            "dissonance_severity_counts": dissonance_diag.get("severity_counts", {}),
        })
    except Exception as diagnostic_exc:
        (out / "debug" / "MONITORING_WARNING.json").write_text(
            json.dumps({"version": VERSION, "status": "WARNING", "message": str(diagnostic_exc)}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        timeline_diag = {"first_mismatch_stage": None}
        rhythm_diag = {"primary_diagnosis": "MONITORING_UNAVAILABLE"}
        dissonance_diag = {"issue_count": 0, "severity_counts": {}}

    _checkpoint("POST_EXPORT_MONITORING", status=("WARNING" if (out / "debug" / "MONITORING_WARNING.json").exists() else "PASS"), details={
        "monitoring_warning": (out / "debug" / "MONITORING_WARNING.json").exists(),
        "first_melody_mismatch_stage": timeline_diag.get("first_mismatch_stage"),
        "rhythm_primary_diagnosis": rhythm_diag.get("primary_diagnosis"),
    })

    boundary_review = write_event_boundary_review(boundaries, out / "05_EVENT_BOUNDARY_REVIEW.md")
    event_integrity = write_event_integrity_report(integrity, out / "06_EVENT_INTEGRITY_REPORT.md")
    debug = out / "debug"
    candidates = write_joint_candidates_json(result, debug / "10_joint_candidates.json")
    dashboard = write_arrangement_dashboard(result, debug / "11_arrangement_dashboard.md")
    diagnostics = write_diagnostic_alternatives(result, debug / "12_diagnostic_alternatives.md")
    boundary_json = write_boundary_candidates_json(boundaries, debug / "13_boundary_candidates.json")
    event_dump = write_event_dump_json(source_melody, source_accompaniment, debug / "14_event_dump.json")
    write_mixed_harmony_diagnostics(analyses, result, debug / "16_mixed_harmony_diagnostics.json")
    _checkpoint("FINAL_DIAGNOSTICS")
    runtime_timing = {
        "version": VERSION,
        "total_seconds": round(time.perf_counter() - _runtime_started, 4),
        "export_validation_recovery_seconds": None,
        "export_recovery_actions": [],
    }
    recorder.record("runtime_timing", runtime_timing)
    recorder.checkpoint("FINAL_DIAGNOSTICS", details={"total_seconds": runtime_timing["total_seconds"]})
    # v0.1.10 read-only G1-G4 fast integrity gate. It never changes arrangement/export.
    try:
        gate_result = write_integrity_gate(out, source_integrity=integrity)
        recorder.record("integrity_gates", gate_result)
        for gate_id, gate in gate_result["gates"].items():
            recorder.checkpoint("INTEGRITY_" + gate_id, status=gate["status"], details=gate)
        recorder.checkpoint("ARRANGEMENT_QUALITY", status=("REVIEW" if arrangement_diag.get("arrangement_status") == "DEGRADED" else "PASS"))
    except Exception as integrity_gate_exc:
        recorder.checkpoint("INTEGRITY_GATES", status="WARNING", details={"message":str(integrity_gate_exc)})
        (debug / "00_GSTE_INTEGRITY_GATE_WARNING.json").write_text(
            json.dumps({"version": VERSION, "status": "WARNING", "message": str(integrity_gate_exc)}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    try:
        write_engineer_debug_summary(out)
    except Exception as engineer_summary_exc:
        (debug / "ENGINEER_DEBUG_SUMMARY_WARNING.json").write_text(
            json.dumps({"version": VERSION, "status": "WARNING", "message": str(engineer_summary_exc)}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    # Public cleanup is deliberately last.  Melody auto-arrangement can defer
    # this boundary because its outer retention/monitoring layer still needs the
    # GSTE event IDs and accompaniment markers written by the Guitar core.
    if sanitize_public_output:
        public_sanitize = sanitize_public_musicxml(tab)
        audition_path = out / "05_TAB_AUDITION_NO_TIES.musicxml"
        if audition_path.exists():
            sanitize_public_musicxml(audition_path)
        (debug / "24_PUBLIC_EXPORT_SANITIZER.json").write_text(
            json.dumps({
                "version": VERSION, "status": "PASS", "target": str(tab.name),
                **public_sanitize,
                "semantics": "Export-boundary cleanup only; all internal diagnostics already completed.",
            }, ensure_ascii=False, indent=2), encoding="utf-8",
        )

    role_md = role_json = None
    if role_result is not None:
        role_md, role_json = write_melody_role_report(role_result, out / "01_MELODY_ROLE_ANALYSIS.md")
    return JointArrangementOutputs(
        review_summary_md=summary, melody_verification_md=melody,
        harmony_bass_review_md=harmony_bass, review_json=review_json,
        tab_musicxml=tab, fingering_review_md=final_review_md,
        fingering_review_json=final_review_json, candidates_json=candidates,
        dashboard_md=dashboard, diagnostics_md=diagnostics,
        boundary_review_md=boundary_review, event_integrity_md=event_integrity,
        boundary_candidates_json=boundary_json, event_dump_json=event_dump,
        arrangement_diagnostics_json=diagnostic_path,
        register_key_report_md=register_report, register_key_report_json=register_json,
        melody_role_report_md=role_md, melody_role_report_json=role_json,
        input_route_json=route_path, source_arrangement_json=source_arrangement_json,
        source_arrangement_md=source_arrangement_md,
    )

