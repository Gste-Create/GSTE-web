from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Pitch:
    midi: int
    name: str | None = None


@dataclass(frozen=True)
class NoteEvent:
    pitch: Pitch
    start: float
    duration: float
    measure: int | None = None
    string: int | None = None
    fret: int | None = None
    source_event_id: str | None = None
    # Musical metadata is deliberately separate from immutable event identity.
    importance: int | None = None
    arrangement_role: str | None = None
    tie_root_id: str | None = None
    ensemble_priority: int | None = None
    ensemble_weight: float | None = None
    # v0.13.5.15.5: musical provenance/variant semantics live on the data line, never inside Event ID.
    source_type: str | None = None
    source_variant: str | None = None
    texture_family: str | None = None
    intent_id: str | None = None
    candidate_id: str | None = None
    pattern_type: str | None = None
    provenance: tuple = ()
    preserve_rhythm: bool = False
    attack_loss: int = 0
    allow_revoice: bool = True
    source_pitch_ref: object | None = None


@dataclass(frozen=True)
class FingeringCandidate:
    note: NoteEvent
    string: int
    fret: int
    position_block: int
    caged_shape: str | None = None
    cost: float = 0.0


@dataclass(frozen=True)
class FingeringPath:
    candidates: list[FingeringCandidate]
    total_cost: float
    warnings: list[str]
    # candidate_layers keeps the playable options considered by the optimizer.
    # Outer list = note index, inner list = candidate positions for that note.
    candidate_layers: list[list[FingeringCandidate]] | None = None
