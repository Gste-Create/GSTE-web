from __future__ import annotations

from gste.core.models import NoteEvent


def require_event_identity(note: NoteEvent, *, context: str = "") -> str:
    """Return the immutable canonical identity or fail at the first consumer.

    One Note, One Identity: downstream stages may carry/add musical metadata and
    guitar realization, but they must never infer or repair a missing identity.
    """
    event_id = note.source_event_id
    if not isinstance(event_id, str) or not event_id.strip():
        suffix = f":{context}" if context else ""
        raise ValueError(f"CANONICAL_EVENT_ID_MISSING{suffix}")
    return event_id
