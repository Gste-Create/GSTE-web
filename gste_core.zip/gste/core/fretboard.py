from __future__ import annotations

from gste.core.models import Pitch
from gste.core.tuning import STANDARD_TUNING, Tuning

POSITION_BLOCKS: list[tuple[int, int]] = [
    (0, 4),
    (3, 6),
    (5, 8),
    (7, 10),
    (10, 13),
    (12, 15),
    (15, 18),
]


def midi_to_string_fret(midi: int, max_fret: int = 17, tuning: Tuning = STANDARD_TUNING) -> list[tuple[int, int]]:
    candidates: list[tuple[int, int]] = []

    for string, open_midi in tuning.strings.items():
        fret = midi - open_midi
        if 0 <= fret <= max_fret:
            candidates.append((string, fret))

    return candidates


def position_block_for_fret(fret: int) -> int:
    for index, (low, high) in enumerate(POSITION_BLOCKS):
        if low <= fret <= high:
            return index

    if fret < 0:
        raise ValueError(f"Invalid negative fret: {fret}")

    return len(POSITION_BLOCKS) - 1


def is_guitar_playable_pitch(pitch: Pitch, max_fret: int = 17, tuning: Tuning = STANDARD_TUNING) -> bool:
    return bool(midi_to_string_fret(pitch.midi, max_fret=max_fret, tuning=tuning))
