from __future__ import annotations

from dataclasses import dataclass

_NOTE_TO_SEMITONE = {
    "C": 0,
    "C#": 1,
    "DB": 1,
    "D": 2,
    "D#": 3,
    "EB": 3,
    "E": 4,
    "F": 5,
    "F#": 6,
    "GB": 6,
    "G": 7,
    "G#": 8,
    "AB": 8,
    "A": 9,
    "A#": 10,
    "BB": 10,
    "B": 11,
}

_SEMITONE_TO_STEP_ALTER = {
    0: ("C", 0),
    1: ("C", 1),
    2: ("D", 0),
    3: ("D", 1),
    4: ("E", 0),
    5: ("F", 0),
    6: ("F", 1),
    7: ("G", 0),
    8: ("G", 1),
    9: ("A", 0),
    10: ("A", 1),
    11: ("B", 0),
}


@dataclass(frozen=True)
class Tuning:
    """Guitar tuning represented as MusicXML string numbers -> open-string MIDI."""

    name: str
    strings: dict[int, int]

    def open_midi(self, string: int) -> int:
        return self.strings[string]

    def musicxml_staff_tunings(self) -> list[tuple[int, str, int]]:
        """Return (line/string, tuning-step, tuning-octave) for MusicXML TAB export."""
        result: list[tuple[int, str, int]] = []
        # MusicXML staff line numbers run from bottom to top, while guitar
        # string numbers run from highest string (1) to lowest string (6).
        # Therefore string 6 belongs on staff line 1 and string 1 on line 6.
        string_count = len(self.strings)
        for string_number in sorted(self.strings):
            line = string_count + 1 - string_number
            midi = self.strings[string_number]
            step, alter = _SEMITONE_TO_STEP_ALTER[midi % 12]
            # MusicXML staff-tuning supports step/octave in the common subset.
            # For sharp open strings, emit the natural step; rare custom sharp
            # tunings still keep fingering correct through MIDI calculations.
            if alter:
                step = f"{step}#"
            octave = midi // 12 - 1
            result.append((line, step, octave))
        return result


BUILTIN_TUNINGS: dict[str, Tuning] = {
    "standard": Tuning("standard", {1: 64, 2: 59, 3: 55, 4: 50, 5: 45, 6: 40}),
    "drop_d": Tuning("drop_d", {1: 64, 2: 59, 3: 55, 4: 50, 5: 45, 6: 38}),
    "dadgad": Tuning("dadgad", {1: 62, 2: 57, 3: 55, 4: 50, 5: 45, 6: 38}),
    "open_g": Tuning("open_g", {1: 62, 2: 59, 3: 55, 4: 50, 5: 43, 6: 38}),
}

STANDARD_TUNING = BUILTIN_TUNINGS["standard"]


def note_name_to_midi(note: str) -> int:
    """Parse note names such as E2, D#3, Bb2 into MIDI numbers."""
    raw = note.strip()
    if len(raw) < 2:
        raise ValueError(f"Invalid note name: {note!r}")

    letter = raw[0].upper()
    rest = raw[1:]
    accidental = ""
    if rest and rest[0] in {"#", "b", "B"}:
        accidental = rest[0].upper()
        rest = rest[1:]

    key = letter + accidental
    if key not in _NOTE_TO_SEMITONE:
        raise ValueError(f"Invalid note name: {note!r}")

    try:
        octave = int(rest)
    except ValueError as exc:
        raise ValueError(f"Invalid octave in note name: {note!r}") from exc

    return (octave + 1) * 12 + _NOTE_TO_SEMITONE[key]


def parse_custom_tuning(value: str, name: str = "custom") -> Tuning:
    """Parse 6-string custom tuning in low-to-high order, e.g. D2,A2,D3,G3,B3,E4."""
    parts = [part.strip() for part in value.split(",") if part.strip()]
    if len(parts) != 6:
        raise ValueError("Custom tuning must contain exactly 6 notes, low-to-high, e.g. D2,A2,D3,G3,B3,E4.")

    midi_values = [note_name_to_midi(part) for part in parts]
    strings = {6 - index: midi for index, midi in enumerate(midi_values)}
    return Tuning(name=name, strings=strings)


def resolve_tuning(tuning_name: str = "standard", custom_tuning: str | None = None) -> Tuning:
    if custom_tuning:
        return parse_custom_tuning(custom_tuning)
    try:
        return BUILTIN_TUNINGS[tuning_name]
    except KeyError as exc:
        choices = ", ".join(sorted(BUILTIN_TUNINGS))
        raise ValueError(f"Unsupported tuning {tuning_name!r}. Choose one of: {choices}.") from exc
