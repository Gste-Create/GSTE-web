from __future__ import annotations

from gste.core.models import FingeringPath


def validate_fingering_path(path: FingeringPath, max_fret: int = 17) -> list[str]:
    warnings = list(path.warnings)

    for index, candidate in enumerate(path.candidates):
        if candidate.fret > max_fret:
            warnings.append(f"Note {index} exceeds max fret {max_fret}.")
        if candidate.string < 1 or candidate.string > 6:
            warnings.append(f"Note {index} has invalid string {candidate.string}.")

    return warnings
