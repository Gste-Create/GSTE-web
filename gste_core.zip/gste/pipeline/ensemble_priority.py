from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable
import xml.etree.ElementTree as ET

from gste.core.models import NoteEvent
from gste.input_formats.router import parse_source_track
from gste.arrangement.source_adapters import EnsembleTrackSpec
from gste.pipeline.ensemble import analyze_ensemble_score
from gste.main import arrange_source_score
from gste.input.project_models import PianoSplitProject
from gste.group_score import InstrumentAnalysisSpec, analyze_instruments_with_piano_pipeline, merge_group_accompaniment, select_source_events_for_prejoint
from gste.core.tuning import STANDARD_TUNING, Tuning

# GUI never exposes these numeric values. Priority is the user-facing contract;
# fixed weights make ensemble behavior deterministic and maintainable.
FIXED_PRIORITY_WEIGHTS: tuple[float, ...] = (1.00, 0.72, 0.50, 0.35, 0.24, 0.16)

@dataclass(frozen=True)
class EnsemblePriorityTrack:
    path: Path
    instrument_family: str
    priority: int

    def __post_init__(self):
        family = self.instrument_family.upper()
        if family in {"RHYTHM_GUITAR", "LEAD_GUITAR"}:
            family = "GUITAR"
        object.__setattr__(self, "instrument_family", family)

    @property
    def fixed_weight(self) -> float:
        idx=max(0,min(self.priority-1,len(FIXED_PRIORITY_WEIGHTS)-1))
        return FIXED_PRIORITY_WEIGHTS[idx]


def _write_track_musicxml(notes: Iterable[NoteEvent], reference_track, path: Path, title: str) -> Path:
    path.parent.mkdir(parents=True,exist_ok=True)
    score=ET.Element('score-partwise',version='3.1')
    work=ET.SubElement(score,'work'); ET.SubElement(work,'work-title').text=title
    part_list=ET.SubElement(score,'part-list')
    sp=ET.SubElement(part_list,'score-part',id='P1'); ET.SubElement(sp,'part-name').text='GSTE Ensemble Priority Accompaniment'
    part=ET.SubElement(score,'part',id='P1')
    divisions=480
    by_measure={}
    for n in notes: by_measure.setdefault(n.measure,[]).append(n)
    ts_by_measure={x.measure:x for x in reference_track.time_signatures}
    current_ts=None
    for mnum in sorted(reference_track.measure_starts):
        measure=ET.SubElement(part,'measure',number=str(mnum))
        attrs=ET.SubElement(measure,'attributes'); ET.SubElement(attrs,'divisions').text=str(divisions)
        if mnum in ts_by_measure: current_ts=ts_by_measure[mnum]
        if current_ts is not None:
            tm=ET.SubElement(attrs,'time'); ET.SubElement(tm,'beats').text=str(current_ts.beats); ET.SubElement(tm,'beat-type').text=str(current_ts.beat_type)
        mstart=reference_track.measure_starts[mnum]
        mlen=reference_track.measure_lengths[mnum]
        # Emit each note as an independent voice reset to measure start. This is
        # verbose but preserves arbitrary overlap and is parsed deterministically.
        for idx,n in enumerate(sorted(by_measure.get(mnum,[]),key=lambda x:(x.start,x.pitch.midi)),1):
            offset=max(0.0,n.start-mstart)
            if offset>1e-9:
                fwd=ET.SubElement(measure,'forward'); ET.SubElement(fwd,'duration').text=str(max(1,round(offset*divisions)))
            ne=ET.SubElement(measure,'note')
            pitch=ET.SubElement(ne,'pitch')
            midi=n.pitch.midi; pc=midi%12; octave=midi//12-1
            names=[('C',0),('C',1),('D',0),('D',1),('E',0),('F',0),('F',1),('G',0),('G',1),('A',0),('A',1),('B',0)]
            step,alter=names[pc]; ET.SubElement(pitch,'step').text=step
            if alter: ET.SubElement(pitch,'alter').text=str(alter)
            ET.SubElement(pitch,'octave').text=str(octave)
            dur=max(1,round(n.duration*divisions)); ET.SubElement(ne,'duration').text=str(dur)
            ET.SubElement(ne,'voice').text=str(idx)
            nots=ET.SubElement(ne,'notations'); other=ET.SubElement(nots,'other-notation',type='gste-event-id'); other.text=n.source_event_id or f'ENS:M{mnum}:N{idx}'
            back=ET.SubElement(measure,'backup'); ET.SubElement(back,'duration').text=str(max(1,round((offset+n.duration)*divisions)))
        # Advance furthest cursor to expected end for alignment metadata.
        fwd=ET.SubElement(measure,'forward'); ET.SubElement(fwd,'duration').text=str(max(1,round(mlen*divisions)))
    ET.ElementTree(score).write(path,encoding='utf-8',xml_declaration=True)
    return path


def arrange_ensemble_priority(melody_path: str|Path, tracks: tuple[EnsemblePriorityTrack,...], *, output_dir: str|Path, tuning: Tuning=STANDARD_TUNING):
    from dataclasses import asdict, replace
    import json
    from gste.group_score.contract import to_accompaniment_data
    if not tracks: raise ValueError('團譜模式至少需要一個伴奏軌。')
    out=Path(output_dir);out.mkdir(parents=True,exist_ok=True)
    melody=parse_source_track(melody_path,track_id='piano_right',role='melody_source')
    raw_tracks=[]; ordered=tuple(sorted(tracks,key=lambda t:t.priority))
    for index,item in enumerate(ordered):
        raw_tracks.append(parse_source_track(item.path,track_id=f'GROUP_{index+1}_{item.instrument_family}',role=item.instrument_family.lower()))
    from gste.alignment.common_timeline import common_timeline
    aligned,report=common_timeline((melody,*raw_tracks))
    audit=out/'ensemble_analysis';audit.mkdir(parents=True,exist_ok=True)
    (audit/'COMMON_TIMELINE_DIAGNOSTICS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (audit/'ORIGINAL_SOURCE_TRACKS.json').write_text(json.dumps([asdict(t) for t in (melody,*raw_tracks)],default=str,ensure_ascii=False,indent=2),encoding='utf-8')
    if aligned is None:
        from gste.diagnostics.recorder import PipelineDiagnosticsRecorder
        recorder=PipelineDiagnosticsRecorder(out)
        recorder.record('common_timeline_alignment',report)
        recorder.checkpoint('COMMON_TIMELINE',status='FAILED',details=report)
        error=ValueError('COMMON_TIMELINE_CONFLICT: see ensemble_analysis/COMMON_TIMELINE_DIAGNOSTICS.json')
        recorder.fail('COMMON_TIMELINE',error)
        raise error
    specs=[InstrumentAnalysisSpec(t.track_id,item.instrument_family,PianoSplitProject(aligned[0],t),item.fixed_weight) for item,t in zip(ordered,aligned[1:])]
    contributions=analyze_instruments_with_piano_pipeline(tuple(specs))
    bundle=merge_group_accompaniment(contributions,diagnostics_dir=audit)
    data=to_accompaniment_data(bundle,contributions)
    (audit/'ACCOMPANIMENT_DATA.json').write_text(json.dumps(asdict(data),ensure_ascii=False,indent=2),encoding='utf-8')
    # No mixed raw carrier: accompaniment observations live in the contract.
    empty=replace(aligned[0],track_id='canonical_accompaniment',notes=[],events=[],role='accompaniment')
    return arrange_source_score(melody_path,tracks[0].path,output_dir=out,tuning=tuning,
        accompaniment_source='ensemble_score',accompaniment_data=data,
        parsed_source_project=PianoSplitProject(aligned[0],empty), original_source_tracks=(melody,*raw_tracks))
