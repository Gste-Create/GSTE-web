from __future__ import annotations

from dataclasses import dataclass

from gste.input.models import InputKind, InputProfile


@dataclass(frozen=True)
class PipelineStage:
    name: str
    status: str
    description: str


def build_pipeline_plan(profile: InputProfile) -> list[PipelineStage]:
    """Return an explicit roadmap for the selected input profile.

    This does not pretend unfinished harmony/accompaniment logic is complete.
    It makes the implemented and planned boundaries visible to CLI, reports,
    tests, and future MuseScore plugin integration.
    """

    stages = [
        PipelineStage("validate", "implemented", "Validate MusicXML and score metadata."),
        PipelineStage("normalize", "partial", "Normalize source parts into melody/TAB events."),
    ]

    if profile.normalized_kind == InputKind.EXISTING_TAB:
        stages.append(PipelineStage("tab_shift", "implemented", "Preserve strings where possible and search a playable shift."))
    else:
        stages.append(PipelineStage("melody_fingering", "implemented", "Generate candidates and select a path with dynamic programming."))

    if profile.source_kind in {InputKind.LEAD_SHEET, InputKind.MELODY_XML}:
        stages.extend(
            [
                PipelineStage("harmony_inference", "planned", "Score and prune chord families from melody and available harmonic evidence."),
                PipelineStage("accompaniment_generation", "planned", "Add accompaniment only after melody-complete shape selection; permit omission."),
            ]
        )
    elif profile.source_kind == InputKind.KEYBOARD_SCORE:
        stages.extend(
            [
                PipelineStage("keyboard_reduction", "planned", "Extract melody, weighted accompaniment evidence, structural bass, and harmonic windows."),
                PipelineStage("guitar_revoicing", "planned", "Prune chord families, expand guitar shapes, and reduce accompaniment around the melody."),
            ]
        )
    elif profile.source_kind == InputKind.BAND_SCORE:
        stages.extend(
            [
                PipelineStage("track_selection", "planned", "Select vocal/lead, rhythm guitar, and bass evidence by section."),
                PipelineStage("arrangement_fusion", "planned", "Fuse melody-complete fingering with pruned chord families and important bass evidence."),
            ]
        )

    stages.append(PipelineStage("export", "implemented", "Write MusicXML TAB and a diagnostic Markdown report."))
    return stages
