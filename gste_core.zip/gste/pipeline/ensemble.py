from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
import json
from gste.parser.track_parser import parse_musicxml_track
from gste.arrangement.source_adapters import EnsembleSourceAdapter, EnsembleTrackSpec, BassSourceAdapter, RhythmGuitarSourceAdapter, StringSectionSourceAdapter

DEFAULT_ADAPTERS={
    "BASS":BassSourceAdapter(),
    "GUITAR":RhythmGuitarSourceAdapter(),
    "RHYTHM_GUITAR":RhythmGuitarSourceAdapter(),
    "LEAD_GUITAR":RhythmGuitarSourceAdapter(),
    "STRINGS":StringSectionSourceAdapter(),
}

def analyze_ensemble_score(track_files: dict[str,str|Path], specs: tuple[EnsembleTrackSpec,...], *, output_dir: str|Path="outputs/ensemble_analysis"):
    """Analyze band/orchestra accompaniment tracks into weighted source intents.

    This v0.13.6 entry point intentionally stops before final guitar arrangement:
    it proves the multi-source boundary and emits auditable contributions that
    later feed the same canonical/guitar engine.
    """
    out=Path(output_dir); out.mkdir(parents=True,exist_ok=True)
    spec_by_id={s.track_id:s for s in specs}
    tracks={}
    for tid,path in track_files.items():
        spec=spec_by_id[tid]
        tracks[tid]=parse_musicxml_track(path,track_id=tid,role=spec.instrument_family.lower())
    adapter=EnsembleSourceAdapter(DEFAULT_ADAPTERS)
    result=adapter.analyze_tracks(tracks,specs)
    payload={"version":"0.13.6","route":"SOURCE_ENSEMBLE","tracks":[]}
    for spec,data in result:
        def conv(x):
            if isinstance(x,tuple): return [conv(v) for v in x]
            try:return asdict(x)
            except TypeError:return x
        payload["tracks"].append({"spec":asdict(spec),"analysis":conv(data),"effective_note":"user_weight is an intent-retention weight, not a literal note-retention percentage"})
    path=out/'02_ENSEMBLE_SOURCE_INTENTS.json'
    path.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    return path
