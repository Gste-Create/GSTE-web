from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from gste.alignment.validator import validate_strict_alignment
from gste.arrangement.source.service import analyze_and_map_piano_source
from gste.arrangement.source import write_source_arrangement_diagnostics
from gste.exporter.piano_analysis_report import (
    write_aligned_tracks_json,
    write_alignment_report,
    write_harmony_report_json,
    write_harmony_summary,
    write_structure_report_json,
    write_structure_summary,
    write_planning_report_json,
    write_planning_summary,
    write_melody_extraction_report_json,
    write_melody_extraction_summary,
    write_full_musical_events_json,
)
from gste.harmony.piano_analysis import analyze_harmony_windows
from gste.harmony.windows import build_fixed_harmony_windows
from gste.input.project_models import PianoSplitProject
from gste.structure.analysis import analyze_structure
from gste.melody import analyze_melody_feasibility, build_position_zone_candidates
from gste.optimizer import build_position_plans
from gste.parser.track_parser import parse_musicxml_track
from gste.melody_extraction import extract_highest_voice


@dataclass(frozen=True)
class PianoAnalysisOutputs:
    validation_report: Path
    aligned_tracks_json: Path | None
    harmony_report_json: Path | None
    summary_report: Path | None
    structure_report_json: Path | None = None
    structure_summary_report: Path | None = None
    planning_report_json: Path | None = None
    planning_summary_report: Path | None = None
    melody_extraction_report_json: Path | None = None
    melody_extraction_summary_report: Path | None = None
    full_musical_events_json: Path | None = None
    source_arrangement_json: Path | None = None
    source_arrangement_md: Path | None = None


def analyze_piano_split(
    melody_path: str | Path,
    left_hand_path: str | Path,
    *,
    output_dir: str | Path = "outputs/piano_analysis",
    quarters_per_window: float = 2.0,
    top_k: int = 3,
    minimum_score: float = 0.0,
) -> PianoAnalysisOutputs:
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    right_hand_source = parse_musicxml_track(melody_path, track_id="piano_right", role="right_hand_source")
    left_hand_source = parse_musicxml_track(left_hand_path, track_id="piano_left", role="accompaniment")
    full_events_path = write_full_musical_events_json(
        right_hand_source, left_hand_source, out_dir / "00_full_musical_events.json"
    )
    extraction = extract_highest_voice(right_hand_source)
    project = PianoSplitProject(
        melody=extraction.melody_track,
        left_hand=left_hand_source,
    )
    alignment = validate_strict_alignment(project)
    validation_path = write_alignment_report(alignment, out_dir / "00_input_validation_report.md")
    if not alignment.is_aligned:
        return PianoAnalysisOutputs(validation_path, None, None, None, None, None, None, None, None, None, full_events_path)

    extraction_path = write_melody_extraction_report_json(extraction, out_dir / "01_melody_extraction.json")
    extraction_summary_path = write_melody_extraction_summary(extraction, out_dir / "02_melody_extraction_summary.md")
    aligned_path = write_aligned_tracks_json(alignment, out_dir / "03_aligned_tracks.json")
    windows = build_fixed_harmony_windows(project, quarters_per_window=quarters_per_window)
    structure = analyze_structure(project, windows)
    analyses = analyze_harmony_windows(windows, top_k=top_k, minimum_score=minimum_score)
    feasibility = analyze_melody_feasibility(project.melody)
    zones = build_position_zone_candidates(project.melody, feasibility, windows)
    plans = build_position_plans(zones, structure.signals)
    structure_path = write_structure_report_json(structure, out_dir / "04_structure_signals.json")
    harmony_path = write_harmony_report_json(analyses, out_dir / "05_harmony_report.json")
    summary_path = write_harmony_summary(analyses, out_dir / "06_harmony_summary.md")
    structure_summary_path = write_structure_summary(structure, out_dir / "07_structure_summary.md")
    planning_path = write_planning_report_json(feasibility, zones, plans, out_dir / "08_planning_report.json")
    planning_summary_path = write_planning_summary(feasibility, zones, plans, out_dir / "09_planning_summary.md")
    source_plan = analyze_and_map_piano_source(project, quarters_per_window=quarters_per_window, chord_top_k=top_k)
    source_json, source_md = write_source_arrangement_diagnostics(
        source_plan, out_dir / "10_source_arrangement_intents.json"
    )
    return PianoAnalysisOutputs(
        validation_report=validation_path,
        aligned_tracks_json=aligned_path,
        harmony_report_json=harmony_path,
        summary_report=summary_path,
        structure_report_json=structure_path,
        structure_summary_report=structure_summary_path,
        planning_report_json=planning_path,
        planning_summary_report=planning_summary_path,
        melody_extraction_report_json=extraction_path,
        melody_extraction_summary_report=extraction_summary_path,
        full_musical_events_json=full_events_path,
        source_arrangement_json=source_json,
        source_arrangement_md=source_md,
    )
