from __future__ import annotations

from dataclasses import dataclass

from gste.fingering.shapes import ChordShape


@dataclass(frozen=True)
class AccompanimentTone:
    pitch_class: int
    importance: float
    role: str
    string: int | None = None


_ROLE_PRIORITY = {
    "characteristic_bass": 5.0,
    "root": 4.0,
    "third": 4.0,
    "seventh": 3.8,
    "counterline": 3.5,
    "fifth": 2.0,
    "extension": 1.5,
    "doubling": 0.5,
    "fill": 0.2,
}


def select_accompaniment_tones(
    tones: list[AccompanimentTone],
    shape: ChordShape,
    blocked_strings: frozenset[int],
    max_tones: int = 3,
) -> list[AccompanimentTone]:
    """Keep the most musical accompaniment evidence after melody claims space.

    Melody strings are treated as unavailable. Dropping accompaniment is legal;
    keeping the selected chord family and its characteristic information is the
    objective.
    """

    usable = [tone for tone in tones if tone.string is None or tone.string not in blocked_strings]
    usable.sort(
        key=lambda tone: (
            -(_ROLE_PRIORITY.get(tone.role, 1.0) + tone.importance),
            tone.pitch_class,
        )
    )
    return usable[: max(max_tones, 0)]
