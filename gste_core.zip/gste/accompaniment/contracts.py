from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, Sequence

from gste.core.models import NoteEvent
from gste.harmony.contracts import ChordEvent


@dataclass(frozen=True)
class AccompanimentEvent:
    pitch_midi: int
    start: float
    duration: float
    role: str


class AccompanimentGenerator(Protocol):
    """Boundary for bass-line, chord-tone, and pattern generators."""

    def generate(
        self,
        melody: Sequence[NoteEvent],
        harmony: Sequence[ChordEvent],
    ) -> list[AccompanimentEvent]: ...
