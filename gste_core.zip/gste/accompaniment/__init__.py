"""Accompaniment contracts and melody-first reduction helpers."""

from gste.accompaniment.reduction import AccompanimentTone, select_accompaniment_tones

__all__ = ["AccompanimentTone", "select_accompaniment_tones"]
