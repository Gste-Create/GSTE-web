"""GSTE engineer-facing parameter control layer.

Public maintenance API:
    from gste.control import get_value, active_profile_path

The active profile is loaded from ``profiles/active_profile.toml``.  Users may
select a preset with ``python tools/select_gste_profile.py <name>`` and restart
GSTE.  Algorithms should read tunable soft/search parameters through this
module instead of embedding new magic numbers in implementation files.
"""
from .loader import get_value, get_section, load_active_profile, active_profile_path

__all__ = ["get_value", "get_section", "load_active_profile", "active_profile_path"]
