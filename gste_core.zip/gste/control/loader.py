from __future__ import annotations

from copy import deepcopy
from functools import lru_cache
from pathlib import Path
import tomllib
from typing import Any

_PROFILE_DIR = Path(__file__).with_name("profiles")
_ACTIVE = _PROFILE_DIR / "active_profile.toml"
_DEFAULT = _PROFILE_DIR / "default.toml"


def active_profile_path() -> Path:
    return _ACTIVE


@lru_cache(maxsize=1)
def load_active_profile() -> dict[str, Any]:
    """Return merged Default + active engineer profile.

    ``default.toml`` is the canonical baseline that reproduces the checked-in
    GSTE behaviour. ``active_profile.toml`` may override only the values an
    engineer wants to tune. Restart GSTE after changing profiles.
    """
    base = _read(_DEFAULT)
    if _ACTIVE.exists():
        _merge(base, _read(_ACTIVE))
    return base


def get_section(name: str) -> dict[str, Any]:
    value = load_active_profile().get(name, {})
    return deepcopy(value) if isinstance(value, dict) else {}


def get_value(path: str, default: Any = None) -> Any:
    node: Any = load_active_profile()
    for key in path.split("."):
        if not isinstance(node, dict) or key not in node:
            return default
        node = node[key]
    return deepcopy(node)


def _read(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("rb") as handle:
        return tomllib.load(handle)


def _merge(target: dict[str, Any], override: dict[str, Any]) -> None:
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(target.get(key), dict):
            _merge(target[key], value)
        else:
            target[key] = value
