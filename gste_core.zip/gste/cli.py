from __future__ import annotations

import argparse
from pathlib import Path

from gste.version import VERSION
from gste.conversion_service import ConversionRequest, run_conversion
from gste.conversion_core import convert_score  # legacy public re-export; CLI does not own implementation
from gste.core.tuning import BUILTIN_TUNINGS
from gste.pipeline.piano_split import analyze_piano_split



def main() -> None:
    parser = argparse.ArgumentParser(description="GSTE command-line interface")
    subparsers = parser.add_subparsers(dest="command", required=True)

    edit_parser = subparsers.add_parser("regenerate", help="Apply editor JSON through the shared GSTE conversion entry")
    edit_parser.add_argument("context", help="GSTE_EDITOR_CONTEXT.json")
    edit_parser.add_argument("requests", help="GSTE_EDIT_REQUEST.json")
    edit_parser.add_argument("--out-dir", required=True)

    local_parser = subparsers.add_parser("local-edit", help="Preview and export frozen local feasible edits")
    local_parser.add_argument("context")
    local_parser.add_argument("requests")
    local_parser.add_argument("--out-dir", required=True)
    local_parser.add_argument("--bpm", type=float, default=120.)

    convert_parser = subparsers.add_parser("convert", help="Convert MusicXML to GSTE TAB MusicXML")
    convert_parser.add_argument("path", help="Input .xml or .musicxml melody/TAB score")
    convert_parser.add_argument("--out-dir", default="outputs", help="Output directory")
    convert_parser.add_argument("--no-auto-shift", action="store_true", help="Disable automatic transposition search")
    convert_parser.add_argument(
        "--mode",
        choices=["auto", "melody", "tab"],
        default="auto",
        help="auto detects TAB string/fret; melody regenerates TAB; tab preserves same-string TAB shape when possible",
    )
    convert_parser.add_argument(
        "--auto-accompaniment",
        action="store_true",
        help="Enable the v0.12.2 melody auto-arrangement pipeline",
    )
    convert_parser.add_argument(
        "--accompaniment-pattern",
        choices=["auto", "root", "root_guide", "bass_inner", "bass_chord", "reduced_arpeggio", "arpeggio"],
        default="auto",
        help="Generated accompaniment style (default: per-window auto selection)",
    )

    convert_parser.add_argument(
        "--tuning",
        default="standard",
        choices=sorted(BUILTIN_TUNINGS.keys()),
        help="Guitar tuning for fingering and TAB export",
    )
    convert_parser.add_argument(
        "--custom-tuning",
        help="Custom 6-string tuning in low-to-high order, e.g. D2,A2,D3,G3,B3,E4",
    )
    convert_parser.add_argument(
        "--max-candidates",
        type=int,
        default=5,
        help="Maximum playable string/fret candidates to keep for each melody note",
    )
    convert_parser.add_argument(
        "--no-candidate-report",
        action="store_true",
        help="Hide the per-note candidate fingering section from the report",
    )

    analyze_parser = subparsers.add_parser("analyze", help="Alias of convert for MVP")
    analyze_parser.add_argument("path", help="Input .xml or .musicxml melody/TAB score")
    analyze_parser.add_argument("--out-dir", default="outputs", help="Output directory")
    analyze_parser.add_argument("--no-auto-shift", action="store_true", help="Disable automatic transposition search")
    analyze_parser.add_argument("--mode", choices=["auto", "melody", "tab"], default="auto")

    analyze_parser.add_argument(
        "--tuning",
        default="standard",
        choices=sorted(BUILTIN_TUNINGS.keys()),
        help="Guitar tuning for fingering and TAB export",
    )
    analyze_parser.add_argument(
        "--custom-tuning",
        help="Custom 6-string tuning in low-to-high order, e.g. D2,A2,D3,G3,B3,E4",
    )
    analyze_parser.add_argument("--max-candidates", type=int, default=5)
    analyze_parser.add_argument("--no-candidate-report", action="store_true")


    piano_parser = subparsers.add_parser(
        "analyze-piano",
        help="Analyze aligned right-hand melody and left-hand accompaniment MusicXML files",
    )
    piano_parser.add_argument("--melody", required=True, help="Right-hand piano MusicXML; MVP keeps the highest note at each onset")
    piano_parser.add_argument("--left-hand", required=True, help="Left-hand accompaniment MusicXML")
    piano_parser.add_argument("--out-dir", default="outputs/piano_analysis", help="Output directory")
    piano_parser.add_argument(
        "--window-quarters",
        type=float,
        default=2.0,
        help="Fixed harmony-window length in quarter-note units",
    )
    piano_parser.add_argument("--top-k", type=int, default=3, help="Chord-family candidates per harmony window")
    piano_parser.add_argument(
        "--minimum-score",
        type=float,
        default=0.0,
        help="Discard chord-family candidates below this score",
    )


    arrange_parser = subparsers.add_parser(
        "arrange-piano",
        help="Jointly optimize melody fingering, chord family, and accompaniment voicing",
    )
    arrange_parser.add_argument("--melody", required=True)
    arrange_parser.add_argument("--left-hand", required=True)
    arrange_parser.add_argument("--out-dir", default="outputs/joint_arrangement")
    arrange_parser.add_argument("--window-quarters", type=float, default=2.0)
    arrange_parser.add_argument("--chord-top-k", type=int, default=3)
    arrange_parser.add_argument("--melody-paths", type=int, default=6)
    arrange_parser.add_argument("--accompaniment-per-chord", type=int, default=4)
    arrange_parser.add_argument("--joint-candidates", type=int, default=24)
    arrange_parser.add_argument("--max-candidates", type=int, default=5)
    arrange_parser.add_argument("--tuning", default="standard", choices=sorted(BUILTIN_TUNINGS.keys()))
    arrange_parser.add_argument("--custom-tuning")

    args = parser.parse_args()
    if args.command == "local-edit":
        import json
        from gste.editor.local import preview, export_preview
        result=preview(args.context,json.loads(Path(args.requests).read_text(encoding="utf-8")))
        print(json.dumps({"accepted":result.accepted,"windows":result.outcomes,"elapsed_ms":result.elapsed_ms},ensure_ascii=False))
        if not result.accepted:
            parser.exit(2,"Local requests have no accepted feasible result.\n")
        print(export_preview(result,Path(args.out_dir),bpm=args.bpm)/"GSTE_LOCAL_TAB.musicxml")
        return
    if args.command == "regenerate":
        from gste.editor.session import regenerate
        result = regenerate(args.context, args.requests, Path(args.out_dir))
        print(result.tab_musicxml)
        return

    if args.command in {"convert", "analyze"}:
        # V0.0.6.4: CLI melody conversion uses the same public service for both
        # AUTO and NONE.  No route may bypass canonical monitoring/output packaging.
        service_result = run_conversion(ConversionRequest(
            kind="melody", melody=Path(args.path), output_dir=Path(args.out_dir),
            accompaniment_mode=("AUTO_GENERATED" if getattr(args, "auto_accompaniment", False) else "NONE"),
            accompaniment_pattern=getattr(args, "accompaniment_pattern", "auto"),
            tuning_name=args.tuning, custom_tuning=args.custom_tuning, max_candidates=args.max_candidates,
        ))
        report_path, tab_path = service_result.report, service_result.tab_musicxml
        print(f"Report written: {report_path}")
        print(f"TAB MusicXML written: {tab_path}")
    elif args.command == "analyze-piano":
        outputs = analyze_piano_split(
            args.melody,
            args.left_hand,
            output_dir=args.out_dir,
            quarters_per_window=args.window_quarters,
            top_k=args.top_k,
            minimum_score=args.minimum_score,
        )
        print(f"Validation report written: {outputs.validation_report}")
        print(f"Full musical events written: {outputs.full_musical_events_json}")
        if outputs.aligned_tracks_json is None:
            print("Strict alignment failed; harmony analysis was not run.")
        else:
            print(f"Aligned tracks written: {outputs.aligned_tracks_json}")
            print(f"Harmony report written: {outputs.harmony_report_json}")
            print(f"Summary written: {outputs.summary_report}")
    elif args.command == "arrange-piano":
        service_result = run_conversion(ConversionRequest(
            kind="piano", melody=Path(args.melody), left_hand=Path(args.left_hand), output_dir=Path(args.out_dir),
            tuning_name=args.tuning, custom_tuning=args.custom_tuning, max_candidates=args.max_candidates,
            window_quarters=args.window_quarters, chord_top_k=args.chord_top_k,
            melody_paths=args.melody_paths, accompaniment_per_chord=args.accompaniment_per_chord,
            joint_candidates=args.joint_candidates,
        ))
        print(f"Report written: {service_result.report}")
        print(f"TAB MusicXML written: {service_result.tab_musicxml}")
        print(f"All diagnostics retained under: {service_result.output_dir}")


if __name__ == "__main__":
    main()
