"""Canonical runtime contract verdict for GSTE.

This module is intentionally small.  It consumes observations already captured by
PipelineDiagnosticsRecorder and is the only component allowed to assign a global
runtime PASS/FAIL/UNAVAILABLE verdict.  It never inspects or mutates musical
objects and never re-runs arrangement logic.
"""
from __future__ import annotations
from typing import Any

_FAILURE = {"FAIL", "FAILED", "BLOCKED"}
_WARNING = {"WARNING", "REVIEW", "DEGRADED", "NOT_AVAILABLE"}


def evaluate_runtime_contract(data: dict[str, Any]) -> dict[str, Any]:
    transitions = list(data.get("transitions") or [])
    stages = dict(data.get("stages") or {})
    failures: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []

    # Boundaries are checked first because they are the most precise evidence
    # of where a mutation/loss first became observable.
    for index, row in enumerate(transitions):
        status = str(row.get("status", "UNAVAILABLE")).upper()
        item = {"kind": "TRANSITION", "name": row.get("name"), "status": status, "index": index, "sequence": row.get("sequence", index)}
        if status in _FAILURE:
            failures.append(item)
        elif status in _WARNING:
            warnings.append(item)

    for index, (name, row) in enumerate(stages.items()):
        status = str((row or {}).get("status", "UNAVAILABLE")).upper()
        item = {"kind": "STAGE", "name": name, "status": status, "index": index, "sequence": row.get("sequence", index)}
        if status in _FAILURE:
            failures.append(item)
        elif status in _WARNING:
            warnings.append(item)

    pipeline_status = str(data.get("status", "UNAVAILABLE")).upper()
    if failures or pipeline_status == "FAILED":
        verdict = "FAIL"
    elif pipeline_status != "COMPLETE":
        verdict = "UNAVAILABLE"
    elif warnings:
        verdict = "REVIEW"
    else:
        verdict = "PASS"

    problems=failures+warnings
    first=min(problems,key=lambda x: x.get("sequence",10**9)) if problems else None
    return {
        "schema": "GSTE_RUNTIME_CONTRACT_V1",
        "verdict": verdict,
        "first_observed_problem": first,
        "failure_count": len(failures),
        "warning_count": len(warnings),
        "rule": "Global verdict is derived only from recorder observations; reports may not recompute a competing global verdict.",
    }
