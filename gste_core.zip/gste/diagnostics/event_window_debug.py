"""Observer-only Event/Window debug probe for v0.13.5.15.4.

Only expands details for locked melody events that are absent from the union of
analysis windows.  It never changes windows, notes, membership, costs, or path
selection.
"""
from __future__ import annotations


def _ids(notes) -> set[str]:
    return {
        str(getattr(note, "source_event_id", "") or "")
        for note in (notes or ())
        if getattr(note, "source_event_id", None)
    }


def _r(value: float) -> float:
    return round(float(value), 9)


def build_event_window_debug(backbone, analyses, *, detail_limit: int = 50) -> dict[str, object]:
    windows = []
    covered_ids: set[str] = set()
    for analysis in analyses or ():
        window = getattr(analysis, "window", None)
        if window is None:
            continue
        member_ids = _ids(getattr(window, "melody_notes", ()))
        covered_ids.update(member_ids)
        start = float(getattr(window, "start", 0.0))
        duration = float(getattr(window, "duration", 0.0))
        windows.append({
            "window_id": str(getattr(window, "window_id", "")),
            "measure": getattr(window, "measure", None),
            "start": start,
            "end": start + duration,
            "member_ids": member_ids,
        })

    missing = [e for e in getattr(backbone, "events", ()) if e.structural_event_id not in covered_ids]
    details = []
    for event in missing[:detail_limit]:
        attack, release = float(event.attack), float(event.release)
        overlaps = [w for w in windows if attack < w["end"] and release > w["start"]]
        same_measure = [w for w in windows if w["measure"] == event.measure]
        nearest = sorted(
            windows,
            key=lambda w: min(abs(attack - w["end"]), abs(release - w["start"]), abs(attack - w["start"])),
        )[:4]

        if overlaps:
            reason_class = "TIME_OVERLAP_EXISTS_BUT_EVENT_NOT_MEMBER"
        elif same_measure:
            reason_class = "NO_TIME_OVERLAP_WITH_SAME_MEASURE_WINDOWS"
        elif windows:
            reason_class = "NO_ANALYSIS_WINDOW_COVERS_EVENT_TIME"
        else:
            reason_class = "NO_ANALYSIS_WINDOWS"

        def slim(w):
            return {
                "window_id": w["window_id"],
                "measure": w["measure"],
                "start": _r(w["start"]),
                "end": _r(w["end"]),
                "contains_event_id": event.structural_event_id in w["member_ids"],
            }

        details.append({
            "event_id": event.structural_event_id,
            "midi": int(event.midi_pitch),
            "measure": event.measure,
            "attack": _r(attack),
            "release": _r(release),
            "duration": _r(release - attack),
            "reason_class": reason_class,
            "time_overlapping_windows": [slim(w) for w in overlaps[:8]],
            "same_measure_windows": [slim(w) for w in same_measure[:8]],
            "nearest_windows": [slim(w) for w in nearest],
        })

    reason_counts: dict[str, int] = {}
    for row in details:
        key = row["reason_class"]
        reason_counts[key] = reason_counts.get(key, 0) + 1

    return {
        "observer_only": True,
        "scope": "UNcovered locked melody events only",
        "locked_event_count": len(getattr(backbone, "events", ())),
        "covered_event_count": len(set(getattr(backbone, "event_ids", ())) & covered_ids),
        "uncovered_event_count": len(missing),
        "analysis_window_count": len(windows),
        "reason_class_counts_in_detail": reason_counts,
        "uncovered_event_details": details,
        "details_truncated": len(missing) > detail_limit,
        "detail_limit": detail_limit,
        "note": "Diagnostic classifications describe observed coverage geometry only; they do not repair or reinterpret membership.",
    }
