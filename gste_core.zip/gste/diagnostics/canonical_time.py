"""Canonical physical-time contract and read-only integrity diagnostics.

v0.13.5.15.5.2 OBSERVER-ONLY FREEZE
------------------------------------
CanonicalTime is the single physical time coordinate for a sounding event:
attack, release and duration. Analysis coordinates (measure/beat/window/grid)
may vary freely but MUST NOT rewrite canonical event time.

This module intentionally does not mutate NoteEvent or pipeline objects.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Any


@dataclass(frozen=True)
class CanonicalTime:
    attack: float
    release: float

    @property
    def duration(self) -> float:
        return self.release - self.attack

    @classmethod
    def from_note(cls, note: Any) -> "CanonicalTime":
        attack = float(note.start)
        return cls(attack=attack, release=attack + float(note.duration))

    def as_dict(self) -> dict[str, float]:
        return {
            "attack": round(self.attack, 9),
            "release": round(self.release, 9),
            "duration": round(self.duration, 9),
        }


def snapshot_notes(notes: Iterable[Any]) -> dict[str, dict[str, object]]:
    """Snapshot identifiable source events without changing ordering/state."""
    rows: dict[str, dict[str, object]] = {}
    for note in notes:
        event_id = str(getattr(note, "source_event_id", "") or "")
        if not event_id:
            continue
        ct = CanonicalTime.from_note(note)
        rows[event_id] = {
            **ct.as_dict(),
            "midi": int(note.pitch.midi),
            "measure": getattr(note, "measure", None),
        }
    return rows


def compare_to_reference(reference: dict[str, dict[str, object]], current: dict[str, dict[str, object]], *, detail_limit: int = 50) -> dict[str, object]:
    """Observer-only identity/time comparison. Missing IDs are reported, never repaired."""
    missing = sorted(set(reference) - set(current))
    unknown = sorted(set(current) - set(reference))
    mutations: list[dict[str, object]] = []
    for event_id in sorted(set(reference) & set(current)):
        ref, cur = reference[event_id], current[event_id]
        ref_time = (ref.get("attack"), ref.get("release"), ref.get("duration"))
        cur_time = (cur.get("attack"), cur.get("release"), cur.get("duration"))
        if ref_time != cur_time:
            mutations.append({"event_id": event_id, "expected": {k: ref.get(k) for k in ("attack","release","duration")}, "actual": {k: cur.get(k) for k in ("attack","release","duration")}})
    return {
        "status": "PASS" if not missing and not unknown and not mutations else "OBSERVED_DIFFERENCE",
        "reference_count": len(reference),
        "current_count": len(current),
        "missing_count": len(missing),
        "unknown_count": len(unknown),
        "time_mutation_count": len(mutations),
        "missing_event_ids": missing[:detail_limit],
        "unknown_event_ids": unknown[:detail_limit],
        "time_mutations": mutations[:detail_limit],
        "details_truncated": len(missing) > detail_limit or len(unknown) > detail_limit or len(mutations) > detail_limit,
    }
