"""Minimal read-only melody conservation probe for v0.13.5.15.5.3.

Purpose: answer one question only: does a locked structural melody event first
vanish from the analysis-window view, or only later from Joint candidate layers?
This module never mutates pipeline data and never affects musical decisions.
"""
from __future__ import annotations


def _ids(notes) -> set[str]:
    return {
        str(getattr(note, "source_event_id", "") or "")
        for note in (notes or ())
        if getattr(note, "source_event_id", None)
    }


def build_minimal_melody_conservation(backbone, analyses, result, *, detail_limit: int = 50) -> dict[str, object]:
    locked = set(getattr(backbone, "event_ids", frozenset()))

    window_ids: set[str] = set()
    for analysis in analyses or ():
        window_ids.update(_ids(getattr(getattr(analysis, "window", None), "melody_notes", ())))

    candidate_ids: set[str] = set()
    for layer in (getattr(result, "candidate_layers", ()) or ()):
        for state in layer:
            melody = getattr(state, "melody", None)
            for cand in (getattr(melody, "notes", ()) or ()):
                note = getattr(cand, "note", None)
                if note is not None:
                    candidate_ids.update(_ids((note,)))

    missing_at_window = sorted(locked - window_ids)
    present_in_window = locked & window_ids
    missing_after_window = sorted(present_in_window - candidate_ids)

    if missing_at_window:
        first_loss = "ANALYSIS_WINDOW_COVERAGE"
    elif missing_after_window:
        first_loss = "AFTER_WINDOW_BEFORE_OR_IN_CANDIDATE_LAYERS"
    else:
        first_loss = "NONE_OBSERVED_THROUGH_CANDIDATE_UNION"

    return {
        "observer_only": True,
        "question": "Does melody identity disappear at analysis-window coverage or later?",
        "locked_event_count": len(locked),
        "window_union_event_count": len(locked & window_ids),
        "candidate_union_event_count": len(locked & candidate_ids),
        "first_loss_stage": first_loss,
        "missing_at_window_count": len(missing_at_window),
        "missing_after_window_count": len(missing_after_window),
        "missing_at_window_ids": missing_at_window[:detail_limit],
        "missing_after_window_ids": missing_after_window[:detail_limit],
        "details_truncated": len(missing_at_window) > detail_limit or len(missing_after_window) > detail_limit,
        "interpretation": {
            "ANALYSIS_WINDOW_COVERAGE": "Supports the meter/window-coverage hypothesis: locked melody events are absent from the union of analysis windows.",
            "AFTER_WINDOW_BEFORE_OR_IN_CANDIDATE_LAYERS": "Rejects window coverage as the first loss: events are visible to analysis windows but disappear later before/in candidate layers.",
            "NONE_OBSERVED_THROUGH_CANDIDATE_UNION": "No melody identity loss observed through candidate union.",
        },
    }
