"""Privacy-safe per-event lifecycle projection. No pitch, title, harmony or score text."""
from __future__ import annotations
from pathlib import Path
import json

def write_event_lifecycle_trace(*, output_dir, source_notes, role_candidates, priority_pool, result, export_integrity):
    out=Path(output_dir); debug=out/'debug'; debug.mkdir(parents=True,exist_ok=True)
    source={str(n.source_event_id): n for n in source_notes if getattr(n,'source_event_id',None)}
    roles={str(getattr(c.note,'source_event_id','')): c for c in role_candidates if getattr(c.note,'source_event_id',None)}
    priority={str(n.source_event_id):n for n in priority_pool if getattr(n,'source_event_id',None)}
    selected={str(c.note.source_event_id):c for st in result.selected for c in (*st.melody.notes,*st.accompaniment.notes) if getattr(c.note,'source_event_id',None)}
    rt={r['source_event_id']:r for r in export_integrity.get('privacy_safe_event_round_trip',[])}
    ids=sorted(set(source)|set(priority)|set(selected)|set(rt), key=lambda x:(getattr(source.get(x) or priority.get(x),'start',10**12),x))
    rows=[]
    for eid in ids:
        n=source.get(eid) or priority.get(eid); rc=roles.get(eid); r=rt.get(eid,{}); sel=selected.get(eid)
        requested_onset=r.get('requested_onset'); requested_release=r.get('requested_release')
        actual_onset=r.get('actual_onset'); actual_release=r.get('actual_release')
        contract=r.get('contract','NOT_EXPORTED')
        if contract=='TIMING_MUTATION' and requested_onset==actual_onset and requested_release!=actual_release: contract='RELEASE_MUTATION'
        rows.append({
          'source_event_id':eid,
          'SOURCE': {'onset': getattr(n,'start',None), 'release': (getattr(n,'start',0)+getattr(n,'duration',0)) if n is not None else None},
          'MELODY_ROLE': {'admitted': eid in roles or eid in priority, 'role': str(getattr(getattr(rc,'role',None),'value',getattr(rc,'role',None))) if rc else None, 'priority': getattr(n,'importance',None) if n is not None else None},
          'PRE_JOINT': {'event_id_present': eid in priority or eid in roles},
          'JOINT': {'decision':'SELECTED' if eid in selected else 'REJECTED_OR_NOT_APPLICABLE', 'representation_event_id': eid if eid in selected else None},
          'EXPORT': {'requested_onset':requested_onset,'requested_release':requested_release,'notation_segment_count':r.get('notation_segment_count',0),'tie_continuation_count':r.get('tie_continuation_count',0)},
          'REPARSE': {'actual_onset':actual_onset,'actual_release':actual_release},
          'CONTRACT': contract,
        })
    payload={'schema':'GSTE_PRIVACY_SAFE_EVENT_LIFECYCLE_V1','privacy':'NO_PITCH_NO_TITLE_NO_HARMONY_NO_SCORE_TEXT','events':rows}
    jp=debug/'EVENT_LIFECYCLE_TRACE.json'; jp.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    mp=out/'EVENT_LIFECYCLE_TRACE.md'; lines=['# Privacy-Safe Event Lifecycle Trace','','No pitch, title, harmony, or score text is included.','']
    interesting=[r for r in rows if r['CONTRACT'] not in ('PASS','NOT_EXPORTED')]
    show=interesting if interesting else rows[:25]
    for r in show:
        lines += [f"## {r['source_event_id']}", '', '```text', f"source_event_id = {r['source_event_id']}", '', 'SOURCE', f"  onset/release = {r['SOURCE']['onset']} / {r['SOURCE']['release']}", '  ↓', 'MELODY ROLE', f"  admitted / role / priority = {r['MELODY_ROLE']['admitted']} / {r['MELODY_ROLE']['role']} / {r['MELODY_ROLE']['priority']}", '  ↓', 'PRE-JOINT', f"  event_id present = {r['PRE_JOINT']['event_id_present']}", '  ↓', 'JOINT', f"  {r['JOINT']['decision']} / representation_event_id = {r['JOINT']['representation_event_id']}", '  ↓', 'EXPORT', f"  requested onset/release = {r['EXPORT']['requested_onset']} / {r['EXPORT']['requested_release']}", f"  notation segment count = {r['EXPORT']['notation_segment_count']}", f"  tie continuation count = {r['EXPORT']['tie_continuation_count']}", '  ↓', 'REPARSE', f"  actual onset/release = {r['REPARSE']['actual_onset']} / {r['REPARSE']['actual_release']}", '  ↓', 'CONTRACT', f"  {r['CONTRACT']}", '```','']
    mp.write_text('\n'.join(lines),encoding='utf-8')
    return mp,jp
