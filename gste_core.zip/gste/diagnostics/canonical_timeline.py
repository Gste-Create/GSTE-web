"""Read-only canonical timeline and window projection API.

v0.13.5.15.4.1 PHASE-1 TIMELINE FOUNDATION
------------------------------------------
This module centralizes the *reference coordinate system* only.  It does not
replace any production window, change membership, regenerate candidates, or
participate in musical selection.

Canonical physical time is expressed in quarter-note units on the parser's
absolute timeline.  Measure/meter are labels projected onto that timeline;
they are never an independent source of absolute time.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

from gste.diagnostics.canonical_time import CanonicalTime

_EPS = 1e-9


@dataclass(frozen=True)
class CanonicalMeasureRange:
    measure: int
    start: float
    end: float

    @property
    def duration(self) -> float:
        return self.end - self.start


@dataclass(frozen=True)
class CanonicalWindowProjection:
    window_id: str
    measure: int | None
    canonical_start: float | None
    canonical_end: float | None
    source: str

    @property
    def duration(self) -> float | None:
        if self.canonical_start is None or self.canonical_end is None:
            return None
        return self.canonical_end - self.canonical_start


class CanonicalTimeline:
    """Single read-only reference clock for event/measure time.

    Phase 1 deliberately wraps existing parser truth rather than changing it.
    Production Harmony/Texture/PreJoint/Joint windows continue to run exactly
    as before.  Callers may query/project/compare only.
    """

    def __init__(self, *, event_times: dict[str, CanonicalTime], measures: dict[int, CanonicalMeasureRange], duration: float):
        self._event_times = dict(event_times)
        self._measures = dict(measures)
        self._duration = float(duration)

    @classmethod
    def from_track(cls, track: Any) -> "CanonicalTimeline":
        event_times: dict[str, CanonicalTime] = {}
        for note in getattr(track, "notes", ()):
            event_id = str(getattr(note, "source_event_id", "") or "")
            if event_id:
                event_times[event_id] = CanonicalTime.from_note(note)

        starts = dict(getattr(track, "measure_starts", {}) or {})
        lengths = dict(getattr(track, "measure_lengths", {}) or {})
        measures: dict[int, CanonicalMeasureRange] = {}
        for measure, start in starts.items():
            if measure not in lengths:
                continue
            start_f = float(start)
            measures[int(measure)] = CanonicalMeasureRange(
                measure=int(measure), start=start_f, end=start_f + float(lengths[measure])
            )
        return cls(event_times=event_times, measures=measures, duration=float(getattr(track, "duration_quarters", 0.0)))

    @property
    def duration(self) -> float:
        return self._duration

    def event_time(self, event_id: str) -> CanonicalTime | None:
        return self._event_times.get(str(event_id))

    def measure_range(self, measure: int) -> CanonicalMeasureRange | None:
        return self._measures.get(int(measure))

    def event_ids_overlapping(self, start: float, end: float) -> tuple[str, ...]:
        start_f, end_f = float(start), float(end)
        return tuple(sorted(
            event_id for event_id, ct in self._event_times.items()
            if ct.attack < end_f and ct.release > start_f
        ))

    def project_window(self, window: Any) -> CanonicalWindowProjection:
        """Project an existing window label onto the canonical measure clock.

        This is comparison-only in Phase 1.  The production window's own
        start/end are not modified.  Within-measure offset is retained when it
        is well-defined; if the current window is outside its labelled measure,
        projection is intentionally unavailable rather than guessed.
        """
        window_id = str(getattr(window, "window_id", ""))
        measure = getattr(window, "measure", None)
        if measure is None:
            return CanonicalWindowProjection(window_id, None, None, None, "NO_MEASURE_LABEL")
        mr = self.measure_range(int(measure))
        if mr is None:
            return CanonicalWindowProjection(window_id, int(measure), None, None, "MEASURE_NOT_IN_TIMELINE")

        current_start = float(getattr(window, "start", 0.0))
        duration = float(getattr(window, "duration", 0.0))
        # Only retain a local offset if current geometry is already inside the
        # canonical measure.  Phase 1 must not invent a repair for broken data.
        if mr.start - _EPS <= current_start <= mr.end + _EPS:
            offset = max(0.0, current_start - mr.start)
            projected_start = mr.start + offset
            projected_end = min(mr.end, projected_start + max(0.0, duration))
            return CanonicalWindowProjection(window_id, int(measure), projected_start, projected_end, "MEASURE_RANGE_PLUS_EXISTING_LOCAL_OFFSET")

        return CanonicalWindowProjection(window_id, int(measure), mr.start, mr.end, "MEASURE_RANGE_REFERENCE_ONLY")


def compare_existing_windows(timeline: CanonicalTimeline, analyses: Iterable[Any], *, detail_limit: int = 50) -> dict[str, object]:
    """Observer-only comparison of current windows against canonical measure ranges."""
    rows: list[dict[str, object]] = []
    mismatch_count = 0
    for analysis in analyses or ():
        window = getattr(analysis, "window", None)
        if window is None:
            continue
        current_start = float(getattr(window, "start", 0.0))
        current_end = current_start + float(getattr(window, "duration", 0.0))
        projection = timeline.project_window(window)
        mismatch = False
        if projection.canonical_start is not None and projection.canonical_end is not None:
            # Reference-only projections flag windows that sit outside the
            # canonical range of their own measure. Exact subdivisions remain
            # unchanged/compatible and therefore do not count as mismatches.
            mr = timeline.measure_range(int(projection.measure)) if projection.measure is not None else None
            if mr is not None:
                mismatch = current_start < mr.start - _EPS or current_end > mr.end + _EPS
        if mismatch:
            mismatch_count += 1
            if len(rows) < detail_limit:
                rows.append({
                    "window_id": projection.window_id,
                    "measure": projection.measure,
                    "current_start": round(current_start, 9),
                    "current_end": round(current_end, 9),
                    "canonical_measure_start": round(projection.canonical_start, 9) if projection.canonical_start is not None else None,
                    "canonical_measure_end": round(projection.canonical_end, 9) if projection.canonical_end is not None else None,
                    "projection_source": projection.source,
                })
    return {
        "observer_only": True,
        "production_windows_modified": False,
        "reference_clock": "PARSER_CANONICAL_ABSOLUTE_QUARTER_TIMELINE",
        "timeline_duration": round(timeline.duration, 9),
        "window_measure_range_mismatch_count": mismatch_count,
        "window_measure_range_mismatches": rows,
        "details_truncated": mismatch_count > detail_limit,
        "detail_limit": detail_limit,
        "note": "Phase 1 API only: production window start/end and musical decisions remain untouched.",
    }
