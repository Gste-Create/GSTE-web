"""Read-only event lifecycle diagnostics for v0.13.5.15.5.2.

No function in this module is allowed to alter candidates, costs, pruning,
selection, hard rules, timing, identity, or fingering.
"""
from __future__ import annotations
from collections import Counter
from typing import Any


def _note_rows_from_candidates(candidates) -> list[Any]:
    return [cand.note for cand in (candidates or ()) if getattr(cand, "note", None) is not None]


def _ids(notes) -> set[str]:
    return {str(getattr(n, "source_event_id", "") or "") for n in notes if getattr(n, "source_event_id", None)}


def _result_stage_notes(result, *, selected_only: bool) -> tuple[list[Any], list[Any]]:
    melody: list[Any] = []
    accompaniment: list[Any] = []
    layers = (getattr(result, "selected", ()) or ()) if selected_only else [state for layer in (getattr(result, "candidate_layers", ()) or ()) for state in layer]
    for state in layers:
        melody.extend(_note_rows_from_candidates(getattr(getattr(state, "melody", None), "notes", ())))
        accompaniment.extend(_note_rows_from_candidates(getattr(getattr(state, "accompaniment", None), "notes", ())))
    return melody, accompaniment


def build_event_lifecycle(backbone, result, *, detail_limit: int = 50) -> dict[str, object]:
    """Locate the first observable loss between candidate union and selected path."""
    locked = set(getattr(backbone, "event_ids", frozenset()))
    candidate_melody, candidate_acc = _result_stage_notes(result, selected_only=False)
    selected_melody, selected_acc = _result_stage_notes(result, selected_only=True)
    candidate_ids, selected_ids = _ids(candidate_melody), _ids(selected_melody)
    missing_candidate = sorted(locked - candidate_ids)
    missing_selected = sorted(locked - selected_ids)
    lost_candidate_to_selected = sorted((locked & candidate_ids) - selected_ids)

    first_loss_stage = None
    if missing_candidate:
        first_loss_stage = "CANDIDATE_LAYERS_OR_EARLIER"
    elif missing_selected:
        first_loss_stage = "JOINT_PATH_SELECTION_OR_RESULT_ASSEMBLY"

    candidate_acc_ids, selected_acc_ids = _ids(candidate_acc), _ids(selected_acc)
    acc_lost = sorted(candidate_acc_ids - selected_acc_ids)
    selected_types = Counter(str(getattr(getattr(s, "accompaniment", None), "candidate_type", "UNKNOWN")) for s in (getattr(result, "selected", ()) or ()))
    return {
        "observer_only": True,
        "melody": {
            "locked_event_count": len(locked),
            "candidate_union_event_count": len(candidate_ids & locked),
            "selected_event_count": len(selected_ids & locked),
            "missing_by_candidate_stage_count": len(missing_candidate),
            "missing_by_selected_stage_count": len(missing_selected),
            "candidate_to_selected_loss_count": len(lost_candidate_to_selected),
            "first_observable_loss_stage": first_loss_stage or "NONE_OBSERVED",
            "missing_by_candidate_stage_ids": missing_candidate[:detail_limit],
            "missing_by_selected_stage_ids": missing_selected[:detail_limit],
            "candidate_to_selected_loss_ids": lost_candidate_to_selected[:detail_limit],
        },
        "accompaniment": {
            "candidate_union_identity_count": len(candidate_acc_ids),
            "selected_identity_count": len(selected_acc_ids),
            "candidate_union_to_selected_identity_loss_count": len(acc_lost),
            "candidate_union_to_selected_identity_loss_ids": acc_lost[:detail_limit],
            "selected_candidate_type_counts": dict(selected_types),
            "metric_note": "Identity continuity observation only. This is NOT a retention KPI because revoicing/generated notes may use different lineage IDs.",
        },
        "details_truncated": len(missing_candidate) > detail_limit or len(missing_selected) > detail_limit or len(acc_lost) > detail_limit,
    }


def result_note_snapshots(result) -> tuple[list[Any], list[Any]]:
    """Expose read-only selected melody/accompaniment notes for CanonicalTime snapshots."""
    return _result_stage_notes(result, selected_only=True)
