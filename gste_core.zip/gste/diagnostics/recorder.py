"""Read-only, failure-safe pipeline diagnostics infrastructure.

Architecture freeze v0.13.5.13.5:
- Recorder observes values supplied by pipeline code.
- Recorder may record, serialize and flush diagnostics only.
- Recorder never receives mutable pipeline objects and exposes no mutation API.
- Disk I/O happens at explicit checkpoints (plus emergency failure flush), not per item.
"""
from __future__ import annotations

from contextvars import ContextVar
from functools import wraps
from pathlib import Path
from typing import Any
import inspect
import json
import time
import traceback

from gste.version import VERSION
from gste.diagnostics.contract_checker import evaluate_runtime_contract

_DEFAULT_STAGES = (
    "SOURCE_PARSER", "INPUT_ROUTE", "UNIFIED_MELODY_ROLE_ANALYSIS",
    "EVENT_IDENTITY_AUDIT", "MELODY_BACKBONE_LOCK", "STRICT_ALIGNMENT",
    "ACCOMPANIMENT_SOURCE_ADAPTER", "INPUT_AND_SOURCE_ANALYSIS",
    "GLOBAL_TRANSFORM_SELECTION", "UNIFIED_MELODY_PREJOINT_SEARCH_CONFIG",
    "FINGERING_PATH_SEARCH", "JOINT_SELECTED", "UNIFIED_MELODY_IDENTITY_LIFECYCLE",
    "PRE_FINAL_EXPORT_AND_REPORTS", "FINAL_FINGERING_REVIEW", "FINAL_EXPORT",
    "POST_EXPORT_MONITORING", "FINAL_DIAGNOSTICS",
)

_current: ContextVar["PipelineDiagnosticsRecorder | None"] = ContextVar("gste_pipeline_recorder", default=None)


class PipelineDiagnosticsRecorder:
    """Single writer for primary monitoring state; strictly observer-only."""

    def __init__(self, output_dir: str | Path):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.path = self.output_dir / "PIPELINE_DIAGNOSTICS.json"
        self._started = time.perf_counter()
        self._last = self._started
        self._sequence = 0
        self._data: dict[str, Any] = {
            "version": VERSION,
            "status": "RUNNING",
            "last_checkpoint": None,
            "stages": {name: {"status": "NOT_REACHED"} for name in _DEFAULT_STAGES},
            "metrics": {
                "windows_generated": "NOT_REACHED",
                "candidates_generated": "NOT_REACHED",
                "candidates_after_prejoint": "NOT_REACHED",
                "reachable_windows": "NOT_REACHED",
                "selected_windows": "NOT_REACHED",
            },
            "observations": {},
            "trackers": {},
            "transitions": [],
            "failure": None,
            "recorder_policy": {
                "read_only": True,
                "allowed_operations": ["observe", "record", "serialize", "flush"],
                "pipeline_mutation": "FORBIDDEN",
                "flush_policy": "CORE_OBSERVATION_CHECKPOINT_AND_EXCEPTION",
                "tracker_policy": "SUMMARY_ALWAYS__DETAIL_ON_DIFFERENCE__DETAIL_LIMITED",
                "canonical_time_policy": "SOURCE_PHYSICAL_TIME_IMMUTABLE__ANALYSIS_WINDOWS_READ_ONLY",
            },
        }
        self.flush()

    @classmethod
    def current(cls) -> "PipelineDiagnosticsRecorder | None":
        return _current.get()

    def install(self):
        return _current.set(self)

    def uninstall(self, token) -> None:
        _current.reset(token)

    def record(self, key: str, value: Any, *, section: str = "observations") -> None:
        """Record immutable diagnostic data in memory; no disk I/O and no pipeline mutation."""
        if section not in self._data or not isinstance(self._data[section], dict):
            self._data[section] = {}
        self._data[section][key] = value

    def record_and_flush(self, key: str, value: Any, *, section: str = "observations") -> None:
        """Record one core observation and atomically persist it immediately."""
        self.record(key, value, section=section)
        self.flush()

    def record_metrics(self, **metrics: Any) -> None:
        for key, value in metrics.items():
            if key in self._data["metrics"]:
                self._data["metrics"][key] = value
            else:
                self.record(key, value, section="metrics_extra")

    def checkpoint(self, stage: str, *, details: dict[str, Any] | None = None, status: str = "PASS") -> None:
        now = time.perf_counter()
        row = self._data["stages"].setdefault(stage, {"status": "NOT_REACHED"})
        self._sequence += 1
        row.update({
            "sequence": self._sequence,
            "status": status,
            "stage_seconds": round(now - self._last, 4),
            "elapsed_seconds": round(now - self._started, 4),
        })
        if details:
            row["details"] = details
        self._last = now
        self._data["last_checkpoint"] = stage
        self.flush()

    def fail(self, stage: str, exc: BaseException, *, details: dict[str, Any] | None = None) -> None:
        now = time.perf_counter()
        row = self._data["stages"].setdefault(stage, {"status": "NOT_REACHED"})
        row["status"] = "FAILED"
        row["elapsed_seconds"] = round(now - self._started, 4)
        if details:
            row["details"] = details
        self._data["status"] = "FAILED"
        self._data["failure"] = {
            "stage": stage,
            "type": type(exc).__name__,
            "message": str(exc),
            "traceback": "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))[-12000:],
        }
        self.flush()
        self._write_unified_report()

    def record_transition(self, name: str, *, input_summary: dict[str, Any], output_summary: dict[str, Any], differences: dict[str, Any] | None = None, status: str = "PASS") -> None:
        """Record only observed boundary I/O. No musical inference is performed here."""
        self._sequence += 1
        self._data["transitions"].append({
            "sequence": self._sequence,
            "name": str(name), "status": str(status),
            "input": dict(input_summary), "output": dict(output_summary),
            "differences": dict(differences or {}),
        })

    def _write_unified_report(self) -> None:
        """One canonical monitor projection. Other reports may present this data but must not recompute it."""
        contract = evaluate_runtime_contract(self._data)
        first = contract.get("first_observed_problem")
        payload = {
            "schema": "GSTE_UNIFIED_RUNTIME_MONITOR_V1",
            "version": self._data.get("version"),
            "status": self._data.get("status"),
            "policy": {
                "single_source_of_truth": "PIPELINE_DIAGNOSTICS.json",
                "observer_only": True,
                "rule": "Record boundary input/output and contract differences only; never run a second arrangement algorithm.",
                "first_observed_problem": "First recorded boundary/stage difference, not an inferred root cause.",
            },
            "contract": contract,
            "first_observed_problem": first,
            "stages": self._data.get("stages", {}),
            "transitions": self._data.get("transitions", []),
            "trackers": self._data.get("trackers", {}),
            "metrics": self._data.get("metrics", {}),
            "failure": self._data.get("failure"),
        }
        jp = self.output_dir / "debug" / "UNIFIED_RUNTIME_MONITOR.json"
        mp = self.output_dir / "UNIFIED_RUNTIME_MONITOR.md"
        jp.parent.mkdir(parents=True, exist_ok=True)
        jp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        lines = [f"# {payload['version']} Unified Runtime Monitor", "", f"Status: **{payload['status']}**", "",
                 f"Canonical contract verdict: **{contract['verdict']}**", "",
                 "This report is a read-only projection of `PIPELINE_DIAGNOSTICS.json`. It does not re-run musical logic.", ""]
        if first:
            lines += [f"First observed problem: **{first['kind']} / {first['name']} / {first['status']}**", ""]
        else:
            lines += ["First observed problem: **NONE OBSERVED**", ""]
        lines += ["## Boundary transitions", "", "| Boundary | Status |", "|---|---|"]
        for row in payload["transitions"]:
            lines.append(f"| {row.get('name')} | {row.get('status')} |")
        if not payload["transitions"]:
            lines.append("| — | NOT_RECORDED |")
        mp.write_text("\n".join(lines) + "\n", encoding="utf-8")

    def complete(self) -> None:
        self._data["status"] = "COMPLETE"
        self._data["elapsed_seconds"] = round(time.perf_counter() - self._started, 4)
        self.flush()
        self._write_unified_report()

    def flush(self) -> Path:
        """Atomic checkpoint write. Never touches pipeline/music state."""
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        temp.write_text(json.dumps(self._data, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        temp.replace(self.path)
        return self.path


def failure_safe_pipeline(func):
    """Ensure every uncaught pipeline failure is emergency-flushed before re-raise."""
    signature = inspect.signature(func)

    @wraps(func)
    def wrapped(*args, **kwargs):
        bound = signature.bind_partial(*args, **kwargs)
        output_dir = bound.arguments.get("output_dir", signature.parameters["output_dir"].default)
        recorder = PipelineDiagnosticsRecorder(output_dir)
        token = recorder.install()
        try:
            result = func(*args, **kwargs)
            recorder.complete()
            return result
        except BaseException as exc:
            stage = str(recorder._data.get("last_checkpoint") or "SOURCE_PARSER")
            recorder.fail(stage, exc)
            raise
        finally:
            recorder.uninstall(token)

    return wrapped
