"""Compact observer-only event conservation summary for v0.13.5.15.6.

This replaces the always-on overlap between lifecycle, melody_conservation and
Event/Window deep probes.  Deep probes remain available for sandbox debugging,
but production monitoring records only the first-loss summary needed after a
failed conversion.
"""
from __future__ import annotations
from collections import Counter
from typing import Any


def _note_rows_from_candidates(candidates) -> list[Any]:
    return [cand.note for cand in (candidates or ()) if getattr(cand, "note", None) is not None]


def _ids(notes) -> set[str]:
    return {str(getattr(n, "source_event_id", "") or "") for n in notes if getattr(n, "source_event_id", None)}


def _result_stage_notes(result, *, selected_only: bool) -> tuple[list[Any], list[Any]]:
    melody: list[Any] = []
    accompaniment: list[Any] = []
    layers = (getattr(result, "selected", ()) or ()) if selected_only else [
        state for layer in (getattr(result, "candidate_layers", ()) or ()) for state in layer
    ]
    for state in layers:
        melody.extend(_note_rows_from_candidates(getattr(getattr(state, "melody", None), "notes", ())))
        accompaniment.extend(_note_rows_from_candidates(getattr(getattr(state, "accompaniment", None), "notes", ())))
    return melody, accompaniment


def result_note_snapshots(result) -> tuple[list[Any], list[Any]]:
    return _result_stage_notes(result, selected_only=True)


def build_event_conservation(backbone, analyses, result) -> dict[str, object]:
    locked = set(getattr(backbone, "event_ids", frozenset()))
    window_ids: set[str] = set()
    for analysis in analyses or ():
        window_ids.update(_ids(getattr(getattr(analysis, "window", None), "melody_notes", ())))

    candidate_melody, candidate_acc = _result_stage_notes(result, selected_only=False)
    selected_melody, selected_acc = _result_stage_notes(result, selected_only=True)
    candidate_ids, selected_ids = _ids(candidate_melody), _ids(selected_melody)
    candidate_acc_ids, selected_acc_ids = _ids(candidate_acc), _ids(selected_acc)

    if locked - window_ids:
        first_loss = "ANALYSIS_WINDOW"
    elif (locked & window_ids) - candidate_ids:
        first_loss = "CANDIDATE_GENERATION"
    elif (locked & candidate_ids) - selected_ids:
        first_loss = "JOINT_SELECTION"
    else:
        first_loss = "NONE_OBSERVED"

    selected_types = Counter(
        str(getattr(getattr(s, "accompaniment", None), "candidate_type", "UNKNOWN"))
        for s in (getattr(result, "selected", ()) or ())
    )
    return {
        "observer_only": True,
        "melody": {
            "locked": len(locked),
            "window_covered": len(locked & window_ids),
            "candidate_union": len(locked & candidate_ids),
            "selected": len(locked & selected_ids),
            "first_loss_stage": first_loss,
        },
        "accompaniment": {
            "candidate_union_identity_count": len(candidate_acc_ids),
            "selected_identity_count": len(selected_acc_ids),
            "candidate_to_selected_identity_loss_count": len(candidate_acc_ids - selected_acc_ids),
            "selected_candidate_type_counts": dict(selected_types),
            "note": "Identity continuity only; revoicing/generated notes can change lineage IDs.",
        },
        "policy": "SUMMARY_ONLY__DEEP_EVENT_LISTS_ARE_SANDBOX_DEBUG",
    }
