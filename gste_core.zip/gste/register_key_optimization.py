"""v0.11.4.1 joint register/key search with register preservation and long-form diagnostics."""
from __future__ import annotations

from dataclasses import dataclass, replace

from gste.core.models import NoteEvent, Pitch
from gste.core.tuning import STANDARD_TUNING, Tuning
from gste.harmony.piano_analysis import WindowHarmonyAnalysis, analyze_harmony_windows
from gste.harmony.windows import build_fixed_harmony_windows
from gste.input.project_models import PianoSplitProject, TrackData
from gste.joint_arrangement.models import JointArrangementResult
from gste.joint_arrangement.optimizer import optimize_joint_arrangement
from gste.register_key_config import (
    HIGH_FRET_THRESHOLD, LARGE_POSITION_MOVE_THRESHOLD,
    ORIGINAL_REGISTER_MIN_BASS_RETENTION, ORIGINAL_REGISTER_MIN_COMFORT_RATE,
    ORIGINAL_REGISTER_MIN_FULL_WINDOW_RATE, REGISTER_PRESERVATION_ENABLED,
)

MELODY_FLOOR_MIDI = 50  # D3 preferred melody register floor; NOT a physical hard limit
FAST_PREFILTER_KEEP = 4
LIGHTWEIGHT_KEEP = 2
FULL_SEARCH_KEEP = 2
# v0.13.3.4 route-aware search budgets. Melody-only keeps a wider pool because
# there is no source-register explosion to justify aggressive pruning.
AUTO_FAST_PREFILTER_KEEP = 5
AUTO_LIGHTWEIGHT_KEEP = 3
AUTO_FULL_SEARCH_KEEP = 1
SOURCE_FAST_PREFILTER_KEEP = 4
SOURCE_LIGHTWEIGHT_KEEP = 2
SOURCE_FULL_SEARCH_KEEP = 2
SAFE_FALLBACK_FULL_EVAL_LIMIT_AUTO = 4
SAFE_FALLBACK_FULL_EVAL_LIMIT_SOURCE = 5
COMPLEX_PIANO_FALLBACK_FULL_EVAL_LIMIT = 3
COMPLEX_PIANO_MELODY_NOTES = 260
COMPLEX_PIANO_WINDOWS = 120
COMPLEX_PIANO_ACCOMPANIMENT_NOTES = 500
COMPLEX_PIANO_MAX_SIMULTANEOUS_NOTES = 3
LONG_SCORE_MELODY_NOTES = 260
LONG_SCORE_WINDOWS = 120
# V0.13.5.11: AUTO_MELODY enters bounded search earlier because each harmony
# window now carries a real texture candidate superset. SOURCE_PIANO keeps the
# established thresholds above unchanged.
AUTO_LONG_SCORE_MELODY_NOTES = 160
AUTO_LONG_SCORE_WINDOWS = 80
DECISIVE_LIGHTWEIGHT_MARGIN = 35.0
MAX_FRET = 18
TRANSFORM_EQUIVALENCE_MARGIN = 15.0


@dataclass(frozen=True)
class RegisterKeyCandidate:
    key_semitones: int
    octave_shift: int
    label: str

    @property
    def total_shift(self) -> int:
        return self.key_semitones + self.octave_shift


@dataclass(frozen=True)
class RegisterKeyEvaluation:
    candidate: RegisterKeyCandidate
    project: PianoSplitProject
    analyses: tuple[WindowHarmonyAnalysis, ...]
    result: JointArrangementResult
    melody_floor_ok: bool
    voice_separation_ok: bool
    comfort_rate: float
    bass_retention_rate: float
    full_candidate_windows: int
    octave_repair_count: int
    melody_only_fallback_count: int
    severe_transition_count: int
    long_high_fret_run_count: int
    consecutive_bass_loss_max: int
    register_preservation_rank: int
    melody_average_fret: float
    melody_median_fret: float
    melody_high_fret_ratio: float
    melody_fingering_cost: float
    transpose_distance_penalty: float
    octave_shift_penalty: float
    melody_playable_ok: bool
    melody_transform_integrity_ok: bool
    eligible: bool
    rejection_reasons: tuple[str, ...]
    score: tuple[float, ...]
    physical_failure_details: tuple[dict[str, object], ...] = ()


def _transpose_track(track: TrackData, semitones: int) -> TrackData:
    def transpose(note: NoteEvent) -> NoteEvent:
        return replace(note, pitch=Pitch(note.pitch.midi + semitones, note.pitch.name))
    return replace(track, notes=[transpose(note) for note in track.notes],
        pitch_transposition_semitones=track.pitch_transposition_semitones+semitones)


def _working_project(project: PianoSplitProject, candidate: RegisterKeyCandidate) -> PianoSplitProject:
    # v0.13.3 Global Transform semantics:
    # key transposition changes the whole song; melody octave displacement is
    # a melody-register choice only.  Source accompaniment register is left for
    # the later guitar revoicing layer instead of being dragged by melody octave.
    return PianoSplitProject(
        melody=_transpose_track(project.melody, candidate.total_shift),
        left_hand=_transpose_track(project.left_hand, candidate.key_semitones),
    )



def _transpose_source_candidate_bundle(bundle, semitones: int, *, priority_semitones: int | None = None):
    """Transpose source Guitar candidate pitches with the song key only.

    Melody octave displacement is intentionally excluded, matching
    ``_working_project`` accompaniment semantics.
    """
    if not bundle:
        return None
    transformed = {}
    for window_id, variants in bundle.items():
        rows = []
        for label, notes in variants:
            shifted = tuple(
                replace(note, pitch=Pitch(note.pitch.midi + (priority_semitones if priority_semitones is not None and str(note.arrangement_role or "").startswith("melody_priority_") else semitones), note.pitch.name),
                    source_pitch_ref=replace(note.source_pitch_ref,key_shift=note.source_pitch_ref.key_shift+semitones) if note.source_pitch_ref is not None else None)
                for note in notes
            )
            rows.append((label, shifted))
        transformed[window_id] = tuple(rows)
    return transformed

def _melody_transform_integrity_ok(original: TrackData, transformed: TrackData, expected_shift: int) -> bool:
    """Hard invariant: a Global Transform may only shift pitch, never melody identity/timing."""
    if len(original.notes) != len(transformed.notes):
        return False
    for before, after in zip(original.notes, transformed.notes):
        if round(before.start, 9) != round(after.start, 9):
            return False
        if round(before.duration, 9) != round(after.duration, 9):
            return False
        if after.pitch.midi - before.pitch.midi != expected_shift:
            return False
    return True


def _melody_playable_on_fretboard(track: TrackData, tuning: Tuning) -> bool:
    opens = tuple(tuning.strings.values())
    return bool(track.notes) and all(
        any(0 <= note.pitch.midi - open_pitch <= MAX_FRET for open_pitch in opens)
        for note in track.notes
    )

def _physical_failure_details(track: TrackData, tuning: Tuning) -> tuple[dict[str, object], ...]:
    """Explain every melody event that cannot be placed on the configured fretboard.

    v0.13.4 keeps physical range as a hard invariant, but makes failures
    auditable instead of collapsing them into MELODY_NOT_FULLY_PLAYABLE.
    """
    opens = tuple(tuning.strings.values())
    lowest = min(opens)
    highest = max(opens) + MAX_FRET
    failures: list[dict[str, object]] = []
    for note in track.notes:
        candidates = [
            {"string": int(string), "fret": int(note.pitch.midi - open_pitch)}
            for string, open_pitch in tuning.strings.items()
            if 0 <= note.pitch.midi - open_pitch <= MAX_FRET
        ]
        if candidates:
            continue
        if note.pitch.midi < lowest:
            reason = "PITCH_BELOW_PHYSICAL_RANGE"
        elif note.pitch.midi > highest:
            reason = "PITCH_ABOVE_PHYSICAL_RANGE"
        else:
            reason = "NO_STRING_FRET_CANDIDATE"
        failures.append({
            "measure": note.measure,
            "start": round(float(note.start), 6),
            "duration": round(float(note.duration), 6),
            "pitch_midi": int(note.pitch.midi),
            "pitch_name": note.pitch.name,
            "source_event_id": note.source_event_id,
            "lowest_guitar_pitch_midi": int(lowest),
            "highest_guitar_pitch_midi": int(highest),
            "max_fret": int(MAX_FRET),
            "candidate_count": 0,
            "reason": reason,
        })
    return tuple(failures)


def _cheap_hard_valid(project: PianoSplitProject, candidate: RegisterKeyCandidate, tuning: Tuning) -> bool:
    """Cheap physical/integrity gate used before ergonomic pruning.

    v0.13.3.4 deliberately excludes the preferred D3 melody floor: a melody
    may be low and ergonomically undesirable while still being physically
    playable and therefore eligible for later soft-cost ranking.
    """
    working = _working_project(project, candidate)
    return (
        _melody_transform_integrity_ok(project.melody, working.melody, candidate.total_shift)
        and _melody_playable_on_fretboard(working.melody, tuning)
    )


def _route_budgets(input_route: str | None) -> tuple[int, int, int, int]:
    return (max(AUTO_FAST_PREFILTER_KEEP,SOURCE_FAST_PREFILTER_KEEP),
            max(AUTO_LIGHTWEIGHT_KEEP,SOURCE_LIGHTWEIGHT_KEEP),
            max(AUTO_FULL_SEARCH_KEEP,SOURCE_FULL_SEARCH_KEEP),
            max(SAFE_FALLBACK_FULL_EVAL_LIMIT_AUTO,SAFE_FALLBACK_FULL_EVAL_LIMIT_SOURCE))




def _cheap_rejection_evaluation(project: PianoSplitProject, candidate: RegisterKeyCandidate, tuning: Tuning) -> RegisterKeyEvaluation:
    """Create an auditable rejection without invoking Joint DP."""
    working = _working_project(project, candidate)
    playable = _melody_playable_on_fretboard(working.melody, tuning)
    integrity = _melody_transform_integrity_ok(project.melody, working.melody, candidate.total_shift)
    floor_ok = bool(working.melody.notes) and min(note.pitch.midi for note in working.melody.notes) >= MELODY_FLOOR_MIDI
    reasons: list[str] = []
    if not playable:
        reasons.append("MELODY_NOT_FULLY_PLAYABLE")
    if not integrity:
        reasons.append("MELODY_GLOBAL_TRANSFORM_INTEGRITY_FAILED")
    result = JointArrangementResult(selected=(), candidate_layers=(), total_cost=float("inf"), warnings=(), diagnostics=())
    return RegisterKeyEvaluation(
        candidate=candidate, project=working, analyses=(), result=result, melody_floor_ok=floor_ok,
        voice_separation_ok=True, comfort_rate=0.0, bass_retention_rate=0.0, full_candidate_windows=0,
        octave_repair_count=0, melody_only_fallback_count=0, severe_transition_count=0,
        long_high_fret_run_count=0, consecutive_bass_loss_max=0, register_preservation_rank=0 if candidate.octave_shift == 0 else 1,
        melody_average_fret=99.0, melody_median_fret=99.0, melody_high_fret_ratio=1.0, melody_fingering_cost=float("inf"),
        transpose_distance_penalty=_tonal_color_cost(candidate.key_semitones) * 1.5,
        octave_shift_penalty=0.0 if candidate.octave_shift == 0 else 30.0, melody_playable_ok=playable,
        melody_transform_integrity_ok=integrity, eligible=False, rejection_reasons=tuple(reasons or ["MELODY_HARD_GATE_FAILED"]),
        score=(1.0, float("inf")), physical_failure_details=_physical_failure_details(working.melody, tuning),
    )

class NoValidGlobalTransformError(ValueError):
    """Raised when every fully evaluated Global Transform violates a melody hard gate."""

    def __init__(self, evaluations: tuple["RegisterKeyEvaluation", ...]):
        self.evaluations = evaluations
        super().__init__("NO_VALID_GLOBAL_TRANSFORM")


def register_key_candidates() -> tuple[RegisterKeyCandidate, ...]:
    """Ordered nearby keys × original/lower octave, including the user-requested set."""
    candidates = []
    for semitones in (0, -1, 1, -2, 2, -3, 3, -4, 4, -5, 5):
        for octave in (0, -12):
            key = "Original key" if semitones == 0 else f"Key {semitones:+d} semitone(s)"
            register = "original register" if octave == 0 else "whole song -1 octave"
            candidates.append(RegisterKeyCandidate(semitones, octave, f"{key}; {register}"))
    return tuple(candidates)



def _estimated_comfort_rate(project: PianoSplitProject, candidate: RegisterKeyCandidate, tuning: Tuning) -> float:
    """Cheap melody-only fret estimate used before any harmony/DP work."""
    if not project.melody.notes:
        return 0.0
    opens = tuple(tuning.strings.values())
    comfortable = 0
    playable = 0
    for note in project.melody.notes:
        midi = note.pitch.midi + candidate.total_shift
        frets = [midi - open_pitch for open_pitch in opens if 0 <= midi - open_pitch <= MAX_FRET]
        if frets:
            playable += 1
            if min(frets) <= 7:
                comfortable += 1
    return comfortable / len(project.melody.notes)


def _fast_prefilter_score(project: PianoSplitProject, candidate: RegisterKeyCandidate, tuning: Tuning) -> tuple[float, ...]:
    working = _working_project(project, candidate)
    windows = build_fixed_harmony_windows(working, quarters_per_window=2.0)
    low = min(tuning.strings.values())
    high = max(tuning.strings.values()) + MAX_FRET
    pitches = [note.pitch.midi for note in working.melody.notes]
    out_of_range = sum(pitch < low or pitch > high for pitch in pitches)
    preferred_floor_penalty = 0.0 if pitches and min(pitches) >= MELODY_FLOOR_MIDI else 18.0
    separated = _voice_separation(windows)
    comfort = _estimated_comfort_rate(project, candidate, tuning)
    register_rank = 0 if candidate.octave_shift == 0 else 1
    # Only true physical out-of-range is lexical here. Preferred register,
    # voice separation and comfort are soft ranking signals.
    soft = (
        preferred_floor_penalty
        + (0.0 if separated else 8.0)
        + 30.0 * (1.0 - comfort)
        + _tonal_color_cost(candidate.key_semitones)
        + 12.0 * register_rank
    )
    return (
        float(out_of_range),
        soft,
        float(abs(candidate.key_semitones)),
        float(abs(candidate.octave_shift)),
    )


def prefilter_register_key_candidates(
    project: PianoSplitProject, *, tuning: Tuning = STANDARD_TUNING, keep: int = FAST_PREFILTER_KEEP
) -> tuple[RegisterKeyCandidate, ...]:
    """Keep mandatory original-key baselines plus the best cheap candidates."""
    from gste.editor.session import constrain_editor_transforms
    all_candidates = constrain_editor_transforms(register_key_candidates())
    hard_valid = [candidate for candidate in all_candidates if _cheap_hard_valid(project, candidate, tuning)]
    mandatory = [candidate for candidate in hard_valid if candidate.key_semitones == 0]
    ordered = sorted(hard_valid, key=lambda candidate: _fast_prefilter_score(project, candidate, tuning))
    selected: list[RegisterKeyCandidate] = []
    for candidate in mandatory + ordered:
        if candidate not in selected:
            selected.append(candidate)
        if len(selected) >= max(keep, len(mandatory)):
            break
    return tuple(selected)

def _tonal_color_cost(semitones: int) -> float:
    # Semitone distance dominates; circle-of-fifths adjacency breaks equal-distance ties.
    fifth_distance = min((7 * abs(semitones)) % 12, (-7 * abs(semitones)) % 12)
    return float(abs(semitones) * 10 + fifth_distance)


def _voice_separation(windows) -> bool:
    for window in windows:
        if window.melody_notes and window.accompaniment_notes:
            if min(note.pitch.midi for note in window.melody_notes) <= max(note.pitch.midi for note in window.accompaniment_notes):
                return False
    return True


def _evaluate(project: PianoSplitProject, candidate: RegisterKeyCandidate, *, tuning: Tuning, quarters_per_window: float,
              chord_top_k: int, melody_paths_per_window: int, accompaniment_per_chord: int,
              joint_candidates_per_window: int, max_candidates_per_note: int, source_candidate_bundle=None) -> RegisterKeyEvaluation:
    working = _working_project(project, candidate)
    # v0.13.5.12.7.1.1: Global/phrase planning locks melody identity but does
    # NOT decide whether a complete guitar fingering path exists.  At this
    # stage we only require per-note exact-pitch fretboard reachability.  The
    # complete path, transition feasibility and accompaniment coexistence are
    # the responsibility of Fingering Path / Joint.
    if not _melody_playable_on_fretboard(working.melody, tuning):
        rejected = _cheap_rejection_evaluation(project, candidate, tuning)
        return replace(rejected, rejection_reasons=(*rejected.rejection_reasons, "MELODY_EXACT_PITCH_OUT_OF_RANGE"))
    windows = build_fixed_harmony_windows(working, quarters_per_window=quarters_per_window)
    analyses = tuple(analyze_harmony_windows(windows, top_k=chord_top_k))
    transformed_bundle = _transpose_source_candidate_bundle(source_candidate_bundle, candidate.key_semitones)
    result = optimize_joint_arrangement( list(analyses), tuning=tuning, melody_paths_per_window=melody_paths_per_window,
        accompaniment_per_chord=accompaniment_per_chord, joint_candidates_per_window=joint_candidates_per_window,
        max_candidates_per_note=max_candidates_per_note, source_candidate_bundle=transformed_bundle)
    melody_floor_ok = bool(working.melody.notes) and min(note.pitch.midi for note in working.melody.notes) >= MELODY_FLOOR_MIDI
    separated = _voice_separation(windows)
    selected = result.selected
    melody_fingerings = [note for state in selected for note in state.melody.notes]
    comfort_rate = (sum(note.fret <= 7 for note in melody_fingerings) / len(melody_fingerings)) if melody_fingerings else 0.0
    source_bass_windows = sum(bool(analysis.window.accompaniment_notes) for analysis in analyses)
    bass_windows = sum(bool(state.accompaniment.notes) for state in selected)
    bass_rate = bass_windows / source_bass_windows if source_bass_windows else 1.0
    full = sum(state.simplification_level == 0 for state in selected)
    octave_repairs = sum(
        "->" in item
        for diagnostic in result.diagnostics
        for item in diagnostic.removed_notes
    )
    total_windows = len(selected)
    full_rate = full / total_windows if total_windows else 0.0
    melody_only = sum(state.simplification_level >= 4 or not state.accompaniment.notes for state in selected)
    severe_transitions = sum(
        float(state.transition_breakdown.get("position_distance", 0.0)) > LARGE_POSITION_MOVE_THRESHOLD
        for state in selected[1:]
    )
    longest_high_run = current_high_run = 0
    longest_bass_loss = current_bass_loss = 0
    for analysis, state in zip(analyses, selected):
        high_window = any(note.fret > HIGH_FRET_THRESHOLD for note in state.melody.notes)
        current_high_run = current_high_run + 1 if high_window else 0
        longest_high_run = max(longest_high_run, current_high_run)
        bass_lost = bool(analysis.window.accompaniment_notes) and not bool(state.accompaniment.notes)
        current_bass_loss = current_bass_loss + 1 if bass_lost else 0
        longest_bass_loss = max(longest_bass_loss, current_bass_loss)
    melody_frets = [note.fret for note in melody_fingerings]
    melody_average_fret = (sum(melody_frets) / len(melody_frets)) if melody_frets else 99.0
    sorted_frets = sorted(melody_frets)
    melody_median_fret = (sorted_frets[len(sorted_frets)//2] if sorted_frets else 99.0)
    melody_high_fret_ratio = (sum(fret > HIGH_FRET_THRESHOLD for fret in melody_frets) / len(melody_frets)) if melody_frets else 1.0
    melody_fingering_cost = sum(float(state.melody.local_cost) for state in selected)
    transpose_distance_penalty = _tonal_color_cost(candidate.key_semitones) * 1.5
    octave_shift_penalty = 0.0 if candidate.octave_shift == 0 else 30.0
    register_rank = 0 if (not REGISTER_PRESERVATION_ENABLED or candidate.octave_shift == 0) else 1
    melody_playable_ok = _melody_playable_on_fretboard(working.melody, tuning)
    melody_transform_integrity_ok = _melody_transform_integrity_ok(
        project.melody, working.melody, candidate.total_shift
    )
    rejection_reasons: list[str] = []
    # v0.13.5.12.10.1: Global Transform eligibility is only melody identity/time
    # + exact-pitch fretboard reachability.  Whether Joint/Fingering finds a
    # complete path belongs to the Fingering layer and must not invalidate a
    # key/register transform here.
    if octave_repairs != 0:
        rejection_reasons.append("MELODY_REQUIRED_LOCAL_OCTAVE_REPAIR")
    if not melody_playable_ok:
        rejection_reasons.append("MELODY_NOT_FULLY_PLAYABLE")
    if not melody_transform_integrity_ok:
        rejection_reasons.append("MELODY_GLOBAL_TRANSFORM_INTEGRITY_FAILED")
    # v0.13.3.1: eligibility is a true hard gate.  Invalid transforms are never
    # allowed to win later simply because their ergonomic soft score is low.
    eligible = not rejection_reasons
    # v0.13.3.1: melody-first Global Transform score.  Original key/register are
    # soft costs, not hard lexical winners.  Accompaniment metrics only break
    # ties after melody playability/fingering quality.
    score = (
        0.0 if eligible else (1.0 if selected else 2.0),
        melody_fingering_cost + transpose_distance_penalty + octave_shift_penalty
        + (18.0 if not melody_floor_ok else 0.0)
        + (25.0 * melody_high_fret_ratio) + (20.0 * (1.0 - comfort_rate)) + (10.0 * severe_transitions),
        float(severe_transitions),
        melody_high_fret_ratio,
        -comfort_rate,
        transpose_distance_penalty,
        octave_shift_penalty,
        -bass_rate,
        -float(full),
        float(melody_only),
        float(longest_bass_loss),
        result.total_cost,
        float(candidate.key_semitones),
    )
    return RegisterKeyEvaluation(
        candidate, working, analyses, result, melody_floor_ok, separated, comfort_rate, bass_rate, full, octave_repairs,
        melody_only, severe_transitions, longest_high_run, longest_bass_loss, register_rank,
        melody_average_fret, melody_median_fret, melody_high_fret_ratio, melody_fingering_cost,
        transpose_distance_penalty, octave_shift_penalty, melody_playable_ok,
        melody_transform_integrity_ok, eligible, tuple(rejection_reasons), score,
        _physical_failure_details(working.melody, tuning)
    )


def is_complex_source_piano(project: PianoSplitProject, *, quarters_per_window: float = 2.0, input_route: str | None = "SOURCE_PIANO") -> bool:
    """Cheap route-specific complexity classification shared by search and orchestration."""
    melody_notes = list(getattr(getattr(project, "melody", None), "notes", ()) or ())
    accompaniment_notes = list(getattr(getattr(project, "left_hand", None), "notes", ()) or ())
    approximate_windows = max(1, int(max([n.start + n.duration for n in melody_notes] + [0.0]) / max(quarters_per_window, 0.25)))
    attack_counts: dict[float, int] = {}
    for note in accompaniment_notes:
        key = round(note.start, 6)
        attack_counts[key] = attack_counts.get(key, 0) + 1
    max_simultaneous = max(attack_counts.values(), default=0)
    return (
        len(melody_notes) >= COMPLEX_PIANO_MELODY_NOTES
        or approximate_windows >= COMPLEX_PIANO_WINDOWS
        or len(accompaniment_notes) >= COMPLEX_PIANO_ACCOMPANIMENT_NOTES
        or max_simultaneous >= COMPLEX_PIANO_MAX_SIMULTANEOUS_NOTES
    )


def _transform_only_evaluation(
    project: PianoSplitProject,
    candidate: RegisterKeyCandidate,
    *,
    tuning: Tuning,
    quarters_per_window: float,
    chord_top_k: int,
) -> RegisterKeyEvaluation:
    """Evaluate key/register without asking the Fingering layer for a path."""
    working = _working_project(project, candidate)
    playable = _melody_playable_on_fretboard(working.melody, tuning)
    integrity = _melody_transform_integrity_ok(project.melody, working.melody, candidate.total_shift)
    windows = build_fixed_harmony_windows(working, quarters_per_window=quarters_per_window)
    analyses = tuple(analyze_harmony_windows(windows, top_k=chord_top_k))
    pitches = [n.pitch.midi for n in working.melody.notes]
    melody_floor_ok = bool(pitches) and min(pitches) >= MELODY_FLOOR_MIDI
    separated = _voice_separation(windows)

    opens = tuple(tuning.strings.values())
    best_frets = []
    for note in working.melody.notes:
        frets = [note.pitch.midi - open_pitch for open_pitch in opens if 0 <= note.pitch.midi - open_pitch <= MAX_FRET]
        if frets:
            best_frets.append(min(frets))
    comfort_rate = (sum(f <= 7 for f in best_frets) / len(best_frets)) if best_frets else 0.0
    melody_average_fret = (sum(best_frets) / len(best_frets)) if best_frets else 99.0
    ordered = sorted(best_frets)
    melody_median_fret = ordered[len(ordered)//2] if ordered else 99.0
    melody_high_fret_ratio = (sum(f > HIGH_FRET_THRESHOLD for f in best_frets) / len(best_frets)) if best_frets else 1.0
    transpose_distance_penalty = _tonal_color_cost(candidate.key_semitones) * 1.5
    octave_shift_penalty = 0.0 if candidate.octave_shift == 0 else 30.0
    register_rank = 0 if (not REGISTER_PRESERVATION_ENABLED or candidate.octave_shift == 0) else 1
    reasons = []
    if not playable:
        reasons.append('MELODY_NOT_FULLY_PLAYABLE')
    if not integrity:
        reasons.append('MELODY_GLOBAL_TRANSFORM_INTEGRITY_FAILED')
    eligible = not reasons
    soft = (
        transpose_distance_penalty + octave_shift_penalty
        + (18.0 if not melody_floor_ok else 0.0)
        + 25.0 * melody_high_fret_ratio
        + 20.0 * (1.0 - comfort_rate)
        + (8.0 if not separated else 0.0)
    )
    empty_result = JointArrangementResult(selected=(), candidate_layers=(), total_cost=0.0, warnings=(), diagnostics=())
    return RegisterKeyEvaluation(
        candidate=candidate, project=working, analyses=analyses, result=empty_result,
        melody_floor_ok=melody_floor_ok, voice_separation_ok=separated,
        comfort_rate=comfort_rate, bass_retention_rate=1.0, full_candidate_windows=0,
        octave_repair_count=0, melody_only_fallback_count=0, severe_transition_count=0,
        long_high_fret_run_count=0, consecutive_bass_loss_max=0,
        register_preservation_rank=register_rank, melody_average_fret=melody_average_fret,
        melody_median_fret=melody_median_fret, melody_high_fret_ratio=melody_high_fret_ratio,
        melody_fingering_cost=0.0, transpose_distance_penalty=transpose_distance_penalty,
        octave_shift_penalty=octave_shift_penalty, melody_playable_ok=playable,
        melody_transform_integrity_ok=integrity, eligible=eligible,
        rejection_reasons=tuple(reasons),
        score=(0.0 if eligible else 1.0, soft, float(abs(candidate.key_semitones)), float(abs(candidate.octave_shift))),
        physical_failure_details=_physical_failure_details(working.melody, tuning),
    )


def optimize_register_and_key(project: PianoSplitProject, *, tuning: Tuning = STANDARD_TUNING, quarters_per_window: float = 2.0,
                              chord_top_k: int = 3, melody_paths_per_window: int = 6, accompaniment_per_chord: int = 4,
                              joint_candidates_per_window: int = 24, max_candidates_per_note: int = 5,
                              input_route: str | None = None, source_candidate_bundle=None) -> tuple[RegisterKeyEvaluation, tuple[RegisterKeyEvaluation, ...]]:
    """v0.13.5.12.10.1 transform-only search.

    Global Transform owns only key/register selection.  It never calls Joint DP
    and never decides whether a complete fingering path exists.  Hard validity
    here is limited to whole-melody timing/identity preservation and exact-pitch
    fretboard reachability.  The selected transform is realized exactly once by
    ``run_fingering_for_selected_transform``.
    """
    from gste.editor.session import constrain_editor_transforms
    all_candidates = constrain_editor_transforms(register_key_candidates())
    hard_valid = [c for c in all_candidates if _cheap_hard_valid(project, c, tuning)]
    if not hard_valid:
        rejected = tuple(_cheap_rejection_evaluation(project, c, tuning) for c in all_candidates)
        raise NoValidGlobalTransformError(rejected)

    # Keep the old bounded candidate philosophy, but ranking is now cheap and
    # independent of Fingering/Joint outcomes.
    ordered = sorted(hard_valid, key=lambda c: _fast_prefilter_score(project, c, tuning))
    keep = max(AUTO_FAST_PREFILTER_KEEP,SOURCE_FAST_PREFILTER_KEEP)
    candidates = ordered[:max(1, keep)]
    evaluations = tuple(
        _transform_only_evaluation(
            project, c, tuning=tuning, quarters_per_window=quarters_per_window, chord_top_k=chord_top_k
        ) for c in candidates
    )
    eligible = tuple(e for e in evaluations if e.eligible)
    if not eligible:
        raise NoValidGlobalTransformError(evaluations)

    best_soft = min(e.score[1] for e in eligible)
    near_best = tuple(e for e in eligible if e.score[1] <= best_soft + TRANSFORM_EQUIVALENCE_MARGIN)
    selected = min(
        near_best,
        key=lambda e: (abs(e.candidate.key_semitones), abs(e.candidate.octave_shift)//12, e.score),
    )
    return selected, evaluations


def run_fingering_for_selected_transform(
    evaluation: RegisterKeyEvaluation,
    *,
    tuning: Tuning = STANDARD_TUNING,
    melody_paths_per_window: int = 6,
    accompaniment_per_chord: int = 4,
    joint_candidates_per_window: int = 24,
    max_candidates_per_note: int = 5,
    source_candidate_bundle=None,
    melody_backbone=None,
) -> RegisterKeyEvaluation:
    """Run the real Fingering/Joint search only after Global Transform selection.

    v0.13.5.12.10.1 responsibility boundary:
    Global Transform decides key/register using melody identity/range + soft
    ranking.  This function is the layer that decides whether the selected
    transform can actually be realized on guitar.  It deliberately uses the
    caller's full Fingering search budget instead of the transform-ranking beam.
    """
    transformed_bundle = _transpose_source_candidate_bundle(
        source_candidate_bundle, evaluation.candidate.key_semitones,
        priority_semitones=evaluation.candidate.total_shift,
    )
    from gste.editor.session import constrain_joint_harmony
    analyses = constrain_joint_harmony(evaluation.analyses, evaluation.candidate.key_semitones)
    result = optimize_joint_arrangement(
        list(analyses),
        tuning=tuning,
        melody_paths_per_window=melody_paths_per_window,
        accompaniment_per_chord=accompaniment_per_chord,
        joint_candidates_per_window=joint_candidates_per_window,
        max_candidates_per_note=max_candidates_per_note,
        source_candidate_bundle=transformed_bundle,
        melody_backbone=melody_backbone,
    )
    return replace(evaluation, result=result, analyses=analyses)
