from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
import secrets
import shutil
import tempfile
from typing import Literal

from gste.conversion_core import ConvertMode, convert_score

StringMode = Literal["high_3", "high_4", "all_6"]


@dataclass(frozen=True)
class DemoResult:
    """Files and user-facing summary returned by the public demo adapter."""

    run_id: str
    report_path: Path
    tab_path: Path
    summary: str


def _make_run_id() -> str:
    date_part = datetime.now().strftime("%Y%m%d")
    return f"GSTE-{date_part}-{secrets.token_hex(2).upper()}"


def run_demo_conversion(
    input_path: str | Path,
    *,
    tuning_name: str = "standard",
    max_candidates: int = 5,
    auto_shift: bool = True,
    mode: ConvertMode = "auto",
    output_root: str | Path | None = None,
) -> DemoResult:
    """Run one stateless conversion for CLI/web callers.

    The caller supplies a temporary uploaded file. Results are copied to a
    run-specific directory, which keeps filenames deterministic for feedback
    while avoiding a database or permanent upload store.
    """

    source = Path(input_path)
    if not source.exists() or not source.is_file():
        raise FileNotFoundError(f"Input score not found: {source}")
    if source.suffix.lower() not in {".xml", ".musicxml"}:
        raise ValueError("Only .xml and .musicxml files are supported in this demo.")
    if not 1 <= max_candidates <= 8:
        raise ValueError("max_candidates must be between 1 and 8.")

    run_id = _make_run_id()
    if output_root is None:
        base_dir = Path(tempfile.mkdtemp(prefix="gste_demo_"))
    else:
        base_dir = Path(output_root)
        base_dir.mkdir(parents=True, exist_ok=True)

    run_dir = base_dir / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    staged_input = run_dir / f"{run_id}{source.suffix.lower()}"
    shutil.copy2(source, staged_input)

    report_path, tab_path = convert_score(
        staged_input,
        output_dir=run_dir,
        auto_shift=auto_shift,
        mode=mode,
        tuning_name=tuning_name,
        max_candidates=max_candidates,
        keep_candidates=True,
    )

    final_report = run_dir / f"{run_id}-report.md"
    final_tab = run_dir / f"{run_id}-tab.musicxml"
    report_path.replace(final_report)
    tab_path.replace(final_tab)

    report_text = final_report.read_text(encoding="utf-8")
    warning_count = report_text.count("WARNING") + report_text.count("Warning")
    summary = (
        f"## Processing complete\n\n"
        f"- Test ID: `{run_id}`\n"
        f"- Input mode: `{mode}`\n"
        f"- Tuning: `{tuning_name}`\n"
        f"- Maximum candidates per note: `{max_candidates}`\n"
        f"- Warning markers in report: `{warning_count}`\n\n"
        "Download the MusicXML and open it in MuseScore for playback and playability review."
    )
    return DemoResult(run_id, final_report, final_tab, summary)
