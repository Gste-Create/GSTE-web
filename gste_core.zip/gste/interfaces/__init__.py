"""Stable application-facing interfaces for CLI, web demos, and future UIs."""

from gste.interfaces.demo_service import DemoResult, run_demo_conversion

__all__ = ["DemoResult", "run_demo_conversion"]
