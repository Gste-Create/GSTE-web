"""Read-only user report projection; never infers a musical cause."""
from pathlib import Path
import json,re,xml.etree.ElementTree as ET
from gste.version import VERSION

def load(p):
    try:return json.loads(p.read_text(encoding='utf-8'))
    except (OSError,ValueError):return {}

def initialize_locations(run,source):
    run=Path(run);d=run/'debug';d.mkdir(parents=True,exist_ok=True)
    try:
        ms=ET.parse(source).getroot().findall('./part/measure')
        labels=[m.get('number',str(i)) for i,m in enumerate(ms,1)]
        (d/'MEASURE_LOCATION_MAP.json').write_text(json.dumps({'labels':labels},ensure_ascii=False),encoding='utf-8')
    except (OSError,ET.ParseError):pass

def _failure_locations(data, stage, msg):
    """Read-only, non-musical location projection; never infer a failing note."""
    results = []
    seen = set()
    def add(measure, reason, evidence, beat=None):
        if measure is None or isinstance(measure, bool):
            return
        try:
            m = int(measure)
        except (TypeError, ValueError):
            return
        if m < 1:
            return
        item = (m, str(reason), evidence, beat)
        if item not in seen:
            seen.add(item)
            results.append(item)
    transform = data('07_GLOBAL_TRANSFORM_SEARCH.json')
    if transform.get('status') == 'NO_VALID_GLOBAL_TRANSFORM' and ('GLOBAL_TRANSFORM' in str(stage) or 'NO_VALID_GLOBAL_TRANSFORM' in str(msg)):
        for candidate in transform.get('candidates', []):
            for item in candidate.get('physical_failure_details', []):
                if isinstance(item, dict) and item.get('reason') in ('PITCH_BELOW_PHYSICAL_RANGE', 'PITCH_ABOVE_PHYSICAL_RANGE', 'NO_STRING_FRET_CANDIDATE'):
                    add(item.get('measure'), item['reason'], '07_GLOBAL_TRANSFORM_SEARCH.json')
    # Only use explicitly recorded failure/issue locations, not all lifecycle events.
    for filename, key in [('04_FINAL_FINGERING_REVIEW.json', 'issues')]:
        obj = data(filename)
        for item in obj.get(key, []) if isinstance(obj, dict) else []:
            if not isinstance(item, dict):
                continue
            loc = item.get('location', item)
            if isinstance(loc, dict) and loc.get('measure') is not None:
                add(loc['measure'], item.get('issue') or item.get('code') or 'FINGERING_REVIEW_ISSUE', filename, loc.get('beat'))
    return results

def write_user_reports(run,*,success,detail=None):
    run=Path(run);files=sorted((run/'debug').rglob('*.json'))
    def find(name):return next((p for p in files if p.name==name),None)
    def data(name):
        p=find(name);return load(p) if p else {}
    labels=data('MEASURE_LOCATION_MAP.json').get('labels',[])
    if not labels:
        tracks=data('ORIGINAL_SOURCE_TRACKS.json')
        if isinstance(tracks,list) and tracks:
            lab=tracks[0].get('measure_display_labels',{});labels=[lab[k] for k in sorted(lab,key=lambda x:int(x))]
    def location(m,beat=None,original=False):
        text=str(m);idx=None
        if original:
            if text in list(map(str,labels)):idx=list(map(str,labels)).index(text)+1
            orig=text
        else:
            try:idx=int(m);orig=str(labels[idx-1]) if 0<idx<=len(labels) else '未提供'
            except (ValueError,TypeError):orig='未提供'
        return f'原譜小節 {orig}／選段第 {idx if idx is not None else "未提供"} 小節／拍點 {beat if beat is not None else "未提供"}'
    for name, key in [('04_FINAL_FINGERING_REVIEW.json', 'issues'), ('22_GPT_HUMAN_REVIEW_PACKET.json', 'review_queue'), ('25_MELODY_IDENTITY_LIFECYCLE.json', 'events')]:
        target = find(name)
        if target is None:
            continue
        obj = load(target)
        for row in obj.get(key, []):
            loc = row.get('location', row)
            if isinstance(loc, dict):
                row['display_location'] = location(loc.get('measure'), loc.get('beat'))
        target.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')
    (run/'MEASURE_LOCATION_GUIDE.md').write_text(
        '# 小節定位對照\n\n| 原譜小節 | 選段序號 |\n|---|---:|\n' +
        '\n'.join(f'| {label} | {i} |' for i,label in enumerate(labels,1)), encoding='utf-8')
    # Normalize display headings, without altering diagnostic numeric fields.
    for p in (run/'debug').rglob('*.md'):
        txt=p.read_text(encoding='utf-8');txt=txt.replace('GSTE_Beta_V0.1.3',f'GSTE {VERSION}').replace('GSTE Beta V0.1.3',f'GSTE {VERSION}')
        txt=re.sub(r'Measure (\d+), beat ([\d.]+)',lambda m:location(m[1],m[2]),txt)
        p.write_text(txt,encoding='utf-8')
    pipeline=data('PIPELINE_DIAGNOSTICS.json');failure=pipeline.get('failure') or {};stage=failure.get('stage','未提供')
    msg=failure.get('message') or detail or '未提供錯誤細節'
    sanity=data('22_MUSICXML_STRUCTURAL_SANITY_PRE_WRITE.json')
    errors=sanity.get('errors',[]) if sanity.get('status')=='FAIL' else []
    code=errors[0].get('code') if errors else (re.search(r'\b[A-Z][A-Z_]{4,}\b',msg).group() if re.search(r'\b[A-Z][A-Z_]{4,}\b',msg) else '未提供')
    causes={'UNSPELLABLE_NOTATED_DURATION':'部分時值元素缺少可辨識的記譜方式','NOTATED_DURATION_MISMATCH':'記譜時值與 duration 不一致'}
    lines=[f'# GSTE {VERSION} 轉換報告','',f'轉換結果：{f"成功" if success else "失敗"}']
    if not success:
        lines += [f'失敗階段：{"最終樂譜輸出／寫檔前結構檢查" if errors else stage}',f'直接原因：{causes.get(code,msg)}',f'錯誤代碼：{code}','','影響範圍：']
        parts=set()
        for e in errors:
            m=re.search(r'/part\[(.*?)\]/measure\[(.*?)\]/note\[(.*?)\]',e.get('path',''))
            if m:parts.add(m[1]);lines.append(f'- {location(m[2],original=True)}；譜表 {m[1]}、元素 {m[3]}：`{e.get("code")}`')
        if errors:lines.append(f'- {len(parts)} 個輸出譜表，共 {len(errors)} 筆。')
        else:
            locations = _failure_locations(data, stage, msg)
            if locations:
                for measure, reason, evidence_name, beat in locations[:30]:
                    lines.append(f'- {location(measure,beat)}；診斷代碼 `{reason}`；證據 `{evidence_name}`')
                if len(locations) > 30:
                    lines.append(f'- 另有 {len(locations)-30} 筆定位，請參閱證據檔案。')
                lines.append('- 上述為診斷記錄的位置，不代表已確認唯一根因；跨小節手型衝突可能涉及前後小節。')
            else:
                lines.append('- 診斷未提供可驗證的小節定位；不從錯誤訊息猜測。')
        completed=[k for k,v in pipeline.get('stages',{}).items() if v.get('status')=='PASS']
        pending=[k for k,v in pipeline.get('stages',{}).items() if v.get('status') in ('FAILED','NOT_REACHED')]
        names={'COMMON_TIMELINE':'時間軸對齊','FINGERING_PATH_SEARCH':'指法搜尋','FINAL_FINGERING_REVIEW':'最終物理檢查','FINAL_EXPORT':'最終樂譜輸出','POST_EXPORT_MONITORING':'輸出後驗證'}
        lines+=['','已完成：','、'.join(names.get(k,k) for k in completed) or '未提供','','尚未完成：','、'.join(names.get(k,k) for k in pending) or '未提供','','詳細證據：']
        evidence=find('22_MUSICXML_STRUCTURAL_SANITY_PRE_WRITE.json') if errors else find('PIPELINE_DIAGNOSTICS.json')
        if evidence:lines.append(f'- [{evidence.name}]({evidence.relative_to(run).as_posix()})')
        lines+=['',f'原始錯誤：`{msg}`','詳細呼叫位置：`debug/ERROR_TRACEBACK.txt`']
        (run/'ERROR_REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    else:
        lines+=['','最終樂譜：`GSTE_TAB.musicxml`','人工檢查引導：`HUMAN_REVIEW_REPORT.md`']
        (run/'CONVERSION_REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    review=[f'# GSTE {VERSION} 人工檢查引導','','僅列診斷已記錄的位置與代碼；提醒不等於確認錯誤。','','| 定位 | 記錄 | 證據檔案 |','|---|---|---|']
    seen=set()
    for name,key in [('04_FINAL_FINGERING_REVIEW.json','issues'),('22_GPT_HUMAN_REVIEW_PACKET.json','review_queue'),('25_MELODY_IDENTITY_LIFECYCLE.json','events')]:
        p=find(name)
        if not p:continue
        for row in data(name).get(key,[]):
            if key=='events' and row.get('status')=='RETAINED':continue
            loc=row.get('location',row);loc=loc if isinstance(loc,dict) else {}
            m=loc.get('measure');beat=loc.get('beat');tag=row.get('issue') or row.get('category') or row.get('status','未提供')
            item=(str(m),str(beat),tag,name)
            if item in seen:continue
            seen.add(item);review.append(f'| {location(m,beat)} | `{tag}`／{row.get("status", "診斷標記")} | [{name}]({p.relative_to(run).as_posix()}) |')
    if not seen:review.append('| 未記錄定位項目 | 不代表音樂性已由人工確認 | GSTE_TAB.musicxml |')
    identity=data('25_MELODY_IDENTITY_LIFECYCLE.json')
    if identity and identity.get('expected_count')==0:review+=['','主旋律優先事件生命週期：本項沒有可核對事件，不能據此宣稱主旋律完整保留。']
    review+=['','拍點沿用診斷檔的計數單位；缺少欄位時顯示未提供，不從音樂內容推測。']
    (run/'HUMAN_REVIEW_REPORT.md').write_text('\n'.join(review)+'\n',encoding='utf-8')
