from __future__ import annotations

from collections import defaultdict
from collections.abc import Sequence

from gste.melody.models import PositionPlan, PositionPlanStep, PositionZoneCandidate, ShiftMode


def _shift_mode(previous: int | None, current: int, boundary: float) -> ShiftMode:
    if previous is None or previous == current:
        return ShiftMode.STAY
    distance = abs(current - previous)
    if boundary >= 0.65:
        return ShiftMode.BOUNDARY_SHIFT
    if distance == 1:
        return ShiftMode.CONTINUOUS_TRANSLATION
    return ShiftMode.FORCED_SHIFT


def build_position_plans(
    zones: Sequence[PositionZoneCandidate],
    structure_signals: Sequence[object],
    *,
    top_k: int = 3,
    beam_width: int = 12,
) -> list[PositionPlan]:
    """Beam-search coarse position paths; does not call or alter fingering DP."""
    grouped: dict[str, list[PositionZoneCandidate]] = defaultdict(list)
    order: list[str] = []
    for zone in zones:
        if zone.segment_id not in grouped:
            order.append(zone.segment_id)
        grouped[zone.segment_id].append(zone)

    signals_by_start = {round(float(sig.start), 6): sig for sig in structure_signals}
    beam: list[tuple[float, tuple[PositionPlanStep, ...]]] = [(0.0, tuple())]

    for segment_id in order:
        segment_zones = grouped[segment_id]
        next_beam: list[tuple[float, tuple[PositionPlanStep, ...]]] = []
        for accumulated, steps in beam:
            previous = steps[-1].position_block if steps else None
            for zone in segment_zones:
                signal = signals_by_start.get(round(zone.start, 6))
                boundary = float(getattr(signal, "position_change_suitability", 0.5))
                mode = _shift_mode(previous, zone.position_block, boundary)
                shift_distance = 0 if previous is None else abs(zone.position_block - previous)
                transition = shift_distance * (1.0 - 0.6 * boundary)
                if mode == ShiftMode.CONTINUOUS_TRANSLATION:
                    transition *= 0.65
                elif mode == ShiftMode.FORCED_SHIFT:
                    transition += 1.5
                incomplete_penalty = 0.0 if zone.melody_complete else 1000.0
                local = zone.estimated_difficulty + transition + incomplete_penalty
                step = PositionPlanStep(
                    segment_id=zone.segment_id,
                    start=zone.start,
                    duration=zone.duration,
                    position_block=zone.position_block,
                    shift_mode=mode,
                    local_cost=round(local, 6),
                    boundary_suitability=round(boundary, 6),
                    melody_complete=zone.melody_complete,
                )
                next_beam.append((accumulated + local, steps + (step,)))
        next_beam.sort(key=lambda item: item[0])
        beam = next_beam[:beam_width]

    plans: list[PositionPlan] = []
    for index, (cost, steps) in enumerate(beam[:top_k], start=1):
        complete = all(step.melody_complete for step in steps)
        plans.append(
            PositionPlan(
                plan_id=f"position_plan_{index}",
                steps=steps,
                total_cost=round(cost, 6),
                melody_complete=complete,
                playable=complete,
            )
        )
    return plans
