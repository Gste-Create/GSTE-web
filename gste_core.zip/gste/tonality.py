"""Shared melody-based tonality analysis for AUTO, Piano and Group.

Input key signatures are facts; missing/unsupported modes never become a
major-key declaration. Source accompaniment and generated chords are not
inference evidence in this phase. This module does not parse XML or mutate music.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass, replace
from math import exp
from pathlib import Path
import json
from gste.core.models import NoteEvent
from gste.input.project_models import TrackData, KeySignatureChange
from gste.structure import metric

_NAMES = ("C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B")
_SCALES = (("major", (0,2,4,5,7,9,11)), ("minor", (0,2,3,5,7,8,10)))


@dataclass(frozen=True)
class KeyCandidate:
    tonic: int
    mode: str
    name: str
    score: float
    confidence: float = 0.0
    source: str = "melody_analysis"
    warnings: tuple[str, ...] = ()
    scale_fit: float = 0.0
    tonic_support: float = 0.0
    dominant_support: float = 0.0
    declaration_bonus: float = 0.0
    reasons: tuple[str, ...] = ()


@dataclass(frozen=True)
class TonalityAnalysis:
    candidates: tuple[KeyCandidate, ...]
    input_key_signatures: tuple[KeySignatureChange, ...]
    declared_key: tuple[int, str] | None
    mode_status: str
    weighted_pitch_classes: tuple[float, ...]
    evidence_track_id: str
    evidence_note_count: int
    pitch_transposition_semitones: int
    score_gap: float | None
    warnings: tuple[str, ...] = ()
    evidence_scope: str = "INPUT_MELODY_NOTES_ONLY"
    confidence_semantics: str = "Relative softmax mass over at least six leading candidates; not a calibrated probability."


def analyze_tonality(notes: list[NoteEvent], timeline: TrackData, *, top_k: int = 3) -> TonalityAnalysis:
    """Rank global major/minor candidates without re-reading input XML.

    Existing duration/strong-beat, first/end-note, scale/tonic/dominant scoring
    is retained. Signature-only input is reported but supplies NO mode bonus.
    Only an explicitly declared major/minor receives the existing +0.28 bonus.
    Later key changes are preserved as input facts; local modulation is not
    inferred, and a whole-track declaration bonus is disabled across changes.
    """
    if not isinstance(top_k, int) or isinstance(top_k, bool) or not 1 <= top_k <= 24:
        raise ValueError("top_k must be an integer from 1 to 24")
    signatures = timeline.key_signatures
    initial = timeline.initial_key_signature
    warnings: list[str] = []
    if initial is not None:
        if not initial.mode_explicit:
            status = "MODE_OMITTED"
        elif initial.mode is None:
            status = "MODE_EMPTY"
        elif initial.mode not in {"major", "minor"}:
            status = "MODE_UNSUPPORTED"
        elif initial.fifths is None:
            status = "NONTRADITIONAL_SIGNATURE"
        else:
            status = "MODE_EXPLICIT"
    else:
        status = "MODE_EXPLICIT" if timeline.declared_key else "NO_INITIAL_KEY_SIGNATURE"
    explicit = timeline.declared_key
    if explicit is not None:
        explicit = ((explicit[0]+timeline.pitch_transposition_semitones)%12, explicit[1])
    if status in {"MODE_OMITTED", "MODE_EMPTY", "MODE_UNSUPPORTED", "NONTRADITIONAL_SIGNATURE"}:
        warnings.append(f"{status}: no major/minor declaration bonus; infer from melody.")
    initial_fact = (initial.fifths, initial.mode, initial.mode_explicit) if initial else None
    if any((s.fifths,s.mode,s.mode_explicit) != initial_fact for s in signatures if s.start > 1e-9):
        explicit = None
        warnings.append("KEY_SIGNATURE_CHANGES: global declaration bonus disabled; local modulation is not modeled.")
    weighted = [0.0]*12
    if not notes:
        return TonalityAnalysis((),signatures,explicit,status,tuple(weighted),timeline.track_id,0,
            timeline.pitch_transposition_semitones,None,tuple(warnings+["EMPTY_MELODY_EVIDENCE"]))
    end = max(n.start+n.duration for n in notes)
    total = 0.0
    for index,note in enumerate(notes):
        strong = metric.metric_context_at(note.start,timeline).is_strong_beat
        weight = (1.0 if strong else .55)*min(max(note.duration,.25),2.0)
        if index == 0 or note.start+note.duration >= end-1e-6:
            weight += .8
        weighted[note.pitch.midi%12] += weight
        total += weight
    candidates=[]
    for tonic in range(12):
        for mode,intervals in _SCALES:
            scale={(tonic+i)%12 for i in intervals}
            fit=sum(weighted[pc] for pc in scale)/max(total,1e-9)
            tonic_support=weighted[tonic]/max(total,1e-9)
            dominant_support=weighted[(tonic+7)%12]/max(total,1e-9)
            bonus=.28 if explicit==(tonic,mode) else 0.0
            score=fit+.20*tonic_support+.08*dominant_support+bonus
            reasons=(f"scale fit {fit:.6f}",f"tonic support {tonic_support:.6f}",
                     f"dominant support {dominant_support:.6f}",f"explicit declaration bonus {bonus:.2f}")
            candidates.append(KeyCandidate(tonic,mode,f"{_NAMES[tonic]} {mode.title()}",score,
                source="musicxml_key" if bonus else "melody_analysis",scale_fit=fit,
                tonic_support=tonic_support,dominant_support=dominant_support,
                declaration_bonus=bonus,reasons=reasons))
    # Deterministic tie ordering is not an extra major-mode score preference.
    candidates.sort(key=lambda c:(-c.score,c.tonic,c.mode))
    top_score=candidates[0].score
    denom=sum(exp((c.score-top_score)*6.0) for c in candidates[:max(6,top_k)])
    top=[]
    for index,c in enumerate(candidates[:top_k]):
        conflict=()
        if index==0 and explicit and (c.tonic,c.mode)!=explicit:
            conflict=(f"MusicXML key {_NAMES[explicit[0]]} {explicit[1]} conflicts with melody evidence.",)
        top.append(replace(c,confidence=exp((c.score-top_score)*6.0)/denom,warnings=conflict))
    return TonalityAnalysis(tuple(top),signatures,explicit,status,tuple(weighted),timeline.track_id,
        len(notes),timeline.pitch_transposition_semitones,candidates[0].score-candidates[1].score,tuple(warnings))


def write_tonality_analysis(analysis: TonalityAnalysis, path: str | Path) -> Path:
    """Existing diagnostics consume this observer-only JSON, not a new monitor."""
    from gste.version import VERSION
    target=Path(path);target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(json.dumps({"version":VERSION,"stage":"TONALITY_ANALYSIS",**asdict(analysis)},
        ensure_ascii=False,indent=2),encoding="utf-8")
    return target
